   
data1=HUE_6A;
data2=HUE_32A;
figure
           
%            MVAL=max([n11 n22]);
   [t,r] = rose(degtorad(data2'),18); 
ADJ=n22(1)./r(2);
r=r*ADJ;

 h2=compass(n22.*cosd(Center),n22.*sind(Center));
                    set(h2,'Color',[0.1 0.1 0.8],'linewidth',0.1) 
                    hold on

% rMax = MVAL;
% h2 = compass(MVAL, 2);
% set(h2,'Color',[1 1 1],'linewidth',0.001) 

%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t,r);
Cut=1.4;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;
h = patch(Xin2, Yin2, 'w');
alpha(h, 1)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.1 0.1 0.8],'LineStyle',':','Linewidth',1.5);  
                       hold on                                                         

  [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n22.*cosd(Center),n22.*sind(Center),0.99);
     plot(arrowx,arrowy,'Color',[0.1 0.1 0.8],'linewidth',0.75);

deg=0.1;
ang=deg/(2*pi);

[t,r] = rose(degtorad(data1'),18);               %# this does not generate a plot
ADJ=n11(1)./r(2);
r=r*ADJ;
%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t+ang/7,r);
Cut=1.4;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;
h = patch(Xin2, Yin2, 'w');
alpha(h, 1)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.8 0.1 0.1],'LineStyle',':','Linewidth',1.5);  
                       hold on                                                         

  [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n11.*cosd(Center+deg),n11.*sind(Center+deg),0.99);
     plot(arrowx,arrowy,'Color',[0.8 0.1 0.1],'linewidth',0.75);                      
                       
 
text(-65,32,'shCobl','FontName','Times','fontsize',15,'Color',[0.8 0.1 0.1]);
text(-65,38,'shCtrl','FontName','Times','fontsize',15,'Color',[0.1 0.1 0.8]);
% text(-35,21,'Others','FontName','Times','fontsize',15,'Color',[0.5 0.5 0.5]);
       
                                            title('Angular (360) beating direction histogram','FontName','Times','fontsize',20);
                                                                                
                                                ax = gca;
                                                grid off
                                                
                                                        a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','Times','fontsize',10);
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','Times','fontsize',10);

%                                                                                             set(gcf,'PaperPositionMode','auto')
 set(gcf,'PaperPositionMode','auto')
%  export_fig([FR filesep 'Vector_angle9'],'-native', '-a2', '-m4','-q101','-png', '-r600');
                                                        print([FR filesep 'Vector_angle9'], '-dpng', '-r600');
                                                                                        set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters epsFig
  
  
   print([FR filesep 'Vector_angle9'], '-dpdf', '-r300');     
   


 