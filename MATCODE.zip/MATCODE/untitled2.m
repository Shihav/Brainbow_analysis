
    clear all
close all
clc

% Datahome='G:\Marie_Brainbow2\Sélection Shihav\Manip 6\TIFF';
% Reshome='G:\Marie_Brainbow2\Sélection Shihav\Manip 6\IMAGEJ';
% Reshome2='G:\Marie_Brainbow2\Sélection Shihav\Manip 6\MATLAB';

Datahome='/import/pr_ciltex/TEST_BRAINBOW/Tiff';
Reshome='/import/pr_ciltex/TEST_BRAINBOW/Imagej2';
Reshome2='/import/pr_ciltex/TEST_BRAINBOW/Process';

% Datahome='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\Tiff';
% Reshome='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\Imagej2';
% Reshome2='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\Process';
% Reshome3='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\Process2';

% Datahome='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\Tiffv';
% Reshome='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\ImageJ';
% Reshome2='G:\Marie_Brainbow2\Sélection Shihav\Marie_brainbow8\Matlabv';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

for imgid=1:numel(Types)
     
       if imgid==13
    tol=0.045;
    else
        tol=0.065;
      end
    
     filename=Types{imgid};
     filename2=strrep(filename,'.tif',''); 
     mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2');
     info = imfinfo(segname);
        num_images = numel(info);
%         Imgseg=[];
%         for k = 1:num_images
%             I = imread(segname, k);
%               Imgseg(:,:,k)=I;   
%               k
%         end        
           
        oriname=[Datahome filesep filename2 '.tif'];
     
          info = imfinfo(oriname);
        num_images = numel(info);

%         ImgR=[];
%         kn=1;
%         for k = 1:4:num_images
%             I = imread(oriname, k);
%               ImgR(:,:,kn)=I;   
%               kn=kn+1
%         end
        
%         ImgG=[];
%         kn=1;
%         for k = 2:4:num_images
%             I = imread(oriname, k);
%               ImgG(:,:,kn)=I;   
%               kn=kn+1
%         end
        
%         ImgB=[];
%         kn=1;
%         for k = 3:4:num_images
%             I = imread(oriname, k);
%               ImgB(:,:,kn)=I;   
%               kn=kn+1
%         end
        
        ImgGR=[];
        kn=1;
        for k = 4:4:num_images
            I = imread(oriname, k);
              ImgGR(:,:,kn)=I;   
              kn=kn+1
        end
%     ImgGR(Imgsegk2==0)=0;     
% ImgRp=uint16(65535.*(ImgR./4096));
% ImgGp=uint16(65535.*(ImgG./4096));
% ImgBp=uint16(65535.*(ImgB./4096));
ImgGRp=uint16(65535.*(ImgGR./4096));
% 
% [Img11r,zval11r]=max(ImgRp,[],3);
% [Img11g,zval11g]=max(ImgGp,[],3);
% [Img11b,zval11b]=max(ImgBp,[],3);

[Img11gr,zval11gr]=max(ImgGRp,[],3);

% clear ImgRp ImgGp ImgBp ImgGRp

% CO=uint16(65535*mat2gray(cat(3,Img11r,Img11g,Img11b)));
% CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
% COF=CO+0.6*CGO;

imwrite(uint16(65535*mat2gray(Img11gr)),[Reshome2 filesep filename2 filesep filename2 'GRAY2.png']);  

% imwrite(uint16(65535*mat2gray(CO)),[Reshome2 filesep filename2 filesep filename2 'FmaxVpC.png']);  
% 
% imgid
%           
%      ImgR(Imgseg==0)=0;
%      ImgG(Imgseg==0)=0;
%      ImgB(Imgseg==0)=0;
%      ImgGR(Imgseg==0)=0;     
%      
% ImgRk=uint16(65535.*(ImgR./4096));
% ImgGk=uint16(65535.*(ImgG./4096));
% ImgBk=uint16(65535.*(ImgB./4096));
% ImgGRk=uint16(65535.*(ImgGR./4096));
% 
% [Img11r,zval11r]=max(ImgRk,[],3);
% [Img11g,zval11g]=max(ImgGk,[],3);
% [Img11b,zval11b]=max(ImgBk,[],3);
% 
% [Img11gr,zval11gr]=max(ImgGRk,[],3);
% 
% CO=uint16(65535*mat2gray(cat(3,Img11r,Img11g,Img11b)));
% CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
% COF=CO+0.6*CGO;
% 
% imwrite(uint16(65535*mat2gray(COF)),[Reshome2 filesep filename2 filesep filename2 'FmaxV.png']);
% 
% imwrite(uint16(65535*mat2gray(CO)),[Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);
% 
% clear ImgR ImgG ImgB ImgGR
% 
%   pcells=unique(Imgseg);
% Imgsegk=Imgseg;
% Imgsegk(Imgseg==0)=max(pcells)+1;
% Imgsegk=max(pcells)+1-Imgsegk;
% Imgsegk(Imgsegk==max(pcells))=0;
% 
% Imgsegk2=Imgsegk;
% 
% pcells=unique(Imgsegk);
% se=ones(3);
% 
% ImgS=(ImgRk+ImgGk+ImgBk+0.2*ImgGRk)/3.2;
% 
% % if imgid==3
% 
% %          for nk=2:length(pcells)
% %             
% %             val=pcells(nk);   
% % object=Imgsegk==pcells(nk);
% %              Imgsegk2(object)=mean(ImgS(object));                                 
% % nk
% %          end
% % save([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2'); 
% % end
% 
% load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2'); 
% 
% clear Imgsegk Imgseg object objectbor objectcore ImgS
%       
% classmap=max(Imgsegk2,[],3);
%       
% I2cpsegb=classmap>0;
%      T1=im2bw(I2cpsegb);
%                            T2=T1;
%                            T3 = imclearborder(T2);
%                            
% classmap4=classmap; 
% classmap(T3==0)=0;
% pcells=unique(classmap);
% 
%          for nk=2:length(pcells)            
%             val=pcells(nk);            
%             sizek=sum(sum(classmap==val));            
%             if sizek<275
%                 classmap(classmap==val)=0;
%             end
%             nk ;   
%          end
% classmap((T2-T3)==1)=classmap4((T2-T3)==1);         
% classmap2=classmap;
% 
% classmapR=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% classmapG=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% classmapB=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% 
% pcells=unique(classmap2);
% classmapk=classmap2;
% % se=ones(3);
% 
% se1=ones(3);
% se2=ones(7);
% CVA=[];
% CSA=[];
% 
%          for nk=2:length(pcells)
%             
%             val=pcells(nk);
%              object = classmap2==val;
%                               objectcore1 = imerode(object, se1);
%                               objectcore2 = imerode(object, se2);
%                               objectbor=object-objectcore1;
%                             
%                               
%                               RV=quantile(double(Img11r(objectcore2==1)),.5);
%                               GV=quantile(double(Img11g(objectcore2==1)),.5);
%                               BV=quantile(double(Img11b(objectcore2==1)),.5);
%                               GRV=quantile(double(Img11gr(objectcore2==1)),.5);
%                               
%                               
%                               RS=std(double(Img11r(objectcore2==1)));
%                               GS=std(double(Img11g(objectcore2==1)));
%                               BS=std(double(Img11b(objectcore2==1)));
%                               GRS=std(double(Img11gr(objectcore2==1)));
%                               
%                               [CVK,PP]=max([RV GV BV]);
%                                CV=max([RV GV BV]);
%                               SA=[RS GS BS];
%                               CS=SA(PP);
%                               CVA=[CVA; CV];
%                                CSA=[CSA; CS];
%                               
%                               if (CV>3254) && (double(CS)/CV)<.75
%                                   
%                               RV=quantile(Img11r(objectcore2==1),.5);
%                               GV=quantile(Img11g(objectcore2==1),.5);
%                               BV=quantile(Img11b(objectcore2==1),.5);
%                               GRV=quantile(Img11gr(objectcore2==1),.5);
%                                   
%                               classmapR(objectbor==1)=(RV+0.1*GRV)/2;
%                               classmapG(objectbor==1)=(GV+0.1*GRV)/2;
%                               classmapB(objectbor==1)=(BV+0.1*GRV)/2;
%                               
%                               classmapR(objectcore1==1)=RV+0.1*GRV;
%                               classmapG(objectcore1==1)=GV+0.1*GRV;
%                               classmapB(objectcore1==1)=BV+0.1*GRV;
%                               
%                               else
%                                   
%                                   classmapk(classmap2==val)=0;
%                                   
%                               end
%              
% nk;
%          end
%          
%          imgid
%               
%          classmap3=uint16((cat(3,classmapR,classmapG,classmapB)));
% imwrite(uint16(classmap3),[Reshome2 filesep filename2 filesep filename2 'FImap3.png']);
% 
% I2cpsegb=classmapk>0;
%      T1=im2bw(I2cpsegb);
%                            T2=T1;
%                            T3 = imclearborder(T2);
%                            
% classmap4=classmapk; 
% %classmap4(T3==0)=0;
% classmap5=classmap4;
% pcells=unique(classmap4);
% se = ones(5); 
% 
% 
% for nid=2:length(pcells)
%        
%         label = pcells(nid); 
% object = classmap4 == label;
% 
% neighbours = imdilate(object, se) & ~object;
% neighbourLabels = unique(classmap4(neighbours));
% neighbourLabels(1)=[];
% 
% if ~isempty(neighbourLabels)
%     areak=[];
%     for kin=1:length(neighbourLabels)
%     
%     areak(kin)=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));
%     end
%     [areak,kin]=min(areak);
%     
%     block=classmap4==neighbourLabels(kin) | classmap4==label;
%     [X,Y]=find(block==1);
%     
%     [CH,Ak]= convhull(X,Y);
%     
%     
%     R1=mean(classmapR(classmap4==neighbourLabels(kin)))/256;
%     R2=mean(classmapR(classmap4==label))/256;
%     
%         G1=mean(classmapG(classmap4==neighbourLabels(kin)))/256;
%     G2=mean(classmapG(classmap4==label))/256;
%     
%         B1=mean(classmapR(classmap4==neighbourLabels(kin)))/256;
%     B2=mean(classmapR(classmap4==label))/256;
%     
%     CDF=max([abs(R1-R2) abs(G1-G2) abs(B1-B2)]);
%     
%     
%     
%             if ((Ak-areak)/Ak) <tol && CDF<15
% 
%                 classmap5(classmap4==neighbourLabels(kin))=mean([label neighbourLabels(kin)]);
%                  classmap5(classmap4==label)=mean([label neighbourLabels(kin)]);
% 
%                 object2 = classmap4 == neighbourLabels(kin);
%                 middle = imdilate(object2, se) & imdilate(object, se);
%                 classmap5(middle)=mean([label neighbourLabels(kin)]);
%                 
%             end
% end
% 
% end
% 
% classmapk=classmap5;
% I2cpsegb=classmapk>0;
%      T1=im2bw(I2cpsegb);
%                            T2=T1;
%                            T3 = imclearborder(T2);
%                            
% classmap4=classmapk; 
% %classmap4(T3==0)=0;
% classmap5=classmap4;
% pcells=unique(classmap4);
% se = ones(5); 
% 
% 
% for nid=2:length(pcells)
%        
%         label = pcells(nid); 
% object = classmap4 == label;
% 
% neighbours = imdilate(object, se) & ~object;
% neighbourLabels = unique(classmap4(neighbours));
% neighbourLabels(1)=[];
% 
% if length(neighbourLabels)>0
%     areak=[];
%     for kin=1:length(neighbourLabels)
%     
%     areak(kin)=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));
%     end
%     [areak,kin]=min(areak);
%     
%     block=classmap4==neighbourLabels(kin) | classmap4==label;
%     [X,Y]=find(block==1);
%     
%     [CH,Ak]= convhull(X,Y);
%     
%     R1=mean(classmapR(classmap4==neighbourLabels(kin)))/256;
%     R2=mean(classmapR(classmap4==label))/256;
%     
%         G1=mean(classmapG(classmap4==neighbourLabels(kin)))/256;
%     G2=mean(classmapG(classmap4==label))/256;
%     
%         B1=mean(classmapR(classmap4==neighbourLabels(kin)))/256;
%     B2=mean(classmapR(classmap4==label))/256;
%     
%     CDF=max([abs(R1-R2) abs(G1-G2) abs(B1-B2)]);
%     
%     
%     
%             if ((Ak-areak)/Ak) <tol && CDF<15
% 
%                 classmap5(classmap4==neighbourLabels(kin))=mean([label neighbourLabels(kin)]);
%                  classmap5(classmap4==label)=mean([label neighbourLabels(kin)]);
% 
%                 object2 = classmap4 == neighbourLabels(kin);
%                 middle = imdilate(object2, se) & imdilate(object, se);
%                 classmap5(middle)=mean([label neighbourLabels(kin)]);
%                 
%             end
% 
% end
% 
% end
% 
% %classmap5((T2-T3)==1)=classmapk((T2-T3)==1);
% 
% classmapR=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% classmapG=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% classmapB=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% 
% LmapR=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% LmapG=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% LmapB=uint16(65535*ones(size(classmap,1),size(classmap,2)));
% 
% pcells=unique(classmap5);
% 
%          for nk=2:length(pcells)            
%             val=pcells(nk);            
%             sizek=sum(sum(classmap5==val));            
%             if sizek<165
%                 classmap5(classmap5==val)=0;
%             end
%             nk ;   
%          end      
% 
% pcells=unique(classmap5);
% classmapk2=classmap5;
% Finalmap=zeros(size(classmap5));
% % se=ones(3);
% 
% se1=ones(3);
% se2=ones(7);
% 
%          for nk=2:length(pcells)
%             
%             val=pcells(nk);
%              object = classmap5==val;
%                               objectcore1 = imerode(object, se1);
%                               objectcore2 = imerode(object, se2);
%                               objectbor=object-objectcore1;
%                                  
%                               RV=quantile(double(Img11r(objectcore2==1)),.95);
%                               GV=quantile(double(Img11g(objectcore2==1)),.95);
%                               BV=quantile(double(Img11b(objectcore2==1)),.95);
%                               GRV=quantile(double(Img11gr(objectcore2==1)),.95);
%                                   
%                               classmapR(objectbor==1)=RV/2;
%                               classmapG(objectbor==1)=GV/2;
%                               classmapB(objectbor==1)=BV/2;
%                               
%                               classmapR(objectcore1==1)=RV;
%                               classmapG(objectcore1==1)=GV;
%                               classmapB(objectcore1==1)=BV;
% 
%                               LmapR(object)=RV;
%                                 LmapG(object)=GV;
%                                   LmapB(object)=BV;
%                                   
%                                Finalmap(object)=nk-1;   
%                                
% nk;
%          end
% imgid
%   classmap3=uint16((cat(3,classmapR,classmapG,classmapB)));
% imwrite(uint16(classmap3),[Reshome2 filesep filename2 filesep filename2 'FinalmapC.png']);
% imwrite(uint8(Finalmap),[Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
% 
%  Lmap3=uint16((cat(3,LmapR,LmapG,LmapB)));
%  imwrite(uint16(Lmap3),[Reshome2 filesep filename2 filesep filename2 'FLmapC.png']);
%  
%  
% %              h = fspecial('gaussian',[3 3],0.75);
% classmapR2=LmapR;
% classmapR2(Finalmap==0)=65535-Img11gr(Finalmap==0);
% classmapG2=LmapG;
% classmapG2(Finalmap==0)=65535-Img11gr(Finalmap==0);
% classmapB2=LmapB;
% classmapB2(Finalmap==0)=65535-Img11gr(Finalmap==0);
%                     
%  classmap32=uint16((cat(3,classmapR2,classmapG2,classmapB2)));
% imwrite(uint16(classmap32),[Reshome2 filesep filename2 filesep filename2 'FinalmapC2.png']);
%  
%   
end