clear all
close all


m{3}=[2703 1138 2512 504];
m{10}=[1 0 1 0];
m{3}=[3139 785 2245 854];



for sisters=2

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT']);

for idx=[3]
    
    mn=m{idx};
    
loadaddress;

LCOLORG=imread([Reshome3 filesep 'mosaicRAW.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'mosaicRAW.png']);

LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);

AG=LCOLORG;
BG=AG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);

A=remove_line(A,A1);
B=remove_line(B,B1);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO' '.png']);
imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO' '.png']);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG' '.png']);
imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_sym' '.png']);
A=cat(3,A,A,A);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_sym' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_sym' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_sym' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_sym' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_sym' '.png']);

A=remove_line(A,A1);
B=remove_line(B,B1);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_sym' '.png']);
imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_sym' '.png']);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_sym' '.png']);
imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_sym' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_asym' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_asym' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_asym' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_asym' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_asym' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_asym' '.png']);

A=remove_line(A,A1);
B=remove_line(B,B1);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_asym' '.png']);
imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_asym' '.png']);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_asym' '.png']);
imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_asym' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_asym2' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_asym2' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_asym2' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_asym2' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_asym2' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_asym2' '.png']);

A=remove_line(A,A1);
B=remove_line(B,B1);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_asym2' '.png']);
imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_asym2' '.png']);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_asym2' '.png']);
imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_asym2' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_other' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_other' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_other' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_other' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_other' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_other' '.png']);

A=remove_line(A,A1);
B=remove_line(B,B1);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_other' '.png']);
imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_other' '.png']);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_other' '.png']);
imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_other' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RL' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RL' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RL' '.png']);

A1=remove_line(A1,A);
B1=remove_line(B1,B);

imwrite(256*uint16(A1)+uint16(A),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLO' '.png']);
imwrite(256*uint16(B1)+uint16(B),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLO' '.png']);

imwrite(256*uint16(A1)+uint16(A)+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLOG' '.png']);
imwrite(256*uint16(B1)+uint16(B)+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLOG' '.png']);

A2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLW' '.png']);
A2=imresize(A2,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLW' '.png']);
B2=A2(mn(1):size(A2,1)-mn(2),mn(3):size(A2,2)-mn(4),:);
imwrite(B2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLW' '.png']);

A2=remove_line(A2,A);
B2=remove_line(B2,B);

imwrite(256*uint16(A2)+uint16(A),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWO' '.png']);
imwrite(256*uint16(B2)+uint16(B),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWO' '.png']);

imwrite(256*uint16(A2)+uint16(A)+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWOG' '.png']);
imwrite(256*uint16(B2)+uint16(B)+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWOG' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);

B3=B;
A3=A;

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fplus' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fplus' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fplus' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R_P' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R_P' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R_P' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R_N' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R_N' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R_N' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP_P' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP_P' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP_P' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP_N' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP_N' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP_N' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_1' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_1' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_1' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_2' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_2' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_3' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_3' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_3' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_1' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_1' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_1' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_2' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_2' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_3' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_3' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_3' '.png']);


% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  'G' '.png']);

imwrite(B3+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
imwrite(A3+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'mosaicRAW.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  'mosaicRAW' '.png']);



idx

end
end

