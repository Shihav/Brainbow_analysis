DATACM=rgb2hsv(DATA(:,6:8));

SV=quantile(DATACM(:,3),((darkest_cells_cut/100)));

raw4=DATACM(:,3)>=(SV);
select=raw4;
PTDATA=DATA(select==1,:);

PTDATACM=rgb2hsv(PTDATA(:,6:8));

     HUEdist=pdist2(DATACM(:,1)*360,PTDATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),PTDATACM(:,3));
     SPACEdist=pdist2(DATA(:,4:5),PTDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),PTDATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)>0;
     
     


DATA=DATA(select==1,:);

