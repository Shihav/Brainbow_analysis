DATA=ADATA;

DATACM=rgb2hsv(DATA(:,6:8));
% HUE=DATACM(:,1)*360; 

% if SU==1
%     
% SV=SVTH;
%     
% else

   HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
   HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
   Hdist=HUEdist/180;
   Sdist=pdist2(DATACM(:,2),DATACM(:,2))/1;
   Vdist=pdist2(DATACM(:,3),DATACM(:,3))/256;

% Tdist=(mean(Hdist+Vdist)/2)';
Tdist=(mean(1*Hdist+1*Vdist)/2)';
DATA=[DATA Tdist];

SVup=quantile(Tdist,((darkest_cells_cutup/100)));
SVdown=quantile(Tdist,((darkest_cells_cutdown/100)));
%SV=65;
% end

% raw1=HUE>=(360-wd2) | HUE<=(0+wd2);
% raw2=HUE>=(120-wd2) & HUE<=(120+wd2);
% raw3=HUE>=(240-wd2) & HUE<=(240+wd2);
raw4=Tdist<=(SVup) & Tdist>(SVdown);

select=raw4;
DATA=DATA(select==1,:);

ADATA=DATA;

