 close all
 clear all
 load Syn
 % load SynCB
% clc;

figure(1)
val=[];

m = {'-s','-o','-^','-v','-h'};

% col=hsv(5);

col=[200 0 0;
    75 75 200;
    200 150 100;
    150 50 150;
    50 200 50]./255;
resan=zeros(5,5,4);

hn=zeros(5,100);
for kin=2:6
    
    kinid=[12 9 8 11 7];

temp=difhka(:,:,kin);
hn=hn+temp(kinid,:);

end

hn=hn./repmat(sum(hn,2),1,100);
hn(isnan(hn))=0;

for kin=2:6

temp=resa(:,:,kin);

for kin2=1:4

resan(kin-1,:,kin2)=temp(kin2,:);
end
end

resann=zeros(5,5,4);

for kin3=1:4
    A=resan(:,:,kin3);
 An=(A - min(A(:)))/(max(A(:)) - min(A(:)));
 resann(:,:,kin3)=An;
end
s = [12 15 18 21 24];
figure
for k=1:5

    valn=resann(:,k,2);
     valr=resann(:,k,3);
      vals=resann(:,k,4);
      
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     for n=1:5
       ternplot(NMI(n),RMSE(n),SNR(n),m{k},'color',col(k,:),'LineWidth',1.5,'MarkerSize',s(n),'MarkerFaceColor',col(k,:));hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
     end
     ternlabel('NMI', 'RMSE', 'SNR')      
end
%legend('MIP','EOG','SML','EDF','SME');
%axes([0 1]);

% set(gca, 'Ticklength', [0 0])
% xlim([0.5 5.5]) ;set(gca,'XTick',1:5);
% 
% [hleg1, hobj1]=legend('MIP','EOG','SML','EDF','SME','Location','southwest');
% legend('boxoff')
% 
% set(hleg1,'FontSize', 20,'FontName','Times');
% 
% xlabel('Noise increment','FontSize', 22,'FontName','Times');
% ylabel('Combined performance','FontSize', 22,'FontName','Times');
% %title('SYN-CB','FontSize', 30,'FontName','Times');
%    box off;   a = get(gca,'XTickLabel'); set(gca,'XTickLabel',a,'FontName','Times','FontSize', 15,'FontName','Times','FontName','Times'); b = get(gca,'YTickLabel'); set(gca,'YTickLabel',b,'FontName','Times','FontSize', 15,'FontName','Times','FontName','Times');
% 
% % textobj = findobj(hobj1, 'type', 'text');
% % set(textobj, 'Interpreter', 'latex', 'fontsize', 16);
% 
% ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
% %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                                             set(gcf,'PaperPositionMode','auto')
%                                             
%        
title('SYN-CEN');
print(['aPerf_terplot_syn'], '-dpdf', '-r300');
%   
%   
%   set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% % print -dpdf -painters epsFig
%   
%   
%    print(['aPerf_comp_comb2_synCB'], '-dpdf', '-r300');
  
  
   
   