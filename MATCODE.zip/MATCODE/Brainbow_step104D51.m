clear all
close all
clc

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36 .36 .36];

slice=ceil(25./zres)+1

slice1=ceil(2./zres)+1
    javaaddpath 'ij.jar';
    javaaddpath 'mij.jar';
% slice2=ceil(10./zres)+1


for idx=18

loadaddress;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

% for imgid=1:numel(Types)
%      
%      filename=Types{imgid};
%      filename2=strrep(filename,'.tif',''); 
%      mkdir([[Reshome2 filesep filename2]]);
%      mkdir([[Reshome5 filesep filename2]]);
%  
%      segname=[Reshome filesep filename2 '4-Watershed.tif'];
% 
%      info = imfinfo(segname);
%         num_images = numel(info);
%   
%         Imgseg=[];
%         for k = 1:num_images
%             I = imread(segname, k);
%               Imgseg(:,:,k)=I;   
%               k
%         end        
%            
%         oriname=[Datahome filesep filename2 '.tif'];
%      
%           info = imfinfo(oriname);
%         num_images = numel(info);
% 
%         ImgR=[];
%         kn=1;
%         for k = 1:4:num_images
%             I = imread(oriname, k);
%               ImgR(:,:,kn)=I;   
%               kn=kn+1
%         end
%         
%         ImgG=[];
%         kn=1;
%         for k = 2:4:num_images
%             I = imread(oriname, k);
%               ImgG(:,:,kn)=I;   
%               kn=kn+1
%         end
%         
%         ImgB=[];
%         kn=1;
%         for k = 3:4:num_images
%             I = imread(oriname, k);
%               ImgB(:,:,kn)=I;   
%               kn=kn+1
%         end
%         
%         ImgGR=[];
%         kn=1;
%         for k = 4:4:num_images
%             I = imread(oriname, k);
%               ImgGR(:,:,kn)=I;   
%               kn=kn+1
%         end
%            
% ImgR=uint16(ImgR);
% ImgG=uint16(ImgG);
% ImgB=uint16(ImgB);
% ImgGR=uint16(ImgGR);
% 
% [Img11r,zval11r]=max(ImgR,[],3);
% [Img11g,zval11g]=max(ImgG,[],3);
% [Img11b,zval11b]=max(ImgB,[],3);
% [Img11gr,zval11gr]=max(ImgGR,[],3);
% 
% save([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR','-v7.3'); 
% save([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG','-v7.3'); 
% save([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR','-v7.3'); 
% save([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB','-v7.3');  
% 
% save([Reshome2 filesep filename2 filesep filename2 'Imgsegb.mat'],'Imgseg','-v7.3');  
% Imgseg=imdilate(Imgseg,ones(3,3,3));
% 
% save([Reshome2 filesep filename2 filesep filename2 'Imgseg.mat'],'Imgseg','-v7.3');  
% 
% load([Reshome2 filesep filename2 filesep filename2 'Imgseg.mat'],'Imgseg');  
% 
% Imgseg=imdilate(Imgseg,ones(7,7,7));
% save([Reshome5 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg','-v7.3');  
% 
% CO=uint16(65535*mat2gray(cat(3,Img11r,Img11g,Img11b)));
% CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
% COF=CO+0.3*CGO;
% 
% imwrite(uint16(65535*mat2gray(COF)),[Reshome2 filesep filename2 filesep filename2 'FmaxVp.png']);  
% imwrite(uint16(65535*mat2gray(CO)),[Reshome2 filesep filename2 filesep filename2 'FmaxVpC.png']);  
% 
% imgid
%           
% end

% for imgid=1:numel(Types)
%        
%      filename=Types{imgid};
%      filename2=strrep(filename,'.tif','');     
%         oriname=[Datahome filesep filename2 '.tif'];
%          mkdir([[Reshome5 filesep filename2]]);
%     
% load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR'); 
% load([Reshome5 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg');  
% 
% mask=uint16([]);
% for k=1:size(ImgGR,3)
% 
%                    timg=ImgGR(:,:,k); 
%                    h = fspecial('disk',55);
%                    timg2 = imfilter(timg,h,'replicate');
%                     timg2(timg2>(25*255))=(255*255);
%                     mask(:,:,k)=timg2;                                      
% k ;       
% end
% [maskm,zmap]=max(mask,[],3);
% hG = fspecial('gaussian',[45 45],9); 
%     zmap=round(imfilter(zmap,hG,'replicate'));
%                    timg2 = imfilter(timg,h,'replicate');
% 
% imwrite(uint16(256*zmap),[Reshome5 filesep filename2 filesep filename2 'ZMAP.png']); 
%      
%      [Img11r,zval11r]=max(ImgR,[],3);
%      [Img11g,zval11g]=max(ImgG,[],3);
%      [Img11b,zval11b]=max(ImgB,[],3);
%      [Img11gr,zval11gr]=max(ImgGR,[],3);
%      CO=uint16(cat(3,Img11r,Img11g,Img11b));
%      C=CO;
%      imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALLC.png']); 
%      
%      CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
%      COF=CO+1*CGO;
% 
%      imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL.png']);  
%  
%       [~,~,stackR]=FV1_make_projection_from_layer2(ImgR,zmap,25,slice(idx));
%       [~,~,stackG]=FV1_make_projection_from_layer2(ImgG,zmap,25,slice(idx));
%       [~,~,stackB]=FV1_make_projection_from_layer2(ImgB,zmap,25,slice(idx));
%       [~,~,stackGR]=FV1_make_projection_from_layer2(ImgGR,zmap,25,slice(idx));
%       [~,~,ImgsegM]=FV1_make_projection_from_layer2(Imgseg,zmap,25,slice(idx));
%       
%       save([Reshome5 filesep filename2 filesep filename2 'stackR.mat'],'stackR','-v7.3'); 
%       save([Reshome5 filesep filename2 filesep filename2 'stackG.mat'],'stackG','-v7.3');  
%       save([Reshome5 filesep filename2 filesep filename2 'stackB.mat'],'stackB','-v7.3');
%       save([Reshome5 filesep filename2 filesep filename2 'stackGR.mat'],'stackGR','-v7.3');
%       save([Reshome5 filesep filename2 filesep filename2 'ImgsegM.mat'],'ImgsegM','-v7.3');  
%       
%       load([Reshome5 filesep filename2 filesep filename2 'stackR.mat'],'stackR'); 
%       load([Reshome5 filesep filename2 filesep filename2 'stackG.mat'],'stackG');  
%       load([Reshome5 filesep filename2 filesep filename2 'stackB.mat'],'stackB'); 
%       load([Reshome5 filesep filename2 filesep filename2 'stackGR.mat'],'stackGR'); 
%       load([Reshome5 filesep filename2 filesep filename2 'ImgsegM.mat'],'ImgsegM');  
%             
%       [Img11r,zval11r]=max(stackR,[],3);
%       [Img11g,zval11g]=max(stackG,[],3);
%       [Img11b,zval11b]=max(stackB,[],3); 
%       [Img11gr,zval11gr]=max(stackGR,[],3);
%       
%      CO=uint16(cat(3,Img11r,Img11g,Img11b));
%      C=CO;
%      imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALL_AC.png']); 
%      
%      CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
%      COF=CO+1*CGO;
% 
%      imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL_A.png']);  
%      
%        stackR(ImgsegM==0)=0;
%      stackG(ImgsegM==0)=0;
%      stackB(ImgsegM==0)=0; 
%      stackGR(ImgsegM==0)=0; 
%      
%       [Img11r,zval11r]=max(stackR,[],3);
%       [Img11g,zval11g]=max(stackG,[],3);
%       [Img11b,zval11b]=max(stackB,[],3); 
%       [Img11gr,zval11gr]=max(stackGR,[],3);
%       
%       
%       CO=uint16(cat(3,zval11r,zval11g,zval11b));
%       C=CO;
%       imwrite(C*256,[Reshome2 filesep filename2 filesep filename2 'PZPOS.png']); 
%       
%          CO=uint16(cat(3,Img11r,Img11g,Img11b));
%      C=CO;
%      imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALL_FC.png']); 
%      
%      
%      CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
%      COF=CO+1*CGO;
% 
%      imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL_F.png']);  
%      
%      imwrite(uint16(cat(3,Img11gr,Img11gr,Img11gr)),[Reshome5 filesep filename2 filesep filename2 'mosaicG.png']); 
%      
%       load([Reshome5 filesep filename2 filesep filename2 'stackR.mat'],'stackR'); 
%       load([Reshome5 filesep filename2 filesep filename2 'stackG.mat'],'stackG');  
%       load([Reshome5 filesep filename2 filesep filename2 'stackB.mat'],'stackB'); 
%       load([Reshome5 filesep filename2 filesep filename2 'stackGR.mat'],'stackGR');  
% 
%      stackR(ImgsegM>0)=0;
%      stackG(ImgsegM>0)=0;
%      stackB(ImgsegM>0)=0; 
%      stackGR(ImgsegM>0)=0; 
%      
%       [Img11r,zval11r]=max(stackR,[],3);
%       [Img11g,zval11g]=max(stackG,[],3);
%       [Img11b,zval11b]=max(stackB,[],3); 
%       [Img11gr,zval11gr]=max(stackGR,[],3); 
%       
%       CO=uint16(cat(3,zval11r,zval11g,zval11b));
%       C=CO;
%       imwrite(C*256,[Reshome2 filesep filename2 filesep filename2 'NZPOS.png']); 
%       
%          CO=uint16(cat(3,Img11r,Img11g,Img11b));
%      C=CO;
%      imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALL_RC.png']); 
%      
%      CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
%      COF=CO+1*CGO;
% 
%      imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL_R.png']);  
%       
% idx
% imgid
% 
% 
% close all
% 
% end


for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([[Reshome5 filesep filename2]]);
    
      C=imread([Reshome5 filesep filename2 filesep filename2 'ALL_RC.png']); 

imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NOverlayM1.png']); 
C=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM1.png']);

LABELM2=color_segR2(C);

classmap5=LABELM2;
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));
LABELM=classmap5;
LABELM=imerode(LABELM,ones(3,3));

pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=C;                                    
mult=[1 1 1];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'NOverlayM2.png']);  
imwrite(uint16(LABELM),[Reshome2 filesep filename2 filesep filename2 'NFinalmapM.png']);

   LCOLOR5=C;                                    
mult=[1 1 1];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
%                           col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end  
imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'NOverlayM3.png']); 



      C=imread([Reshome5 filesep filename2 filesep filename2 'ALL_FC.png']); 

imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'POverlayM1.png']); 
C=imread([Reshome2 filesep filename2 filesep filename2 'POverlayM1.png']);

LABELM2=color_segR2(C);

classmap5=LABELM2;
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));
LABELM=classmap5;
LABELM=imerode(LABELM,ones(3,3));

pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=C;                                    
mult=[1 1 1];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'POverlayM2.png']);  
imwrite(uint16(LABELM),[Reshome2 filesep filename2 filesep filename2 'PFinalmapM.png']);

   LCOLOR5=C;                                    
mult=[1 1 1];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
%                           col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end  
imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'POverlayM3.png']); 




idx
imgid


close all
% clc
end



for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([Reshome5 filesep 'Mosaic3']);   

     A=imread([Reshome5 filesep filename2 filesep filename2 'ALL.png']);  
     
     imwrite(uint16(A),[Reshome5 filesep 'Mosaic3' filesep 'ALL' num2str(imgid) '.png']);  
      
idx
imgid


close all

end


end