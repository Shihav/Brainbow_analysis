clear all
close all
clc

load rc.mat 'rc'
load countAS.mat 'countAS'
load countA.mat 'countA'
load ZDD.mat symzd asymzd symzdA asymzdA symxd asymxd symyd asymyd
load TQRES.mat infoTA infoQA

DataArray=100*ones(100,4);
DataArray(1:82,1)=symzd(1:2:164);
DataArray(1:86,2)=symzd(165:2:end);
DataArray(1:81,3)=asymzd(1:2:162);
DataArray(1:99,4)=asymzd(163:2:end);

DataArray(DataArray==100)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.4; 0.4 0.9 0.4; 0.4 0.4 0.4];

figure
UnivarScatter(DataArray,'PointSize',12,'Width',.4,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Z distance (\mum)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 4.5])
ylim([0 30])
pbaspect([4,4,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:4,...                         %# Change the axes tick marks
        'XTickLabel',{'Sym E14','Sym E13','Asym E14','Asym E13'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Z DIST SYM_ASYM_E13_E14'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Z DIST SYM_ASYM_E13_E14.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Z DIST SYM_ASYM_E13_E14' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:82,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM E14')

MATN=DataArray(1:86,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM E13')

MATN=DataArray(1:81,3);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM E14')

MATN=DataArray(1:99,4);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM E13')



symzd=sqrt(symxd.^2+symyd.^2+symzd.^2);
asymzd=sqrt(asymxd.^2+asymyd.^2+asymzd.^2);

DataArray=100*ones(100,4);
DataArray(1:82,1)=symzd(1:2:164);
DataArray(1:86,2)=symzd(165:2:end);
DataArray(1:81,3)=asymzd(1:2:162);
DataArray(1:99,4)=asymzd(163:2:end);

DataArray(DataArray==100)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.4; 0.4 0.9 0.4; 0.4 0.4 0.4];

figure
UnivarScatter(DataArray,'PointSize',12,'Width',.4,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['3D distance (\mum)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 4.5])
ylim([0 125])
pbaspect([4,4,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:4,...                         %# Change the axes tick marks
        'XTickLabel',{'Sym E14','Sym E13','Asym E14','Asym E13'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' '3D DIST SYM_ASYM_E13_E14'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' '3D DIST SYM_ASYM_E13_E14.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' '3D DIST SYM_ASYM_E13_E14' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:82,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM E14')

MATN=DataArray(1:86,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM E13')

MATN=DataArray(1:81,3);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM E14')

MATN=DataArray(1:99,4);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM E13')