% function make_projection

clear all;
close all;
clc;
load col;

depthmat(1,1)=0.0057;
% depthmat(1,2)=0.0480530;
depthmat(2,1)=0.0057;
% depthmat(2,2)=0.0600664;
% depthmat(2,3)=0.0480530;
% javaaddpath 'C:\Program Files\MATLAB\R2010a\java\bioformats_package.jar';
javaaddpath 'C:\Program Files\MATLAB\R2010a\java\ij.jar';
javaaddpath 'C:\Program Files\MATLAB\R2010a\java\mij.jar'
MIJ.start;

if strncmp(computer,'PC',2)
    javaaddpath 'C:\Program Files\MATLAB\R2010a\java\bioformats_package.jar';
    home='C:\ENS_CILTEX\PKD1final_codes_results\PKD1';
else  % isunix
    javaaddpath '/import/pr_ciltex/Volume cellule mitose-Shihav/bioformats_package.jar';
    home='/import/pr_ciltex/PKD1final_codes_results/PKD1';
end

condlist={'MT checked','WT checked'};
% mouse='n1';
for condid=[2 1]
    cond=condlist{condid};
dataroot=[home filesep cond filesep];
datarootR=[home filesep cond 'R'];
mkdir(datarootR)
datarootRin=[home filesep cond 'R' filesep];
d=dir(fullfile(dataroot,'*.tif*'));
Types={d.name};


% Types(1:2)=[];

for inj=1:length(Types)

id=[dataroot Types{inj}];
     Im9=Tiff([datarootRin Types{inj} 'channel1WFGM22.tif']);
     Im10=read(Im9);
      Im10=imcomplement(Im10);

                  Im41=uint16(65535*mat2gray(Im10));
                           h = fspecial('disk',3);
                           Im42=imfilter(Im41,h,'replicate');
                           h = fspecial('gaussian',[10 10],3);
                           Im43=imfilter(Im42,h,'replicate');
                           Im44=imcomplement(uint16(65535*mat2gray(im2bw(Im43,0.1))));
%                            [xin,yin]=ind2sub(size(Im4),find(Im44==0));
                           MIJ.createImage(Im44);
                                MIJ.run('Find Maxima...', sprintf('noise=%d output=[Segmented Particles]',1000));
                                Im45 = MIJ.getCurrentImage;
                                Im45=imclearborder(Im45);
                                labeledImage1 = bwlabel(Im45,4);
                                 MIJ.closeAllWindows;
                                 Totalcells=unique(labeledImage1(:));
                                 Im46=65535*mat2gray(max(Im45(:))-Im45);
                                   h = fspecial('gaussian',[3 3],2);
                           Im47=imfilter(Im46,h,'replicate');
                           Im48=uint16(65535*mat2gray(Im47));
%              labeledImage1=Im18;
             col_map_object=zeros(size(Im10));
%                 col_map_objectcore=zeros(size(Im6));
%                       col_map_objectbor=zeros(size(Im6));
                      Area=[];
     se1=ones(2); 
                          for id=2:length(Totalcells)
                              object=[];
                              
                              object = labeledImage1 == Totalcells(id);
                              objectcore = imerode(object, se1);
%                               objectcore2 = imerode(object, se1);
%                               objectbor=object-objectcore2;
                              
%                               Height(id)=round(2*mean(qzr3(object)));

                              NNZpixels=nnz(object);
                              Area(id)=ceil(NNZpixels*depthmat(condid*1));
                              
                              col_map_object(objectcore==1)=Area(id);
%                               col_map_objectcore(objectcore2==1)=Height;
%                               col_map_objectbor(object==1)=Height(id);
                              
                              id
                          end
                          
%                           Heightmap{condid,inj,series}=Height;
                          Areamap{condid,inj}=Area;
                          col_map_object(col_map_object>40)=40;
                          
                          Im6c1=zeros(size(col_map_object));
                           Im6c2=zeros(size(col_map_object));
                            Im6c3=zeros(size(col_map_object));
                      
                          for Ar=1:40
  
                                  Im6c1(col_map_object==Ar)=col(Ar+1,1);
                                  Im6c2(col_map_object==Ar)=col(Ar+1,2);
                                  Im6c3(col_map_object==Ar)=col(Ar+1,3);
                                  
                                  
                              Ar
                          end
                          Im6c=cat(3,Im6c1,Im6c2,Im6c3); 
                          
                           Im488=cat(3,mat2gray(Im48),mat2gray(Im48),mat2gray(Im48));
                          
                          Im6c=uint16(double(Im6c).*(1-Im488));
                          
                          for ind=1:3
                          col_img2a=Im6c(:,:,ind);
                          col_img2a(labeledImage1==0)=0;             
                          Im6c(:,:,ind)=col_img2a;
                          end                          
                          
%                           for ind=1:3
% %                           col_img2a=Im8c(:,:,ind);
%                           col_img2a=Im6c(:,:,ind);
%                           col_img2a(Im41==65535)=0;
% %                           col_img2a(Im12==0)=65535;
%                           
%                           Im6c(:,:,ind)=col_img2a;
% %                           col_img2(:,:,ind)=col_img2(:,:,ind)-double(Im48);
%                           end
%                           
%                           
                          
       imwrite(uint16(Im6c),[datarootRin Types{inj} 'Areamap.png']);  
                       
end
save FV Areamap
end
% end

