   MTYPE={'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h'};
for imgid=worklist  
     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');  
     mkdir([Reshome3 filesep  filename2]);
        
     LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
     
            load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');
        load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');  
        
    for varv=[2];
        
    tDATA=DATA(ID==imgid,:);
    
    RMEAN=[];
    GMEAN=[];
    BMEAN=[];
     RSTD=[];
    GSTD=[];
    BSTD=[];
     RR=[];
    GR=[];
    BR=[];
    
    [Rp,RErrorEst] = polyfit(DATA(:,6),DATA(:,9),3);
        [Gp,GErrorEst] = polyfit(DATA(:,7),DATA(:,10),3);
            [Bp,BErrorEst] = polyfit(DATA(:,8),DATA(:,11),3);

    
    for pn1=1:size(tDATA,1)
        for pn2=1:size(tDATA,1)
                RMEAN(pn1,pn2)=max([tDATA(pn1,6) tDATA(pn2,6)]);
                 GMEAN(pn1,pn2)=max([tDATA(pn1,7) tDATA(pn2,7)]);
                  BMEAN(pn1,pn2)=max([tDATA(pn1,8) tDATA(pn2,8)]);
            
          RSTD(pn1,pn2)=2*min([tDATA(pn1,9) tDATA(pn2,9)]);
                 GSTD(pn1,pn2)=2*min([tDATA(pn1,10) tDATA(pn2,10)]);
                  BSTD(pn1,pn2)=2*min([tDATA(pn1,11) tDATA(pn2,11)]);
                  
                       RR(pn1,pn2)=min([polyval(Rp,tDATA(pn1,6),RErrorEst) polyval(Rp,tDATA(pn2,6),RErrorEst)]);
                 GR(pn1,pn2)=min([polyval(Gp,tDATA(pn1,7),GErrorEst) polyval(Gp,tDATA(pn2,7),GErrorEst)]);
                  BR(pn1,pn2)=min([polyval(Bp,tDATA(pn1,8),BErrorEst) polyval(Bp,tDATA(pn2,8),BErrorEst)]);
        end
    end
    
    RD=pdist2(tDATA(:,6),tDATA(:,6));
    RR=RR.*varv;
    RD(RD>RR)=255;
    RD(RD==0)=254;
    
    GD=pdist2(tDATA(:,7),tDATA(:,7));
    GR=GR.*varv;
    GD(GD>GR)=255;
    GD(GD==0)=254;
    
    BD=pdist2(tDATA(:,8),tDATA(:,8));
    BR=BR.*varv;
    BD(BD>BR)=255;
    BD(BD==0)=254;
    
    DF=RD<255 & GD<255 & BD<255;
    cp=1;
    xyval=[];
    for cp1=1:size(tDATA,1)
        for cp2=1:size(tDATA,1)
            if DF(cp1,cp2)==1
                     xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
                        xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
                         xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
                         xyval(cp,8:9)=[cp1 cp2];
                           xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
                           cp=cp+1;
            end
        end
    end  
   
     CN=1;
    FLAG=zeros(1,size(tDATA,1));
    CS=[];
    for CL=1:size(tDATA,1)
     
        CS(CL)=sum(xyval(:,8)==CL);
        if CS(CL)>1 
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),1:CN);
            
            if sum(FS)==0
            CN=CN+1;
            FLAG(List(FS==0))=CN;
            else

            FLAG(List(FS==0))=mode(FLAG(List(FS==1)));
            end
        else
             FLAG(CL)=1;
        end
  
    end
  
    CT=unique(FLAG);
    
    for loop=CT(2:end)
        
        list=find(ismember(FLAG,loop));
        for ink=1:length(list)
             CS=sum(xyval(:,8)==list(ink));
             if CS<length(list)
                 FLAG(list(ink))=0;
             end
        end     
    end
    
    for CL=find(ismember(FLAG,0));

        CS(CL)=sum(xyval(:,8)==CL);       
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),0);
            
            if sum(FS)>1
            CN=CN+1;
            FLAG(List(FS==1))=CN;
            else

            FLAG(List(FS==1))=1;
            end
    end
    
    for fc=1:length(FLAG)
        
        if sum(FLAG==FLAG(fc))==1
        
        FLAG(fc)=1;
        end
    end
    
     CT=unique(FLAG);
    CTN=[];
     CTNC=[];
    
    for loop=CT
        
        CTN(loop)=sum(FLAG==loop);
          CTNC(loop,:)=mean(tDATA(FLAG==loop,6:8),1);
        
    end
    
    FLAGM=FLAG;
    for fc=1:length(FLAG)
        
        FLAGM(fc)=CTN(FLAG(fc));
    end
    
    save([Reshome3 filesep filename2 filesep filename2 'clusterVV' num2str(varv) '.mat'],'FLAG','CTN','CTNC');  

    CTN
    CTNC=CTNC/50;
    CTNC(CTNC>1)=1;
                 
      m=4;
     Imk2=imresize(LCOLOR4,m);
     Imk22=Imk2;
     
  
   
   CK=xyval(:,5:7)/32;
   CK(CK>1)=1;
   
%      figure
% 
%   imagesc(Imk2);hold on
%      for zin=1:size(xyval,1)       
% %          if  diffval(zin)<0.25      
% 
%    U=m*xyval(zin,4)-m*xyval(zin,2);
%    V=m*xyval(zin,3)-m*xyval(zin,1);
%    Z=sqrt(U.^2+V.^2);   
%   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',CK(zin,:),'maxheadsize',0.05,'linewidth',0.5) ; hold on
% %          end
% 
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VVvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VVvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VVvector_direction_var' num2str(varv) '.png']);
%       close all    
%       imgid
      
%          figure
% %     Imk2=imresize(LCOLOR4,m);
%   imagesc(Imk22);hold on
% 
%      for zin=1:size(center,1)       
%          if center(zin,2)<900
% 
%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% 
%          else         
%                  text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%          end
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VVPvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VVPvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VVPvector_direction_var' num2str(varv) '.png']);
%       close all    
%       imgid
%             
%               figure
% %     Imk2=imresize(LCOLOR4,m);
%   imagesc(Imk22);hold on
% 
%      for zin=1:size(center,1)       
%          if center(zin,2)<900
% 
%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%       
%         if FLAG(zin)>1
%    h=scatter(m*tDATA(zin,5)+20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
%         end
% 
%          else         
%                  text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         if FLAG(zin)>1
%    h=scatter(m*tDATA(zin,5)-20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
%         end
% 
%          end
% 
% %          if FLAGM(zin)==2
% %             
% %             NL=find(ismember(FLAG,FLAG(zin)));
% %             FL=NL(~ismember(NL,zin));
% %             
% %               U=m*tDATA(FL,5)-m*tDATA(zin,5);
% %    V=m*tDATA(FL,4)-m*tDATA(zin,4);
% %    Z=sqrt(U.^2+V.^2);   
% %         
% %           quiver(m*tDATA(zin,5),m*tDATA(zin,4),U,V,0,'color',CTNC(FLAG(zin),:),'maxheadsize',0.025,'linewidth',0.25) ; hold on
% %          end
%          
%              
%          
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VVPMvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VVPMvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VVPMvector_direction_var' num2str(varv) '.png']);
  
  
  
                figure
%     Imk2=imresize(LCOLOR4,m);
  imagesc(Imk22);hold on

     for zin=1:size(center,1)       
         if center(zin,2)<900

%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
      
        if FLAG(zin)>1
   h=scatter(m*tDATA(zin,5)+20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
        end

         else         
%                  text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
        if FLAG(zin)>1
   h=scatter(m*tDATA(zin,5)-20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
        end

         end

         if FLAGM(zin)==2
            
            NL=find(ismember(FLAG,FLAG(zin)));
            FL=NL(~ismember(NL,zin));
            
              U=m*tDATA(FL,5)-m*tDATA(zin,5);
   V=m*tDATA(FL,4)-m*tDATA(zin,4);
   Z=sqrt(U.^2+V.^2);   
        
          quiver(m*tDATA(zin,5),m*tDATA(zin,4),U,V,0,'color',CTNC(FLAG(zin),:),'maxheadsize',0.05,'linewidth',0.5) ; hold on
         end
         
         
         
         
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome3 filesep filename2 filesep filename2 '_VVPMFvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VVPMFvector_direction_var' num2str(varv) '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
  imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VVPMFvector_direction_var' num2str(varv) '.png']);

  
      close all    
      imgid 
      
      
      [HC,NC]=hist(CTN(2:end),[1:9])
      
      
      HC(1)=HC(1)+CTN(1);
      
      if size(NC,1)>size(NC,2)
      
      HC=HC.*NC';
      else
           HC=HC.*NC;
      end
      
      figure
      
      hBar=bar(NC,HC,0.75);
      

colk=[0.5 0.5 0.8; 0.7 1 0.7; 0.6 0.6 0.6; 0.5 0.5 0.5; 0.4 0.4 0.4; 0.3 0.3 0.3; 0.2 0.2 0.2; 0.1 0.1 0.1;0 0 0]/1.2;
                        hBarChildren = get(hBar, 'Children');
                        index = 1:9;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);
                        ylim([0 max(HC)+10])
%                         
                        y=HC;
x=NC;
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.5,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
                        
 set(gca,'XTick',1:9)
 ax = gca;
 set(ax,'XTickLabel',{'S', 'C', '3','4', '5', '6','7', '8', '9'});
  ylim([0 length(FLAG)+1]);                               
                                             
 xlabel('Clustering type','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Cluster count'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  filename2 filesep filename2 'Cluster countVV' num2str(varv) '.png'], '-dpng', '-r300'); 


HCR=zeros(1,9);
NCR=zeros(1,9);
for rtimes=1:RANDN
   RtDATA=DATA(round((size(DATA,1)-1)*rand(size(tDATA,1),1))+1,:);
tDATA=RtDATA;


   RMEAN=[];
    GMEAN=[];
    BMEAN=[];
     RSTD=[];
    GSTD=[];
    BSTD=[];
     RR=[];
    GR=[];
    BR=[];
    
    [Rp,RErrorEst] = polyfit(DATA(:,6),DATA(:,9),3);
        [Gp,GErrorEst] = polyfit(DATA(:,7),DATA(:,10),3);
            [Bp,BErrorEst] = polyfit(DATA(:,8),DATA(:,11),3);

    
    for pn1=1:size(tDATA,1)
        for pn2=1:size(tDATA,1)
                RMEAN(pn1,pn2)=max([tDATA(pn1,6) tDATA(pn2,6)]);
                 GMEAN(pn1,pn2)=max([tDATA(pn1,7) tDATA(pn2,7)]);
                  BMEAN(pn1,pn2)=max([tDATA(pn1,8) tDATA(pn2,8)]);
            
          RSTD(pn1,pn2)=2*min([tDATA(pn1,9) tDATA(pn2,9)]);
                 GSTD(pn1,pn2)=2*min([tDATA(pn1,10) tDATA(pn2,10)]);
                  BSTD(pn1,pn2)=2*min([tDATA(pn1,11) tDATA(pn2,11)]);
                  
                       RR(pn1,pn2)=min([polyval(Rp,tDATA(pn1,6),RErrorEst) polyval(Rp,tDATA(pn2,6),RErrorEst)]);
                 GR(pn1,pn2)=min([polyval(Gp,tDATA(pn1,7),GErrorEst) polyval(Gp,tDATA(pn2,7),GErrorEst)]);
                  BR(pn1,pn2)=min([polyval(Bp,tDATA(pn1,8),BErrorEst) polyval(Bp,tDATA(pn2,8),BErrorEst)]);
        end
    end
    
    
    RD=pdist2(tDATA(:,6),tDATA(:,6));
    RR=RR.*varv;
    RD(RD>RR)=255;
    RD(RD==0)=254;
    
    GD=pdist2(tDATA(:,7),tDATA(:,7));
    GR=GR.*varv;
    GD(GD>GR)=255;
    GD(GD==0)=254;
    
    BD=pdist2(tDATA(:,8),tDATA(:,8));
    BR=BR.*varv;
    BD(BD>BR)=255;
    BD(BD==0)=254;
    
    DF=RD<255 & GD<255 & BD<255;
    cp=1;
    xyval=[];
    for cp1=1:size(tDATA,1)
        for cp2=1:size(tDATA,1)
            if DF(cp1,cp2)==1
                     xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
                        xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
                         xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
                         xyval(cp,8:9)=[cp1 cp2];
                           xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
                           cp=cp+1;
            end
        end
    end   

    
     CN=1;
    FLAG=zeros(1,size(tDATA,1));
    CS=[];
    for CL=1:size(tDATA,1)
     
        CS(CL)=sum(xyval(:,8)==CL);
        if CS(CL)>1 
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),1:CN);
            
            if sum(FS)==0
            CN=CN+1;
            FLAG(List(FS==0))=CN;
            else

            FLAG(List(FS==0))=mode(FLAG(List(FS==1)));
            end
        else
             FLAG(CL)=1;
        end
  
    end
  
    CT=unique(FLAG);
    
    for loop=CT(2:end)
        
        list=find(ismember(FLAG,loop));
        for ink=1:length(list)
             CS=sum(xyval(:,8)==list(ink));
             if CS<length(list)
                 FLAG(list(ink))=0;
             end
        end     
    end
    
    for CL=find(ismember(FLAG,0));

        CS(CL)=sum(xyval(:,8)==CL);       
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),0);
            
            if sum(FS)>1
            CN=CN+1;
            FLAG(List(FS==1))=CN;
            else

            FLAG(List(FS==1))=1;
            end
    end
    
    for fc=1:length(FLAG)
        
        if sum(FLAG==FLAG(fc))==1
        
        FLAG(fc)=1;
        end
    end
    
     CT=unique(FLAG);
    
     
     
    CTN=[];
     CTNC=[];
    
    for loop=CT
        
        CTN(loop)=sum(FLAG==loop);
          CTNC(loop,:)=mean(tDATA(FLAG==loop,6:8),1);
        
    end
    
    FLAGM=FLAG;
    for fc=1:length(FLAG)
        
        FLAGM(fc)=CTN(FLAG(fc));
    end
    
    save([Reshome3 filesep filename2 filesep filename2 'clusterVVR' num2str(varv) '.mat'],'FLAG','CTN','CTNC');  


   [HC,NC]=hist(CTN(2:end),[1:9]);
      
      
      HC(1)=HC(1)+CTN(1);
      
      if size(NC,1)>size(NC,2)
      NC=NC'
      end
           HC=HC.*NC;
      
      HCR=HCR+HC;
      NCR=NCR+NC;
end    
      figure
      NC=round(NCR./rtimes);
      HC=round(HCR./rtimes);
      hBar=bar(NC,HC,0.75);
      

colk=[0.5 0.5 0.8; 0.7 1 0.7; 0.6 0.6 0.6; 0.5 0.5 0.5; 0.4 0.4 0.4; 0.3 0.3 0.3; 0.2 0.2 0.2; 0.1 0.1 0.1;0 0 0]/1.2;
                        hBarChildren = get(hBar, 'Children');
                        index = 1:9;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);
                        ylim([0 max(HC)+10])
%                         
                        y=HC;
x=NC;
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.5,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
                        
 set(gca,'XTick',1:9)
 ax = gca;
 set(ax,'XTickLabel',{'S', 'C', '3','4', '5', '6','7', '8', '9'});
  ylim([0 length(FLAG)+1]);                               
                                             
 xlabel('Clustering type','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Random Cluster count'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  filename2 filesep filename2 'Cluster countVVR' num2str(varv) '.png'], '-dpng', '-r300');  



%                         
  
    end   
%     close all
end

