% clear all
% close all
% 
% clc
PmatA=[]

for idx=[1 2 3 5 7 8]
for cutp=[0]
    
for BTH=[80]



loadaddress;
load([Reshome3 filesep 'BncoupA_' num2str(cutp) '_' num2str(BTH) '.mat'],'ncoupA');  
% load([Reshome3 filesep 'ncoupA.mat'],'ncoupA');  

HTHid=0;
Pmat=[];
Rmat=[];
RRmat=[];
for HTH=[2 3.5 5 6.5]
    HTHid=HTHid+1;
    STHid=0;
for STH=[30 50 70 90]  
    STHid=STHid+1;
%     ncoup=[];

 ncoup=ncoupA{HTHid,STHid};
 
 Rmat(HTHid,STHid)=ncoup(1);
 
 RRmat(HTHid,STHid)=mean(ncoup(2:101));
 
[h,p]=ttest2(ncoup(1),ncoup(2:101)) 

Pmat(HTHid,STHid)=p;


 
end
end

PmatA=[PmatA;Pmat];

   figure() 

mat = Pmat';  
mat2 = Rmat';
mat3 = RRmat';%# A 5-by-5 matrix of random values from 0 to 1
imagesc(mat);            %# Create a colored plot of the matrix values
colormap(bone);
caxis manual
caxis([0 .05])%# Change the colormap to gray (so higher values are
 colorbar                       %#   black and lower values are white)

textStrings = num2str(mat(:),'%10.2e');  %# Create strings from the matrix values
textStrings = strtrim(cellstr(textStrings));
textStrings=strcat('P = ',textStrings);%# Remove any space padding
textStrings2 = num2str(100*mat2(:),'%0.2f');  %# Create strings from the matrix values
textStrings2 = strtrim(cellstr(textStrings2)); 
textStrings2=strcat('DCR = ',textStrings2,'%');%# Remove any space padding
textStrings3 = num2str(100*mat3(:),'%0.2f');  %# Create strings from the matrix values
textStrings3 = strtrim(cellstr(textStrings3));  %# Remove any space padding
textStrings3=strcat('BRCR = ',textStrings3,'%');
[x,y] = meshgrid(1:4,1:4);   %# Create x and y coordinates for the strings
hStrings = text(x(:),y(:)-.25,textStrings(:),...      %# Plot the strings
                'HorizontalAlignment','center','FontSize', 10,'FontName','Times');
hStrings2 = text(x(:),y(:),textStrings2(:),...      %# Plot the strings
                'HorizontalAlignment','center','FontSize', 8,'FontName','Times');
hStrings3 = text(x(:),y(:)+.25,textStrings3(:),...      %# Plot the strings
                'HorizontalAlignment','center','FontSize', 8,'FontName','Times');
midValue = mean(get(gca,'CLim'));  %# Get the middle value of the color range
textColors = repmat(mat(:) < midValue,1,3);  %# Choose white or black for the
                                             %#   text color of the strings so
                                             %#   they can be easily seen over
                                             %#   the background color
set(hStrings,{'Color'},num2cell(textColors,2));
set(hStrings2,{'Color'},num2cell(textColors,2));%# Change the text colors
set(hStrings3,{'Color'},num2cell(textColors,2));%# Change the text colors

set(gca,'XTick',1:4,...                         %# Change the axes tick marks
        'XTickLabel',{'2','3.5','5','6.5'},...  %#   and tick labels
        'YTick',1:4,...
        'YTickLabel',{'30','50','70','90'},...
        'TickLength',[0 0],'FontSize', 15,'FontName','Times');
%  xticklabel_rotate([],45,[],'Fontsize',11)
% RotateXLabel(45,{'K=16','K=17','K=18','K=19','K=20','K=21','K=22','K=23','K=24','K=25'})

% set(gca, 'Ticklength', [0 0])
% ax = gca;
% set(ax,'XTick',1:1:10);
% %   dType = {'11','12','13','14','15','16','17','18','19','20','21','22','23','24','25'};
%     dType = {'16','17','18','19','20','21','22','23','24','25'};
%    set(gca, 'XTickLabel', dType); 
% xlim([0.5 10.5])
% ylim([-0.4 1.05])
% 
%   h1=legend({'Fixel kernel','Adaptive kernel with 10 range','Adaptive kernel with 20 range'}, 'Location', 'southeast'); 
%    set(h1,'FontSize',15);
%    legend('boxoff')
%  grid on

xlabel('Hue threshold (in degrees)','FontSize', 16,'FontName','Times');
ylabel('Distance threshold (in microns)','FontSize', 16,'FontName','Times');

title(['P-map: ' num2str(BTH) ' Value. diff. thres.'],'FontSize', 18,'FontName','Times');

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.7,.7,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
                                 
        print([FINR filesep 'RESULT_M' num2str(idx) filesep num2str(idx) '_BP-Map_' num2str(BTH)], '-dpng', '-r300');
        print([FINR filesep 'RESULT_M' num2str(idx) filesep num2str(idx) '_BP-Map_' num2str(BTH)], '-dpdf', '-r300');
 
%           set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% % print -dpdf -painters epsFig
%   
% 
%    print([Reshome3 filesep 'P-map'], '-dpdf', '-r300');

         



end

end

end

save([FINR filesep 'BP-MapA.mat'],'PmatA');

close all

% load(['G:\Marie_2016_NEW\Combined' filesep 'P-MapA.mat'],'PmatA');
% 
% Box=PmatA(1:45,2:5);
% [A,LS]=min(Box);
% min(PmatA(46:90,2:5))
% min(PmatA(91:135,2:5))
% min(PmatA(181:225,2:5))
% 
% 
% close all