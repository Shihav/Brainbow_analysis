clear all
close all
% 
clc

DD=10;

for idx=[2]
    
    cutp=0
    HTH=6.5
    STH=90
    BTH=80
    
    if cutp==0
        cid=1;
    elseif cutp==25
        cid=2;
    elseif cutp==50
        cid=3;
    elseif cutp==75
        cid=4;
    end

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
load(['DATAB' num2str(idx)],'DTA','DTCMA'); 

DTB=DTA;
DTCMB=DTCMA;

load([Reshome3 filesep 'BncoupA_' num2str(0) '_' num2str(BTH) '.mat'],'ncoupA'); 
ncoupB=ncoupA;

load(['DATAF' num2str(idx)],'DTA','DTCMA'); 

load([Reshome3 filesep 'ncoupA_' num2str(0) '_' num2str(BTH) '.mat'],'ncoupA'); 

ncoup=ncoupA{4,4};
bpcells=size(DATA,1) 


  DATA=DTA{2,1};
    DATACM=DTCMA{2,1};
     DATA(:,6:8)=hsv2rgb(DATACM);

%PLOT_ADJUSTEDR

% ncoupA=[];
ncA=[];
HTHid=0;

    HTHid=HTHid+1;
    STHid=0;
   
    STHid=STHid+1;
%     ncoup=[];
    nc=[];
    
    loopid=328
    
    mkdir([FINR filesep 'RESULT_M' num2str(idx) 'BLINK_RANDF_VIDEO']);
     mkdir([FINR filesep 'RESULT_M' num2str(idx) 'BGLINK_RANDF_VIDEO']);
for loopin=[66:101]
    
figure    
   loopid=loopid+2;
   
  ncoup=ncoupA{4,4};
        [nc,hc]=hist(bpcells*ncoup(:,2:101)',linspace(round(bpcells/4.5),round(bpcells/1.5),101));

 nc=nc/sum(nc);
 hck=hc;
 nck=nc;
       

    nc = smooth(nc,15,'loess');
    nc(nc<0)=0;
    nc=nc./sum(nc);
 
    Colors=[0.5 0.5 0.5];
       
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on

xlim ([round(bpcells/4.5) round(bpcells/1.5)])

       hold on

  ncoup=ncoupB{4,4};     
               [nc,hc]=hist(bpcells*ncoup(:,2:loopin)',linspace(round(bpcells/4.5),round(bpcells/1.5),101));

 nc=nc/sum(nc);
 hck=hc;
 nck=nc;
       

    nc = smooth(nc,15,'loess');
    nc(nc<0)=0;
    nc=nc./sum(nc);
 
    Colors=[0.7 0.1 0.1];
       
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on

xlim ([round(bpcells/4.5) round(bpcells/1.5)])

       hold on
       
       
 Colors=[0.1 0.65 0.1];
hold on

hc=[round(bpcells*ncoup(:,1))'-2.5 round(bpcells*ncoup(:,1))'+2.5];

 if loopin>1
     
%      nc=[max(nc) max(nc)];
     
     nc=[1 1];
     
 else

 nc=[1 1];

 end
       
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on

% x_labels{1} = sprintf('M1\n(%d cells)',bpcells);

ylim([0 .1])
xlim([round(bpcells/4.5) round(bpcells/1.5)])



% set(gca,'XTick',0.5:0.5:1.5,...                         %# Change the axes tick marks
%         'XTickLabel',{'','M2',''},...  %#   and tick labels
%         'TickLength',[0 0],'FontSize', 15,'FontName','Times');


% set(gca,'XTickLabel', {'','',''});
% [hx,hy] = format_ticks(gca,x_labels);
%  xlabel(['Percentage of cells coupled'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label
                                            xlabel(['Number of cells coupled'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label
                                            ylabel(['Probablity'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label

%                                                 set(gca, 'Ticklength', [0 0])
%                                                 ax = gca;
                                                grid off
                                                box off
%                                                 legend('boxoff')

%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([10,6,1])

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     
  
loadaddress;

export_fig([FINR filesep 'RESULT_M' num2str(idx) 'BGLINK_RANDF_VIDEO' filesep 'G_RATIO' num2str(loopin+100)],'-a2', '-m3','-p0.02','-png', '-r300');
close all
clc
    
   DATA=DTB{loopin,cid};
    DATACM=DTCMB{loopin,cid};
    
    DATA(:,6:8)=hsv2rgb(DATACM);
    
    
    
%      PLOT_ADJUSTED
    
%     if loopin==2
%      PLOT_REMOVEDR
%     end
    
    tDATA=DATA;
    
    Bdist=pdist2(DATACM(:,3),DATACM(:,3));

     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     
     SPACEdist=pdist2(DATA(:,4:5),DATA(:,4:5))*.31;
    
%% check conditions    
   Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(Bdist>BTH)=12000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  

        cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
        NBP2=size(D,2);
        idbox1=[1:NBP1];
        idbox2=[1:NBP2];
        Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end               

   xyval(xyval(:,13)>=10000,:)=[];
   
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 nc(loopin)=size(xyval,1);
 
% if loopin==2
 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%  LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
  LCOLORL=imread([Reshome3 filesep 'FOXLM2.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
%  CENTER=imread([Reshome3 filesep 'CENTER.png']);
% LCOLORG(LCOLORL==0)=0; 


% sum(sum(CENTER>0))
 
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
%                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');

                           labeledImage = bwlabel(I2cpsegb>0, 4);
% LCOLORL



CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.75*CO;


%      figure
%      m=1;
%     COF2=imresize(COF,m);
%  imshow(COF2(1:3000,:,:));hold on
% 
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
% 
% export_fig([FINR filesep 'RESULT_M' num2str(idx) 'RANDF_VIDEO' filesep 'Random' num2str(idx) '_frame' num2str(0)],'-a2', '-m4','-p0','-q101','-png', '-r300');
% 
%       close all    

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
     
     if sum(pos(:))<10000
     
     colorA(pos)=LCOLORCA(pos)+(256*DATA(cell,6)-mean(LCOLORCA(pos)));
      colorB(pos)=LCOLORCB(pos)+(256*DATA(cell,7)-mean(LCOLORCB(pos)));
       colorC(pos)=LCOLORCC(pos)+(256*DATA(cell,8)-mean(LCOLORCC(pos)));
     cell;
    
     end
 end
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.75*CO;

  m=1; COF2=imresize(COF,m);
  
  
  G1=uint16(65535*mat2gray(imread([FINR filesep 'RESULT_M' num2str(idx) 'BGLINK_RANDF_VIDEO' filesep 'G_RATIO' num2str(loopin+100) '.png'])));
  
  sft=20;
  COF2(3000-size(G1,1)+1-sft:3000-sft,1+sft:size(G1,2)+sft,:)=G1;
  
  
  
  
     figure
%      m=1;
  imshow(COF2(1:3000,:,:));hold on
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig([FINR filesep 'RESULT_M' num2str(idx) 'BLINK_RANDF_VIDEO' filesep 'Random' num2str(idx) '_frame' num2str(loopid)],'-a2', '-m4','-p0','-q101','-png', '-r300');

      close all    
      
%       end
%  end
      
 figure
     m=1;
  imshow(COF2(1:3000,:,:));hold on
% 
% %     for zin=1:size(tDATA,1)       
% %          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM(zin,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(Connection(zin))],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
% % %           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
% % %           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %      end
%   
     for zin=1:size(xyval,1)   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.75) ; hold on
%          end

     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
% 
export_fig([FINR filesep 'RESULT_M' num2str(idx) 'BLINK_RANDF_VIDEO' filesep 'Random' num2str(idx) '_frame' num2str(loopid+1)],'-a2', '-m4','-p0','-q101','-png', '-r300');


      close all   
      
% end 
end


end