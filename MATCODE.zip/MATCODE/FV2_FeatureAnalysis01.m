clear all
close all

clc

% Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiffv';
% Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\ImageJ';
% Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\MATLAB';

% Datahome='/import/pr_ciltex/TEST_BRAINBOW/Tiff';
% Reshome='/import/pr_ciltex/TEST_BRAINBOW/Imagej2';
% Reshome2='/import/pr_ciltex/TEST_BRAINBOW/Process';

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiff';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Imagej2';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

RAK=[];
GAK=[];
BAK=[];

imgid=1%:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
        
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2'); 
Imgsegk2=uint16(Imgsegk2);
% load([Reshome2 filesep filename2 filesep filename2 'Imgsegk.mat'],'Imgsegk');
load([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB'); 

     ImgR(Imgsegk2==0)=0;
     ImgG(Imgsegk2==0)=0;
     ImgB(Imgsegk2==0)=0;
%      ImgGR(Imgsegk==0)=0;

Img11r=sum(ImgR,3)./sum(Imgsegk2>0,3);
Img11g=sum(ImgG,3)./sum(Imgsegk2>0,3);
Img11b=sum(ImgB,3)./sum(Imgsegk2>0,3);


  
% [Img11r,zval11r]=max(ImgR,[],3);
% [Img11g,zval11g]=max(ImgG,[],3);
% [Img11b,zval11b]=max(ImgB,[],3);
[Img11gr,zval11gr]=max(ImgGR,[],3);

clear ImgGR

FOX=imread([Reshome2 filesep filename2 filesep filename2 'FOXJ1map.png']);
% FOX2=imdilate(FOX>0,ones(3));
Img11gr(FOX==0)=0;
CO=uint8(cat(3,Img11r,Img11g,Img11b));
CGO=uint8(cat(3,Img11gr,Img11gr,Img11gr));
COF=CO+0.3*CGO;

imwrite(uint8(COF),[Reshome2 filesep filename2 filesep filename2 'Ori2.png']);  
imwrite(uint8(CO),[Reshome2 filesep filename2 filesep filename2 'OriC2.png']);  

imwrite(uint8(CGO),[Reshome2 filesep filename2 filesep filename2 'GRAY2.png']); 
LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);

pcells=unique(LABEL);
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABEL == val;
                              objectcore=imerode(object, se);
                              objectbor=(object-objectcore)>0;
                         LABEL(objectbor)=0;
         end

 LABEL = bwlabel(LABEL, 8);
pcells=unique(LABEL);
objectbor_map=zeros(size(LABEL));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABEL == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=CO;                                    
mult=[2 2 4];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;  
                          col_img2a(objectbor_map==1)=255;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint8(Compb),[Reshome2 filesep filename2 filesep filename2 'OverlayM.png']);  


COG=3*rgb2gray(CO);

        Img=imcomplement(COG);
        mean_s=5;

        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=imcomplement(Img2);
        Img8=imcomplement(Img);

        kernel_s=25;

        max3=max(Img3(:));
        min3=min(Img3(:));
        multf=2.5;
        type=16;
        mins=3;
        maxs=5;
        types=linspace(mins,maxs,type);
              Chd= uint16(round(type-1)*mat2gray(Img3))+1;
              Imgn=[];
                   for k=1:type
                  
                      h = fspecial('gaussian',[kernel_s kernel_s],types(k));
                                       Imgn(:,:,k) = imfilter(Img8,h,'replicate');
                   end
              adapt_image=zeros(size(Img8));
              
              for k=1:type
                        temp=Imgn(:,:,k);
                      adapt_image(Chd==k)=temp(Chd==k);
                                  
              end
              
             
pcells=unique(LABEL);
LABELM=uint16(zeros(size(LABEL)));

Imgsegk3=uint16(zeros(size(Imgsegk2)));


ncell=1;
for nk=length(pcells):-1:2            
             val=pcells(nk);          
%             val=23; 

                              object = LABEL == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
               
                adapt_imagek=adapt_image;
                adapt_imagek(object~=1)=0;
                
img =adapt_imagek;
imgN = double(img-min(img(:)))/(max(img(:)-min(img(:))));
% th1=graythresh(imgN);
% th2 = graythresh(imgN(imgN>th1));

% th1=0.25;
th2=0.5;

% cellMsk = imgN>th1;
nucMsk = imgN>th2;
cellMsk=object-nucMsk;

cellMskM=imerode(cellMsk,ones(3));
nucMskM=imerode(nucMsk,ones(3));

% figure,imshow(cellMsk+nucMsk,[])
                
[xx,yy]=ndgrid(-5:5,-5:5);
gf = exp((-xx.^2-yy.^2)/20);
filtImg = conv2(imgN,gf,'same');

% figure,imshow(filtImg,[])

filtImgM = imimposemin(-filtImg,cellMskM | nucMskM); 
filtImgM(filtImgM>=0) = -Inf;

ws = watershed(filtImgM);
ws(~object) = 0;

lblImg = bwlabel(ws);
% figure,imshow(label2rgb(lblImg,'jet','k','shuffle'));
pcellsL=unique(lblImg);

se1=ones(3);
se2=ones(3);

if length(pcellsL)==2
    object2 = lblImg==1;
    
        objectcore1 = imerode(object2, se1);
                                      objectcore2 = imerode(object2, se2);
                                      objectbor=object2-objectcore1;

                                      RV=quantile(double(Img11r(objectcore2==1)),.5);
                                      GV=quantile(double(Img11g(objectcore2==1)),.5);
                                      BV=quantile(double(Img11b(objectcore2==1)),.5);

                                      RS=std(double(Img11r(objectcore2==1)));
                                      GS=std(double(Img11g(objectcore2==1)));
                                      BS=std(double(Img11b(objectcore2==1)));

                                      [CVK,PP]=max([RV GV BV]);
                                       CV=max([RV GV BV]);
                                      SA=[RS GS BS];
                                      CS=SA(PP);
                                          sizek=sum(sum(object2));  

                                      if (CV>3) && (double(CS)/CV)<1 && sizek>275

      object3=imdilate(object2, ones(5));


                                         LABELM(object & object3)=ncell;
%       LABELM(object2)=ncell;
                                 ncell=ncell+1
                                      end
else

        for nk2=2:length(pcellsL)

                val2=pcellsL(nk2);

                     object2 = lblImg==val2;
                                      objectcore1 = imerode(object2, se1);
                                      objectcore2 = imerode(object2, se2);
                                      objectbor=object2-objectcore1;

                                      RV=quantile(double(Img11r(objectcore2==1)),.5);
                                      GV=quantile(double(Img11g(objectcore2==1)),.5);
                                      BV=quantile(double(Img11b(objectcore2==1)),.5);

                                      RS=std(double(Img11r(objectcore2==1)));
                                      GS=std(double(Img11g(objectcore2==1)));
                                      BS=std(double(Img11b(objectcore2==1)));

                                      [CVK,PP]=max([RV GV BV]);
                                       CV=max([RV GV BV]);
                                      SA=[RS GS BS];
                                      CS=SA(PP);
                                          sizek=sum(sum(object2));  

                                      if (CV>5) && (double(CS)/CV)<1 && sizek>275

                                          object3=imdilate(object2, ones(5));


                                         LABELM(object & object3)=ncell;
                                         ncell=ncell+1

                                      end




        end
end
figure
imagesc(LABELM)
figure
imagesc(LABEL>0)
nk
close all
end   



pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=CO;                                    
mult=[2 2 4];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          col_img2a(objectbor_map==1)=255;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint8(Compb),[Reshome2 filesep filename2 filesep filename2 'OverlayM2.png']);  
imwrite(uint16(LABELM),[Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);


LABELM=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);

LABELM3=repmat(LABELM,[1 1 size(Imgsegk2,3)]);
LABELM3B=repmat(LABELM>0,[1 1 size(Imgsegk2,3)]);
Imgsegk3(LABELM3B & Imgsegk2>0)=LABELM3(LABELM3B & Imgsegk2>0);

save([Reshome2 filesep filename2 filesep filename2 'Imgsegk3.mat'],'Imgsegk3'); 

clear Imgsegk2 Imgsegk LABELM3 LABELM3B

mult=[2 2 4];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint8(Compb),[Reshome2 filesep filename2 filesep filename2 'FINALC.png']);  

imgid
pcells=unique(LABELM);
% CA=[];

% ImgR=LCOLOR5(:,:,1);
% ImgG=LCOLOR5(:,:,2);
% ImgB=LCOLOR5(:,:,3);

id=1;
CA=[];
         for nk=[153 151 144 137 169 163 134 126 102 98 60 62 48 46 52 39 18 16]          
            val=nk; 
           
object3d=Imgsegk3==val;
                RA=2*double(ImgR(object3d));
                 GA=2*double(ImgG(object3d));
                  BA=4*double(ImgB(object3d));     
             
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA(id,10:11)=cent;
            
            CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
          id=id+1
         end 
         CA1=CA;
 save([Reshome2 filesep filename2 filesep filename2 'CA1.mat'],'CA1');  
 
COK(:,:,1)=2*CO(:,:,1);
COK(:,:,2)=2*CO(:,:,2);
COK(:,:,3)=4*CO(:,:,3);
 
 
  figure
  imagesc(imresize(COK,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
          num2str(round((CA(zin,6)))) ')'],'FontSize',3,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method1'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method1' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method1' '.png']);
  
    resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method1.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(CA1(:,1:9));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'R mean', 'G mean', 'B mean', 'R median', 'G median', 'B median', 'R std', 'G std', 'B std'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')
  
  
 Imgsegk2B=imerode(Imgsegk3>0,ones(3));
 Imgsegk4=uint16(zeros(size(Imgsegk3)));

Imgsegk4(Imgsegk2B)=Imgsegk3(Imgsegk2B);

clear Imgsegk2B

 

 id=1;
CA=[];
         for nk=[153 151 144 137 169 163 134 126 102 98 60 62 48 46 52 39 18 16]          
            val=nk; 
           
object3d=Imgsegk4==val;
                RA=2*double(ImgR(object3d));
                 GA=2*double(ImgG(object3d));
                  BA=4*double(ImgB(object3d));     
             
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA(id,10:11)=cent;
            
            CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
          id=id+1
         end 
         CA2=CA;
 save([Reshome2 filesep filename2 filesep filename2 'CA2.mat'],'CA2');  
  
  figure
  imagesc(imresize(COK,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
          num2str(round((CA(zin,6)))) ')'],'FontSize',3,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method2'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method2' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method2' '.png']); 
  
  resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method2.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(CA2(:,1:9));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'R mean', 'G mean', 'B mean', 'R median', 'G median', 'B median', 'R std', 'G std', 'B std'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')

  
   id=1;
CA=[];
         for nk=[153 151 144 137 169 163 134 126 102 98 60 62 48 46 52 39 18 16]          
            val=nk; 
           
object3d=Imgsegk3==val;
                 RA=2*double(ImgR(object3d));
                
                RAM=median(RA);
                RAS=std(RA);
                
                RA(RA<(RAM-RAS))=[];
                RA(RA>(RAM+RAS))=[];
                
                 GA=2*double(ImgG(object3d));
                 
                GAM=median(GA);
                GAS=std(GA);
                
                GA(GA<(GAM-GAS))=[];
                GA(GA>(GAM+GAS))=[];
                
                  BA=4*double(ImgB(object3d)); 
                  
                BAM=median(BA);
                BAS=std(BA);
                
                BA(BA<(BAM-BAS))=[];
                BA(BA>(BAM+BAS))=[];
             
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA(id,10:11)=cent;
            
            CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
          id=id+1
         end 
         CA3=CA;
 save([Reshome2 filesep filename2 filesep filename2 'CA3.mat'],'CA3');  
  
  figure
  imagesc(imresize(COK,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
          num2str(round((CA(zin,6)))) ')'],'FontSize',3,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method3'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method3' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method3' '.png']); 
  
  resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method3.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(CA3(:,1:9));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'R mean', 'G mean', 'B mean', 'R median', 'G median', 'B median', 'R std', 'G std', 'B std'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')


   id=1;
CA=[];
         for nk=[153 151 144 137 169 163 134 126 102 98 60 62 48 46 52 39 18 16]          
            val=nk; 
           
object3d=Imgsegk3==val;

AZ=sum(sum(object3d));
[VZ,PZ]=max(AZ);

ImgRt=ImgR(:,:,PZ);
ImgGt=ImgG(:,:,PZ);
ImgBt=ImgB(:,:,PZ);

object = LABELM == val;     

                 RA=2*double(ImgRt(object));
                 GA=2*double(ImgGt(object));
                  BA=4*double(ImgBt(object)); 
                  
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA(id,10:11)=cent;
            
            CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
          id=id+1
         end 
         CA4=CA;
 save([Reshome2 filesep filename2 filesep filename2 'CA4.mat'],'CA4');  
 
  figure
  imagesc(imresize(COK,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
          num2str(round((CA(zin,6)))) ')'],'FontSize',3,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method4'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method4' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method4' '.png']); 
  
  resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method4.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(CA4(:,1:9));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'R mean', 'G mean', 'B mean', 'R median', 'G median', 'B median', 'R std', 'G std', 'B std'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')


ImgGR=ImgR+ImgG+ImgB;

   id=1;
CA=[];
         for nk=[153 151 144 137 169 163 134 126 102 98 60 62 48 46 52 39 18 16]          
            val=nk; 
           
object3d=Imgsegk3==val;
ImgGRt=ImgGR;
ImgGRt(~object3d)=0;

AZ=sum(sum(ImgGRt));
[VZ,PZ]=max(AZ);

ImgRt=ImgR(:,:,PZ);
ImgGt=ImgG(:,:,PZ);
ImgBt=ImgB(:,:,PZ);

object = LABELM == val;     

                 RA=2*double(ImgRt(object));
                 GA=2*double(ImgGt(object));
                  BA=4*double(ImgBt(object)); 
                  
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA(id,10:11)=cent;
            
            CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
          id=id+1
         end 
         CA5=CA;
 save([Reshome2 filesep filename2 filesep filename2 'CA5.mat'],'CA5');  
 
  figure
  imagesc(imresize(COK,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
          num2str(round((CA(zin,6)))) ')'],'FontSize',3,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method5'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method5' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method5' '.png']); 
  
  resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method5.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(CA5(:,1:9));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'R mean', 'G mean', 'B mean', 'R median', 'G median', 'B median', 'R std', 'G std', 'B std'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')

clear ImgGR ImgGRt


%    labeledImage1=LABEL;
%        center=[];
%        cellsL=unique(labeledImage1);
% 
%            for id=2:size(cellsL,1)
%                tag=cellsL(id);
% 
%                                      object = labeledImage1 == tag;
%                             CL=[];         
%                           for ind=1:3
%                           col_img2a=LCOLOR5(:,:,ind);
%                           CL(ind)=mean(col_img2a(object));    
%                           end 
%                                      
%                               s = regionprops(object,'centroid');
%                              cent=s.Centroid;
%                               cent=fliplr(double(round(cent)));
%                               center(id-1,1:2)=cent;
%                             center(id-1,3:5)=CL; 
% %                              center(id-1,1)=id; 
%                            
%            end
%            
% %            center(:,3:5)=CA(:,13:15);
% imgid           
%   save([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');   
  
%   resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];
%     
%     if exist(resfile, 'file')==2
%   delete(resfile);
%     end
%      
%     MATT=[[1:size(center,1)]' center(:,1:2) CA(:,10:12)/16 CA(:,16:18)/16];
%     nps=length(unique(Imgsegk2))-2;
%     
%     clear cell
%     B = cell(size(MATT,1),size(MATT,2));
% for ii=1:size(MATT,1)
%     for jj=1:size(MATT,2)
%   B(ii,jj) = {MATT(ii,jj)};
%     end
% end
% 
%     BK = cell(size(MATT,1),size(MATT,2));
% for ii=1:size(MATT,1)
%     for jj=1:size(MATT,2)
%   BK(ii,jj+3) = {MATT(ii,jj)};
%     end
%       BK(ii,1) = {filename2};
%        BK(ii,2) = {imgid};
%        BK(ii,3) = {nps};
% end
% 
% BKA=[BKA;BK];
% A = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
% C=[A;BK];
% xlswrite(resfile,C,1,'A1') 
      
% end

% AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
% C=[AK;BKA];
%    resfile = [Reshome2 filesep 'Result.xlsx'];
% 
%     if exist(resfile, 'file')==2
%   delete(resfile);
%     end
% 
% xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')
% 
% save([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');    
% % 
% 
%      ImgR(Imgseg==0)=0;
%      ImgG(Imgseg==0)=0;
%      ImgB(Imgseg==0)=0;
%      ImgGR(Imgseg==0)=0;     
%      
% ImgRk=uint16(65535.*(ImgR./4096));
% ImgGk=uint16(65535.*(ImgG./4096));
% ImgBk=uint16(65535.*(ImgB./4096));
% ImgGRk=uint16(65535.*(ImgGR./4096));
% 
% [Img11r,zval11r]=max(ImgRk,[],3);
% [Img11g,zval11g]=max(ImgGk,[],3);
% [Img11b,zval11b]=max(ImgBk,[],3);
% 
% [Img11gr,zval11gr]=max(ImgGRk,[],3);
% 
% CO=uint16(65535*mat2gray(cat(3,Img11r,Img11g,Img11b)));
% CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
% COF=CO+0.3*CGO;
% imwrite(uint16(65535*mat2gray(COF)),[Reshome2 filesep filename2 filesep filename2 'FmaxV.png']);
% 
% imwrite(uint16(65535*mat2gray(CO)),[Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);
