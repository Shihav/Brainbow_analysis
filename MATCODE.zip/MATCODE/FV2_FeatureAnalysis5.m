   MTYPE={'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h'};
for imgid=worklist  
     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');    
     mkdir([Reshome3 filesep  filename2]);
        
     LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
     
            load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');
        load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center'); 
        varid=1;
    for varv=[255*0.025 255*0.05 255*0.1];
        
    tDATA=DATA(ID==imgid,:);
    
    RMEAN=[];
    GMEAN=[];
    BMEAN=[];
     RSTD=[];
    GSTD=[];
    BSTD=[];
    for pn1=1:size(tDATA,1)
        for pn2=1:size(tDATA,1)
                RMEAN(pn1,pn2)=max([tDATA(pn1,6) tDATA(pn2,6)]);
                 GMEAN(pn1,pn2)=max([tDATA(pn1,7) tDATA(pn2,7)]);
                  BMEAN(pn1,pn2)=max([tDATA(pn1,8) tDATA(pn2,8)]);
            
          RSTD(pn1,pn2)=2*min([tDATA(pn1,9) tDATA(pn2,9)]);
                 GSTD(pn1,pn2)=2*min([tDATA(pn1,10) tDATA(pn2,10)]);
                  BSTD(pn1,pn2)=2*min([tDATA(pn1,11) tDATA(pn2,11)]);
        end
    end
    
   
    
    RD=pdist2(tDATA(:,6),tDATA(:,6));
    RD(RD>varv)=255;
    RD(RD==0)=254;
    
    GD=pdist2(tDATA(:,7),tDATA(:,7));
    GD(GD>varv)=255;
    GD(GD==0)=254;
    
    BD=pdist2(tDATA(:,8),tDATA(:,8));
    BD(BD>varv)=255;
    BD(BD==0)=254;
    
    DF=RD<255 & GD<255 & BD<255;
    cp=1;
    xyval=[];
    for cp1=1:size(tDATA,1)
        for cp2=1:size(tDATA,1)
            if DF(cp1,cp2)==1
                     xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
                        xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
                         xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
                         xyval(cp,8:9)=[cp1 cp2];
                           xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
                           cp=cp+1;
            end
        end
    end  
   
     CN=1;
    FLAG=zeros(1,size(tDATA,1));
    CS=[];
    for CL=1:size(tDATA,1)
     
        CS(CL)=sum(xyval(:,8)==CL);
        if CS(CL)>1 
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),1:CN);
            
            if sum(FS)==0
            CN=CN+1;
            FLAG(List(FS==0))=CN;
            else

            FLAG(List(FS==0))=mode(FLAG(List(FS==1)));
            end
        else
             FLAG(CL)=1;
        end
  
    end
  
    CT=unique(FLAG);
    
    for loop=CT(2:end)
        
        list=find(ismember(FLAG,loop));
        for ink=1:length(list)
             CS=sum(xyval(:,8)==list(ink));
             if CS<length(list)
                 FLAG(list(ink))=0;
             end
        end     
    end
    
    for CL=find(ismember(FLAG,0));

        CS(CL)=sum(xyval(:,8)==CL);       
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),0);
            
            if sum(FS)>1
            CN=CN+1;
            FLAG(List(FS==1))=CN;
            else

            FLAG(List(FS==1))=1;
            end
    end
    
    for fc=1:length(FLAG)
        
        if sum(FLAG==FLAG(fc))==1
        
        FLAG(fc)=1;
        end
    end
    
     CT=unique(FLAG);
    CTN=[];
     CTNC=[];
    
    for loop=CT
        
        CTN(loop)=sum(FLAG==loop);
          CTNC(loop,:)=mean(tDATA(FLAG==loop,6:8),1);
        
    end
    
    FLAGM=FLAG;
    for fc=1:length(FLAG)
        
        FLAGM(fc)=CTN(FLAG(fc));
    end
    
    save([Reshome2 filesep filename2 filesep filename2 'Vcluster' num2str(varv) '.mat'],'FLAG','CTN','CTNC');  

    CTN
    CTNC=CTNC/50;
    CTNC(CTNC>1)=1;
                 
      m=4;
     Imk2=imresize(LCOLOR4,m);
     Imk22=Imk2;
     

   
   CK=xyval(:,5:7)/32;
   CK(CK>1)=1;

%      figure
%   imagesc(Imk2);hold on
%      for zin=1:size(xyval,1)       
% %          if  diffval(zin)<0.25      
% 
%    U=m*xyval(zin,4)-m*xyval(zin,2);
%    V=m*xyval(zin,3)-m*xyval(zin,1);
%    Z=sqrt(U.^2+V.^2);   
%   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',CK(zin,:),'maxheadsize',0.05,'linewidth',0.5) ; hold on
% %          end
% 
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_Vvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_Vvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_Vvector_direction_var' num2str(varv) '.png']);
%       close all    
%       imgid
      
%          figure
% %     Imk2=imresize(LCOLOR4,m);
%   imagesc(Imk22);hold on
% 
%      for zin=1:size(center,1)       
%          if center(zin,2)<900
% 
%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% 
%          else         
%                  text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%          end
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VPvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VPvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VPvector_direction_var' num2str(varv) '.png']);
%       close all    
%       imgid
            
%               figure
% %     Imk2=imresize(LCOLOR4,m);
%   imagesc(Imk22);hold on
% 
%      for zin=1:size(center,1)       
%          if center(zin,2)<900
% 
%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%       
%         if FLAG(zin)>1
%    h=scatter(m*tDATA(zin,5)+20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
%         end
% 
%          else         
%                  text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         if FLAG(zin)>1
%    h=scatter(m*tDATA(zin,5)-20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
%         end
% 
%          end
% 
% %          if FLAGM(zin)==2
% %             
% %             NL=find(ismember(FLAG,FLAG(zin)));
% %             FL=NL(~ismember(NL,zin));
% %             
% %               U=m*tDATA(FL,5)-m*tDATA(zin,5);
% %    V=m*tDATA(FL,4)-m*tDATA(zin,4);
% %    Z=sqrt(U.^2+V.^2);   
% %         
% %           quiver(m*tDATA(zin,5),m*tDATA(zin,4),U,V,0,'color',CTNC(FLAG(zin),:),'maxheadsize',0.025,'linewidth',0.25) ; hold on
% %          end
%          
%              
%          
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VPMvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VPMvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VPMvector_direction_var' num2str(varv) '.png']);
  
  
  
                figure
%     Imk2=imresize(LCOLOR4,m);
%CLIST=1;
CLIST=1;
DLIST=[]
  imagesc(Imk22);hold on

     for zin=1:size(center,1)       
         if center(zin,2)<900

         text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
          num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
      
        if FLAG(zin)>1
   h=scatter(m*tDATA(zin,5)+20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
        end

         else         
                 text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
          num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
        if FLAG(zin)>1
   h=scatter(m*tDATA(zin,5)-20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
        end

         end

         if FLAGM(zin)==2
            
            NL=find(ismember(FLAG,FLAG(zin)));
            FL=NL(~ismember(NL,zin));
            
              U=m*tDATA(FL,5)-m*tDATA(zin,5);
   V=m*tDATA(FL,4)-m*tDATA(zin,4);
   Z=sqrt(U.^2+V.^2);  
   DLIST(CLIST)=sqrt((U./m).^2+(V./m).^2); 
    CLIST= CLIST+1;  
    
        
          quiver(m*tDATA(zin,5),m*tDATA(zin,4),U,V,0,'color',CTNC(FLAG(zin),:),'maxheadsize',0.05,'linewidth',0.5) ; hold on
         end
         
     DVlist{imgid,varid}=DLIST;  
     YVlist{imgid,varid}=Y(:);  
         
         
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VPMFvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VPMFvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VPMFvector_direction_var' num2str(varv) '.png']);
  
  export_fig([Reshome3 filesep filename2 filesep filename2 '_VPMFvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VPMFvector_direction_var' num2str(varv) '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
  imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VPMFvector_direction_var' num2str(varv) '.png']);

  
      close all    
      imgid 
      
      
      [HC,NC]=hist(CTN(2:end),[1:7])
      
      
      HC(1)=HC(1)+CTN(1);
      
      if size(NC,1)>size(NC,2)
      
      HC=HC.*NC';
      else
           HC=HC.*NC;
      end
      
       HCO=HC;
      
%       figure
%       
%       hBar=bar(NC,HC,0.75);
%       
% 
% colk=[0.5 0.5 0.8; 0.7 1 0.7; 0.6 0.6 0.6; 0.5 0.5 0.5; 0.4 0.4 0.4; 0.3 0.3 0.3; 0.2 0.2 0.2; 0.1 0.1 0.1;0 0 0]/1.2;
%                         hBarChildren = get(hBar, 'Children');
%                         index = 1:9;
%                         set(hBarChildren, 'CData', index);
%                         colormap(colk);
%                         ylim([0 max(HC)+10])
% %                         
%                         y=HC;
% x=NC;
% for i1=1:numel(y)
%     text(x(i1),y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.5,...
%                'HorizontalAlignment','center',...
%                'VerticalAlignment','bottom')
% end
%                         
%  set(gca,'XTick',1:9)
%  ax = gca;
%  set(ax,'XTickLabel',{'S', 'C', '3','4', '5', '6','7', '8', '9'});
%   ylim([0 length(FLAG)+1]);                                           
%  xlabel('Clustering type','FontSize', 20,'FontName','Times');
%                                             ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Cluster count'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome3 filesep  filename2 filesep filename2 'Cluster countV' num2str(varv) '.png'], '-dpng', '-r300');                        
%  


HCR=zeros(1,7);
NCR=zeros(1,7);
for rtimes=1:RANDN
   RtDATA=DATA(round((size(DATA,1)-1)*rand(size(tDATA,1),1))+1,:);
tDATA=RtDATA;


   RMEAN=[];
    GMEAN=[];
    BMEAN=[];
     RSTD=[];
    GSTD=[];
    BSTD=[];
    for pn1=1:size(tDATA,1)
        for pn2=1:size(tDATA,1)
                RMEAN(pn1,pn2)=mean([tDATA(pn1,6) tDATA(pn2,6)]);
                 GMEAN(pn1,pn2)=mean([tDATA(pn1,7) tDATA(pn2,7)]);
                  BMEAN(pn1,pn2)=mean([tDATA(pn1,8) tDATA(pn2,8)]);
            
          RSTD(pn1,pn2)=min([tDATA(pn1,9) tDATA(pn2,9)]);
                 GSTD(pn1,pn2)=min([tDATA(pn1,10) tDATA(pn2,10)]);
                  BSTD(pn1,pn2)=min([tDATA(pn1,11) tDATA(pn2,11)]);
        
        
        
        end
    end
    
    
    RD=pdist2(tDATA(:,6),tDATA(:,6));
    RD(RD>varv)=255;
    RD(RD==0)=254;
    
    GD=pdist2(tDATA(:,7),tDATA(:,7));
    GD(GD>varv)=255;
    GD(GD==0)=254;
    
    BD=pdist2(tDATA(:,8),tDATA(:,8));
    BD(BD>varv)=255;
    BD(BD==0)=254;
    
    DF=RD<255 & GD<255 & BD<255;
    cp=1;
    xyval=[];
    for cp1=1:size(tDATA,1)
        for cp2=1:size(tDATA,1)
            if DF(cp1,cp2)==1
                     xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
                        xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
                         xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
                         xyval(cp,8:9)=[cp1 cp2];
                           xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
                           cp=cp+1;
            end
        end
    end   

    
     CN=1;
    FLAG=zeros(1,size(tDATA,1));
    CS=[];
    for CL=1:size(tDATA,1)
     
        CS(CL)=sum(xyval(:,8)==CL);
        if CS(CL)>1 
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),1:CN);
            
            if sum(FS)==0
            CN=CN+1;
            FLAG(List(FS==0))=CN;
            else

            FLAG(List(FS==0))=mode(FLAG(List(FS==1)));
            end
        else
             FLAG(CL)=1;
        end
  
    end
  
    CT=unique(FLAG);
    
    for loop=CT(2:end)
        
        list=find(ismember(FLAG,loop));
        for ink=1:length(list)
             CS=sum(xyval(:,8)==list(ink));
             if CS<length(list)
                 FLAG(list(ink))=0;
             end
        end     
    end
    
    for CL=find(ismember(FLAG,0));

        CS(CL)=sum(xyval(:,8)==CL);       
            List=[xyval(ismember(xyval(:,8),CL),9)];
            FS=ismember(FLAG(List),0);
            
            if sum(FS)>1
            CN=CN+1;
            FLAG(List(FS==1))=CN;
            else

            FLAG(List(FS==1))=1;
            end
    end
    
    for fc=1:length(FLAG)
        
        if sum(FLAG==FLAG(fc))==1
        
        FLAG(fc)=1;
        end
    end
    
     CT=unique(FLAG);
    
     
     
    CTN=[];
     CTNC=[];
    
    for loop=CT
        
        CTN(loop)=sum(FLAG==loop);
          CTNC(loop,:)=mean(tDATA(FLAG==loop,6:8),1);
        
    end
    
    FLAGM=FLAG;
    for fc=1:length(FLAG)
        
        FLAGM(fc)=CTN(FLAG(fc));
    end
    
    save([Reshome2 filesep filename2 filesep filename2 'clusterV' num2str(varv) 'R.mat'],'FLAG','CTN','CTNC');  


   [HC,NC]=hist(CTN(2:end),[1:7]);
      
      
      HC(1)=HC(1)+CTN(1);
      
      if size(NC,1)>size(NC,2)
      NC=NC'
      end
           HC=HC.*NC;
      C2count(imgid,2+rtimes,varid)=[HC(2)./size(tDATA,1)];
      HCR=HCR+HC;
      NCR=NCR+NC;
end    
        figure
      
          NC=round(NCR./rtimes);
      HC=round(HCR./rtimes);
      hBar=bar([HCO;HC]',0.75);
      

colk=[0.5 0.5 0.8; 0.7 1 0.7; 0.6 0.6 0.6; 0.5 0.5 0.5; 0.4 0.4 0.4; 0.3 0.3 0.3; 0.2 0.2 0.2];
                        hBarChildren = get(hBar, 'Children');
                        index = 1:1:7;
                        index2 = 8:1:14;
                        colk=[colk;colk/1.75];
                        set(hBarChildren{1}, 'CData', index);
%                         colormap(colk);
                         set(hBarChildren{2}, 'CData', index2);
                        colormap(colk);
                        ylim([0 max(HC)+10])
%                         
                        y=HC;
x=NC;
for i1=1:numel(y)
    text(x(i1)+0.125,y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.5,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end

                        y=HCO;
x=NC;
for i1=1:numel(y)
    text(x(i1)-0.125,y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.5,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
                        
 set(gca,'XTick',1:7)
 ax = gca;
 set(ax,'XTickLabel',{'1', '2', '3','4', '5', '6','7'});
  ylim([0 length(FLAG)+1]);                               
                                             
 xlabel('Clustering type','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Data vs random cluster count'], 'FontSize',24,'FontName','Times') % y-axis label                                          
print([Reshome3 filesep  filename2 filesep filename2 'Cluster countV' num2str(varv) 'R.png'], '-dpng', '-r300');  

C2count(imgid,1:2,varid)=[HCO(2)./size(tDATA,1) HC(2)./size(tDATA,1)];
  varid=varid+1;
    end   
%     close all
end

 save([Reshome2 filesep 'c2countV.mat'],'C2count','DVlist','YVlist');  



%   Pantone = importdata([Reshome2 filesep 'Pantone_list.xlsx']);
% 
% PDATA=Pantone.data.Sheet1(:,2:4);
% 
% figure()
% 
%     valn=PDATA(:,1);
%      valr=PDATA(:,2);
%      vals=PDATA(:,3);
%      val=(valn+valr+vals);
%      NMI=valn./val; 
%      RMSE=valr./val; 
%      SNR=vals./val;      
%      
%     for n=1:size(PDATA,1)
%        ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',PDATA(n,1:3)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',PDATA(n,1:3)./255);hold on; 
%        
%     end
%      ternlabel('RED', 'GREEN', 'BLUE')      
% 
% title('Color distribution Pantone');
% print([Reshome2 filesep 'Color distribution Pantone'], '-dpng', '-r300');  

% [w pc ev] = princomp(COA(:,[10:12])/16);
% 
%  figure()
%  
% %   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
% h=scatter(pc(:,1),pc(:,2),15,DATA(:,5:7)/255,'filled');
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
% xlim([-200 200]);
% ylim([-200 200]);
% 
%   xlabel('PCA component 1','FontSize', 20,'FontName','Times');
%                                             ylabel('PCA component 2', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['PCA of color descriptor'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome2 filesep  'PCA of color descriptor'], '-dpng', '-r300'); 
% 
% 
% [w pc ev] = princomp(PDATA);
% 
%  figure()
%  
% %   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
% h=scatter(pc(:,1),pc(:,2),15,PDATA/255,'filled');
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
% xlim([-200 200]);
% ylim([-200 200]);
%   xlabel('PCA component 1','FontSize', 20,'FontName','Times');
%                                             ylabel('PCA component 2', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['PCA of Pantone'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome2 filesep  'PCA of Pantone'], '-dpng', '-r300'); 
% 
% 
% 
% [w pc ev] = princomp([COA(:,[13:15])/16;PDATA]);
% 
%  figure()
%  
% %   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
% 
% h=scatter(pc(size(COA,1)+1:end,1),pc(size(COA,1)+1:end,2),10,PDATA/255,'filled');hold on;
% h=scatter(pc(1:size(COA,1),1),pc(1:size(COA,1),2),15,[0 0 0],'filled');hold on;
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
% xlim([-200 200]);
% ylim([-200 200]);
%   xlabel('PCA component 1','FontSize', 20,'FontName','Times');
%                                             ylabel('PCA component 2', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['PCA'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome2 filesep  'PCA'], '-dpng', '-r300'); 
% 
% 
% D=5;
% sdiffvalk(diffvalk>D)=[];
% cdiffvalk(diffvalk>D)=[];
% diffvalk(diffvalk>D)=[];
% 
% sdiffvalk=sdiffvalk(1:2:end);
% cdiffvalk=cdiffvalk(1:2:end);
% diffvalk=diffvalk(1:2:end);
% 
% 
% figure
% 
% scatter(sdiffvalk,cdiffvalk)
% 
% h=scatter(cdiffvalk,sdiffvalk,15,[0.1 0.5 0.7],'filled');
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
%  colormap((pink)); 
%  
%  xlim([0 1])
%   ylim([0 1])
%  
%  xlabel('Color distance','FontSize', 20,'FontName','Times');
%                                             ylabel('Spatial distance', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Color Space correlation = ' num2str(corr(cdiffvalk,sdiffvalk))], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome2 filesep  'Color Space correlation'], '-dpng', '-r300'); 

% 
%  figure()
%  
% %   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
% h=scatter(PDATA(:,1),PDATA(:,2),25*(mat2gray(PDATA(:,3))+0.5),PDATA(:,1:3)/255,'filled');
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
% 
%   xlabel('Red','FontSize', 20,'FontName','Times');
%                                             ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Color distribution Pantone 2'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome2 filesep  'Color distribution Pantone 2'], '-dpng', '-r300'); 
% 
% 
%  figure()
%  
% %   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
% h=scatter3(PDATA(:,1),PDATA(:,2),PDATA(:,3),15,PDATA(:,1:3)/255,'filled');
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
% view(38,18)
% 
%   xlabel('Red','FontSize', 20,'FontName','Times');
%                                             ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Color distribution Pantone 3'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print([Reshome2 filesep  'Color distribution Pantone 3'], '-dpng', '-r300'); 

