clear all
close all
% 
clc
% BTH=75;

dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=75;
Bdiff_allowed=80;
Hdiff_allowed=13;
Sdiff_allowed=70;

Hdiff_max=40;
Sdiff_max=140;

% Hdiff_allowed1=15;
% Sdiff_allowed1=75;
% Sdiff_allowed2=100;
load_angle=0;

D_th=2;
T_th=sqrt(2);

wd=0;
wd2=0;

SVTH=100;
SV2=0;

SU=0;
cut=0.99;

sisters=2;
LM=0.75;

nidx=1;
rc=[];
nc=[];

% HTH=10;
% STH=100;
% BTH=80;
% SATH=0.5;

HTH=10;
STH=100;
BTH=100;
SATH=0.33;

DR=0;

Prlist{1}=[];
Prlist{2}=[];
Prlist{3}=[];
Prlist{5}=[];
Prlist{7}=[];
Prlist{8}=[];

Nrlist{1}=[33];
Nrlist{2}=[];
Nrlist{3}=[];
Nrlist{5}=[];
Nrlist{7}=[];
Nrlist{8}=[];

for idx=[1 2 3 5 7 8]
          
loadaddress;
  
load([Reshome2 filesep 'Pall.mat'],'PDATA'); 
PDATA(Prlist{idx},:)=[];

% nc(nidx)=size(PDATA,1);

load([Reshome2 filesep 'Nall.mat'],'NDATA');
NDATA(Nrlist{idx},:)=[];


nc(nidx)=size(PDATA,1);

dmap=pdist2(PDATA(:,4:5),NDATA(:,4:5));
dmapmin=min(dmap);

NDATA((dmapmin<7)',:)=[];

% load([Reshome2 filesep 'all.mat'],'DATA'); 

DATA=PDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multp=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

DATACM=rgb2hsv(DATA(:,6:8));

filter_data;

PSDATA=DATA;
% make_hue_plot2(PSDATA)

% load([Reshome2 filesep 'Nall.mat'],'NDATA'); 

DATA=NDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multn=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

filter_data;

NSDATA=DATA;
% make_hue_plot2(NSDATA);

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
% make_hue_plot2(ADATA);
    
if DR==1
    
PSDATA=ADATA(ADATA(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATA(ADATA(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);

end   

    tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));

    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=1;
     
     ADATA=ADATA(select,:);   
 
 
     tDATA=ADATA;
     tDATACM=rgb2hsv(ADATA(:,6:8));
     DATACM=rgb2hsv(ADATA(:,6:8));
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     
%% check conditions    
%    Costmat=SPACEdist/10+HUEdist;
div=0.5*HTH/STH;

   Costmat=SPACEdist;%HUEdist + SPACEdist*div;
   Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;
                           xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];

                 end  

   xyval(xyval(:,13)>=20000,:)=[];
%    xyval(xyval(:,14)==2 & xyval(:,15)==2,:)=[];
   
if DR==1
    
 tADATA=ADATA(unique(xyval(:,8)),:);

PSDATA=ADATA(ADATA(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATA(ADATA(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_R' '.png']);


  figure
  imshow(COF1+COF2);hold on
  tDATA=PSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
   tDATA=NSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
              text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     for zin=1:size(xyval,1) 
         
         if xyval(zin,14)==1 && xyval(zin,15)==1
             CC=[1 1 1];
         elseif xyval(zin,14)==1 && xyval(zin,15)==2
             CC=[1 1 0];
         elseif xyval(zin,14)==2 && xyval(zin,15)==1
             CC=[1 1 0];  
         elseif xyval(zin,14)==2 && xyval(zin,15)==2
             CC=[0.6 0.6 .9];
         end
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',.75) ; hold on
%   dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
%     text(m*mean([xyval(zin,2) xyval(zin,4)])+1,m*mean([xyval(zin,1) xyval(zin,3)])-1,[char(10) num2str(round(dg))],'FontSize',3,'FontName','Times','Color',[1 1 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');

     end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_RL'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


imp=(xyval(:,14)==1 & xyval(:,15)==1) | (xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1);
xyvals=xyval(imp,:);


if DR==1
    
ADATAS=ADATA(unique(xyvals(:,8:9)),:);

PSDATA=ADATAS(ADATAS(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATAS(ADATAS(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
% imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_R' '.png']);


  figure
  imshow(COF1+COF2+0.2*LCOLORG);hold on
%   tDATA=PSDATA;
%      for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));  
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%      
%    tDATA=NSDATA;
%      for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));  
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
%               text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
     
     for zin=1:size(xyvals,1) 
         
         if xyvals(zin,14)==1 && xyvals(zin,15)==1
             CC=[1 1 1];
         elseif xyvals(zin,14)==1 && xyvals(zin,15)==2
             CC=[1 1 0];
         elseif xyvals(zin,14)==2 && xyvals(zin,15)==1
             CC=[1 1 0];  
         elseif xyvals(zin,14)==2 && xyvals(zin,15)==2
             CC=[0.6 0.6 .9];
         end
         
   U=m*xyvals(zin,4)-m*xyvals(zin,2);
   V=m*xyvals(zin,3)-m*xyvals(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyvals(zin,2),m*xyvals(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',.75) ; hold on
%   dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
%     text(m*mean([xyval(zin,2) xyval(zin,4)])+1,m*mean([xyval(zin,1) xyval(zin,3)])-1,[char(10) num2str(round(dg))],'FontSize',3,'FontName','Times','Color',[1 1 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');

     end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLF'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


SD=sum(xyval(:,14)==1 & xyval(:,15)==1);
AD=sum(xyval(:,14)==1 & xyval(:,15)==2) + sum(xyval(:,14)==2 & xyval(:,15)==1);

rc(nidx,:)=[SD AD];

nidx=nidx+1;


FDATACM=DATACM;
Fxyval=xyval;
FDATA=ADATA;

if load_angle==1
    

AK=[340 10 40 70 100 130 160 190 220 250 280 310 340];
BK=[20 50 80 110 140 170 200 230 260 290 320 350 20];
% xyval=txyval;

for anga=1:length(AK)
    
    close all
    
    DATA=FDATA;
    DATACM=FDATACM;
    xyval=Fxyval;
    HUE=DATACM(:,1)*360;
 if anga==1


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;

 elseif anga==13 


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;

 else
    select=DATACM(:,3)>5 & HUE>=AK(anga) & HUE<BK(anga);
 end
 
DATAz=DATA(select,:);
DATACMz=DATACM(select,:);
%  make_hue_plot(DATAz,DATACMz)
 
 cells1=find(select==1);
 linefrom=ismember(xyval(:,8),cells1);
 
DATAz=DATA(cells1,:);
DATACMz=DATACM(cells1,:);
%  make_hue_plot(DATAz,DATACMz)
 
 
 cells2=unique(xyval(linefrom,9));
 
   DATAz=DATA(cells2,:);
DATACMz=DATACM(cells2,:);
%  make_hue_plot(DATAz,DATACMz)
 
 cells=unique([cells1;cells2]);
 
 linefrom1=ismember(xyval(:,8),cells);
 linefrom2=ismember(xyval(:,9),cells);
 linefrom=linefrom1 | linefrom2;
 
 xyval=xyval(linefrom==1,:);
 
 
DATA=DATA(cells,:);
DATACM=DATACM(cells,:);

DATAk=DATA;
DATACMk=DATACM;

ADATA=DATA;

% make_hue_plot(DATAk,DATACMk)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'angHUE' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');

PSDATA=ADATA(ADATA(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATA(ADATA(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
% imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_R' '.png']);


  figure
  imshow(COF1+COF2);hold on
  tDATA=PSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
   tDATA=NSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
              text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     for zin=1:size(xyval,1) 
         
         if xyval(zin,14)==1 && xyval(zin,15)==1
             CC=[1 1 1];
         elseif xyval(zin,14)==1 && xyval(zin,15)==2
             CC=[1 1 0];
         elseif xyval(zin,14)==2 && xyval(zin,15)==1
             CC=[1 1 0];  
         elseif xyval(zin,14)==2 && xyval(zin,15)==2
             CC=[0.6 0.6 .9];
         end
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',.75) ; hold on
%   dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
%     text(m*mean([xyval(zin,2) xyval(zin,4)])+1,m*mean([xyval(zin,1) xyval(zin,3)])-1,[char(10) num2str(round(dg))],'FontSize',3,'FontName','Times','Color',[1 1 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');

     end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
  

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'ZLINK_idx' num2str(idx) 'ang' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');

end

end

close all
end


myC= [0.5 0.8 0.5;
    0.8 0.8 0.8];



figure

H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');

HR= rc./repmat(sum(rc,2),[1 2]);

% mn=sum(HR(:,1).*nc')/sum(nc);

mn=sum(rc(:,1))/sum(rc(:));

% mn=mean(HR(:,1));

% mn=sum(HR(:,1).*sum(rc,2))/sum(sum(rc,2));




for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 20,'FontName','times') % y-axis label

title(['Symmetric division rate = ' num2str(mn,'%0.2f') '%'],'FontSize', 20,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([8,6,1])

 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     




export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'CELL_DIST3'],'-a2', '-m6','-p0.02','-png', '-r600');



figure

rc(:,2)=rc(:,2)/2;

H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');

HR= rc./repmat(sum(rc,2),[1 2]);

% mn=sum(HR(:,1).*nc')/sum(nc);

mn=sum(rc(:,1))/sum(rc(:));

% mn=mean(HR(:,1));

% mn=sum(HR(:,1).*sum(rc,2))/sum(sum(rc,2));




for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 20,'FontName','times') % y-axis label

title(['Origin from symmetric division = ' num2str(mn,'%0.2f') '%'],'FontSize', 20,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([8,6,1])

 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     




export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'CELL_DIST4'],'-a2', '-m6','-p0.02','-png', '-r600');




close all;



