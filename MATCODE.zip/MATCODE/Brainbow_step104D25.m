clear all
close all

COLORA=[];

for idx=[1 2 3 5 7 8]
    
    loadaddress;
     
load([Reshome2 filesep 'Pall2.mat'],'PDATA'); 
PDATA=PDATA(:,1:11);
COLORA=[COLORA;PDATA];

load([Reshome2 filesep 'Nall2.mat'],'NDATA'); 
NDATA=NDATA(:,1:11);
COLORA=[COLORA;NDATA];

end




RMATA=[];


PMAT=[];

HID=0;

SID=1;
for MRL=[1:101]
    
    HID=HID+1;

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

ftype=7;

DRF=0; %% plot filtering steps
DRS=0; %% plot selected cells
DR=0; %% make final link plot
DH=0; %% draw hue plot
GL=0.2; %% Gray image weight


DRAP=0; %% make all plots
MPL=0; %% make post links

singles=0;

CPL=1; %% Allowed number of unique min colored cells

cr=0;

MAT=[];

symd=[];
asymd=[];

symhd=[];
asymhd=[];

for sisters=2
LM=1;

nidx=1;
rc=[];
rcp=[];
nc=[];

HTH=10;
STH=100;
BTH=100;
SATH=0.33;

ts=0;
tm=0;

OLDIST=7;

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);

final_remove_list;

for idx=[1 2 3 5 7 8]
    
    xyvalAR=[];
    ADATAAR=[];
    xyvalsAR=[];
    ADATASAR=[];
    ADATALA=[];
       
    loadaddress;
  
load([Reshome2 filesep 'Pall2.mat'],'PDATA'); 
PDATA=PDATA(:,1:11);
PDATA(Prlist{idx},:)=[];

load(['FOX' num2str(idx)],'centerF'); 
SPACE=min((pdist2(centerF(:,1:2),PDATA(:,4:5))*.31),[],2);
centerF(SPACE>100,:)=[];

if MRL>1 
ridp=randperm(size(PDATA,1));
ridcp=randperm(size(COLORA,1));
ridcf=randperm(size(centerF,1));
end

load([Reshome2 filesep 'Nall2.mat'],'NDATA');
NDATA=NDATA(:,1:11);
NDATA(Nrlist{idx},:)=[];

if MRL>1 
ridn=randperm(size(NDATA,1));
ridcn=randperm(size(COLORA,1));
end
      
if MRL>1
RMATA{MRL,idx,1}=ridp;
RMATA{MRL,idx,2}=ridcp;
RMATA{MRL,idx,3}=ridn;
RMATA{MRL,idx,4}=ridcn;
RMATA{MRL,idx,5}=ridcf;
end
    
for darkest_cells_cutid=1:length(darkest_cells_cutupA) 
    
    darkest_cells_cutup=darkest_cells_cutupA(darkest_cells_cutid);
    darkest_cells_cutdown=darkest_cells_cutdownA(darkest_cells_cutid);
             
loadaddress;
  
load([Reshome2 filesep 'Pall2.mat'],'PDATA'); 
PDATA=PDATA(:,1:11);
PDATA(Prlist{idx},:)=[];
PDATAB=PDATA;

if MRL>1 
PDATA=[PDATA(ridp,1:3) centerF(ridcf(1:size(PDATA,1)),1:2)  COLORA(ridcp(1:size(PDATA,1)),6:end)];
end

load([Reshome2 filesep 'Nall2.mat'],'NDATA');
NDATA=NDATA(:,1:11);
NDATA(Nrlist{idx},:)=[];

rshift=(rand(size(NDATA,1),2)*200/.31) - 100/.31;

if MRL>1 
NDATA=[NDATA(ridn,1:3) NDATA(ridn,4:5)+rshift COLORA(ridcn(1:size(NDATA,1)),6:end)];
end

nc(nidx)=size(PDATA,1);

dmap=pdist2(PDATA(:,4:5),NDATA(:,4:5));
dmapmin=min(dmap);

NDATA((dmapmin<OLDIST)',:)=[];
NDATAB=NDATA;

MAT(idx,1)=size(PDATAB,1);
MAT(idx,2)=size(NDATAB,1);

DATA=PDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multp=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

tests=[DATA(:,6:8)./DATA(:,9:11)];
testm=DATA(:,6:8);
select=max(tests,[],2)>ts & max(testm,[],2)>tm;
DATA=DATA(select==1,:);

PDATABB=DATA;

if ftype==5
filter_data5;
elseif ftype==6
filter_data6;
end
PSDATA=DATA;

DATA=NDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multn=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

tests=[DATA(:,6:8)./DATA(:,9:11)];
testm=DATA(:,6:8);
select=max(tests,[],2)>ts & max(testm,[],2)>tm;
DATA=DATA(select==1,:);

NDATABB=DATA;

if ftype==5
filter_data5;
elseif ftype==6
filter_data6;
end
NSDATA=DATA;

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
ADATAB=[PDATABB;NDATABB];

if ftype==7
filter_data7;
end

if DRF==1    
BMAKE_FILTERED_PLOT2;
end   

    tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=CPL;
     
     if singles==1
     select1=sum(PC,2)==1 & tDATA(:,1)==1;
     select=select | select1;
     end
     
     
     
     ADATA=ADATA(select,:);  
     
     NSDATA=ADATA(ADATA(:,1)==2,:);
     PSDATA=ADATA(ADATA(:,1)==1,:);
% if MRL>1     
%      rid=randperm(size(PDATAB,1));
% PSDATA=[PDATAB(rid(1:size(PSDATA,1)),1:5) PSDATA(:,6:end)];
% 
%     rid=randperm(size(NDATAB,1));
% NSDATA=[NDATAB(rid(1:size(NSDATA,1)),1:5) NSDATA(:,6:end)];
% 
% 
% %      rid=randperm(size(PSDATA,1));
% % PSDATA=[PSDATA(rid(1:size(PSDATA,1)),1:5) PSDATA(:,6:end)];
% % 
% %     rid=randperm(size(NSDATA,1));
% % NSDATA=[NSDATA(rid(1:size(NSDATA,1)),1:5) NSDATA(:,6:end)];
% 
% NSDATA(:,1)=2;
% ADATA=[PSDATA;NSDATA];
% end
     
 
     tDATA=ADATA;
     tDATACM=rgb2hsv(ADATA(:,6:8));
     DATACM=rgb2hsv(ADATA(:,6:8));
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     
%% check conditions    
%    Costmat=SPACEdist/10+HUEdist;
div=HTH/STH;

% %   Costmat=SPACEdist;%HUEdist + SPACEdist*div;
   if sisters <4
   Costmat=1*HUEdist + SPACEdist*0;
   
   else
%     HUEdist(SPACEdist<(STH/2))=SPACEdist(SPACEdist<(STH/2));
    Costmat=0*HUEdist + SPACEdist*1;
   end
   Costmat1 = diag(diag(Costmat)+1);
   
   Costmat(Costmat1>0)=20000;
%    Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
%    Costmat(SPACEdist<=(STH/4) & Costmat<20000)=SPACEdist(SPACEdist<=(STH/4) & Costmat<20000)/STH;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;
                           xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];
                            xyval(cp,16:17)=[tDATA(Aida(cp,1),12) tDATA(Aida(cp,2),12)];
                 end  
   xyval(xyval(:,13)>=20000,:)=[];
%    xyval(xyval(:,14)==2 & xyval(:,15)==2,:)=[];

imp=(xyval(:,14)==1 & xyval(:,15)==1) | (xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1);
xyvals=xyval(imp,:);
ADATAS=ADATA(unique(xyvals(:,8:9)),:);

ADATAL=ADATA;
ADATAL(unique(xyvals(:,8:9)),:)=[];

xyvalAR=[xyvalAR;xyval];
ADATAAR=[ADATAAR;ADATA];
ADATASAR=[ADATASAR;ADATAS];
xyvalsAR=[xyvalsAR;xyvals];
ADATALA=[ADATALA;ADATAL];


end



if MPL==1
    MAKE_POST_LINK
end



% if MRL>1
%     MAKE_RAND_LINK
% end




MAT(idx,3)=size(ADATAAR(ADATAAR(:,1)==1,:),1);
MAT(idx,4)=size(ADATAAR(ADATAAR(:,1)==2,:),1);

if DH==1
make_hue_plot2(ADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2(ADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

xyval=xyvalAR;
ADATA=ADATAAR;

if DRS==1
    BMAKE_SELECTED_PLOT;
end

xyval=xyvalAR;
ADATA=ADATAAR;

xyvals=xyvalsAR;
ADATAS=ADATASAR;

if DR==1
    BMAKE_FINAL_PLOT2;
end

SD=sum(xyval(:,14)==1 & xyval(:,15)==1);
AD=sum(xyval(:,14)==1 & xyval(:,15)==2) + sum(xyval(:,14)==2 & xyval(:,15)==1);
rc(nidx,:)=[SD AD];

SDP=xyval((xyval(:,14)==1 & xyval(:,15)==1),16:17);
ADP=xyval((xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1),16:17);
rcp(nidx,:)=[sum(SDP(:)) sum(ADP(:))];

SDP=xyval((xyval(:,14)==1 & xyval(:,15)==1),[1:4 13]);
ADP=xyval((xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1),[1:4 13]);

SDPD=mean(sqrt((SDP(:,1)-SDP(:,3)).^2+(SDP(:,2)-SDP(:,4)).^2)*.31);
ADPD=mean(sqrt((ADP(:,1)-ADP(:,3)).^2+(ADP(:,2)-ADP(:,4)).^2)*.31);

symd=[symd; sqrt((SDP(:,1)-SDP(:,3)).^2+(SDP(:,2)-SDP(:,4)).^2)*.31];
asymd=[asymd; sqrt((ADP(:,1)-ADP(:,3)).^2+(ADP(:,2)-ADP(:,4)).^2)*.31];


SDPHD=mean(SDP(:,5));
ADPHD=mean(ADP(:,5));

symhd=[symhd; SDP(:,5)];
asymhd=[asymhd; ADP(:,5)];



MAT(idx,19:20)=[SDPD ADPD];

MAT(idx,22:23)=[SDPHD ADPHD];

MAT(idx,5)=size(xyval,1)/2;
MAT(idx,6)=SD/2;
MAT(idx,7)=AD/2;
MAT(idx,8)=sum(xyval(:,14)==2 & xyval(:,15)==2)/2;

% MD=double(imread([FINR filesep 'DISTANCE MAP' num2str(idx) '.png']))/64;
% ADATALAP=ADATALA(ADATALA(:,1)==1,:);
% ttDATA=ADATALAP;
% 
% distt=[];
% for lin=1:size(ttDATA,1)
%     distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;
% end
% 
% SB=sum(distt<=((STH+25)/1));
% SC=size(ttDATA,1)-SB;
% S=size(ttDATA,1);
% 
% MAT(idx,9:11)=[S SB SC];
% 
% ADATALAN=ADATALA(ADATALA(:,1)==2,:);
% ttDATA=ADATALAN;
% 
% distt=[];
% for lin=1:size(ttDATA,1)
%     distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;
% end
% 
% SB=sum(distt<=((STH+25)/1));
% SC=size(ttDATA,1)-SB;
% S=size(ttDATA,1);
% 
% MAT(idx,12:14)=[S SB SC];
% 
% 
% load(['FOX' num2str(idx)],'centerF'); 
% 
% distt=[];
% for lin=1:size(centerF,1)
%     distt(lin)=MD(centerF(lin,1),centerF(lin,2))*.31;
% end
% 
% FP=sum(distt<=((STH+25)/1));
% 
% MAT(idx,15)=[FP];
% 
% ttDATA=PDATABB;
% 
% distt=[];
% for lin=1:size(ttDATA,1)
%     distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;
% end
% 
% BFP=sum(distt<=((STH+25)/1));
% 
% MAT(idx,17)=[BFP];

nidx=nidx+1;

FDATACM=DATACM;
Fxyval=xyval;
FDATA=ADATA;

if load_angle==1
    BMAKE_ANGULAR_PLOT
end

close all
end

if DRAP==1

BRAINBOW_FINAL_PLOT

end

end

TL=sum(rc(:))/2;

PMAT(HID,SID,1)=(sum(rcp(:))/2)
PMAT(HID,SID,2)=TL
PMAT(HID,SID,3)=(sum(rcp(:))/2)/TL

mn=sum(rc(:,1))/sum(rc(:));
PMAT(HID,SID,4)=mn

rck=[rc(:,1) rc(:,2)/2];
mn=sum(rck(:,1))/sum(rck(:));

PMAT(HID,SID,5)=mn

MRL
end

save PMATRAND.mat PMAT

save RMATA RMATA