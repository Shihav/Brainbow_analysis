%  close all;clear all;
%  load RMN5;
 [d1,d2,d3]=size(RMN);
figure(1)
val=[];
m = {'-s','-o','-^','-v','-h'};
col=[200 0 0;
    75 75 200;
    200 150 100;
    150 50 150;
    50 200 50]./255;
resan=zeros(3,5,4);
resan(:,:,2)=RMN(:,[12 9 8 11 7],1);
resan(:,:,3)=RMN(:,[12 9 8 11 7],3);
resan(:,:,4)=RMN(:,[12 9 8 11 7],2);

resann=zeros(3,5,4);

for kin3=1:4
    A=resan(:,:,kin3);
 An=(A - min(A(:)))/(max(A(:)) - min(A(:)));
 resann(:,:,kin3)=An;
end
s = [24 18 12];
for k=1:5
    valn=resann(:,k,2);
     valr=1-resann(:,k,3);
     vals=resann(:,k,4);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     for n=1:3
       ternplot(NMI(n),RMSE(n),SNR(n),m{k},'color',col(k,:),'LineWidth',1.5,'MarkerSize',s(n),'MarkerFaceColor',col(k,:));hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
     end
     ternlabel('NMI', 'RMSE', 'SNR')      
end
title('SYN-Tissue');
print(['aPerf_terplot_synTissue'], '-dpdf', '-r300');
print(['aPerf_terplot_synTissue'], '-dpng', '-r300');