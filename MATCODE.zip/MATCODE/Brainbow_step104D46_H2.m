clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36 .36 .36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);
mkfig=0;
countAS=[];
xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14)]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\HUE' ]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF' ]);
% m=1;
m{3}=[3139 785 2245 854];
m{10}=[1 0 1 0];
multa(10,:)=multa(3,:);
count=[];
for idx=[1 2 3 5 7 8 11 12 13 14 15 16 17 18]
    
    mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF\HUE\' 'M' num2str(pool(idx))]);
      mn=[1 0 1 0];  
     if idx==7
     LW=0.2;
     elseif idx==11
     LW=0.2;
     elseif idx==10
     LW=2;
     elseif idx==12
     LW=0.8;
     else
     LW=0.4;
     end
     
        if idx==10
     LW2=.5*LW;
        else
     LW2=2*LW;
        end
     
     
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB','valAT','valAQ','LINKA'); 


if idx==10
    nk=m{3};
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(3) 'ang' num2str(14)  'CG' '.png']); 
AG=LCOLORG;
LCOLORG=LCOLORG(nk(1):size(AG,1)-nk(2),nk(3):size(AG,2)-nk(4),:);
elseif idx>10
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
else
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
end
AG=LCOLORG;
LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

% count(1,1)=size(PDATABB,1);
% count(1,2)=size(NDATABB,1);
select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(1,1)=size(PDATABB,1);
count(1,2)=size(NDATABB,1);


AG=imread([Reshome3 filesep 'mosaicG.png']);
AG=AG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

% imwrite(AG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A0_ALL_CELL_FOXJ1.png']);

if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A1_ALL_CELL.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A2_ALL_CELL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A3_ALL_CELL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A4_ALL_CELL'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


% [ADATAS_T_MA,xyvals_T_MA]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_DSYM_M,xyvals_DSYM_M,ADATAS_DSYM_MR]=crop_cell_link(ADATAS_DSYM,xyvals_DSYM,mn,AG,0);
PDATABB=ADATAS_DSYM_M(ADATAS_DSYM_M(:,1)==1,:);
NDATABB=ADATAS_DSYM_M(ADATAS_DSYM_M(:,1)==2,:);
xyval=xyvals_DSYM_M;
count(7,1)=size(PDATABB,1);
count(7,2)=size(NDATABB,1);

if mkfig==1
% [LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DSB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G1_DOUBLET_SYM.png']);
% imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G2_DOUBLET_SYM.png']);

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G4_DOUBLET_SYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G6_DOUBLET_SYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G5_DOUBLET_SYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G7_DOUBLET_SYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');

% make_ternary_plot2line([PDATABB;NDATABB],xyval,LW2)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G3_DOUBLET_SYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

% [ADATAS_T_MA,xyvals_T_MA]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_DASYM_M,xyvals_DASYM_M,ADATAS_DASYM_MR]=crop_cell_link(ADATAS_DASYM,xyvals_DASYM,mn,AG,0);
PDATABB=ADATAS_DASYM_M(ADATAS_DASYM_M(:,1)==1,:);
NDATABB=ADATAS_DASYM_M(ADATAS_DASYM_M(:,1)==2,:);
xyval=xyvals_DASYM_M;
count(8,1)=size(PDATABB,1);
count(8,2)=size(NDATABB,1);

if mkfig==1
% [LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DASB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H1_DOUBLET_ASYM.png']);
% imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H2_DOUBLET_ASYM.png']);
% % 
make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H4_HDOUBLET_ASYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H5_DOUBLET_ASYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H6_DOUBLET_ASYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H7_DOUBLET_ASYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');


% make_ternary_plot2line([PDATABB;NDATABB],xyval,LW2)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H3_DOUBLET_ASYM'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

% [ADATAS_T_MA,xyvals_T_MA]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_D_M,xyvals_D_M,ADATAS_D_MR]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
[ADATAS_D_M,xyvals_D_M,ADATAS_D_MRN]=crop_cell_linkN(ADATAS_D_M,xyvals_D_M,mn,AG,0);
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

if mkfig==1
% [LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F1_DOUBLET.png']);
% imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F2_DOUBLET.png']);

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F4_DOUBLET'],'-a2', '-m6','-p0','-q101','-png', '-r600');
 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F5_DOUBLET'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F6_DOUBLET'],'-a2', '-m6','-p0','-q101','-png', '-r600');
 
make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F7_DOUBLET'],'-a2', '-m6','-p0','-q101','-png', '-r600');


% make_ternary_plot2line([PDATABB;NDATABB],xyval,LW2)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F3_DOUBLET'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

[ADATAS_T_M,xyvals_T_M,ADATAS_T_MR]=crop_cell_link_dyn(ADATAS_T,xyvals_T,mn,AG,LINKA,1,[3]);
[ADATAS_T_M,xyvals_T_M,ADATAS_T_MRN]=crop_cell_link_dynN(ADATAS_T_M,xyvals_T_M,mn,AG,LINKA,0,[3]);
PDATABB=ADATAS_T_M(ADATAS_T_M(:,1)==1,:);
NDATABB=ADATAS_T_M(ADATAS_T_M(:,1)==2,:);
xyval=xyvals_T_M;
% count(10,1)=size(PDATABB,1);
% count(10,2)=size(NDATABB,1);

PDATABBT=PDATABB;
NDATABBT=NDATABB;
xyvalT=xyval;

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_TB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_I4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_I'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_I2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB;PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_I3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

[ADATAS_Q_M,xyvals_Q_M,ADATAS_Q_MR]=crop_cell_link_dyn(ADATAS_Q,xyvals_Q,mn,AG,LINKA,1,[4]);
[ADATAS_Q_M,xyvals_Q_M,ADATAS_Q_MRN]=crop_cell_link_dynN(ADATAS_Q_M,xyvals_Q_M,mn,AG,LINKA,0,[4]);
% [ADATAS_D_M,xyvals_D_M]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
PDATABB=ADATAS_Q_M(ADATAS_Q_M(:,1)==1,:);
NDATABB=ADATAS_Q_M(ADATAS_Q_M(:,1)==2,:);
xyval=xyvals_Q_M;
% count(11,1)=size(PDATABB,1);
% count(11,2)=size(NDATABB,1);

PDATABBQ=PDATABB;
NDATABBQ=NDATABB;
xyvalQ=xyval;

count(9,1)=size([PDATABBT;PDATABBQ],1);
count(9,2)=size([NDATABBT;NDATABBQ],1);

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_QB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_J4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_J'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_J2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_J3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

if mkfig==1
% [LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],LW,sisters,idx,'_2B',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I1_TRIP_QUAD.png']);
% imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I2_TRIP_QUAD.png']);
% 
make_hue_plot2big([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I4_TRIP_QUAD'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I5_TRIP_QUAD'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I6_TRIP_QUAD'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2lineS([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I7_TRIP_QUAD'],'-a2', '-m6','-p0','-q101','-png', '-r600');


% make_ternary_plot2line([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],LW2)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I3_TRIP_QUAD'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end



[ADATAS_M_M,xyvals_M_M,ADATAS_M_MR]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_M_M,xyvals_M_M,ADATAS_M_MRN]=crop_cell_link_dynN(ADATAS_M_M,xyvals_M_M,mn,AG,LINKA,0,[5:8]);
% [ADATAS_D_M,xyvals_D_M]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
PDATABB=ADATAS_M_M(ADATAS_M_M(:,1)==1,:);
NDATABB=ADATAS_M_M(ADATAS_M_M(:,1)==2,:);
xyval=xyvals_M_M;
% count(12,1)=size(PDATABB,1);
% count(12,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_MB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_K4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_K'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_K2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_K3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

PDATABB=ADATAS_R(ADATAS_R(:,1)==1,:);
NDATABB=ADATAS_R(ADATAS_R(:,1)==2,:);

[ADATAS_R_M,xyvals_R_M,ADATAS_R_MR]=crop_cell_link_dyn(ADATAS_R,xyvals_R,mn,AG,LINKA,1,[9:16]);
[ADATAS_R_M,xyvals_R_M,ADATAS_R_MRN]=crop_cell_link_dynN(ADATAS_R_M,xyvals_R_M,mn,AG,LINKA,0,[9:16]);
% [ADATAS_D_M,xyvals_D_M]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
PDATABB=ADATAS_R_M(ADATAS_R_M(:,1)==1,:);
NDATABB=ADATAS_R_M(ADATAS_R_M(:,1)==2,:);
xyval=xyvals_R_M;
% count(13,1)=size(PDATABB,1);
% count(13,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_RB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_L4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_L'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_L2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_L3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

ADATASF2=[SINGLEP;SINGLEN;ADATAS_Z;ADATAS_D_MR;ADATAS_T_MR;ADATAS_Q_MR];

PDATABB=ADATASF2(ADATASF2(:,1)==1,:);
NDATABB=ADATASF2(ADATASF2(:,1)==2,:);

% PDATABB=[SINGLEP;ADATAS_Z];
% NDATABB=SINGLEN;

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

% count(3,1)=size(PDATABB,1);
% count(3,2)=size(NDATABB,1);

% if mkfig==0
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_B4.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_B3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_B'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end


PDATABB=[];
NDATABB=[DOUBLETN;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN];

% select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
% PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

% count(4,1)=size(PDATABB,1);
% count(4,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_C4.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB;PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_C3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_C'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end



ADATASF=[ADATAS_R2;ADATAS_R;ADATAS_M];

RM=[DOUBLETN;ADATASF;ADATASF2;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN];

check=min(pdist2(RAWF(:,4:5),RM(:,4:5)),[],2);
RAWF(check==0,:)=[];  


PDATABB=ADATASF(ADATASF(:,1)==1,:);
NDATABB=ADATASF(ADATASF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

% count(5,1)=size(PDATABB,1);
% count(5,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_D4.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_D3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_D'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end


PDATABB=RAWF(RAWF(:,1)==1,:);
NDATABB=RAWF(RAWF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

% count(6,1)=size(PDATABB,1);
% count(6,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_E4.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_E3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'FIG6_E'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end




% ADATAS_ZP=ADATAS_Z(ADATAS_Z(:,1)==1,:);
% ADATAS_ZN=ADATAS_Z(ADATAS_Z(:,1)==2,:);






PDATABB=[];
NDATABB=[DOUBLETN;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN;SINGLEN];

% select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
% PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(2,1)=size(PDATABB,1);
count(2,2)=size(NDATABB,1);

if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_B1_NEG_DIV.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB;PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_B2_NEG_DIV'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_B3_NEG_DIV'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_B4_NEG_DIV'],'-a2', '-m6','-p0','-q101','-png', '-r600');


end



ADATASF=[ADATAS_R2;ADATAS_R;ADATAS_M;ADATAS_Z;ADATAS_Q_MR];

RM=[DOUBLETN;ADATASF;ADATASF2;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN];

check=min(pdist2(RAWF(:,4:5),RM(:,4:5)),[],2);
RAWF(check==0,:)=[];  


PDATABB=ADATASF(ADATASF(:,1)==1,:);
NDATABB=ADATASF(ADATASF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(3,1)=size(PDATABB,1);
count(3,2)=size(NDATABB,1);

if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C1_FREQUENT.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C2_FREQUENT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C3_FREQUENT'],'-a2', '-m6','-p0','-q101','-png', '-r600');


make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C4_FREQUENT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

end


RAWF=[RAWF];

PDATABB=RAWF(RAWF(:,1)==1,:);
NDATABB=RAWF(RAWF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(4,1)=size(PDATABB,1);
count(4,2)=size(NDATABB,1);

if mkfig==0
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D1_REMAIN_CELL.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D2_REMAIN_CELL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'REMAINING_CELLS\' 'M' num2str(pool(idx)) '_D3_REMAIN_CELL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'REMAINING_CELLS\' 'M' num2str(pool(idx)) '_D4_REMAIN_CELL'],'-a2', '-m6','-p0','-q101','-png', '-r600');



end



RAWF2=[SINGLEP];

PDATABB=RAWF2(RAWF2(:,1)==1,:);
NDATABB=RAWF2(RAWF2(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(5,1)=size(PDATABB,1);
count(5,2)=size(NDATABB,1);

if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E1_SINGLE_EPEN.png']);
% 
% make_ternary_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E2_SINGLE_EPEN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E3_SINGLE_EPEN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\HUE\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E4_SINGLE_EPEN'],'-a2', '-m6','-p0','-q101','-png', '-r600');


end







% count(:,3)=count(:,1)+count(:,2)
% % countcrop=count;
% % save countcrop.mat 'countcrop'
% 
% % make_hue_plot2S([SINGLEP;SINGLEP])
% % export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' 'M' num2str(pool(idx)) 'HueS' num2str(14) 'SINGLE'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% countAS{idx}=count;
% 
% 
% MATN=count;
% 
% myfile = fopen(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_CountS.xls'] ,'wt'); 
% fprintf(myfile,'Catagoy\tEPENDYNAL\tNON_EPEN\tTOTAL\t\n');
% 
% tp={'Brainbow','Neural only','Very frequent','Remaining','Singles','Doublet','Doublet Sym','Doublet Asym', 'Trip plus Quad'};
% 
% % fprintf(myfile,'Cell ID\tG mean\t\n');
% % fprintf(myfile,'%g\t%g\n',MATN');
% 
% 
%     for ii=1:size(MATN,1)
%         for jj=1:size(MATN,2)+1
%             if jj==1
%         fprintf(myfile,tp{1,ii});
%         fprintf(myfile,'\t');
%             elseif jj>1 && jj<(size(MATN,2)+1)
%         fprintf(myfile,num2str(MATN(ii,jj-1))); 
%         fprintf(myfile,'\t');
%             else
%         fprintf(myfile,num2str(MATN(ii,jj-1))); 
%         fprintf(myfile,'\t\n');
%             end
%         end
%     end
% 
% 
% 
% % sa = size(MATN);
% % fprintf(myfile,[repmat('%g\t',1,sa(2)-1) '%g\n'],MATN.');
% fclose(myfile);



idx
close all
end

% % save countAS.mat 'countAS'
% 
% 
% clear all
% close all
% clc
% pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];
% load countAS.mat 'countAS'
% load countA.mat 'countA'
% 
% k=1;
% rc=[];
% 
% for kin=[7 8 3 1 5 2 13 15 17 18 14 16 12 11]
%     
%     tem=countA{kin};
%     tem2=countAS{kin};
%     
% %   rc(k,1)=tem(9,3)/2;    
% % %   rc(k,1)=tem(9,3)/2+tem(4,3)/2;  
% %   rc(k,2)=tem(10,3)/3;
% %   rc(k,3)=tem(11,3)/4;
% rc(k,1)=pool(kin);
% if kin<11
%     rc(k,2)=14;
% else
%     rc(k,2)=13;
% end
% rc(k,3)=tem2(1,1);
% rc(k,4)=tem2(1,2);
% rc(k,5)=tem2(1,3);
% rc(k,6)=tem2(2,3);
% rc(k,7)=tem2(3,3);
% rc(k,8)=tem2(4,3);
% rc(k,9)=tem2(5,3);
% rc(k,10)=tem2(6,3)/2;
% rc(k,11)=tem2(7,3)/2;
% rc(k,12)=tem2(8,3)/2;
% rc(k,13)=tem(10,3)/3+tem(11,3)/4;
% rc(k,14)=rc(k,10)/rc(k,13);
% 
% 
%    
%   k=k+1;
%   
% end
%   
% %   temt=temt+tem;
%   
%   
%    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'CountALL.xls'];
% if exist(resfile3, 'file')==2
% delete(resfile3);
% end
% 
% 
% MATN=rc;
% 
% myfile = fopen(resfile3 ,'wt'); 
% fprintf(myfile,'Mosaic\tAGE\tEPENDYNAL\tNon Epen\tTOTAL\tOnly neural\tFrequesnt\tRemain\tSingles\tDoublet\tDoub Sum\tDoub Asym\tTrip+Quad\tRATIO\t\n');
% 
% 
%     for ii=1:size(MATN,1)
%         for jj=1:size(MATN,2)
%             if jj==1
%                 fprintf(myfile,'M');
%         fprintf(myfile,num2str(MATN(ii,jj)));
%         fprintf(myfile,'\t');
%             elseif jj==2
%                 fprintf(myfile,'E');
%         fprintf(myfile,num2str(MATN(ii,jj)));
%         fprintf(myfile,'\t');
%             elseif jj>2 && jj<size(MATN,2)
%        fprintf(myfile,num2str(MATN(ii,jj)));
%         fprintf(myfile,'\t');
%             else
%         fprintf(myfile,num2str(MATN(ii,jj))); 
%         fprintf(myfile,'\t\n');
%             end
%         end
%     end
% 
% 
% 
% % sa = size(MATN);
% % fprintf(myfile,[repmat('%g\t',1,sa(2)-1) '%g\n'],MATN.');
% fclose(myfile);
%   
%   
% save rc.mat 'rc';