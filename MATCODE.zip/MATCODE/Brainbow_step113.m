clear all
close all
% 
clc


DD=10;

for idx=[2]
    
    cutp=0
    HTH=6.5
    STH=90
    BTH=80
    
    if cutp==0
        cid=1;
    elseif cutp==25
        cid=2;
    elseif cutp==50
        cid=3;
    elseif cutp==75
        cid=4;
    end

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

load(['FOX' num2str(idx)],'centerF'); 

bpcells=size(DATA,1)

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

%PLOT_ADJUSTED

load(['DATAF' num2str(idx)],'DTA','DTCMA'); 

ncoupA=[];
ncA=[];
HTHid=0;

    HTHid=HTHid+1;
    STHid=0;
   
    STHid=STHid+1;
    ncoup=[];
    nc=[];
for loopin=1:1
   
   DATA=DTA{loopin,cid};
    DATACM=DTCMA{loopin,cid};
    
    DATA(:,6:8)=hsv2rgb(DATACM);
       
    if loopin==1
    % PLOT_REMOVED
    end
    
    tDATA=DATA;
    
    Bdist=pdist2(DATACM(:,3),DATACM(:,3));

     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     
     SPACEdist=pdist2(DATA(:,4:5),DATA(:,4:5))*.31;
    
%% check conditions    
   Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(Bdist>BTH)=12000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  

        cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
        NBP2=size(D,2);
        idbox1=[1:NBP1];
        idbox2=[1:NBP2];
        Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end               

   xyval(xyval(:,13)>=10000,:)=[];
   
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 nc(loopin)=size(xyval,1);
 
if loopin==1
 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
%  LCOLORL=imread([Reshome3 filesep 'FOXLM2.png']);

 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
 
  CENTER=imread([Reshome3 filesep 'CENTER.png']);
  
%   fpc=sum(sum(CENTER>0))
  
  
%          Img=LCOLORG(:,:,1);
%           mean_s=45;
%         h = fspecial('disk', mean_s);
%         Img2 = imfilter(Img,h,'replicate');
% 
%         Img3=Img2;
%         
%         mask=uint16(zeros(size(Img3)));
%         
%                 
%         if idx==7
%         
%         mask(Img3>(max(Img2(:))*.15))=65535;
%         elseif idx==8
%         
%         mask(Img3>(max(Img2(:))*.15))=65535;
%         else
%         mask(Img3>(max(Img2(:))*.3))=65535;
%         end
%         
%         
% %         mask(Img3>(max(Img2(:))*.3))=65535;
%         
%         mask=imdilate(mask,strel('disk',45));
%         mask = imfill(mask);
% 
%         maskf=uint16(zeros(size(Img3)));    
%            CC = bwconncomp(mask);
%    numOfPixels = cellfun(@numel,CC.PixelIdxList);
%    [unused,indexOfMax] = max(numOfPixels);
%    maskf(CC.PixelIdxList{indexOfMax}) = 65535;
%     
% %         maskb=uint16(zeros(size(Img3)));
% %         Img33=cat(3,Img3,Img3,Img3);
% %         mask3=cat(3,maskf,maskb,maskb);
%         
%         MASK=uint16(65535*mat2gray(maskf));
% 
% %                 imwrite2tif(Img1,[],[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2mask.tif'],'uint16');
%              %    imwrite2tif(Imgover,[],[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2maskover.tif'],'uint16');
% % 
% CENTER(MASK==0)=0;
%   fpc=sum(sum(CENTER>0))
%   
%   areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
%   
%  imwrite(MASK,[FINB filesep 'AREA' num2str(idx) '.png']);
  
  
%   [points2x,points2y]=find(CENTER>0);
%        
%         [CH,STATk]= convhull(points2x,points2y);
%         figure
%         imagesc(CENTER);hold on
%         plot(points2y(CH),points2x(CH),'r-')
%       
%   
%   CH = bwconvhull(double(CENTER>0));
% imshow(CH);
% title('Union Convex Hull');
%     
% 
% CH_objects = bwconvhull(BW,'objects');
% imshow(CH_objects);
% title('Objects Convex Hull');
  
  
 
% LCOLORG(LCOLORL==0)=0; 

MASK=imread([FINB filesep 'AREA' num2str(idx) '.png']);

CENTER(MASK==0)=0;
  fpc=sum(sum(CENTER>0))
  
  areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
 
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
%                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');

                           labeledImage = bwlabel(I2cpsegb>0, 4);
% LCOLORL

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
        if sum(pos(:))<10000
     colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
        end
     cell;
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.5*CO;

mkdir([FINR filesep 'RESULT_M' num2str(idx) 'LINk_VIDEO']);

     figure
     m=1
     COF2=imresize(COF,m);
  imshow(COF2(1:3000,:,:));hold on
  
   axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure  
  
  export_fig([FINR filesep 'RESULT_M' num2str(idx) 'LINk_VIDEO' filesep 'LINK_idx' num2str(idx) '_frame' num2str(0)],'-a2', '-m4','-p0','-q101','-png', '-r300');

  close all  
for link=2:2:size(xyval,1)
    
     figure
  imshow(COF2(1:3000,:,:));hold on
  
     for zin=1:link   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.75) ; hold on
%          end

     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig([FINR filesep 'RESULT_M' num2str(idx) 'LINk_VIDEO' filesep 'LINK_idx' num2str(idx) '_frame' num2str(link)],'-a2', '-m4','-p0','-q101','-png', '-r300');
close all

end

%       close all  
%       
%      imwrite(uint16(COF),[FINR filesep 'MAIN_idx' num2str(idx) '.png']);hold on 

      close all   
      
end 
end

%  ncoupA=ncoup;
%  ncA=ncoup;
%  [h,p]=ttest2(ncoup(1),ncoup(2:101));
%  p
%  ratio=ncoup(1) 
%  random_ratio=mean(ncoup(2:101))
end