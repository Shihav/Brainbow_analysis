%%test seg

%Author : Athi Narayanan S
%M.E, Embedded Systems,
%K.S.R College of Engineering
%Erode, Tamil Nadu, India.
%http://sites.google.com/site/athisnarayanan/
%s_athi1983@yahoo.co.in

%Clear Memory & Command Window
clc;
clear all;
close all;


input_im=imread('tile001_01NOverlayM1.png');


I=input_im;
gradmagk=[];
hG = fspecial('gaussian',[15 15],3);
for kin=1:3
    
    I(:,:,kin)=imfilter(I(:,:,kin),hG,'replicate');

hy = fspecial('sobel');
hx = hy';
Iy = imfilter(double(I(:,:,kin)), hy, 'replicate');
Ix = imfilter(double(I(:,:,kin)), hx, 'replicate');
gradmagk(:,:,kin) = sqrt(Ix.^2 + Iy.^2);
end

IG=rgb2gray(I);

gradmag=sum(gradmagk,3);

% hG = fspecial('gaussian',[15 15],1); 
%      gradmag = imfilter(gradmag,hG,'replicate'); 

% figure, imshow(gradmag,[]), title('Gradient magnitude (gradmag)')
% L = watershed(gradmag);
% % Lrgb = label2rgb(L);
%  figure, imshow(L), title('Watershed transform of gradient magnitude (Lrgb)')
% 
% g = gradmag - min(gradmag(:));
% g = g / max(g(:));
% 
% gk=1-g;
% 
% gk(I<6554)=0;
% figure, imshow(gk)
% 
% hG = fspecial('gaussian',[15 15],2); 
%      gkk = imfilter(gk,hG,'replicate'); 
% figure, imshow(gkk)
% 
% imgN=gkk*256;
% 
% Iy = imfilter(imgN, hy, 'replicate');
% Ix = imfilter(imgN, hx, 'replicate');
% imgN2 = sqrt(Ix.^2 + Iy.^2);
% 
%  javaaddpath 'ij.jar';
%     javaaddpath 'mij.jar';
    
%     gradmag(I<3280)=0;
    I = gradmag;%imgN2;
    figure, imshow(uint8(I))   
     I=uint16(65535*mat2gray(localnormalize(double(I),75,75)));
    
    Img1=I;
NCHmax=2;
          mean_s=NCHmax/2;  
       mins=0.51;
        maxs=NCHmax/2;
        kernel_s=round(maxs*5);
    
IM4=Img1; 
%   fname1=strrep(fname,'.tif','');  

Img=Img1;

        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=imcomplement(Img2);
        Img8=imcomplement(Img);

        max3=max(Img3(:));
        min3=min(Img3(:));

        type=16;
     
        types=linspace(mins,maxs,type);
              Chd= uint16(round(type-1)*mat2gray(Img3))+1;
              Imgn=[];
                   for k=1:type
                  
                      h = fspecial('gaussian',[kernel_s kernel_s],types(k));
                                       Imgn(:,:,k) = imfilter(Img8,h,'replicate');
                   end
              adapt_image=zeros(size(Img8));
              
              for k=1:type
                        temp=Imgn(:,:,k);
                      adapt_image(Chd==k)=temp(Chd==k);
                                  
              end

        Img1=uint16(65535*mat2gray(adapt_image));
        
%          imwrite(Img1,[nametex 'Adaptive_gaussian_filtered' '.png']);
                 
       Im2=Img1;
        Im4=uint16(65535*mat2gray(IM4));
       idx=1; 
       tol(idx)=std(double(Im2(:)))/sqrt(3);
       
    MIJ.createImage(Im2);
    MIJ.run('Find Maxima...', sprintf('noise=%d output=[Segmented Particles]',tol(idx)));
    I = MIJ.getCurrentImage;
    
    MIJ.closeAllWindows;
 
    Img11=uint16(65535*mat2gray(I));

    ImgOut11=uint16(plot_maxima2(Im4,imcomplement(Img11)));

%                 imwrite(uint16(65535*mat2gray(ImgOut10)),[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2WFGM1.png']);
%                 imwrite(uint16(65535*mat2gray(ImgOut11)),[nametex 'Segmenation.png']);
%                 imwrite2tif(ImgOut12,[],[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2WFGM3.tif'],'uint16');
%                 imwrite2tif(uint16(65535*mat2gray(Img10)),[],[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2WFGM11.tif'],'uint16');
%                 imwrite(uint16(65535*mat2gray(ImgOut11)),[nametex 'Border.png']);
      

figure, imshow(input_im)

Img12=bwareaopen(Img11>0,5000);
Img13=(Img11>0)-Img12;

Img14=imread('tile001_01FinalmapM.png');
Img14=imdilate(Img14,ones(5,5));

Img13(Img14>0)=0;

lblImg = bwlabel(Img13);
figure,imshow(label2rgb(lblImg,'jet','k','shuffle'));

LABELM=lblImg;
classmap=LABELM;
pcells=unique(classmap);

         for nk=2:length(pcells)            
            val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));            
            if sizek<275
                
                
                
                classmap(classmap==val)=0;
%                 Imgsegk(Imgsegk==val)=0;
                
            end
         end
            
pcells=unique(classmap);

         for nk=2:length(pcells)  
              val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));      
                                         
                                             [X,Y]=find(object2==1);
    
                                          [CH,Ak]= convhull(X,Y);  
                                          
                                          
                                          if (abs(double(Ak)-double(sizek))/double(sizek)) >0.25 
                                                classmap(object2)=0;

                                          end
                                          
                                          
            
            
            nk 
         end
         
 pcells=unique(classmap);

         for nk=2:length(pcells)  
              val=pcells(nk);  
            object2 = classmap==val;
            
            IGG=median(IG(object2));
          

                                          
                                          
                                          if IGG<3280 
                                                classmap(object2)=0;

                                          end
                                          
                                          
            
            
            nk 
         end
         
         
% classmap((T2-T3)==1)=classmap4((T2-T3)==1);         
LABELM=classmap;


classmap5=LABELM;
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));
LABELM=classmap5;
LABELM=imerode(LABELM,ones(3,3));


figure, imshow(uint16(65535*mat2gray(ImgOut11)));
th2=256*0.33;
bw = imgN>th2;

D = -bwdist(~bw);
% imagesc(D)

Ld = watershed(D);
% imshow(label2rgb(Ld))

bw2 = bw;
bw2(Ld == 0) = 0;
% imshow(bw2)

mask = imextendedmin(D,2);

D2 = imimposemin(D,mask);
Ld2 = watershed(D2);
bw3 = bw;
bw3(Ld2 == 0) = 0;
% imshow(bw3)

figure, imshow(input_im)

lblImg = bwlabel(bw3);
figure,imshow(label2rgb(lblImg,'jet','k','shuffle'));



th = graythresh(g); %# Otsu's method.
a = imhmax(g,th/2); %# Conservatively remove local maxima.
th = graythresh(a);
b = a > th/4; %# Conservative global threshold.
c = imclose(b,ones(6)); %# Try to close contours.
d = imfill(c,'holes'); %# Not a bad segmentation by itself.
%# Use the rough segmentation to define markers.
g2 = imimposemin(g, ~ imdilate( bwperim(a), ones(3) ));
L = watershed(g2);

 figure, imshow(L)

sz_im=size(input_im);

cform = makecform('srgb2lab');
lab_he = applycform(input_im,cform);
ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
ab = reshape(ab,nrows*ncols,2);

nColors = 12;
% repeat the clustering 3 times to avoid local minima
[cluster_idx, cluster_center] = kmeans(ab,nColors,'distance','sqEuclidean', 'Replicates',3);

pixel_labels = reshape(cluster_idx,nrows,ncols);
%imshow(pixel_labels,[]), title('image labeled by cluster index');
segmented_images = cell(1,3);
rgb_label = repmat(pixel_labels,[1 1 3]);

for k = 1:nColors
    color = input_im;
    color(rgb_label ~= k) = 0;
    segmented_images{k} = color;
end

for k=1:nColors
%figure
title_string=sprintf('objects in cluster %d',k);
%imshow(segmented_images{k}), title(title_string);
end


finalSegmentedImage=segmented_images{1};
%imshow(finalSegmentedImage);
close all;

Icombine = [input_im finalSegmentedImage];
imshow(Icombine);

%Parameters for the Segmentation
nBins=5;
winSize=7;
nClass=36;

%Read Input Image
inImg = double(imread('tile001_01NOverlayM1.png'));
% imshow(inImg);title('Input Image');
% 
% %Segmentation
% outImg = colImgSeg(inImg, nBins, winSize, nClass);
% 
% %Displaying Output
% figure;imshow(outImg);title('Segmentation Maps');
% colormap('default');

im=inImg(1:100,1:100,:);

[l, Am, C] = slic(im, 10, 1, 1, 'median');
show(drawregionboundaries(l, uint8(im/256), [255 255 255]))

lc = spdbscan(l, C, Am, 0);
show(drawregionboundaries(lc, uint8(im/256), [255 255 255]))