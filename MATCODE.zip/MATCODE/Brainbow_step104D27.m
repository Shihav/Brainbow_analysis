load PMATSEARCH.mat PMAT
VD=[];
for HID=1:5
    for SID=1:5
        
        x1=PMAT(HID,SID,1,10,5);
        x2=PMAT(HID,SID,2:101,10,5);
        
        [h,p]=ttest2(x1,x2);
        
        VD(HID,SID)=p;
        


    end
end

figure
mat = VD;  
mat2 = VD;
mat3 = VD;%# A 5-by-5 matrix of random values from 0 to 1
imagesc(1*log10(mat));            %# Create a colored plot of the matrix values
colormap(flipud(bone));
caxis manual
caxis([-5 -2])%# Change the colormap to gray (so higher values are
colorbar                       %#   black and lower values are white)

textStrings = num2str(mat(:),'%10.2e');  %# Create strings from the matrix values
textStrings = strtrim(cellstr(textStrings));
textStrings=strcat(textStrings);%# Remove any space padding
% textStrings2 = num2str(100*mat2(:),'%0.0f');  %# Create strings from the matrix values
% textStrings2 = strtrim(cellstr(textStrings2)); 
% textStrings2=strcat(textStrings2);%# Remove any space padding
% textStrings3 = num2str(100*mat3(:),'%0.0f');  %# Create strings from the matrix values
% textStrings3 = strtrim(cellstr(textStrings3));  %# Remove any space padding
% textStrings3=strcat(textStrings3);
[x,y] = meshgrid(1:5,1:5);   %# Create x and y coordinates for the strings
hStrings = text(x(:),y(:),textStrings(:),...      %# Plot the strings
                'HorizontalAlignment','center','FontSize', 10,'FontName','Times');
% hStrings2 = text(x(:),y(:)-.175,textStrings2(:),...      %# Plot the strings
%                 'HorizontalAlignment','center','FontSize', 20,'FontName','Times');
% hStrings3 = text(x(:),y(:)+.175,textStrings3(:),...      %# Plot the strings
%                 'HorizontalAlignment','center','FontSize', 20,'FontName','Times');
midValue = mean(get(gca,'CLim'));  %# Get the middle value of the color range
textColors = repmat(1*log10(mat(:)) > midValue,1,3);  %# Choose white or black for the
                                             %#   text color of the strings so
                                             %#   they can be easily seen over
                                             %#   the background color
set(hStrings,{'Color'},num2cell(textColors,2));

% textColors=repmat([0.6 0.9 0.6],16,1);
% textColors2=repmat([0.9 0.6 0.6],16,1);
                                         

% set(hStrings2,{'Color'},num2cell(textColors,2));%# Change the text colors
% set(hStrings3,{'Color'},num2cell(textColors2,2));%# Change the text colors

set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'60','80','100','120','140'},...  %#   and tick labels
        'YTick',1:5,...
        'YTickLabel',{'5','7.5','10','12.5','15'},...
        'TickLength',[0 0],'FontSize', 12,'FontName','Times');

set(gcf,'color','w'); 
xlabel('XY distance threshold (in microns)','FontSize', 16,'FontName','Times');
ylabel('Hue threshold (in degrees)','FontSize', 16,'FontName','Times');

% title(['P-map: ' num2str(BTH) ' Value. diff. thres.'],'FontSize', 18,'FontName','Times');

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.7,.7,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
                                 
%         print([FINR filesep 'RESULT_M' num2str(idx) filesep num2str(idx) '_BP-Map_WP' num2str(BTH)], '-dpng', '-r300');
%         print([FINR filesep 'RESULT_M' num2str(idx) filesep num2str(idx) '_BP-Map_WP' num2str(BTH)], '-dpdf', '-r300');
   export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\PLOT\' 'COMP_DIST_M2'],'-a2', '-m2','-p0.02','-png', '-r200');
% close all



  for idx=[1 2 3 5 7 8]       


VD=[];
for HID=1:5
    for SID=1:5
        
        x1=PMAT(HID,SID,1,idx,5);
        x2=PMAT(HID,SID,2:101,idx,5);
        
        [h,p]=ttest2(x1,x2);
        
        VD(HID,SID)=p;
        


    end
end

figure
mat = VD;  
mat2 = VD;
mat3 = VD;%# A 5-by-5 matrix of random values from 0 to 1
imagesc(1*log10(mat));            %# Create a colored plot of the matrix values
colormap(flipud(bone));
caxis manual
caxis([-2 0])%# Change the colormap to gray (so higher values are
colorbar                       %#   black and lower values are white)

textStrings = num2str(mat(:),'%10.2e');  %# Create strings from the matrix values
textStrings = strtrim(cellstr(textStrings));
textStrings=strcat(textStrings);%# Remove any space padding
% textStrings2 = num2str(100*mat2(:),'%0.0f');  %# Create strings from the matrix values
% textStrings2 = strtrim(cellstr(textStrings2)); 
% textStrings2=strcat(textStrings2);%# Remove any space padding
% textStrings3 = num2str(100*mat3(:),'%0.0f');  %# Create strings from the matrix values
% textStrings3 = strtrim(cellstr(textStrings3));  %# Remove any space padding
% textStrings3=strcat(textStrings3);
[x,y] = meshgrid(1:5,1:5);   %# Create x and y coordinates for the strings
hStrings = text(x(:),y(:),textStrings(:),...      %# Plot the strings
                'HorizontalAlignment','center','FontSize', 10,'FontName','Times');
% hStrings2 = text(x(:),y(:)-.175,textStrings2(:),...      %# Plot the strings
%                 'HorizontalAlignment','center','FontSize', 20,'FontName','Times');
% hStrings3 = text(x(:),y(:)+.175,textStrings3(:),...      %# Plot the strings
%                 'HorizontalAlignment','center','FontSize', 20,'FontName','Times');
midValue = mean(get(gca,'CLim'));  %# Get the middle value of the color range
textColors = repmat(1*log10(mat(:)) > midValue,1,3);  %# Choose white or black for the
                                             %#   text color of the strings so
                                             %#   they can be easily seen over
                                             %#   the background color
set(hStrings,{'Color'},num2cell(textColors,2));

% textColors=repmat([0.6 0.9 0.6],16,1);
% textColors2=repmat([0.9 0.6 0.6],16,1);
                                         

% set(hStrings2,{'Color'},num2cell(textColors,2));%# Change the text colors
% set(hStrings3,{'Color'},num2cell(textColors2,2));%# Change the text colors

set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'60','80','100','120','140'},...  %#   and tick labels
        'YTick',1:5,...
        'YTickLabel',{'5','7.5','10','12.5','15'},...
        'TickLength',[0 0],'FontSize', 12,'FontName','Times');

set(gcf,'color','w'); 
xlabel('XY distance threshold (in microns)','FontSize', 16,'FontName','Times');
ylabel('Hue threshold (in degrees)','FontSize', 16,'FontName','Times');

% title(['P-map: ' num2str(BTH) ' Value. diff. thres.'],'FontSize', 18,'FontName','Times');

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.7,.7,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
                                 
%         print([FINR filesep 'RESULT_M' num2str(idx) filesep num2str(idx) '_BP-Map_WP' num2str(BTH)], '-dpng', '-r300');
%         print([FINR filesep 'RESULT_M' num2str(idx) filesep num2str(idx) '_BP-Map_WP' num2str(BTH)], '-dpdf', '-r300');
   export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\PLOT\' 'COMP_DIST_M2_' num2str(idx)],'-a2', '-m2','-p0.02','-png', '-r200');
% close all

  end