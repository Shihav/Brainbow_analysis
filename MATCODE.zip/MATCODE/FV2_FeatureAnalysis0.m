clear all
close all

clc

% Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiffv';
% Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\ImageJ';
% Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\MATLAB';

% Datahome='/import/pr_ciltex/TEST_BRAINBOW/Tiff';
% Reshome='/import/pr_ciltex/TEST_BRAINBOW/Imagej2';
% Reshome2='/import/pr_ciltex/TEST_BRAINBOW/Process';

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiff';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Imagej2';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

RAK=[];
GAK=[];
BAK=[];

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
        
               info = imfinfo(oriname);
        num_images = numel(info);
     
%              ImgGR=uint8([]);
%         kn=1;
%         for k = 4:4:num_images
%             I = uint8(double(imread(oriname, k))/16);
%               ImgGR(:,:,kn)=I;   
%               kn=kn+1
%         end

        ImgR=uint8([]);
        kn=1;
        for k = 1:4:num_images
           I = uint8(double(imread(oriname, k))/16);
              ImgR(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgG=uint8([]);
        kn=1;
        for k = 2:4:num_images
            I = uint8(double(imread(oriname, k))/16);
              ImgG(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgB=uint8([]);
        kn=1;
        for k = 3:4:num_images
             I = uint8(double(imread(oriname, k))/16);
              ImgB(:,:,kn)=I;   
              kn=kn+1
        end
%                 
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2');
% box=max(Imgsegk2,[],3); 
LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
 
%          ImgGR(Imgsegk2==0)=0;
%          ImgGRk=uint16(65535.*(ImgGR./4096));
%          [Img11gr,zval11gr]=max(ImgGRk,[],3);
 
LCOLOR=imread([Reshome2 filesep filename2 filesep filename2 'FLmapC.png']);
LCOLOR2=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC2.png']);
LCOLOR3=imread([Reshome2 filesep filename2 filesep filename2 'FmaxV.png']);
LCOLOR5=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);

Comp=uint16(zeros(size(LCOLOR5)));

                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;    
                          Comp(:,:,ind)=col_img2a;
                          end   
Img11gr=imread([Reshome2 filesep filename2 filesep filename2 'GRAY2.png']);                          
CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));

Compk=uint16(Comp)+0.3*CGO;   

 h = fspecial('gaussian',[15 15],5);
 Comp(:,:,3)=2*Comp(:,:,3);
                                       CompG = imfilter(rgb2gray(Comp),h,'replicate');
                                       CompG(LABEL==0)=0;
                                       CompG(CompG<(5*255))=0;
LABEL(CompG==0)=0;  

                                       se=ones(3);

pcells=unique(LABEL);
se=ones(5);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABEL == val;
                              objectcore=imerode(object, se);
                              objectbor=(object-objectcore)>0;
                         LABEL(objectbor)=0;
         end

 LABEL = bwlabel(LABEL, 8);
pcells=unique(LABEL);
objectbor_map=zeros(size(LABEL));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABEL == val;
                               sizek=sum(sum(object==1));            
                                if sizek<225
                                    LABEL(object)=0;
                                else
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                         

%                      object_map(object)=1;
                       objectbor_map(objectbor)=1;
%                          objectcore_map(objectcore)=1;
                                end
         end
                                       
                                       Compb=1*Comp;

                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'Finaloverlay.png']);  
imwrite(uint16(LABEL),[Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);
imwrite(uint16(Compk),[Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
imwrite(uint16(Comp),[Reshome2 filesep filename2 filesep filename2 'Finalmap3.png']);
LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
imgid
pcells=unique(LABEL);
CA=[];

ImgR=LCOLOR5(:,:,1);
ImgG=LCOLOR5(:,:,2);
ImgB=LCOLOR5(:,:,3);

         for nk=2:length(pcells)            
            val=pcells(nk); 
            
%             point=unique(box(LABEL==val));
%             point(point==0)=[];
%             
%             RA=[];GA=[];BA=[];
%             for cellm=1:length(point)            
                RA=double(ImgR(LABEL==val));
                 GA=double(ImgG(LABEL==val));
                  BA=double(ImgB(LABEL==val));                
%             end
            
            SA=RA+GA+BA;
            CA(nk-1,:)=[mean(RA./SA) mean(GA./SA) mean(BA./SA) median(RA./SA) median(GA./SA) median(BA./SA) std(RA./SA) std(GA./SA) std(BA./SA)...
                mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)];
RAK=[RAK;RA];  
GAK=[GAK;GA];  
BAK=[BAK;BA];  
          nk
         end 
         
 save([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');   

   labeledImage1=LABEL;
       center=[];
       cellsL=unique(labeledImage1);

           for id=2:size(cellsL,1)
               tag=cellsL(id);

                                     object = labeledImage1 == tag;
                            CL=[];         
                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          CL(ind)=mean(col_img2a(object));    
                          end 
                                     
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              center(id-1,1:2)=cent;
                            center(id-1,3:5)=CL; 
%                              center(id-1,1)=id; 
                           
           end
           
%            center(:,3:5)=CA(:,13:15);
imgid           
  save([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');   
  
%   resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];
%     
%     if exist(resfile, 'file')==2
%   delete(resfile);
%     end
%      
%     MATT=[[1:size(center,1)]' center(:,1:2) CA(:,10:12)/16 CA(:,16:18)/16];
%     nps=length(unique(Imgsegk2))-2;
%     
%     clear cell
%     B = cell(size(MATT,1),size(MATT,2));
% for ii=1:size(MATT,1)
%     for jj=1:size(MATT,2)
%   B(ii,jj) = {MATT(ii,jj)};
%     end
% end
% 
%     BK = cell(size(MATT,1),size(MATT,2));
% for ii=1:size(MATT,1)
%     for jj=1:size(MATT,2)
%   BK(ii,jj+3) = {MATT(ii,jj)};
%     end
%       BK(ii,1) = {filename2};
%        BK(ii,2) = {imgid};
%        BK(ii,3) = {nps};
% end
% 
% BKA=[BKA;BK];
% A = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
% C=[A;BK];
% xlswrite(resfile,C,1,'A1') 
      
end

% AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
% C=[AK;BKA];
%    resfile = [Reshome2 filesep 'Result.xlsx'];
% 
%     if exist(resfile, 'file')==2
%   delete(resfile);
%     end
% 
% xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')
% 
save([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');    
% 
