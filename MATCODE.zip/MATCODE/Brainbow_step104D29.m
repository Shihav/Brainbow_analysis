clear all
close all

COLORA=[];

for idx=[12]
    
    loadaddress;
    
   LCOLORCP=imread([Reshome3 filesep 'NmosaicOP.png']);
   LCOLORCPS=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
                       
                           labeledImage = bwlabel(I2cpsegb>0, 4);
                           LCOLORL=labeledImage;

LCOLORLM=imdilate(LCOLORL,ones(7,7));

                          for ind=1:3
                          col_img2a=LCOLORCP(:,:,ind); 
                          col_img2a(LCOLORLM==0)=0;
                          LCOLORCP(:,:,ind)=col_img2a;
                          end   
figure
imshow(LCOLORCP);

figure
imshow(LCOLORCPS);

imwrite(LCOLORCP,[Reshome3 filesep 'NmosaicO2.png']);
imwrite(uint16(LCOLORLM),[Reshome3 filesep 'NFinalmapM2.png']);


   LCOLORCP=imread([Reshome3 filesep 'PmosaicOP.png']);
   LCOLORCPS=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);


 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
                       
                           labeledImage = bwlabel(I2cpsegb>0, 4);
                           LCOLORL=labeledImage;
if idx>10
LCOLORLM=imdilate(LCOLORL,ones(7,7));
elseif idx==8
LCOLORLM=imdilate(LCOLORL,ones(7,7)); 
else
LCOLORLM=imdilate(LCOLORL,ones(1,1));       
end

                          for ind=1:3
                          col_img2a=LCOLORCP(:,:,ind); 
                          col_img2a(LCOLORLM==0)=0;
                          LCOLORCP(:,:,ind)=col_img2a;
                          end   
figure
imshow(LCOLORCP);

figure
imshow(LCOLORCPS);

imwrite(LCOLORCP,[Reshome3 filesep 'PmosaicO2.png']);
imwrite(uint16(LCOLORLM),[Reshome3 filesep 'PFinalmapM2.png']);

close all
    
end