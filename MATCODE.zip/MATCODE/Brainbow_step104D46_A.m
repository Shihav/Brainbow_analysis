clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36 .36 .36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);
mkfig=1;
countA=[];
xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14)]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\HUE' ]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF' ]);
% m=1;
m{3}=[3139 785 2245 854];
m{10}=[1 0 1 0];
multa(10,:)=multa(3,:);
count=[];
for idx=[10]
    
    mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF\' num2str(idx)]);
      mn=[1 0 1 0];  
     if idx==7
     LW=0.2;
     elseif idx==11
     LW=0.2;
     elseif idx==12
     LW=0.8;
     else
     LW=0.4;
     end
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB','valAT','valAQ','LINKA'); 

% if mkfig==1
% make_hue_plot2([PDATAB;NDATAB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) 'ALLR'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) 'ALLM'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

if idx==10
    nk=m{3};
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(3) 'ang' num2str(14)  'CG' '.png']); 
AG=LCOLORG;
LCOLORG=LCOLORG(nk(1):size(AG,1)-nk(2),nk(3):size(AG,2)-nk(4),:);
elseif idx>10
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
else
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
end
AG=LCOLORG;
LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

count(1,1)=size(PDATABB,1);
count(1,2)=size(NDATABB,1);
select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(2,1)=size(PDATABB,1);
count(2,2)=size(NDATABB,1);

if mkfig==0
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_A4.png']);

make_ternary_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_A3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_A'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


% [ADATAS_T_MA,xyvals_T_MA]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_DSYM_M,xyvals_DSYM_M,ADATAS_DSYM_MR]=crop_cell_link(ADATAS_DSYM,xyvals_DSYM,mn,AG,0);
PDATABB=ADATAS_DSYM_M(ADATAS_DSYM_M(:,1)==1,:);
NDATABB=ADATAS_DSYM_M(ADATAS_DSYM_M(:,1)==2,:);
xyval=xyvals_DSYM_M;
count(7,1)=size(PDATABB,1);
count(7,2)=size(NDATABB,1);

if mkfig==0
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DSB',multp,multn,Reshome3,1,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F4.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F5.png']);

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

% [ADATAS_T_MA,xyvals_T_MA]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_DASYM_M,xyvals_DASYM_M,ADATAS_DASYM_MR]=crop_cell_link(ADATAS_DASYM,xyvals_DASYM,mn,AG,0);
PDATABB=ADATAS_DASYM_M(ADATAS_DASYM_M(:,1)==1,:);
NDATABB=ADATAS_DASYM_M(ADATAS_DASYM_M(:,1)==2,:);
xyval=xyvals_DASYM_M;
count(8,1)=size(PDATABB,1);
count(8,2)=size(NDATABB,1);

if mkfig==0
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DASB',multp,multn,Reshome3,1,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_G4.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_G5.png']);

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_G'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_G2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_G3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

% [ADATAS_T_MA,xyvals_T_MA]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_D_M,xyvals_D_M,ADATAS_D_MR]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
[ADATAS_D_M,xyvals_D_M,ADATAS_D_MRN]=crop_cell_linkN(ADATAS_D_M,xyvals_D_M,mn,AG,0);
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(9,1)=size(PDATABB,1);
count(9,2)=size(NDATABB,1);

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_H4.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_H5.png']);

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_H'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_H2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_H3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

[ADATAS_T_M,xyvals_T_M,ADATAS_T_MR]=crop_cell_link_dyn(ADATAS_T,xyvals_T,mn,AG,LINKA,1,[3]);
[ADATAS_T_M,xyvals_T_M,ADATAS_T_MRN]=crop_cell_link_dynN(ADATAS_T_M,xyvals_T_M,mn,AG,LINKA,0,[3]);
PDATABB=ADATAS_T_M(ADATAS_T_M(:,1)==1,:);
NDATABB=ADATAS_T_M(ADATAS_T_M(:,1)==2,:);
xyval=xyvals_T_M;
count(10,1)=size(PDATABB,1);
count(10,2)=size(NDATABB,1);

PDATABBT=PDATABB;
NDATABBT=NDATABB;
xyvalT=xyval;

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_TB',multp,multn,Reshome3,1,mn,1);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_I4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_I'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_I2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB;PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_I3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

[ADATAS_Q_M,xyvals_Q_M,ADATAS_Q_MR]=crop_cell_link_dyn(ADATAS_Q,xyvals_Q,mn,AG,LINKA,1,[4]);
[ADATAS_Q_M,xyvals_Q_M,ADATAS_Q_MRN]=crop_cell_link_dynN(ADATAS_Q_M,xyvals_Q_M,mn,AG,LINKA,0,[4]);
% [ADATAS_D_M,xyvals_D_M]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
PDATABB=ADATAS_Q_M(ADATAS_Q_M(:,1)==1,:);
NDATABB=ADATAS_Q_M(ADATAS_Q_M(:,1)==2,:);
xyval=xyvals_Q_M;
count(11,1)=size(PDATABB,1);
count(11,2)=size(NDATABB,1);

PDATABBQ=PDATABB;
NDATABBQ=NDATABB;
xyvalQ=xyval;

count(14,1)=size([PDATABBT;PDATABBQ],1);
count(14,2)=size([NDATABBT;NDATABBQ],1);

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_QB',multp,multn,Reshome3,1,mn,1);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_J4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_J'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_J2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_J3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],LW,sisters,idx,'_2B',multp,multn,Reshome3,1,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG13_M4.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG13_M5.png']);

make_hue_plot2big([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG13_M'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG13_M2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABBT;PDATABBQ;NDATABBT;NDATABBQ],[xyvalT;xyvalQ],2*LW)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG13_M3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end



[ADATAS_M_M,xyvals_M_M,ADATAS_M_MR]=crop_cell_link_dyn(ADATAS_M,xyvals_M,mn,AG,LINKA,1,[5:8]);
[ADATAS_M_M,xyvals_M_M,ADATAS_M_MRN]=crop_cell_link_dynN(ADATAS_M_M,xyvals_M_M,mn,AG,LINKA,0,[5:8]);
% [ADATAS_D_M,xyvals_D_M]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
PDATABB=ADATAS_M_M(ADATAS_M_M(:,1)==1,:);
NDATABB=ADATAS_M_M(ADATAS_M_M(:,1)==2,:);
xyval=xyvals_M_M;
count(12,1)=size(PDATABB,1);
count(12,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_MB',multp,multn,Reshome3,1,mn,1);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_K4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_K'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_K2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_K3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

PDATABB=ADATAS_R(ADATAS_R(:,1)==1,:);
NDATABB=ADATAS_R(ADATAS_R(:,1)==2,:);

[ADATAS_R_M,xyvals_R_M,ADATAS_R_MR]=crop_cell_link_dyn(ADATAS_R,xyvals_R,mn,AG,LINKA,1,[9:16]);
[ADATAS_R_M,xyvals_R_M,ADATAS_R_MRN]=crop_cell_link_dynN(ADATAS_R_M,xyvals_R_M,mn,AG,LINKA,0,[9:16]);
% [ADATAS_D_M,xyvals_D_M]=crop_cell_link(ADATAS_D,xyvals_D,mn,AG,0);
PDATABB=ADATAS_R_M(ADATAS_R_M(:,1)==1,:);
NDATABB=ADATAS_R_M(ADATAS_R_M(:,1)==2,:);
xyval=xyvals_R_M;
count(13,1)=size(PDATABB,1);
count(13,2)=size(NDATABB,1);

% if mkfig==1
% LCOLORG=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_RB',multp,multn,Reshome3,1,mn,1);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_L4.png']);
% 
% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_L'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_L2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_ternary_plot2line([PDATABB;NDATABB],xyval,2*LW)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_L3'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% end

ADATASF2=[SINGLEP;SINGLEN;ADATAS_Z;ADATAS_D_MR;ADATAS_T_MR;ADATAS_Q_MR];

PDATABB=ADATASF2(ADATASF2(:,1)==1,:);
NDATABB=ADATASF2(ADATASF2(:,1)==2,:);

% PDATABB=[SINGLEP;ADATAS_Z];
% NDATABB=SINGLEN;

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(3,1)=size(PDATABB,1);
count(3,2)=size(NDATABB,1);

if mkfig==0
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_B4.png']);

make_ternary_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_B3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_B'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


PDATABB=[];
NDATABB=[DOUBLETN;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN];

% select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
% PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(4,1)=size(PDATABB,1);
count(4,2)=size(NDATABB,1);

if mkfig==1
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_C4.png']);

make_ternary_plot2big([PDATABB;NDATABB;PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_C3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_C'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end



ADATASF=[ADATAS_R2;ADATAS_R;ADATAS_M];

RM=[DOUBLETN;ADATASF;ADATASF2;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN];

check=min(pdist2(RAWF(:,4:5),RM(:,4:5)),[],2);
RAWF(check==0,:)=[];  


PDATABB=ADATASF(ADATASF(:,1)==1,:);
NDATABB=ADATASF(ADATASF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(5,1)=size(PDATABB,1);
count(5,2)=size(NDATABB,1);

if mkfig==1
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_D4.png']);

make_ternary_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_D3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_D'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


PDATABB=RAWF(RAWF(:,1)==1,:);
NDATABB=RAWF(RAWF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

if mkfig==1
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_E4.png']);

make_ternary_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_E3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_E'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end




ADATAS_ZP=ADATAS_Z(ADATAS_Z(:,1)==1,:);
ADATAS_ZN=ADATAS_Z(ADATAS_Z(:,1)==2,:);






PDATABB=[];
NDATABB=[DOUBLETN;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN;SINGLEN;ADATAS_ZN];

% select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
% PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(15,1)=size(PDATABB,1);
count(15,2)=size(NDATABB,1);

if mkfig==1
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_C4.png']);

make_ternary_plot2big([PDATABB;NDATABB;PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_C3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_C'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end



ADATASF=[ADATAS_R2;ADATAS_R;ADATAS_M];

RM=[DOUBLETN;ADATASF;ADATASF2;ADATAS_D_MRN;ADATAS_T_MRN;ADATAS_Q_MRN];

check=min(pdist2(RAWF(:,4:5),RM(:,4:5)),[],2);
RAWF(check==0,:)=[];  


PDATABB=ADATASF(ADATASF(:,1)==1,:);
NDATABB=ADATASF(ADATASF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(16,1)=size(PDATABB,1);
count(16,2)=size(NDATABB,1);

if mkfig==1
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_D4.png']);

make_ternary_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_D3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_D'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


RAWF=[RAWF;SINGLEP;ADATAS_ZP];

PDATABB=RAWF(RAWF(:,1)==1,:);
NDATABB=RAWF(RAWF(:,1)==2,:);

select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(17,1)=size(PDATABB,1);
count(17,2)=size(NDATABB,1);

if mkfig==1
LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,1);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_E4.png']);

make_ternary_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_E3'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2big([PDATABB;NDATABB])
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_E'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end










count(:,3)=count(:,1)+count(:,2);
% countcrop=count;
% save countcrop.mat 'countcrop'

% make_hue_plot2S([SINGLEP;SINGLEP])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) 'SINGLE'],'-a2', '-m6','-p0','-q101','-png', '-r600');
countA{idx}=count;

idx
close all
end

% save countA.mat 'countA'
