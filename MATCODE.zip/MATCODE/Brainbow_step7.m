clear all
close all

clc

% Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiffv';
% Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\ImageJ';
% Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\MATLAB';

% Datahome='/import/pr_ciltex/TEST_BRAINBOW/Tiff';
% Reshome='/import/pr_ciltex/TEST_BRAINBOW/Imagej2';
% Reshome2='/import/pr_ciltex/TEST_BRAINBOW/P';

Datahome='G:\Marie_Brainbow2\Selection Shihav\Marie_brainbow8\Tiff';
Reshome='G:\Marie_Brainbow2\Selection Shihav\Marie_brainbow8\Imagej2';
Reshome2='G:\TEST_BRAINBOW\P';
Reshome3='G:\TEST_BRAINBOW\P2';

mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);
 
RANDN=10;


MTYPE={'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h'};
     C2count=[];
     CLIST=1;
     DLIST=[];
     YA=[];
     
     DVlist=[];
     YVlist=[];
     
cut(1,1:4)=round([1 1+pdist2(114.9,-170.7)/0.31 1 1024]);  
cut(2,1:4)=round([1 1+pdist2(-170.7,-456.3)/0.31 1 1+pdist2(5113.2,5398.8)/0.31]); 
cut(3,1:4)=round([1 1+pdist2(-170.7,-456.3)/0.31 1 1024]); 
cut(4,1:4)=round([1 1024 1 1+pdist2(4827.6,5113.2)/0.31]); 
cut(5,1:4)=round([1 1024 1 1024]); 
worklist =1:numel(Types);

shift(1,1:2)=[0,1024];
shift(2,1:2)=[915,1035];
shift(3,1:2)=[908,1950];
shift(4,1:2)=[1830,138];
shift(5,1:2)=[1823,1053];

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLC.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
 
 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
% 
% % Tile 0 (G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process\Mosaic\tile001_01FinalmapC3.png): 0.0, 0.0
% % Tile 1 (G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process\Mosaic\tile002_01FinalmapC3.png): 11.0000305, 915.0001
% % Tile 2 (G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process\Mosaic\tile003_01FinalmapC3.png): 926.0, 908.0001
% % Tile 3 (G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process\Mosaic\tile004_01FinalmapC3.png): -885.99994, 1830.0
% % Tile 4 (G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Process\Mosaic\tile005_01FinalmapC3.png): 29.000044, 1823.0
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

LABEL=LABELM;

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];
DATA=[];

 INFO=cells2.data.Sheet1;
ID=INFO(:,1);
    for IDk=1:5
    tINFO=INFO(ID==IDk,:);
    
    tINFO(:,4:5)=tINFO(:,4:5)+repmat(shift(IDk,1:2),size(tINFO,1),1);
    INFO(ID==IDk,:)=tINFO;
    end
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;
%                 RA=double(ImgR(object))/256;
%                  GA=double(ImgG(object))/256;
%                   BA=double(ImgB(object))/256;   
%                   
                  
%                    object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));

              
              
              
              
                            center(nk-1,3:5)=INFO(plist,6:8); 
%             SA=RA+GA+BA;
            CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
            CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
% RAK=[RAK;RA];  
% GAK=[GAK;GA];  
% BAK=[BAK;BA]; 

 DATA(nk-1,1:11)=[1 1 length(pcells) center(nk-1,1:2) INFO(plist,6:8) INFO(plist,9:11)];


          nk
         end 
         
save([Reshome2 filesep 'all.mat'],'DATA','CA','CA2','center','RAK','GAK','BAK'); 
load([Reshome2 filesep 'all.mat'],'DATA','CA','CA2','center','RAK','GAK','BAK'); 

    for varv=[1];
%% adjusting xy positions in mosaic  

% DATA=cells2.data.Sheet1;
% ID=DATA(:,1);
%     for IDk=1:5
%     tDATA=DATA(ID==IDk,:);
%     
%     tDATA(:,4:5)=tDATA(:,4:5)+repmat(shift(IDk,1:2),size(tDATA,1),1);
%     DATA(ID==IDk,:)=tDATA;
%     end

%             SD=pdist2(DATA(:,4:5),DATA(:,4:5));
%     
%     thresh = 7;
%     SD(SD==0)=3*1024;
%     [mask,mpos] = min(SD,[],1);
%     mergeid=mask<thresh;
%     class=1:1:length(mergeid);
%     ttDATA=[];
%     cnk=1;
%     for loopk=1:length(mergeid)
%         
%         if mergeid(loopk)>0
%            ttDATA(cnk,:)=round(max([DATA(loopk,:);DATA(mpos(loopk),:)]));
%             cnk=cnk+1;
%         end
%     end
%     [A,B]=unique(ttDATA,'rows');
%     kDATA=DATA(mergeid==0,:);
%     DATA=[kDATA;A];
    
    
    
figure()
% varv=1;
%   DATA=DATA(~(DATA(:,6)<varv & DATA(:,7)<varv & DATA(:,8)<varv),:);
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
% mult=[2 2 4];
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:11);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT);
DATA(:,6:11)=DATAT;
     
 %% positing final positives  
 
    tDATA=DATA;
         m=4;
         
          LCOLORC(:,:,1)=mult(1)*LCOLORC(:,:,1);
  LCOLORC(:,:,2)=mult(2)*LCOLORC(:,:,2);
  LCOLORC(:,:,3)=mult(3)*LCOLORC(:,:,3);
     LCOLOR4=LCOLORC;
     Imk2=imresize(LCOLOR4,m);
     Imk22=Imk2;
%     
%          figure
%   imagesc(Imk22);hold on
% 
%      for zin=1:size(tDATA,1)       
%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',2.5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',1.5,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% export_fig([Reshome3 filesep '_VPvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep '_VPvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep '_VPvector_direction_var' num2str(varv) '.png']);
%       close all    
%       imgid
    
% 

%% find exclusive positives
%     TH=1;
%     RG=(DATA(:,6)./DATA(:,9))>TH & (DATA(:,7)./DATA(:,10))>TH & (DATA(:,8)./DATA(:,11))<TH;
%     RGB=(DATA(:,6)./DATA(:,9))>TH & (DATA(:,7)./DATA(:,10))>TH & (DATA(:,8)./DATA(:,11))>TH;
% %     
%     tDATA=DATA(RG | RGB,:);
    
%         tDATA=DATA;
     
%% check conditions    
%     RMEAN=[];
%     GMEAN=[];
%     BMEAN=[];
    RSTD=[];
    GSTD=[];
    BSTD=[];
    Rdiff=[];
    Gdiff=[];
    Bdiff=[];
    for pn1=1:size(tDATA,1)
        for pn2=1:size(tDATA,1)
%                 RMEAN(pn1,pn2)=mean([tDATA(pn1,6) tDATA(pn2,6)]);
%                  GMEAN(pn1,pn2)=mean([tDATA(pn1,7) tDATA(pn2,7)]);
%                   BMEAN(pn1,pn2)=mean([tDATA(pn1,8) tDATA(pn2,8)]);
            
                RSTD(pn1,pn2)=max([tDATA(pn1,9) tDATA(pn2,9)]);
                 GSTD(pn1,pn2)=max([tDATA(pn1,10) tDATA(pn2,10)]);
                  BSTD(pn1,pn2)=max([tDATA(pn1,11) tDATA(pn2,11)]);
                                  
                Rdiff(pn1,pn2)=tDATA(pn1,6)-tDATA(pn2,6);
                 Gdiff(pn1,pn2)=tDATA(pn1,7)-tDATA(pn2,7);
                  Bdiff(pn1,pn2)=tDATA(pn1,8)-tDATA(pn2,8);
        end
    end
    
      SD=pdist2(tDATA(:,4:5),tDATA(:,4:5));
%     direction=(abs(Rdiff)+abs(Gdiff)+abs(Bdiff))-abs(Rdiff+Gdiff+Bdiff)>2;
    
    RD=pdist2(tDATA(:,6),tDATA(:,6));
    Rvarv=RSTD.*varv;
    RD(RD>=Rvarv)=255;
    RD(SD==0)=254;
    
    GD=pdist2(tDATA(:,7),tDATA(:,7));
    Gvarv=GSTD.*varv;
    GD(GD>=Gvarv)=255;
    GD(SD==0)=254;
    
    BD=pdist2(tDATA(:,8),tDATA(:,8));
    Bvarv=BSTD.*varv;
    BD(BD>=Bvarv)=255;
    BD(SD==0)=254;
%     
%     AD=pdist2(tDATA(:,6),tDATA(:,6))+pdist2(tDATA(:,7),tDATA(:,7))+pdist2(tDATA(:,8),tDATA(:,8));
%      AD(AD>varv)=255;
%     AD(AD==0)=254;
   
    DF=RD<254 & GD<254 & BD<254;
%     cp=1;
%     xyval=[];
%     for cp1=1:size(tDATA,1)
%         for cp2=1:size(tDATA,1)
%             if DF(cp1,cp2)==1
%                      xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
%                         xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
%                          xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
%                          xyval(cp,8:9)=[cp1 cp2];
%                            xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
%                            cp=cp+1;
%             end
%         end
%     end  
%       norm2=[size(LCOLOR4,1) size(LCOLOR4,2) 255 255 255];
% % %        norm2=[255 255 255];
% % %                  CO= tDATA(:,6:8);
% % %                    CO=CO./repmat(norm2,size(CO,1),1);
% % %                   D = single(pdist2(CO,CO,'euclidean'));
% % %                   D(DF==0)=9;
% % %                   D(D==0)=9;
  D=SD;
  D(SD==0)=10000;
  D(DF==0)=9000;
       cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end  
                 


%  LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%  LCOLORL=imread([Reshome3 filesep 'mosaicL.png']);
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
% LCOLORG(LCOLORL==0)=0; 
 
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);


 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
%  LCOLORCA=mult(1)*LCOLORCA;
%  LCOLORCB=mult(2)*LCOLORCB;
%  LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
%                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');

                           labeledImage = bwlabel(I2cpsegb>0, 4);
% LCOLORL

%  for cell=1:size(DATA,1)
%      
%      
%      
%      val=LCOLORL(DATA(cell,4),DATA(cell,5));
%      pos=LCOLORL==val;
%      
%      colorA(pos)=LCOLORCA(pos);
%       colorB(pos)=LCOLORCB(pos);
%        colorC(pos)=LCOLORCC(pos);
%      cell
%      
%  end
%  
%  CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
% CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
COF=CLC+0.2*CO;
% 
   CK=xyval(:,5:7)/32;
   CK(CK>1)=1;

     figure
     m=4;
  imagesc(imresize(COF,m));hold on
  
  
    for zin=1:size(tDATA,1)       
         text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,num2str(zin),'FontSize',2,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',1.5,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
%           num2str(round((tDATA(zin,11)))) ')'],'FontSize',1.5,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
  
     for zin=1:size(xyval,1)   
         
            
         if  xyval(zin,13)<500

%  text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(zin),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)))) ',' num2str(round((xyval(zin,6)))) ','...
%           num2str(round((xyval(zin,7)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');

   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.25) ; hold on
         end

     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome3 filesep 'Vvector_direction_var' num2str(varv+1)],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome3 filesep 'Vvector_direction_var' num2str(varv+1) '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[m*size(LCOLOR4,1) m*size(LCOLOR4,2)]);
  imwrite(uint8(Imk2),[Reshome3 filesep 'Vvector_direction_var' num2str(varv+1) '.png']);
      close all    

    end  
       
            
%               figure
% %     Imk2=imresize(LCOLOR4,m);
%   imagesc(Imk22);hold on
% 
%      for zin=1:size(center,1)       
%          if center(zin,2)<900
% 
%          text(m*tDATA(zin,5)+30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%       
%         if FLAG(zin)>1
%    h=scatter(m*tDATA(zin,5)+20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
%         end
% 
%          else         
%                  text(m*tDATA(zin,5)-30,m*tDATA(zin,4)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)-10,m*tDATA(zin,4)-10,[char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         if FLAG(zin)>1
%    h=scatter(m*tDATA(zin,5)-20,m*tDATA(zin,4)-100,10+2*FLAG(zin),CTNC(FLAG(zin),:),'filled',MTYPE{FLAG(zin)});
%         end
% 
%          end
% 
% %          if FLAGM(zin)==2
% %             
% %             NL=find(ismember(FLAG,FLAG(zin)));
% %             FL=NL(~ismember(NL,zin));
% %             
% %               U=m*tDATA(FL,5)-m*tDATA(zin,5);
% %    V=m*tDATA(FL,4)-m*tDATA(zin,4);
% %    Z=sqrt(U.^2+V.^2);   
% %         
% %           quiver(m*tDATA(zin,5),m*tDATA(zin,4),U,V,0,'color',CTNC(FLAG(zin),:),'maxheadsize',0.025,'linewidth',0.25) ; hold on
% %          end
%          
%              
%          
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep filename2 filesep filename2 '_VPMvector_direction_var' num2str(varv)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep filename2 filesep filename2 '_VPMvector_direction_var' num2str(varv) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(Imk2),[Reshome3 filesep filename2 filesep filename2 '_VPMvector_direction_var' num2str(varv) '.png']);
  
  
  
             