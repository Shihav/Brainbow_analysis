% clear all
% close all

clc

% Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiffv';
% Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\ImageJ';
% Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\MATLAB';

% Datahome='/import/pr_ciltex/TEST_BRAINBOW/Tiff';
% Reshome='/import/pr_ciltex/TEST_BRAINBOW/Imagej2';
% Reshome2='/import/pr_ciltex/TEST_BRAINBOW/Process';

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiffv';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\ImageJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Matlabv';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

RAK=[];
GAK=[];
BAK=[];

for imgid=5:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
        
               info = imfinfo(oriname);
        num_images = numel(info);
     
             ImgGR=[];
        kn=1;
        for k = 4:4:num_images
            I = imread(oriname, k);
              ImgGR(:,:,kn)=I;   
              kn=kn+1;
        end

        ImgR=[];
        kn=1;
        for k = 1:4:num_images
            I = imread(oriname, k);
              ImgR(:,:,kn)=I;   
              kn=kn+1;
        end
        
        ImgG=[];
        kn=1;
        for k = 2:4:num_images
            I = imread(oriname, k);
              ImgG(:,:,kn)=I;   
              kn=kn+1;
        end
        
        ImgB=[];
        kn=1;
        for k = 3:4:num_images
            I = imread(oriname, k);
              ImgB(:,:,kn)=I;   
              kn=kn+1;
        end
                
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2');
box=max(Imgsegk2,[],3); 
LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
 
         ImgGR(Imgsegk2==0)=0;
         ImgGRk=uint16(65535.*(ImgGR./4096));
         [Img11gr,zval11gr]=max(ImgGRk,[],3);
 
LCOLOR=imread([Reshome2 filesep filename2 filesep filename2 'FLmapC.png']);
LCOLOR2=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC2.png']);
LCOLOR3=imread([Reshome2 filesep filename2 filesep filename2 'FmaxV.png']);
LCOLOR5=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);

Comp=zeros(size(LCOLOR5));

                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;    
                          Comp(:,:,ind)=col_img2a;
                          end                           
CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
Compk=uint16(Comp)+0.3*CGO;                          
                          
imwrite(uint16(Compk),[Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
imwrite(uint16(Comp),[Reshome2 filesep filename2 filesep filename2 'Finalmap3.png']);
LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
imgid
pcells=unique(LABEL);
CA=[];

         for nk=2:length(pcells)            
            val=pcells(nk); 
            
            point=unique(box(LABEL==val));
            point(point==0)=[];
            
            RA=[];GA=[];BA=[];
            for cellm=1:length(point)            
                RA=[RA;ImgR(Imgsegk2==point(cellm))];
                 GA=[GA;ImgG(Imgsegk2==point(cellm))];
                  BA=[BA;ImgB(Imgsegk2==point(cellm))];                  
            end
            
            SA=RA+GA+BA;
            CA(nk-1,:)=[mean(RA./SA) mean(GA./SA) mean(BA./SA) median(RA./SA) median(GA./SA) median(BA./SA) std(RA./SA) std(GA./SA) std(BA./SA) mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)];
RAK=[RAK;RA];  
GAK=[GAK;GA];  
BAK=[BAK;BA];  
          nk
         end 
         
 save([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');   

   labeledImage1=LABEL;
       center=[];
       cellsL=unique(labeledImage1);

           for id=2:size(cellsL,1)
               tag=cellsL(id);

                                     object = labeledImage1 == tag;
                            CL=[];         
                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          CL(ind)=mean(col_img2a(object));    
                          end 
                                     
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              center(id-1,1:2)=cent;
                            center(id-1,3:5)=CL; 
%                              center(id-1,1)=id; 
                           
           end
           
%            center(:,3:5)=CA(:,13:15);
imgid           
  save([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');   
  
%   resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];
%     
%     if exist(resfile, 'file')==2
%   delete(resfile);
%     end
%      
%     MATT=[[1:size(center,1)]' center(:,1:2) CA(:,10:12)/16 CA(:,16:18)/16];
%     nps=length(unique(Imgsegk2))-2;
%     
%     clear cell
%     B = cell(size(MATT,1),size(MATT,2));
% for ii=1:size(MATT,1)
%     for jj=1:size(MATT,2)
%   B(ii,jj) = {MATT(ii,jj)};
%     end
% end
% 
%     BK = cell(size(MATT,1),size(MATT,2));
% for ii=1:size(MATT,1)
%     for jj=1:size(MATT,2)
%   BK(ii,jj+3) = {MATT(ii,jj)};
%     end
%       BK(ii,1) = {filename2};
%        BK(ii,2) = {imgid};
%        BK(ii,3) = {nps};
% end
% 
% BKA=[BKA;BK];
% A = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
% C=[A;BK];
% xlswrite(resfile,C,1,'A1') 
      
end

% AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
% C=[AK;BKA];
%    resfile = [Reshome2 filesep 'Result.xlsx'];
% 
%     if exist(resfile, 'file')==2
%   delete(resfile);
%     end
% 
% xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')
% 
save([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');    
% 
