clear all
close all
clc

cells2 = importdata('C:\ENS_CILTEX\Development paper final\MyExpt_P0Kif3aImage.csv');
                            vars = fieldnames(cells2);
                            for i = 1:length(vars)
                                assignin('base', ['cells2' vars{i}], cells2.(vars{i}));
                            end

dataW=[];
dataM=[];

n=1;
                            
for kin=11:19
    dataW(n)=str2double(cells2textdata(kin,2));
    
    n=n+1;
end

n=1;
                            
for kin=2:10
    dataM(n)=str2double(cells2textdata(kin,2));
    
    n=n+1;
end



%Concatenate them, and fill the empty ones with nans, keep in mind that you
%can do this much faster with the function padcat(available in mathworks, Copyright (c) 2009, Jos van der Geest)
DataArray=nan(size(15,1),2);
DataArray(1:9,1)=dataW;
DataArray(1:9,2)=dataM;

% answer=questdlg('Do you want to choose the colors from the palette?','','Yes','Use Default','Use Default');
% if strcmp('Yes',answer)
%     Colors=ColorCoder(2);
% else
    Colors=[0.75 0 0;0 0.75 0];
% end
%
% figure
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors);

figure
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);
title('Cell density','FontSize', 20,'FontName','Times')
% pbaspect([5,4,1])
                                                                                                                                                                                                                                 
%                                             xlim([-1 150])
                                            ylim([200 375])
%                                             xlabel('Area Bin (\mum^2)','FontSize', 17,'FontName','Times') % x-axis label
%                                             ylabel(['Number of cells (per 35785 \mum^2)'],'FontSize', 12,'FontName','Times') % y-axis label
                                            ylabel(['Number of cells (per 0.036 mm^2)'],'FontSize', 12,'FontName','Times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
%                                                 legend('boxoff')

  [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');



%                                                     title('P1 BETACAT SAS6 replicates','FontSize', 20,'FontName','Times');
                                                                                                        
%   text(1.65, 350,['Sig. diff. = ' num2str(H,'%d')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
  text(1.5, 370,['P value = ' num2str(P,'%f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
  text(1.5, 360,['KS stat = ' num2str(KSSTAT,'%f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','Times','fontsize',10,'FontName','Times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','Times','fontsize',10,'FontName','Times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     
  
export_fig(['Result2'],'-a2', '-m6','-p0.02','-png', '-r600');
% axis tight
  set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters epsFig
  
  
   print(['Result2'], '-dpdf', '-r600');  

