clear all
close all
clc

load countA.mat 'countA'

k=1;
rc=[];
temt=zeros(14,3);
for kin=[7 8 3 1 5 2]
    
    tem=countA{kin};
    
%   rc(k,1)=tem(9,3)/2;    
% %   rc(k,1)=tem(9,3)/2+tem(4,3)/2;  
%   rc(k,2)=tem(10,3)/3;
%   rc(k,3)=tem(11,3)/4;
rc(k,1)=kin;
rc(k,2)=tem(2,1);
rc(k,3)=tem(2,2);
rc(k,4)=tem(9,3)/2;
rc(k,5)=tem(10,3)/3+tem(11,3)/4;
rc(k,6)=rc(k,4)/rc(k,5);


   
  k=k+1;
  
end
  
%   temt=temt+tem;
  
  
   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'CountE14.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
% xlswrite(resfile3,SUMR,1,'A1')
% close all

MATN=rc;

myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Mosaic\tEPENDYNAL\tNon Ependymal\tdoubles\tTrip+Quad\tRATIO\t\n');

% tp={'Brainbow','Singles','Neural only','Very frequent','Remaining','Symmetric','Asymmteric','Doublet', 'Triplet', 'Quadruplet','double division'};

% fprintf(myfile,'Cell ID\tG mean\t\n');
% fprintf(myfile,'%g\t%g\n',MATN');


    for ii=1:size(MATN,1)
        for jj=1:size(MATN,2)
            if jj==1
                fprintf(myfile,'M');
        fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
            elseif jj>1 && jj<size(MATN,2)
       fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
            else
        fprintf(myfile,num2str(MATN(ii,jj))); 
        fprintf(myfile,'\t\n');
            end
        end
    end



% sa = size(MATN);
% fprintf(myfile,[repmat('%g\t',1,sa(2)-1) '%g\n'],MATN.');
fclose(myfile);
  
  
  
 k=1;
rc=[];
temt=zeros(14,3);
for kin=[13 15 17 18 14 16 12 11]
    
    tem=countA{kin};
    
%   rc(k,1)=tem(9,3)/2;    
% %   rc(k,1)=tem(9,3)/2+tem(4,3)/2;  
%   rc(k,2)=tem(10,3)/3;
%   rc(k,3)=tem(11,3)/4;
rc(k,1)=kin;
rc(k,2)=tem(2,1);
rc(k,3)=tem(2,2);
rc(k,4)=tem(9,3)/2;
rc(k,5)=tem(10,3)/3+tem(11,3)/4;
rc(k,6)=rc(k,4)/rc(k,5);


   
  k=k+1;
  
end
  
%   temt=temt+tem;
  
  
   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'CountE13.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
% xlswrite(resfile3,SUMR,1,'A1')
% close all

MATN=rc;

myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Mosaic\tEPENDYNAL\tNon Ependymal\tdoubles\tTrip+Quad\tRATIO\t\n');

% tp={'Brainbow','Singles','Neural only','Very frequent','Remaining','Symmetric','Asymmteric','Doublet', 'Triplet', 'Quadruplet','double division'};

% fprintf(myfile,'Cell ID\tG mean\t\n');
% fprintf(myfile,'%g\t%g\n',MATN');


    for ii=1:size(MATN,1)
        for jj=1:size(MATN,2)
            if jj==1
                fprintf(myfile,'M');
        fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
            elseif jj>1 && jj<size(MATN,2)
       fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
            else
        fprintf(myfile,num2str(MATN(ii,jj))); 
        fprintf(myfile,'\t\n');
            end
        end
    end



% sa = size(MATN);
% fprintf(myfile,[repmat('%g\t',1,sa(2)-1) '%g\n'],MATN.');
fclose(myfile);
