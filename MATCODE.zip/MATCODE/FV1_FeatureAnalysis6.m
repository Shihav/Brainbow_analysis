% clear all
% close all

clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\IMAGEJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

RAK=[];
GAK=[];
BAK=[];

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
        
               info = imfinfo(oriname);
        num_images = numel(info);
     
             ImgGR=[];
        kn=1;
        for k = 4:4:num_images
            I = imread(oriname, k);
              ImgGR(:,:,kn)=I;   
              kn=kn+1
        end

        ImgR=[];
        kn=1;
        for k = 1:4:num_images
            I = imread(oriname, k);
              ImgR(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgG=[];
        kn=1;
        for k = 2:4:num_images
            I = imread(oriname, k);
              ImgG(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgB=[];
        kn=1;
        for k = 3:4:num_images
            I = imread(oriname, k);
              ImgB(:,:,kn)=I;   
              kn=kn+1
        end
                
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2');
box=max(Imgsegk2,[],3); 
LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
 
         ImgGR(Imgsegk2==0)=0;
         ImgGRk=uint16(65535.*(ImgGR./4096));
         [Img11gr,zval11gr]=max(ImgGRk,[],3);
 
LCOLOR=imread([Reshome2 filesep filename2 filesep filename2 'FLmapC.png']);
LCOLOR2=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC2.png']);
LCOLOR3=imread([Reshome2 filesep filename2 filesep filename2 'FmaxV.png']);
LCOLOR5=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);

Comp=zeros(size(LCOLOR5));

                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;    
                          Comp(:,:,ind)=col_img2a;
                          end                           
CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
Compk=uint16(Comp)+0.6*CGO;                          
                          
imwrite(uint16(Compk),[Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
imwrite(uint16(Comp),[Reshome2 filesep filename2 filesep filename2 'Finalmap3.png']);
LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);

pcells=unique(LABEL);
CA=[];

         for nk=2:length(pcells)            
            val=pcells(nk); 
            
            point=unique(box(LABEL==val));
            point(point==0)=[];
            
            RA=[];GA=[];BA=[];
            for cell=1:length(point)            
                RA=[RA;ImgR(Imgsegk2==point(cell))];
                 GA=[GA;ImgG(Imgsegk2==point(cell))];
                  BA=[BA;ImgB(Imgsegk2==point(cell))];                  
            end
            
            SA=RA+GA+BA;
            CA(nk-1,:)=[mean(RA./SA) mean(GA./SA) mean(BA./SA) median(RA./SA) median(GA./SA) median(BA./SA) std(RA./SA) std(GA./SA) std(BA./SA) mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)];
RAK=[RAK;RA];  
GAK=[GAK;GA];  
BAK=[BAK;BA];  
          nk
         end 
         
 save([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');   

   labeledImage1=LABEL;
       center=[];
       cellsL=unique(labeledImage1);

           for id=2:size(cellsL,1)
               tag=cellsL(id);

                                     object = labeledImage1 == tag;
                            CL=[];         
                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          CL(ind)=mean(col_img2a(object));    
                          end 
                                     
                              s = regionprops(object,'centroid');
                              center(id-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
                            center(id-1,3:5)=CL; 
                           
           end
           
           center(:,3:5)=CA(:,13:15);
           
  save([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');   
  
       load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');
        load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');  
          
       wgt=1;
        norm=[size(LABEL,1) size(LABEL,2) wgt*65535 wgt*65535 wgt*65535];
           center2=center./repmat(norm,size(center,1),1);

            norm2=[1 1 1 1 1 1 1 1 1 4096 4096 4096 4096 4096 4096 4096 4096 4096];
           CA2=CA./repmat(norm2,size(CA,1),1);
           
           [COPx,COPy]=terncoords(CA2(:,4),CA2(:,5),CA2(:,6));
           COP=[COPx COPy];
           
           CO=[CA2(:,[4:6 13:18]) center2(:,[1:2])]; 
           
           RGBV=(CA(:,13:15)')/16;
           [CN, ptsCN, centresN] = dbscan(RGBV, 10, 1);
   
           DMAT=pdist2(RGBV',centresN');
[VID,CID]=min(DMAT,[],2);
           
     
                  DS = single(pdist2(CO(:,10:11),CO(:,10:11),'euclidean')); 
                  DC = single(pdist2(CO(:,1:9),CO(:,1:9),'euclidean')); 
                  
                  D = single(pdist2(CO,CO,'euclidean'));
                  D(D==0)=11;
                  DS(DS==0)=11;
                    DC(DC==0)=11;      
       cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
            cdiffval=[];
              sdiffval=[];
                diffval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     diffval(cp,1)=D(Aida(cp,1),Aida(cp,2));
                     sdiffval(cp,1)=DS(Aida(cp,1),Aida(cp,2));
                     cdiffval(cp,1)=DC(Aida(cp,1),Aida(cp,2));

                     xyval(cp,1:2)=[center(Aida(cp,1),1) center(Aida(cp,1),2)];
                        xyval(cp,3:4)=[center(Aida(cp,2),1) center(Aida(cp,2),2)];
                         xyval(cp,5:7)=[center(Aida(cp,1),3) center(Aida(cp,1),4) center(Aida(cp,1),5)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[center(Aida(cp,2),3) center(Aida(cp,2),4) center(Aida(cp,2),5)];

                 end   
 
      m=4;
     Imk2=imresize(LCOLOR4,m);
     
   figure
  imagesc(Imk2);hold on

     for zin=1:size(cosmat,1)       
         if  diffval(zin)<0.25      

   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[.75 .75 0],'maxheadsize',100/Z,'linewidth',0.5) ; hold on
         end
     end
     axis equal   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction4'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction4.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction4.png']);
                           
   save([Reshome2 filesep filename2 filesep filename2 'val.mat'],'diffval','cdiffval','sdiffval','xyval','CO');                          
       
  figure
      m=4;
     Imk2=imresize(LCOLOR4,m);
    
   imagesc(Imk2);hold on
   
     for zin=1:size(cosmat,1)                
     if xyval(zin,2)<900     
     text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     else         
           text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');     
     end   
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction'],'-a2', '-m4','-png', '-r300');

   figure
  
   imagesc(Imk2);hold on
   
     for zin=1:size(cosmat,1)      

     if xyval(zin,2)<=900
     
     text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
          num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 .95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     else
         
           text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
           
          text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[num2str(xyval(zin,8)), char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
          num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.9 .9 .9],'HorizontalAlignment','right','VerticalAlignment', 'top');
     
     end     
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction2'],'-a2', '-m4','-png', '-r300');
                 
  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR,1) 2*size(LCOLOR,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction.png']);  
  
    LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction2.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR,1) 2*size(LCOLOR,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction2.png']);
  
   close all
  resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];
    
    if exist(resfile, 'file')==2
  delete(resfile);
    end
    
    [V,D]=sort(xyval(:,8));
    xyval2=xyval(D,:);
      
    MATT=[xyval2(:,8) center(:,1:2) round(center(:,3:5)/255)];
    nps=length(unique(Imgseg))-2;
    
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end

    BK = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  BK(ii,jj+3) = {MATT(ii,jj)};
    end
      BK(ii,1) = {filename2};
       BK(ii,2) = {imgid};
       BK(ii,3) = {nps};
end
    
BKA=[BKA;BK];
A = {'Cell id','Center X', 'Center Y','Red','Green','Blue'};
C=[A;B];
xlswrite(resfile,C,1,'A1') 
      
    MATT=[xyval(:,8:9) xyval(:,1:2) round(xyval(:,5:7)/255) xyval(:,3:4) round(xyval(:,10:12)/255)];
    
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end
    
A = {'Cell id','Neighbour ID', 'Center X', 'Center Y','Red','Green','Blue','Neighbour X','Neighbour Y','Red N','Green N','Blue N'};
C=[A;B];
xlswrite(resfile,C,3,'A1')

zind=find(sdiffval<1024*0.2 & Rdiffval<((RT+(2*RM/65535)*RT)*65535) & Gdiffval<((RT+(2*GM/65535)*RT)*65535) & Bdiffval<((RT+(BM/65535)*RT)*65535) & cdiffval<((2*RT)*65535));
xyval=xyval(zind,:);

CP=1:2:size(xyval,1)-1;
xyval=xyval(CP,:);

    MATT=[xyval(:,8:9) xyval(:,1:2) round(xyval(:,5:7)/255) xyval(:,3:4) round(xyval(:,10:12)/255)];
    
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end
    
A = {'Cell id','Neighbour ID', 'Center X', 'Center Y','Red','Green','Blue','Neighbour X','Neighbour Y','Red N','Green N','Blue N'};
C=[A;B];
xlswrite(resfile,C,2,'A1')

end

AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue'};
C=[AK;BKA];

   resfile = [Reshome2 filesep 'Result.xlsx'];

    if exist(resfile, 'file')==2
  delete(resfile);
    end

xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')

save([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');    

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);

DATA=cells2.data.Sheet1;
% DATA(end-1:end,:)=[];
ID=DATA(:,1);

DATA(:,1)=[];

% DATA=DATA(1:28,:)

figure()

    valn=DATA(:,5);
     valr=DATA(:,6);
     vals=DATA(:,7);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATA(n,5:7)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution 4');
print([Reshome2 filesep  'Color distribution 4'], '-dpng', '-r300'); 
% print(['aPerf_terplot_synTissue'], '-dpdf', '-r300');
% print(['aPerf_terplot_synTissue'], '-dpng', '-r300');

FP=DATA(DATA(:,2)==1,1);

% pos=[];
val=[];
for pid=1:length(FP)
val(pid)=sum(ID==pid);
% val(pid)=DATA(pos(pid),2);
end

figure
scatter(FP,val) 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
colk=pink(length(FP))/1.25;

h=scatter(FP,val,90*(mat2gray(val)+0.5),colk,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
 colormap((pink));  %# Change the colormap to gray (so higher values are
    %   colorbar                       %#   black and lower values are white)
    caxis manual
    caxis([1 length(FP)])
    colorbar

for pid=1:length(FP)
   text(FP(pid)+7,val(pid)+1,num2str(val(pid)/FP(pid),'%.2f'),'FontSize',9,'FontName','Times','Color',colk(pid,:),'HorizontalAlignment','left','VerticalAlignment', 'top');
end
 xlabel('FoxJ1 positives','FontSize', 20,'FontName','Times');
                                            ylabel('Brainbow positives', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Rate of Brainbow positive cells'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 5'], '-dpng', '-r300'); 


 figure()
 [nc,hc]=hist(DATA(:,5),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'r','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(DATA(:,6),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'g','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(DATA(:,7),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'b','LineStyle','-','LineWidth',2);
 
  hold on
  [hleg1, hobj1]=legend(['STD = ' num2str(std(DATA(:,5)))],['STD = ' num2str(std(DATA(:,6)))],['STD = ' num2str(std(DATA(:,7)))],'Location','northeast');
legend('boxoff')

set(hleg1,'FontSize',16,'FontName','Times');  

xlim([0 255])

  xlabel('Spectrum','FontSize', 20,'FontName','Times');
                                            ylabel('Probability', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution'], '-dpng', '-r300'); 


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter(DATA(:,5),DATA(:,6),50*(mat2gray(DATA(:,7))+0.5),DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution 2'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 2'], '-dpng', '-r300'); 


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter3(DATA(:,5),DATA(:,6),DATA(:,7),sum(DATA(:,5:7),2)/5,DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
view(38,18)

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution 3'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 3'], '-dpng', '-r300'); 

