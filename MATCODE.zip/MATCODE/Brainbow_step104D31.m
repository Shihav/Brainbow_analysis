clear all
close all

clc
mnk{3}=[2703 1138 2512 504];
mnk{3}=[3139 785 2245 854];


load multa multa

% for idx=[3]
% 
% loadaddress;
% 
% % mkdir(Reshome3);
% 
% d=dir(fullfile(Datahome,'*.tif*'));
% Types={d.name}; 
%  
% load_pic
% create_HM
% HM=round(HM);
% shift2=HM;
% 
% shift=fliplr(shift2);
% 
% dimm1=max(shift2(:,1))+DY;
% dimm2=max(shift2(:,2))+DX;
% 
% shift=[shift(:,1)+DX shift(:,2)+DY];
% 
% m=1;
% mn=mnk{3};
% 
% A=imread([Reshome3 filesep 'PmosaicO2.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'RAW_plus.png']);
% 
% A=imread([Reshome3 filesep 'NmosaicO2.png']);
% B1=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'RAW_minus.png']);
% 
% imwrite(B+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'RAW_pm.png']);
% 
% 
% 
% % pic=[];
% % pic1=[];
% % load_pic;
% % for worklistn=1:numel(Types)
% %      filename2=strrep(Types{worklistn},'.tif','');    
% %      LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL_AC.png']);
% %      pic1{worklistn}=LCOLOR4;
% % end
% % for j=numel(Types):-1:1
% %                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% % end
% % pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% % imwrite(pic,[Reshome3 filesep 'ALL_ACR.png']);
% % A=pic;
% % B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% % imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_ACR' '.png']);
% % 
% % 
% % pic=[];
% % pic1=[];
% % load_pic;
% % for worklistn=1:numel(Types)
% %      filename2=strrep(Types{worklistn},'.tif','');    
% %      LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL_FC.png']);
% %      pic1{worklistn}=LCOLOR4;
% % end
% % for j=numel(Types):-1:1
% %                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% % end
% % pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% % imwrite(pic,[Reshome3 filesep 'ALL_FCR.png']);
% % A=pic;
% % B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% % imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_FCR' '.png']);
% % 
% % pic=[];
% % pic1=[];
% % load_pic;
% % for worklistn=1:numel(Types)
% %      filename2=strrep(Types{worklistn},'.tif','');    
% %      LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL_RC.png']);
% %      pic1{worklistn}=LCOLOR4;
% % end
% % for j=numel(Types):-1:1
% %                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% % end
% % pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% % imwrite(pic,[Reshome3 filesep 'ALL_RCR.png']);
% % A=pic;
% % B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% % imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RCR' '.png']);
% 
% 
% inp=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RCR' '.png']); 
% imgid=idx;       
% mult=multa;
% for ind=1:3
% col_img2a=mult(imgid,ind)*inp(:,:,ind);
% inp(:,:,ind)=col_img2a;
% end 
%           
% imwrite(inp,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
%         
%         
% inp2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_FCR' '.png']); 
%            
% mult=multa;
% for ind=1:3
% col_img2a=mult(imgid,ind)*inp2(:,:,ind);
% inp2(:,:,ind)=col_img2a;
% end
%         
% imwrite(inp2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_FC' '.png']);   
%   
% imwrite(max(cat(4,inp,inp2),[],4),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_AC' '.png']);  
% 
% A=imread([Reshome3 filesep 'FOXLM.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'FOXLM' '.png']);
% 
% C=bwlabel(B>0,8);
% imwrite(C,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'FLABEL' '.png']);
% 
% Img13=C;
% objectbor_map=(Img13-imerode(Img13,ones(5)))>0;
% imwrite(objectbor_map,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'BORDER_F.png']);
% 
% A=imread([Reshome3 filesep 'mosaicG.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% 
% cdata=B; 
% mult=[1 1 1];
% for ind=1:2
% col_img2a=mult(ind)*cdata(:,:,ind);
% %                           col_img2a(LABELM==0)=0;
% col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'FSEG.png']);
% 
% A=imread([Reshome3 filesep 'PFinalmapM2.png']);
% % [LABELM,NUM] = bwlabel(LCOLORL>0,8);
% % A=LABELM;
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'FLABEL_S' '.png']);
% 
% Img13=B;
% objectbor_map=(Img13-imerode(Img13,ones(5)))>0;
% imwrite(objectbor_map,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'BORDER_F_S.png']);
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_FC' '.png']);
% mult=[1 1 1];
% for ind=1:3
% col_img2a=mult(ind)*cdata(:,:,ind);
% %                           col_img2a(LABELM==0)=0;
% col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'FSEG_S.png']);
% %  
% LABELM=imread([Reshome3 filesep 'NFinalmapM2.png']);
% % [LABELM,NUM] = bwlabel(LCOLORL>0,8);
% A=LABELM;
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'NLABEL_S' '.png']);
% 
% Img13=B;
% objectbor_map=(Img13-imerode(Img13,ones(5)))>0;
% imwrite(objectbor_map,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NBORDER_F_S.png']);
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
% mult=[1 1 1];
% for ind=1:2
% col_img2a=mult(ind)*cdata(:,:,ind);
% %                           col_img2a(LABELM==0)=0;
% col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NFSEG.png']);
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
% mult=[1 1 1];
% for ind=1:3
% col_img2a=mult(ind)*cdata(:,:,ind);
% col_img2a(B==0)=0;
% col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NFSEG_S.png']);
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RCR' '.png']);
% 
% 
% [LABELM,gradmag,adapt_image]=color_segF(cdata);
% 
% imwrite(uint16(65535*mat2gray(gradmag)),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3GRAD' '.png']);
% imwrite(uint16(65535*mat2gray(adapt_image)),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3ADAPT' '.png']);
% 
% 
% % LABELM2=imdilate(LABELM,ones(7,7));
% % imwrite(LABELM,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NFinalmapM.png']);
% % imwrite(LABELM2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NFinalmapM2.png']);
% 
% 
% 
% 
% A=imread([Reshome3 filesep 'NFinalmapM2.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NFinalmapM2.png']);
% A=imread([Reshome3 filesep 'NFinalmapM.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NFinalmapM.png']);
% 
% 
% A=imread([Reshome3 filesep 'PFinalmapM2.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'FLABEL_S' '.png']);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PFinalmapM2.png']);
% A=imread([Reshome3 filesep 'PFinalmapM.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PFinalmapM.png']);
% 
% A=imread([Reshome3 filesep 'PmosaicOP.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PmosaicOP.png']);
% A=imread([Reshome3 filesep 'PmosaicO2.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PmosaicO2.png']);
% 
% A=imread([Reshome3 filesep 'NmosaicOP.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NmosaicOP.png']);
% A=imread([Reshome3 filesep 'NmosaicO2.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NmosaicO2.png']);
% 
% 
% 
% 
% B=LABELM2;
% 
% Img13=B;
% objectbor_map=(Img13-imerode(Img13,ones(5)))>0;
% imwrite(objectbor_map,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NBORDER_F_S2.png']);
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
% mult=[1 1 1];
% for ind=1:2
% col_img2a=mult(ind)*cdata(:,:,ind);
% %                           col_img2a(LABELM==0)=0;
% col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NFSEG2.png']);
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
% mult=[1 1 1];
% for ind=1:3
% col_img2a=mult(ind)*cdata(:,:,ind);
% col_img2a(B==0)=0;
% col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NFSEG_S2.png']);
% 
% NL=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'NLABEL_S' '.png']);
% NL=imdilate(NL,ones(1,1));
% B(NL>0)=0;
% 
% BW2 = bwareaopen(B, 500);
% classmap=bwlabel(BW2);
% pcells=unique(classmap);
% 
%          for nk=2:length(pcells)  
%               val=pcells(nk);  
%             object2 = classmap==val;
%             sizek=sum(sum(object2));      
%                                          
%                                              [X,Y]=find(object2==1);
%     
%                                           [CH,Ak]= convhull(X,Y);  
%                                                                                     
%                                           if (abs(double(Ak)-double(sizek))/double(sizek)) >0.25 
%                                                 classmap(object2)=0;
% 
%                                           end
%                                           
%             nk ;
%          end
% 
% 
% 
% B(classmap==0)=0;
% 
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NEXTRAB.png']);
% 
% 
% cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
% mult=[1 1 1];
% for ind=1:3
% col_img2a=mult(ind)*cdata(:,:,ind);
% col_img2a(B==0)=0;
% % col_img2a(objectbor_map>0)=65535;
% cdata(:,:,ind)=col_img2a;
% end
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'NEXTRA.png']);
% 
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);
% MINUSG=rgb2gray(MINUS);
% 
% EXTRA=cdata;
% EXTRA(MINUSG>0)=0;
% 
% imwrite(MINUS+EXTRA,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus2' '.png']);
% 
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_R' '.png']);
% MINUSG=rgb2gray(MINUS);
% 
% EXTRA=cdata;
% EXTRA(MINUSG>0)=0;
% 
% imwrite(MINUS+EXTRA,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_R2' '.png']);
% 
% MINUS1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_R2' '.png']);
% MINUS2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RP' '.png']);
% imwrite(MINUS1+MINUS2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RP2' '.png']);
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLWO' '.png']);
% MINUSG=rgb2gray(MINUS);
% 
% EXTRA=cdata;
% EXTRA(MINUSG>0)=0;
% 
% imwrite(MINUS+EXTRA,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLWO2' '.png']);
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLWO2' '.png']);
% G=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) 'G' '.png']);
% 
% imwrite(MINUS+0.5*G,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLWOG2' '.png']);
% 
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLO' '.png']);
% MINUSG=rgb2gray(MINUS);
% 
% EXTRA=cdata;
% EXTRA(MINUSG>0)=0;
% 
% imwrite(MINUS+EXTRA,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLO2' '.png']);
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLO2' '.png']);
% G=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) 'G' '.png']);
% 
% imwrite(MINUS+0.5*G,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLOG2' '.png']);
% 
% MINUS=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '' '.png']);
% MINUSG=rgb2gray(MINUS);
% 
% EXTRA=cdata;
% EXTRA(MINUSG>0)=0;
% imwrite(MINUS+EXTRA,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_2' '.png']);
% 
% 
% typ=1;
% ang=0;
% 
% % cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_FCR' '.png']);
% % imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PmosaicO' '.png']);
% % imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PmosaicO2' '.png']);
% % 
% % cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RCR' '.png']);
% % imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NmosaicO' '.png']);
% % imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NmosaicO2' '.png']);
% 
%  A=imread([Reshome3 filesep 'ZMAP.png']);  
%  B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
%  imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'ZMAP' '.png']);
%   A=imread([Reshome3 filesep 'NZPOSmosiac.png']);  
%  B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
%  imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'NZPOSmosiac' '.png']);
%  
%    A=imread([Reshome3 filesep 'PZPOSmosiac.png']);  
%  B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
%  imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PZPOSmosiac' '.png']);
%  
%     A=imread([Reshome3 filesep 'PZPOSmosiac.png']);  
%  B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
%  imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'PZPOSmosiac' '.png']);
%  
%  cdata=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) 'G' '.png']);
% imwrite(cdata,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'mosaicG' '.png']);
% %  
% end


for idx=3
    
    idxt=idx;
    
    loadaddress2;
    
    loadaddress;

% mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 
 
load_pic
create_HM
HM=round(HM);
shift2=HM;

shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];

m=1;
mn=mnk{3};

A=imread([Reshome3 filesep 'PmosaicOP.png']);
LCOLORC=imread([Reshome3 filesep 'PmosaicOP.png']);
LCOLORC=LCOLORC(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);

 LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);
 LCOLORL=LCOLORL(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
 
 LCOLORZ=imread([Reshome3 filesep 'ZMAP.png']); 
 LCOLORZ=LCOLORZ(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
 LCOLORZPOS=imread([Reshome3 filesep 'PZPOSmosiac.png']); 
 LCOLORZPOS=LCOLORZPOS(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
 
 
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
 ImgRZ=LCOLORZPOS(:,:,1);
 ImgGZ=LCOLORZPOS(:,:,2);
 ImgBZ=LCOLORZPOS(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

% imwrite(uint16(LABELM),[Reshome3 filesep 'NmosaicLM.png'])


% LABEL=LABELM;
LABEL=imerode(LABELM,ones(1,1));

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];

% DATA=PDATA;
DATA=[];
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;      
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
%               [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));
              
% center(nk-1,3:8)=[mean(ImgR(object))/255 mean(ImgG(object))/255 mean(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 
center(nk-1,3:8)=[median(ImgR(object))/255 median(ImgG(object))/255 median(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 

                            
                            %             CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
%             CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
 DATA(nk-1,1:11)=[1 nk-1 length(pcells)-1 center(nk-1,1:8)];
%  
%  
 Zcell=median([ImgRZ(object);ImgGZ(object);ImgBZ(object)]);
 Zapi=median([LCOLORZ(object)]);
 
 
 DATA(nk-1,12)=round((Zcell-Zapi)/256);
 
 DATA(nk-1,13)=round(Zapi/256);


          nk
         end 
         
         PDATA=DATA;
         
save(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT' filesep 'Pall3.mat'],'PDATA'); 
idx

typ=1;
ang=0;

LCOLORC=imread([Reshome3 filesep 'NmosaicOP.png']);
LCOLORC=LCOLORC(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);

 LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);
 LCOLORL=LCOLORL(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
 
 LCOLORZ=imread([Reshome3 filesep 'ZMAP.png']); 
 LCOLORZ=LCOLORZ(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
 LCOLORZPOS=imread([Reshome3 filesep 'NZPOSmosiac.png']); 
 LCOLORZPOS=LCOLORZPOS(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
 
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
 ImgRZ=LCOLORZPOS(:,:,1);
 ImgGZ=LCOLORZPOS(:,:,2);
 ImgBZ=LCOLORZPOS(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

% imwrite(uint16(LABELM),[Reshome3 filesep 'NmosaicLM.png'])


% LABEL=LABELM;
LABEL=imerode(LABELM,ones(1,1));

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];
% DATA=NDATA;
DATA=[];
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;      
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
%               [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));
              
% center(nk-1,3:8)=[mean(ImgR(object))/255 mean(ImgG(object))/255 mean(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 
center(nk-1,3:8)=[median(ImgR(object))/255 median(ImgG(object))/255 median(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 

                            
                            %             CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
%             CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
 DATA(nk-1,1:11)=[1 nk-1 length(pcells)-1 center(nk-1,1:8)];
 
 
 Zcell=median([ImgRZ(object);ImgGZ(object);ImgBZ(object)]);
 Zapi=median([LCOLORZ(object)]);
 
 
 DATA(nk-1,12)=round(Zcell/256)-25;
 
 DATA(nk-1,13)=round(Zapi/256);


          nk
         end 
         
         NDATA=DATA;
         
save(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT' filesep 'Nall3.mat'],'NDATA'); 
idx



end