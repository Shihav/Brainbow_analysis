% clear all
% close all
% 
% clc
PmatA=[]

% for limit=[0.01 0.001]
nt=0;
for idx=[1 2 3 5 7 8]
    
    nt=nt+1;
    
%     mkdir([FINR filesep 'RESULT_M' num2str(idx)]);
for cutp=[0]
    
for BTH=[80]



loadaddress;
load([Reshome3 filesep 'ncoupF_' num2str(cutp) '_' num2str(BTH) '.mat'],'ncoupA');  
% load([Reshome3 filesep 'ncoupA.mat'],'ncoupA');  

HTHid=0;
Pmat=[];
Rmat=[];
RRmat=[];
% for HTH=[8]
%     HTHid=HTHid+1;
%     STHid=0;
% for STH=[110]  
%     STHid=STHid+1;
%     ncoup=[];

 ncoup=ncoupA{4,5};
 
%  Rmat(HTHid,STHid)=ncoup(1);
%  
%  RRmat(HTHid,STHid)=mean(ncoup(2:101));
%  
% [h,p]=ttest2(ncoup(1),ncoup(2:101)) 

% Pmat(HTHid,STHid)=p;

PmatA(nt)=ncoup(1);
 
% end
% end

% PmatA=[PmatA;Pmat];

 
end

end

end

sum(PmatA.*[746 275 834 107 370 407])./sum([746 275 834 107 370 407])

% save([FINR filesep 'P-MapA.mat'],'PmatA');

% close all

% end

% load(['G:\Marie_2016_NEW\Combined' filesep 'P-MapA.mat'],'PmatA');
% 
% Box=PmatA(1:45,2:5);
% [A,LS]=min(Box);
% min(PmatA(46:90,2:5))
% min(PmatA(91:135,2:5))
% min(PmatA(181:225,2:5))
% 
% 
% close all