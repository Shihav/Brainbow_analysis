clear all
close all

clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\IMAGEJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB';
Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB2';
% Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\FINAL';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);
 


DATA=cells2.data.Sheet1;

 figure()
h=scatter(DATA(:,6),DATA(:,9),25,[DATA(:,6)/255 0*DATA(:,6)/255 0*DATA(:,6)/255],'filled');
xlim([0 256]);
ylim([0 128]);
 xlabel('Mean','FontSize', 20,'FontName','Times');
                                            ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Mean vs Standard deviation - RED'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Mean vs Standard deviation - RED'], '-dpng', '-r300'); 

 figure()
h=scatter(DATA(:,7),DATA(:,10),25,[0*DATA(:,7)/255 DATA(:,7)/255 0*DATA(:,7)/255],'filled');
xlim([0 256]);
ylim([0 128]);
 xlabel('Mean','FontSize', 20,'FontName','Times');
                                            ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Mean vs Standard deviation - GREEN'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Mean vs Standard deviation - GREEN'], '-dpng', '-r300'); 

 figure()
h=scatter(DATA(:,8),DATA(:,11),25,[0*DATA(:,8)/255 0*DATA(:,8)/255 DATA(:,8)/255],'filled');
xlim([0 256]);
ylim([0 128]);
 xlabel('Mean','FontSize', 20,'FontName','Times');
                                            ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Mean vs Standard deviation - BLUE'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Mean vs Standard deviation - BLUE'], '-dpng', '-r300'); 



DATAB=DATA(:,6:8);
DATAB=DATAB+5;
DATAB(DATAB>255)=255;

DATA(:,9:11)=DATA(:,9:11);

figure()

    valn=DATA(:,6);
     valr=DATA(:,7);
     vals=DATA(:,8);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Raw ternary plot');
print([Reshome3 filesep  'Raw ternary plot'], '-dpng', '-r300'); 

figure()

    valn=DATAB(:,1);
     valr=DATAB(:,2);
     vals=DATAB(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATAB(n,1:3)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATAB(n,1:3)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Brighten ternary plot');
print([Reshome3 filesep  'Brighten ternary plot'], '-dpng', '-r300'); 


figure()

    valn=DATA(:,6)./DATA(:,9);
     valr=DATA(:,7)./DATA(:,10);
     vals=DATA(:,8)./DATA(:,11);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',mean(DATA(n,9:11),2)/2.5,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Adjusted ternary plot');
print([Reshome3 filesep  'Adjusted ternary plot'], '-dpng', '-r300'); 





% DATA(end-1:end,:)=[];
ID=DATA(:,1);

% DATA(:,1)=[];
FP=unique(ID);

% pos=[];
val=[];
FJ=[]
for pid=1:length(FP)
val(pid)=sum(ID==pid);
FJ(pid)=mean(DATA(ID==pid,2));
% val(pid)=DATA(pos(pid),2);
end



figure()
 [nc,hc]=hist(RAK/16,linspace(0,255,25));
 nc=nc/sum(nc); 
 plot(hc,nc,'r','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(GAK/16,linspace(0,255,25));
 nc=nc/sum(nc); 
 plot(hc,nc,'g','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(BAK/16,linspace(0,255,25));
 nc=nc/sum(nc); 
 plot(hc,nc,'b','LineStyle','-','LineWidth',2);
 
  hold on
  [hleg1, hobj1]=legend(['STD = ' num2str(std(RAK/16))],['STD = ' num2str(std(GAK/16))],['STD = ' num2str(std(BAK/16))],'Location','northeast');
legend('boxoff')

set(hleg1,'FontSize',16,'FontName','Times');  

xlim([0 255])

  xlabel('Spectrum','FontSize', 20,'FontName','Times');
                                            ylabel('Probability', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['RGB color Spectrum'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Color Spectrum'], '-dpng', '-r300'); 



figure
h=bar([FJ-val;val]','stacked');
colk=bone(length(FP))/1.25;
ylim([0 1000]);
y=FJ;
x=1:length(FP);
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(val(i1),'%0.0f'),'Color',[0.4 0.1 0.1],...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end

 colormap([0.8 0.8 0.8; 0.8 0.2 0.2]);  %# Change the colormap to gray (so higher values are
    %   colorbar                       %#   black and lower values are white)
    caxis manual
    caxis([1 2])
legend('FOXJ1','Brainbow+FoXJ1');
xlabel('Image ID','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Brainbow count'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Brainbow count'], '-dpng', '-r300');                        
                        

figure
hBar=bar(FP,100*(val./FJ)',0.8); 
colk=bone(length(FP))/1.25;

                        hBarChildren = get(hBar, 'Children');
                        index = 1:length(FP);
                        set(hBarChildren, 'CData', index);
                        colormap(colk);

y=100*(val./FJ)';
x=1:length(FP);
for i1=1:numel(y)
    text(x(i1)+0.4,y(i1)+0.65,num2str(y(i1),'%0.2f'),'rotation', 90,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end

xlabel('Image ID','FontSize', 20,'FontName','Times');
                                            ylabel('Brainbow (%)', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Brainbow efficiency'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Brainbow efficiency'], '-dpng', '-r300');        


TH=1.5;
DATAR=DATA(:,6:8);

R=sum((DATA(:,6)./DATA(:,9))>TH & (DATA(:,7)./DATA(:,10))<TH & (DATA(:,8)./DATA(:,11))<TH)
G=sum((DATA(:,6)./DATA(:,9))<TH & (DATA(:,7)./DATA(:,10))>TH & (DATA(:,8)./DATA(:,11))<TH)
B=sum((DATA(:,6)./DATA(:,9))<TH & (DATA(:,7)./DATA(:,10))<TH & (DATA(:,8)./DATA(:,11))>TH)
RG=sum((DATA(:,6)./DATA(:,9))>TH & (DATA(:,7)./DATA(:,10))>TH & (DATA(:,8)./DATA(:,11))<TH)
GB=sum((DATA(:,6)./DATA(:,9))<TH & (DATA(:,7)./DATA(:,10))>TH & (DATA(:,8)./DATA(:,11))>TH)
BR=sum((DATA(:,6)./DATA(:,9))>TH & (DATA(:,7)./DATA(:,10))<TH & (DATA(:,8)./DATA(:,11))>TH)
RGB=sum((DATA(:,6)./DATA(:,9))>TH & (DATA(:,7)./DATA(:,10))>TH & (DATA(:,8)./DATA(:,11))>TH)
A=sum([R G B RG GB BR RGB]);

   figure() 
                   
                    hBar= bar([1:7],[R G B RG GB BR RGB],0.6);
colk=[1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; 1 1 1]/1.3;
                        hBarChildren = get(hBar, 'Children');
                        index = 1:7;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);
                        ylim([0 140])
                        
                        y=[R G B RG GB BR RGB];
x=[1:7];
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.2,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
                        
 set(gca,'XTick',1:7)
 ax = gca;
 set(ax,'XTickLabel',{'R', 'G', 'B','RG', 'GB', 'BR','RGB'});
                       
                        
 xlabel('Color combinations','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['RGB count'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'RGB count'], '-dpng', '-r300');                        
                        

              figure          
                        
                        
%                         X = categorical({'North','South','North','East','South','West'});
% explode = {'North','South'};
hBar=pie([R G B RG GB BR RGB],[0 0 1 0 0 0 1],{['R = ' num2str(R) ' (' num2str(100*R./A,'%.2f') '%)'],['G = ' num2str(G) ' (' num2str(100*G./A,'%.2f') '%)'],...
    ['B = ' num2str(B) ' (' num2str(100*B./A,'%.2f') '%)'],['RG = ' num2str(RG) ' (' num2str(100*RG./A,'%.2f') '%)'],['GB = ' num2str(GB) ' (' num2str(100*GB./A,'%.2f') '%)'],...
    ['BR = ' num2str(BR) ' (' num2str(100*BR./A,'%.2f') '%)'],['RGB = ' num2str(RGB) ' (' num2str(100*RGB./A,'%.2f') '%)']})
colormap(colk)             

h = hBar;

hText = findobj(h,'Type','text');
textPositions_cell = get(hText,{'Position'}); % cell array
textPositions = cell2mat(textPositions_cell); % numeric array
textPositions = textPositions * 1.1; % scale position
set(hText,{'Position'},num2cell(textPositions,[3,2])) % set new position

%  xlabel('Color combinations','FontSize', 20,'FontName','Times');
%                                             ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['RGB efficiency'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'RGB efficiency'], '-dpng', '-r300'); 


figure

FKK=DATA(DATA(:,3)==1,2);
colk=pink(length(FKK))/1.2;
h=scatter(FKK,val'./FKK,90*(mat2gray(val)+0.5),colk,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
 colormap((pink));  %# Change the colormap to gray (so higher values are
    %   colorbar                       %#   black and lower values are white)
    caxis manual
    caxis([1 length(FP)])
    colorbar


for pid=1:length(FP)
   text(FP(pid)+7,val(pid)+1,num2str(val(pid)/FP(pid),'%.2f'),'FontSize',9,'FontName','Times','Color',colk(pid,:),'HorizontalAlignment','left','VerticalAlignment', 'top');
end
 xlabel('FoxJ1 positives','FontSize', 20,'FontName','Times');
                                            ylabel('Brainbow positives', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Rate of Brainbow positive cells'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Rate of Brainbow positive cells'], '-dpng', '-r300'); 



 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter3(DATA(:,6),DATA(:,7),DATA(:,8),sum(DATA(:,6:8),2)/5,DATA(:,6:8)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
view(38,18)

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['3D Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  '3D Color distribution'], '-dpng', '-r300'); 

close all

 figure()
DD=[DATA(:,6)./DATA(:,9) DATA(:,7)./DATA(:,10) DATA(:,8)./DATA(:,11)]; 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter3(DATA(:,6)./DATA(:,9),DATA(:,7)./DATA(:,10),DATA(:,8)./DATA(:,11),mean(DD,2)/0.05,DATA(:,6:8)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
view(38,18)

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Adjusted 3D Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Adjusted 3D Color distribution'], '-dpng', '-r300'); 

close all

for imgid=1:numel(Types)
  
     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif',''); 
     mkdir([Reshome3 filesep  filename2]);
        
       tDATA=DATA(ID==imgid,:);

figure()

    valn=tDATA(:,6);
     valr=tDATA(:,7);
     vals=tDATA(:,8);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,6:8)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,3)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution ternary');
print([Reshome3 filesep  filename2 filesep filename2 'Color distribution ternary'], '-dpng', '-r300'); 


figure()

    valn=tDATA(:,6)./tDATA(:,9);
     valr=tDATA(:,7)./tDATA(:,10);
     vals=tDATA(:,8)./tDATA(:,11);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,6:8)./255);hold on; 
         [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,3)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Adjusted ternary plot');
print([Reshome3 filesep  filename2 filesep filename2 'Adjusted ternary plot'], '-dpng', '-r300'); 


close all

end

