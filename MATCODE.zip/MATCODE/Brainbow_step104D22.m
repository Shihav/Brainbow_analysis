clear all
close all

clc

for idx=[3]

loadaddress;

load([Reshome2 filesep 'Pall.mat'],'PDATA');

% mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

% for imgid=1:numel(Types)
%        
%      filename=Types{imgid};
%      filename2=strrep(filename,'.tif','');     
%         oriname=[Datahome filesep filename2 '.tif'];
% %          mkdir([[Reshome2 filesep filename2]]);
%      segname=[Reshome filesep filename2 '4-Watershed.tif'];
%      
% load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB'); 
% 
% 
% if idx>7
% 
% load([Reshome2 filesep filename2 filesep filename2 'Imgsegk4.mat'],'Imgsegk4');  
% 
% Imgseg=Imgsegk4;
% 
% else
% 
% % save([Reshome2 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg','-v7.3');  
% load([Reshome2 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg'); 
% 
% end
% 
%   
%      ImgR(Imgseg==0)=0;
%      ImgG(Imgseg==0)=0;
%      ImgB(Imgseg==0)=0;   
% 
% [Img11r,zval11r]=max(ImgR,[],3);
% [Img11g,zval11g]=max(ImgG,[],3);
% [Img11b,zval11b]=max(ImgB,[],3);
% 
% CO=uint16(cat(3,zval11r,zval11g,zval11b)); 
% 
% C=CO;
% imwrite(C*256,[Reshome2 filesep filename2 filesep filename2 'PZPOS.png']); 
%  
% % LABELM=imread([Reshome2 filesep filename2 filesep filename2 'PFinalmapM.png']);
% 
% % ZMAP=imread([Reshome2 filesep filename2 filesep filename2 'ZMAP.png']);
% 
% %    LCOLOR5=C;                                    
% % mult=[1 1 1];
% %                           for ind=1:3
% %                           col_img2a=mult(ind)*LCOLOR5(:,:,ind);
% %                           col_img2a(LABELM==0)=0;  
% % %                           col_img2a(objectbor_map==1)=65535;    
% %                           Compb(:,:,ind)=col_img2a;
% %                           end  
% % imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'POverlayM3.png']); 
% 
% close all
% clc
% 
% imgid
% idx
% end

 
load_pic
create_HM
HM=round(HM);
shift2=HM;


shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];

         m=4;

% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'PZPOS.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'PZPOSmosiac.png']);



typ=1;
ang=0;

 LCOLORC=imread([Reshome3 filesep 'PmosaicOP.png']);
 LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);
 
 LCOLORZ=imread([Reshome3 filesep 'ZMAP.png']);  
 LCOLORZPOS=imread([Reshome3 filesep 'PZPOSmosiac.png']); 
 
 
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
 ImgRZ=LCOLORZPOS(:,:,1);
 ImgGZ=LCOLORZPOS(:,:,2);
 ImgBZ=LCOLORZPOS(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

% imwrite(uint16(LABELM),[Reshome3 filesep 'NmosaicLM.png'])


% LABEL=LABELM;
LABEL=imerode(LABELM,ones(1,1));

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];

% DATA=PDATA;
DATA=[];
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;      
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
%               [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));
              
% center(nk-1,3:8)=[mean(ImgR(object))/255 mean(ImgG(object))/255 mean(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 
center(nk-1,3:8)=[median(ImgR(object))/255 median(ImgG(object))/255 median(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 

                            
                            %             CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
%             CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
 DATA(nk-1,1:11)=[1 nk-1 length(pcells)-1 center(nk-1,1:8)];
%  
%  
 Zcell=median([ImgRZ(object);ImgGZ(object);ImgBZ(object)]);
 Zapi=median([LCOLORZ(object)]);
 
 
 DATA(nk-1,12)=round((Zcell-Zapi)/256);
 
 DATA(nk-1,13)=round(Zapi/256);


          nk
         end 
         
         PDATA=DATA;
         
save([Reshome2 filesep 'Pall2.mat'],'PDATA'); 
idx

end