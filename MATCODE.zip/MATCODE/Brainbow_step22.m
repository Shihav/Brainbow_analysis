clear all
close all

clc

for idx=8

loadaddress;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

RAK=[];
GAK=[];
BAK=[];

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
        
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk3.mat'],'Imgsegk3');
Imgsegk3=uint16(Imgsegk3);
Imgsegk2=Imgsegk3;
clear Imgsegk3
% load([Reshome2 filesep filename2 filesep filename2 'Imgsegk.mat'],'Imgsegk');
load([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB'); 

     ImgR(Imgsegk2==0)=0;
     ImgG(Imgsegk2==0)=0;
     ImgB(Imgsegk2==0)=0;
%      ImgGR(Imgsegk==0)=0;

Img11r=sum(ImgR,3)./sum(Imgsegk2>0,3);
Img11g=sum(ImgG,3)./sum(Imgsegk2>0,3);
Img11b=sum(ImgB,3)./sum(Imgsegk2>0,3);

[Img11gr,zval11gr]=max(ImgGR,[],3);

clear ImgGR

FOX=(max(Imgsegk2,[],3))>0;
Img11gr(FOX==0)=0;
CO=uint16(cat(3,Img11r,Img11g,Img11b));
CGO=uint16(cat(3,Img11gr,Img11gr,Img11gr));
COF=CO+0.3*CGO;

imwrite(uint16(COF),[Reshome2 filesep filename2 filesep filename2 'Ori2.png']);  
imwrite(uint16(CO),[Reshome2 filesep filename2 filesep filename2 'OriC2.png']);  

imwrite(uint16(CGO),[Reshome2 filesep filename2 filesep filename2 'GRAY2.png']); 
%LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
LABEL=max(Imgsegk2,[],3);

pcells=unique(LABEL);
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABEL == val;
                              objectcore=imerode(object, se);
                              objectbor=(object-objectcore)>0;
                         LABEL(objectbor)=0;
         end

 LABEL = bwlabel(LABEL, 8);
pcells=unique(LABEL);
objectbor_map=zeros(size(LABEL));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABEL == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=CO;                                    
mult=[2 2 4];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'OverlayM.png']);  

% if idx==8
%     COG=Img11gr+3*rgb2gray(CO);
% else
COR=3*CO(:,:,1);
% end
% COG=Img11gr;

        Img=imcomplement(COR);
        mean_s=5;

        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=imcomplement(Img2);
        Img8=imcomplement(Img);

        kernel_s=25;

        max3=max(Img3(:));
        min3=min(Img3(:));
        multf=2.5;
        type=16;
        mins=3;
        maxs=5;
        types=linspace(mins,maxs,type);
              Chd= uint16(round(type-1)*mat2gray(Img3))+1;
              Imgn=[];
                   for k=1:type
                  
                      h = fspecial('gaussian',[kernel_s kernel_s],types(k));
                                       Imgn(:,:,k) = imfilter(Img8,h,'replicate');
                   end
              adapt_imageR=zeros(size(Img8));
              
              for k=1:type
                        temp=Imgn(:,:,k);
                      adapt_imageR(Chd==k)=temp(Chd==k);
                                  
              end
              
              COG=3*CO(:,:,2);
% end
% COG=Img11gr;

        Img=imcomplement(COG);
        mean_s=5;

        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=imcomplement(Img2);
        Img8=imcomplement(Img);

        kernel_s=25;

        max3=max(Img3(:));
        min3=min(Img3(:));
        multf=2.5;
        type=16;
        mins=3;
        maxs=5;
        types=linspace(mins,maxs,type);
              Chd= uint16(round(type-1)*mat2gray(Img3))+1;
              Imgn=[];
                   for k=1:type
                  
                      h = fspecial('gaussian',[kernel_s kernel_s],types(k));
                                       Imgn(:,:,k) = imfilter(Img8,h,'replicate');
                   end
              adapt_imageG=zeros(size(Img8));
              
              for k=1:type
                        temp=Imgn(:,:,k);
                      adapt_imageG(Chd==k)=temp(Chd==k);
                                  
              end
              
              COB=3*CO(:,:,3);
% end
% COG=Img11gr;

        Img=imcomplement(COB);
        mean_s=5;

        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=imcomplement(Img2);
        Img8=imcomplement(Img);

        kernel_s=25;

        max3=max(Img3(:));
        min3=min(Img3(:));
        multf=2.5;
        type=16;
        mins=3;
        maxs=5;
        types=linspace(mins,maxs,type);
              Chd= uint16(round(type-1)*mat2gray(Img3))+1;
              Imgn=[];
                   for k=1:type
                  
                      h = fspecial('gaussian',[kernel_s kernel_s],types(k));
                                       Imgn(:,:,k) = imfilter(Img8,h,'replicate');
                   end
              adapt_imageB=zeros(size(Img8));
              
              for k=1:type
                        temp=Imgn(:,:,k);
                      adapt_imageB(Chd==k)=temp(Chd==k);
                                  
              end
              
             
pcells=unique(LABEL);
LABELM=uint16(zeros(size(LABEL)));

Imgsegk4=uint16(zeros(size(Imgsegk2)));


ncell=1;
for nk=length(pcells):-1:2            
             val=pcells(nk);          
%             val=23; 

                              object = LABEL == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                              
                              valm(1)=std(adapt_imageR(object));
                               valm(2)=std(adapt_imageG(object));
                               valm(3)=std(adapt_imageB(object));
                               
                               [valmv,valmp]=max(valm);
          
                  if valmp==1             
                               
                adapt_imagek=adapt_imageR;
                  elseif valmp==2 
                      adapt_imagek=adapt_imageG;
                  else  
                      adapt_imagek=adapt_imageB;
                  end
                adapt_imagek(object~=1)=0;
                
img =adapt_imagek;
imgN = double(img-min(img(:)))/(max(img(:)-min(img(:))));

% if idx==8
% th2=0.15;
% else
%     
    th2=0.25;
% end
% % th1=0.25;
% if idx==2 && imgid==5 && nk==52
% th2=0.95;
% elseif idx==2 && imgid==5 && nk==17
%     th2=0.75;
% elseif idx==3 && imgid==18 && nk==171
%     th2=0.8;
% elseif idx==3 && imgid==19 && nk==59
%     th2=0.825;
% elseif idx==3 && imgid==22 && nk==10
%     th2=0.89;
% elseif idx==3 && imgid==13 && nk==36
%     th2=0.75;
% % elseif idx==1 && imgid==3 && nk==81
% %     th2=0.675;
% % elseif idx==3 && imgid==5 && nk==38
% %     th2=0.9;
% else
%     th2=0.25;
% end

% if idx==3 && imgid==18 && nk==171
%     sizekth=140;
% elseif idx==3 && imgid==19 && nk==59
%     sizekth=120;
% elseif idx==3 && imgid==22 && nk==10
%     sizekth=150;
% else
% if idx==8 && imgid==7
%     sizekth=150;
% else
    sizekth=225;
% end
% end

% if idx==3 && imgid==22 && nk==10
%     notc=1;
% else
    notc=0;
% end

% if idx==3 && imgid==22 && nk==10
%     redc=0.45;
% else
    redc=0.25;
% end

% if idx==3 && imgid==13 && nk==36
%     cvc=2;
% else
    cvc=1.5;
% end
    

% cellMsk = imgN>th1;
nucMsk = imgN>th2;
cellMsk=object-nucMsk;

cellMskM=imerode(cellMsk,ones(3));
nucMskM=imerode(nucMsk,ones(3));

% figure,imshow(cellMsk+nucMsk,[])
                
[xx,yy]=ndgrid(-5:5,-5:5);
gf = exp((-xx.^2-yy.^2)/20);
filtImg = conv2(imgN,gf,'same');

% figure,imshow(filtImg,[])

filtImgM = imimposemin(-filtImg,cellMskM | nucMskM); 
filtImgM(filtImgM>=0) = -Inf;

ws = watershed(filtImgM);
ws(~object) = 0;

lblImg = bwlabel(ws);
% figure,imshow(label2rgb(lblImg,'jet','k','shuffle'));
pcellsL=unique(lblImg);

se1=ones(3);
se2=ones(3);

if length(pcellsL)==2
    object2 = lblImg==1;
    
        objectcore1 = imerode(object2, se1);
                                      objectcore2 = imerode(object2, se2);
                                      objectbor=object2-objectcore1;

                                      RV=quantile(double(Img11r(objectcore2==1)),.5);
                                      GV=quantile(double(Img11g(objectcore2==1)),.5);
                                      BV=quantile(double(Img11b(objectcore2==1)),.5);

                                      RS=std(double(Img11r(objectcore2==1)));
                                      GS=std(double(Img11g(objectcore2==1)));
                                      BS=std(double(Img11b(objectcore2==1)));

                                      [CVK,PP]=max([RV GV BV]);
                                       CV=max([RV GV BV]);
                                      SA=[RS GS BS];
                                      CS=SA(PP);
                                          sizek=sum(sum(object2));  
                                         
                                          
                                          
                                      if (CV>(3*255)) && (double(CS)/double(CV))<1.5 && sizek>225 
                                          
                                          
                                                  [X,Y]=find(object2==1);
    
                                          [CH,Ak]= convhull(X,Y);  
                                          
                                          
                                          if (abs(double(Ak)-double(sizek))/double(sizek)) <=0.25

                                         object3=imdilate(object2, ones(5));


                                         LABELM(object & object3)=ncell;
%       LABELM(object2)=ncell;
                                 ncell=ncell+1
                                          end
                                      end
else

        for nk2=2:(length(pcellsL)-notc)

                val2=pcellsL(nk2);

                     object2 = lblImg==val2;
                                      objectcore1 = imerode(object2, se1);
                                      objectcore2 = imerode(object2, se2);
                                      objectbor=object2-objectcore1;

                                      RV=quantile(double(Img11r(objectcore2==1)),.5);
                                      GV=quantile(double(Img11g(objectcore2==1)),.5);
                                      BV=quantile(double(Img11b(objectcore2==1)),.5);

                                      RS=std(double(Img11r(objectcore2==1)));
                                      GS=std(double(Img11g(objectcore2==1)));
                                      BS=std(double(Img11b(objectcore2==1)));

                                      [CVK,PP]=max([RV GV BV]);
                                       CV=max([RV GV BV]);
                                      SA=[RS GS BS];
                                      CS=SA(PP);
                                          sizek=sum(sum(object2));  

                                        
                                          
                                          
                                      if (CV>(3*255)) && (double(CS)/double(CV))<cvc && sizek>sizekth
                                          
                                             [X,Y]=find(object2==1);
    
                                          [CH,Ak]= convhull(X,Y);  
                                          
                                          
                                          if (abs(double(Ak)-double(sizek))/double(sizek)) <redc

                                          object3=imdilate(object2, ones(5));


                                         LABELM(object & object3)=ncell;
                                         ncell=ncell+1
                                          end

                                      end




        end
end
% figure
% imagesc(LABELM)
% figure
% imagesc(LABEL>0)
nk
close all
end   



pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=CO;                                    
mult=[2 2 4];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'OverlayM2.png']);  
imwrite(uint16(LABELM),[Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);


LABELM=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);

LABELM3=repmat(LABELM,[1 1 size(Imgsegk2,3)]);
LABELM3B=repmat(LABELM>0,[1 1 size(Imgsegk2,3)]);
Imgsegk4(LABELM3B & Imgsegk2>0)=LABELM3(LABELM3B & Imgsegk2>0);

save([Reshome2 filesep filename2 filesep filename2 'Imgsegk4.mat'],'Imgsegk4'); 
Imgsegk3=Imgsegk4;
clear Imgsegk2 Imgsegk4 LABELM3 LABELM3B

                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'FINALC2.png']); 

mult=[2 2 4];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'FINALC.png']);  

imgid
pcells=unique(LABELM);
% CA=[];

% ImgR=LCOLOR5(:,:,1);
% ImgG=LCOLOR5(:,:,2);
% ImgB=LCOLOR5(:,:,3);


LABEL=LABELM;
imgid
pcells=unique(LABEL);
CA=[];
CA2=[];

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object3d=Imgsegk3==val;
                RA=double(ImgR(object3d))/256;
                 GA=double(ImgG(object3d))/256;
                  BA=double(ImgB(object3d))/256;   
                  
                  
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
            
            SA=RA+GA+BA;
            CA(nk-1,:)=[mean(RA./SA) mean(GA./SA) mean(BA./SA) median(RA./SA) median(GA./SA) median(BA./SA) std(RA./SA) std(GA./SA) std(BA./SA) mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)];
            CA2(nk-1,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
RAK=[RAK;RA];  
GAK=[GAK;GA];  
BAK=[BAK;BA];  
          nk
         end 
         
 save([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');   

   labeledImage1=LABEL;
       center=[];
       cellsL=unique(labeledImage1);

           for id=2:size(cellsL,1)
               tag=cellsL(id);

                                     object = labeledImage1 == tag;
                            CL=[];         
                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          CL(ind)=mean(col_img2a(object));    
                          end 
                                     
                              s = regionprops(object,'centroid');
                              center(id-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
                            center(id-1,3:5)=CL; 
%                              center(id-1,1)=id; 
                           
           end
           
%            center(:,3:5)=CA(:,13:15);
imgid           
  save([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');   
  
    resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];
    
    if exist(resfile, 'file')==2
  delete(resfile);
    end
      if size(center,1)>0 
    MATT=[[1:size(center,1)]' center(:,1:2) CA(:,10:12)/16 CA(:,16:18)/16];
    nps=length(unique(Imgsegk3))-2;
    
    clear cell
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end

    BK = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  BK(ii,jj+3) = {MATT(ii,jj)};
    end
      BK(ii,1) = {filename2};
       BK(ii,2) = {imgid};
       BK(ii,3) = {nps};
end

BKA=[BKA;BK];
A = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
C=[A;BK];
xlswrite(resfile,C,1,'A1') 
      end
% 

id=1;
CA2=[];
          for nk=2:length(pcells)            
            val=pcells(nk); 
           
object3d=Imgsegk3==val;
                RA=2*double(ImgR(object3d));
                 GA=2*double(ImgG(object3d));
                  BA=4*double(ImgB(object3d));     
             
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(id,10:11)=cent;
            
            CA2(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]/256; 
          id=id+1
         end 
         CA1=CA2;
save([Reshome2 filesep filename2 filesep filename2 'CA1.mat'],'CA1');  
 
% COK(:,:,1)=2*CO(:,:,1);
% COK(:,:,2)=2*CO(:,:,2);
% COK(:,:,3)=4*CO(:,:,3);
 
 CA=CA2;
  figure
  imagesc(imresize(Compb,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
%           num2str(round((CA(zin,6)))) ')'],'FontSize',4,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method2'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method2' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method2' '.png']);

% if imgid==1
% 
% id=1;
% CA=[];
%          for nk=[152 154 138 145 171 164 135 127 103 99 48 46 60 62 52 39 73 75 18 16]          
%             val=nk; 
%            
% object3d=Imgsegk3==val;
%                 RA=2*double(ImgR(object3d));
%                  GA=2*double(ImgG(object3d));
%                   BA=4*double(ImgB(object3d));     
%              
%                    object = LABELM == val;         
%                               s = regionprops(object,'centroid');
%                              cent=s.Centroid;
%                               cent=fliplr(double(round(cent)));
%                               CA(id,10:11)=cent;
%             
%             CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]/256; 
%           id=id+1
%          end 
%          CA1=CA;
%  save([Reshome2 filesep filename2 filesep filename2 'CA1.mat'],'CA1');  
%  
% COK(:,:,1)=2*CO(:,:,1);
% COK(:,:,2)=2*CO(:,:,2);
% COK(:,:,3)=4*CO(:,:,3);
%  
%  
%   figure
%   imagesc(imresize(Compb,4));hold on
% m=4;
%      for zin=1:size(CA,1)       
% 
%          text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
%           num2str(round((CA(zin,3)))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
%           num2str(round((CA(zin,6)))) ')'],'FontSize',4,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%               text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
%           num2str(round((CA(zin,9)))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%      end
% 
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%   
%   export_fig([Reshome2 filesep filename2 filesep filename2 '_method1'],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method1' '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
%   Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
%   imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method1' '.png']);
%   
% end


end

AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
C=[AK;BKA];
   resfile = [Reshome2 filesep 'Result.xlsx'];

    if exist(resfile, 'file')==2
  delete(resfile);
    end

xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')
% 
save([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');    
  
end
  
