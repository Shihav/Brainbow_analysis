clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=75;
Bdiff_allowed=80;
Hdiff_allowed=13;
Sdiff_allowed=70;

Hdiff_max=40;
Sdiff_max=140;

% Hdiff_allowed1=15;
% Sdiff_allowed1=75;
% Sdiff_allowed2=100;
load_angle=0;

D_th=2;
T_th=sqrt(2);

wd=0;
wd2=0;

SVTH=100;
SV2=0;

SU=0;
cut=0.99;

sisters=4;

for idx=[1]
         
loadaddress;
  
load([Reshome2 filesep 'Pall.mat'],'PDATA'); 

load([Reshome2 filesep 'Nall.mat'],'NDATA'); 


dmap=pdist2(PDATA(:,4:5),NDATA(:,4:5));
dmapmin=min(dmap);

NDATA((dmapmin<7)',:)=[];

% load([Reshome2 filesep 'all.mat'],'DATA'); 

DATA=PDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multp=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

DATACM=rgb2hsv(DATA(:,6:8));

filter_data;

PSDATA=DATA;
make_hue_plot2(PSDATA)

% load([Reshome2 filesep 'Nall.mat'],'NDATA'); 

DATA=NDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multn=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

filter_data;

NSDATA=DATA;
make_hue_plot2(NSDATA);

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
make_hue_plot2(ADATA);


    tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
  
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=8;
     BdistB=Bdist<=128;
     SPACEdistB=SPACEdist<=100;
     SATdistB=SATdist<=0.5;

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters;
     
     ADATA=ADATA(select,:);   
 
 
     tDATA=ADATA;
     tDATACM=rgb2hsv(ADATA(:,6:8));
     
 




inDATA=ADATA(ADATA(:,1)==1,:);

LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

mult=multp;
make_CL2;
COF1=CL;

inDATA=ADATA(ADATA(:,1)==2,:);
make_hue_plot2(inDATA)

LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

mult=multn;
make_CL2;
COF2=CL;

m=1;
    
     figure
  imshow(COF1+COF2);hold on
  
  PSDATA=ADATA(ADATA(:,1)==1,:);
  NSDATA=ADATA(ADATA(:,1)==2,:);
  
     for zin=1:size(PSDATA,1)  
           DATACM1=rgb2hsv(PSDATA(zin,6:8));  
           text(m*PSDATA(zin,5)+3,m*PSDATA(zin,4)-3,[char(10) num2str(PSDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     for zin=1:size(NSDATA,1)  
           DATACM1=rgb2hsv(NSDATA(zin,6:8));  
           text(m*NSDATA(zin,5)+3,m*NSDATA(zin,4)-3,[char(10) num2str(NSDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
%               text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
  
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');
close all

if load_angle==1

AK=[340 10 40 70 100 130 160 190 220 250 280 310 340];
BK=[20 50 80 110 140 170 200 230 260 290 320 350 20];

for anga=1:length(AK)
    
    DATA=tDATA;
    DATACM=tDATACM;
    HUE=DATACM(:,1)*360;
    
    
 if anga==1 


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;
 elseif anga==13 


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;
 else
    select=DATACM(:,3)>5 & HUE>=AK(anga) & HUE<BK(anga);
 end

 DATA=DATA(select,:);
DATACM=DATACM(select,:);
 
DATAk=DATA;
DATACMk=DATACM;

% make_hue_plot(DATAk,DATACMk)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'angHUE' num2str(anga)  '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');


inDATA=DATA(DATA(:,1)==1,:);
make_hue_plot2(inDATA)

LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

mult=multp;
make_CL2;
COF1=CL;

inDATA=DATA(DATA(:,1)==2,:);
make_hue_plot2(inDATA)

LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

mult=multn;
make_CL2;
COF2=CL;

m=1;
    
     figure
  imshow(COF1+COF2);hold on
  
  PSDATA=DATA(DATA(:,1)==1,:);
  NSDATA=DATA(DATA(:,1)==2,:);
  
     for zin=1:size(PSDATA,1)  
           DATACM1=rgb2hsv(PSDATA(zin,6:8));  
           text(m*PSDATA(zin,5)+3,m*PSDATA(zin,4)-3,[char(10) num2str(PSDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     for zin=1:size(NSDATA,1)  
           DATACM1=rgb2hsv(NSDATA(zin,6:8));  
           text(m*NSDATA(zin,5)+3,m*NSDATA(zin,4)-3,[char(10) num2str(NSDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
%               text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
  
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'ZLINK_idx' num2str(idx) 'ang' num2str(anga)  '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');
close all

end


end


close all
end
