figure()

    valn=DATA(:,6);
     valr=DATA(:,7);
     vals=DATA(:,8);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      
set(gcf,'color','w');
title('Brighten ternary plot','FontName','Times','fontsize',24);
% print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Brighten ternary plotR'], '-dpng', '-r300'); 
export_fig(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Brighten ternary plotR'],'-a2', '-m4','-p0','-q101','-png', '-r600');

figure
HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATA(mt,6:8)/255)
end
%                                             ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['HSV distribution'], 'FontSize',24,'FontName','Times') % y-axis label   
                                             a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',12);
b = get(gca,'YTickLabel');
set(gca,'YTickLabel',b,'FontName','Times','fontsize',12);

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
% print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_HSV distributionTMR'], '-dpng','-r300'); 
set(gcf,'color','w');
export_fig(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_HSV distributionTMR'],'-a2', '-m4','-p0','-q101','-png', '-r600');
