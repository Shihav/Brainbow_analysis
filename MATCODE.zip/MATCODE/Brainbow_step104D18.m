clear all
close all

cut=0.99;
darkest_cells_cut=75;
sisters=2;

final_remove_list;

LM=1;

nidx=1;
rc=[];
nc=[];

HTH=10;
STH=100;
BTH=100;
SATH=0.33;

DR=0;
OLDIST=7;

for idx=[1 2 3 5 7 8]
          
loadaddress;
  
load([Reshome2 filesep 'Pall.mat'],'PDATA'); 
PDATA(Prlist{idx},:)=[];

load([Reshome2 filesep 'Nall.mat'],'NDATA');
NDATA(Nrlist{idx},:)=[];

dmap=pdist2(PDATA(:,4:5),NDATA(:,4:5));
dmapmin=min(dmap);

NDATA((dmapmin<OLDIST)',:)=[];

DATA=PDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multp=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);
DATACM=rgb2hsv(DATA(:,6:8));

PDATA=DATA;
filter_data3;
PSDATA=DATA;

DATA=NDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multn=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

NDATA=DATA;
filter_data3;
NSDATA=DATA;

NSDATA(:,1)=2;

ADATA=[PDATA;NDATA];
tp='_P';
BMAKE_FILTERED_PLOT2;

ADATA=[PSDATA;NSDATA];
tp='_P2';
BMAKE_FILTERED_PLOT2;

 tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=2;
     
     ADATA=ADATA(select,:);  

tp='_P3';
BMAKE_FILTERED_PLOT2;
  

end

 