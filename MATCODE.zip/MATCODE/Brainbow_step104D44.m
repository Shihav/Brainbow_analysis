clear all
close all

clc
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT']);

load TQRES.mat infoTA infoQA

myC= [0.7 0.7 0.7;
    0.9 0.9 1;
    0.9 1 0.9];
k=1;
rc=[];
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=infoQA(infoQA(:,10)==kin,:);
    
    for kin2=1:size(tem,1)
        if tem(kin2,1)==1
        tem(kin2,11)=0;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==2
            
                       if tem(kin2,6)<tem(kin2,8)
            
        tem(kin2,11)=2;
        tem(kin2,12)=0;
        
           else
                 tem(kin2,11)=1;
        tem(kin2,12)=1;
           end
%         tem(kin2,11)=1;
%         tem(kin2,12)=1;
        elseif tem(kin2,1)==3
        tem(kin2,11)=2;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==4
        tem(kin2,11)=4;
        tem(kin2,12)=0;
        end
        
    end
    
  rc(k,1)=sum(tem(:,11));  
  rc(k,2)=sum(tem(:,12)); 
   
  k=k+1;
    
end


figure

H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Origin from symmetric division = ' num2str(100*mn,'%0.2f') '%, total cell = ' num2str(sum(rc(:)))],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
ylim([0 1.05])
pbaspect([8,6,1])

set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'QUAD_SYM'],'-a2', '-m6','-p0.02','-png', '-r600');




mat=[];
mat(1,1)=sum(infoQA(:,1)==1);
mat(1,2)=sum(infoQA(:,1)==2);
mat(1,3)=sum(infoQA(:,1)==3);
mat(1,4)=sum(infoQA(:,1)==4);

myC=[1 0.6 0.6];

figure

hold on
    h=bar(1,mat(1,1),0.5);
        set(h,'FaceColor',[0.2 0.2 1]);
       set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(2,mat(1,2),0.5);
        set(h,'FaceColor',[0.2 1 0.2]);
        set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(3,mat(1,3),0.5);
        set(h,'FaceColor',[1 0.2 0.2]);
        set(get(h,'Children'),'FaceAlpha',0.6);
    h=bar(4,mat(1,4),0.5);
        set(h,'FaceColor',[1 0.2 1]);
        set(get(h,'Children'),'FaceAlpha',0.6);
hold off


% H=bar(mat,0.5);

% 
% for k=1:1
%   set(H(k),'facecolor',myC(k,:))
% end

ylabel(['Number of samples'],'FontSize', 14,'FontName','times') % y-axis label
xlabel(['Number of ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
title('Types of Quadruplets','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 4.5])
% ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:4,...                         %# Change the axes tick marks
        'XTickLabel',{'1','2','3','4'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'QUAD_TYPE'],'-a2', '-m6','-p0.02','-png', '-r600');


mat=[];
mat(1,1)=sum(infoQA(:,10)==7);
mat(1,2)=sum(infoQA(:,10)==8);
mat(1,3)=sum(infoQA(:,10)==3);
mat(1,4)=sum(infoQA(:,10)==1);
mat(1,5)=sum(infoQA(:,10)==13);
mat(1,6)=sum(infoQA(:,10)==15);
mat(1,7)=sum(infoQA(:,10)==5);
mat(1,8)=sum(infoQA(:,10)==17);
mat(1,9)=sum(infoQA(:,10)==18);
mat(1,10)=sum(infoQA(:,10)==14);
mat(1,11)=sum(infoQA(:,10)==16);
mat(1,12)=sum(infoQA(:,10)==12);
mat(1,13)=sum(infoQA(:,10)==2);
mat(1,14)=sum(infoQA(:,10)==11);

myC=[0.7 0.7 0.9];

figure
H=bar(mat,0.5);

for k=1:1
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Number of Quadruplets'],'FontSize', 14,'FontName','times') % y-axis label
title('Quadruplets among mosaics','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
% ylim([0 1.05])
pbaspect([8,6,1])
 
set_xlabel_12
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'QUAD_COUNT'],'-a2', '-m6','-p0.02','-png', '-r600');



figure; hold on

for kin=1:size(infoQA,1)

    if infoQA(kin,1)==1
scatter(infoQA(kin,2),infoQA(kin,4),50,[0.2 0.2 1],'filled'); hold on;
alpha(0.6);
    elseif infoQA(kin,1)==2
scatter(infoQA(kin,2),infoQA(kin,4),50,[0.2 1 0.2],'filled'); hold on;
alpha(0.6);
    elseif infoQA(kin,1)==3
scatter(infoQA(kin,2),infoQA(kin,4),50,[1 0.2 0.2],'filled'); hold on;
alpha(0.6);
    elseif infoQA(kin,1)==4
scatter(infoQA(kin,2),infoQA(kin,4),50,[1 0.2 1],'filled'); hold on;
alpha(0.6);
    end
alpha(0.6)
end

%  hl = legend('1 FoxJ1+','2 FoxJ1+','3 FoxJ1+');
% % hl = legend(H,['Symmetric division'],['Asymmetric division']);
% set(hl,'FontSize', 12,'FontName','Times');
% legend('boxoff')
% 
%                                                                                         hc = findobj(hl, '-property', 'FaceColor');
%                                                                                         set(hc(1), 'FaceColor',[1 0 0])
%                                                                                         set(hc(2), 'FaceColor', [0 1 0])
%                                                                                         set(hc(3), 'FaceColor', [0 0 1])
%                                                                                         
%                                                                                         

xlabel(['Mean distance among ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
ylabel(['Mean distance to ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label

title('Quadruplets spatial distance relation','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0 150])
ylim([0 150])
pbaspect([8,8,1])
 
%  set(gca,'XTick',1:6,...                         %# Change the axes tick marks
%         'XTickLabel',{'M5','M6','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'QUAD_spatial_distance'],'-a2', '-m6','-p0.02','-png', '-r600');


figure; hold on

for kin=1:size(infoQA,1)

    if infoQA(kin,1)==1
scatter(infoQA(kin,6),infoQA(kin,8),50,[0.2 0.2 1],'filled'); hold on;
alpha(0.6);
    elseif infoQA(kin,1)==2
scatter(infoQA(kin,6),infoQA(kin,8),50,[0.2 1 0.2],'filled'); hold on;
alpha(0.6);
    elseif infoQA(kin,1)==3
scatter(infoQA(kin,6),infoQA(kin,8),50,[1 0.2 0.2],'filled'); hold on;
alpha(0.6);
    elseif infoQA(kin,1)==4
scatter(infoQA(kin,6),infoQA(kin,8),50,[1 0.2 1],'filled'); hold on;
alpha(0.6);
    end
alpha(0.6);
end

%  hl = legend('1 FoxJ1+','2 FoxJ1+','3 FoxJ1+');
% % hl = legend(H,['Symmetric division'],['Asymmetric division']);
% set(hl,'FontSize', 12,'FontName','Times');
% legend('boxoff')
% 
%                                                                                         hc = findobj(hl, '-property', 'FaceColor');
%                                                                                         set(hc(1), 'FaceColor',[1 0 0])
%                                                                                         set(hc(2), 'FaceColor', [0 1 0])
%                                                                                         set(hc(3), 'FaceColor', [0 0 1])
%                                                                                         
%                                                                                         

xlabel(['Mean distance among ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
ylabel(['Mean distance to ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label

title('Quadruplets color distance relation','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0 15])
ylim([0 15])
pbaspect([8,8,1])
 
%  set(gca,'XTick',1:6,...                         %# Change the axes tick marks
%         'XTickLabel',{'M5','M6','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'QUAD_hue_distance'],'-a2', '-m6','-p0.02','-png', '-r600');

