xin=1;

     UP=[];
      VP=[];
       XP=[];
        YP=[];
        NP=[];
        
        
          
   U=m*xyvalk(:,4)-m*xyvalk(:,2);
   V=m*xyvalk(:,3)-m*xyvalk(:,1);
   Z=sqrt(U.^2+V.^2);   
   U=1*m*U./Z;
    V=1*m*V./Z;
gid=1;
gidn=1;
while xin<size(LCOLORG,1)
    
     xstart=xin;
        xend=min([xin+wsize-1 size(LCOLORG,1)]);
        
        yin=1;
        
    while yin<size(LCOLORG,2)
        
        ystart=yin;
        yend=min([yin+wsize-1 size(LCOLORG,2)]);
        ydiff=yend-ystart;
        if ydiff==(wsize-1)
        yin=yend-shift+1;
        else
        yin=size(LCOLORG,2);
        end
        
        
        if circ==0
        % square grid
        select=xyvalk(:,2)>=ystart & xyvalk(:,2)<=yend & xyvalk(:,1)>=xstart & xyvalk(:,1)<=xend;
        elseif circ==1
        % circular grid
        midy=(ystart+yend)/2;
        midx=(xstart+xend)/2;
        
        distm=pdist2([midx midy],xyvalk(:,1:2))';
        select=distm<(wsize/2+shift);
        end
        
        if sum(select)>0
            
            
         UP(gid,1)=sum(U(select==1));
         VP(gid,1)=sum(V(select==1));
%          XP(gid,1)=(ystart+yend)/2;
%          YP(gid,1)=(xstart+xend)/2;
         
                  XP(gid,1)=mean(mean(xyvalk(select==1,[2 4])));
         YP(gid,1)=mean(mean(xyvalk(select==1,[1 3])));
         
         NP(gid,1)=sum(select==1);
        
        gid=gid+1;
        end
        
        
        
        gidn=gidn+1;
        
    end
    
        xdiff=xend-xstart;
        if xdiff==(wsize-1)
        xin=xend-shift+1;
        else
        xin=size(LCOLORG,1);
        end
end

sum(NP)
size(xyvalk,1)

 UPm=UP/m;
VPm=VP/m;

ZPm=sqrt(UPm.^2+VPm.^2);

 UPm=2*m*UPm./ZPm;
    VPm=2*m*VPm./ZPm;
    
    CC=NP/NMAX;
    CC(CC>1)=1;
    
      [arrowx,arrowy]=vekplot2(m*XP,m*YP,UPm,VPm,75);
      
      for as=1:length(NP)
     plot(arrowx(:,as),arrowy(:,as),'Color',CC(as)*CCN,'linewidth',8*LW);hold on;
      end
      
          [arrowx,arrowy]=vekplot2(m*XP,m*YP,-UPm,-VPm,75);
      
      for as=1:length(NP)
     plot(arrowx(:,as),arrowy(:,as),'Color',CC(as)*CCN,'linewidth',8*LW);hold on;
      end