clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

zres=[0.52 0.36 0.36 1 0.36 1 0.47 0.47 1 0.36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);


xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE' ]);
% m=1;
m{3}=[3139 785 2245 854];

count=[];
infoTA=[];
infoQA=[];
infoDA=[];
for idx=[1 2 3 5 7 8 11]
   if idx==11
       xyr=0.297;
   else
    xyr=0.31;
   end
%       mn=m{idx};  
     if idx==7
     LW=0.2;
     else
     LW=0.4;
     end
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB','valAT','valAQ','LINKA'); 


% ADATAS_D(:,2)=10000*(ADATAS_D(:,1)-1)+ADATAS_D(:,2);
TAG=zeros(size(ADATAS_D,1),1);

for kin=1:1:size(xyvals_D,1)
 ar=xyvals_D(kin,24:25);
 
 TAG(ismember(ADATAS_D(:,2),ar))=kin;

end


pcells=unique(TAG);
infoT=[];
DG=[1 0;0 1];
for kin=1:length(pcells)
    
    TEM=ADATAS_D(TAG==pcells(kin),:);
    infoT(kin,1)=sum(TEM(:,1)==1);
    SD=pdist2(TEM(:,4:5),TEM(:,4:5))*xyr;
    SD(DG==1)=[];
    infoT(kin,2)=mean(SD);
    infoT(kin,3)=std(SD);
    
    SD=pdist2(TEM(:,4:5),TEM(:,4:5))*xyr;
    
    
    TT=TEM(:,1)*TEM(:,1)';
    SD(TT==4 | DG==1)=[];
%     SD(DG==1)=[];
    
    infoT(kin,4)=mean(SD);
    infoT(kin,5)=std(SD);
    
    
    
       DATACM=rgb2hsv(TEM(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
SD=HUEdist;
        SD(DG==1)=[];
    infoT(kin,6)=mean(SD);
    infoT(kin,7)=std(SD);
    
    SD=HUEdist;
%        SD(TT==4)=[];
    SD(TT==4 | DG==1)=[];
    
    infoT(kin,8)=mean(SD);
    infoT(kin,9)=std(SD);
    
    infoT(kin,10)=idx;
    
end

infoD=infoT;

infoDA=[infoDA;infoD];



DG=[1 0 0; 0 1 0; 0 0 1];
ADATAS_T(:,2)=10000*(ADATAS_T(:,1)-1)+ADATAS_T(:,2);
TAG=zeros(size(ADATAS_T,1),1);

for kin=1:3:size(valAT,1)
 ar=valAT(kin:kin+2);
 
 TAG(ismember(ADATAS_T(:,2),ar))=kin;

end


pcells=unique(TAG);
infoT=[];
for kin=1:length(pcells)
    
   TEM=ADATAS_T(TAG==pcells(kin),:);
    infoT(kin,1)=sum(TEM(:,1)==1);
    SD=pdist2(TEM(:,4:5),TEM(:,4:5))*xyr;
    SD(DG==1)=[];
    infoT(kin,2)=mean(SD);
    infoT(kin,3)=std(SD);
    
    SD=pdist2(TEM(:,4:5),TEM(:,4:5))*xyr;
    
    
    TT=TEM(:,1)*TEM(:,1)';
    SD(TT==4 | DG==1)=[];
%     SD(DG==1)=[];
    
    infoT(kin,4)=mean(SD);
    infoT(kin,5)=std(SD);
    
    
    
       DATACM=rgb2hsv(TEM(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
SD=HUEdist;
        SD(DG==1)=[];
    infoT(kin,6)=mean(SD);
    infoT(kin,7)=std(SD);
    
    SD=HUEdist;
%        SD(TT==4)=[];
    SD(TT==4 | DG==1)=[];
    
    infoT(kin,8)=mean(SD);
    infoT(kin,9)=std(SD);
    
    infoT(kin,10)=idx;
    
end



infoTA=[infoTA;infoT];


DG=[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];

ADATAS_Q(:,2)=10000*(ADATAS_Q(:,1)-1)+ADATAS_Q(:,2);
TAG=zeros(size(ADATAS_Q,1),1);

for kin=1:4:size(valAQ,1)
 ar=valAQ(kin:kin+3);
 
 TAG(ismember(ADATAS_Q(:,2),ar))=kin;

end


pcells=unique(TAG);
infoT=[];
for kin=1:length(pcells)
    
   TEM=ADATAS_Q(TAG==pcells(kin),:);
    infoT(kin,1)=sum(TEM(:,1)==1);
    SD=pdist2(TEM(:,4:5),TEM(:,4:5))*xyr;
    SD(DG==1)=[];
    infoT(kin,2)=mean(SD);
    infoT(kin,3)=std(SD);
    
    SD=pdist2(TEM(:,4:5),TEM(:,4:5))*xyr;
    
    
    TT=TEM(:,1)*TEM(:,1)';
    SD(TT==4 | DG==1)=[];
%     SD(DG==1)=[];
    
    infoT(kin,4)=mean(SD);
    infoT(kin,5)=std(SD);
    
    
    
       DATACM=rgb2hsv(TEM(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
SD=HUEdist;
        SD(DG==1)=[];
    infoT(kin,6)=mean(SD);
    infoT(kin,7)=std(SD);
    
    SD=HUEdist;
%        SD(TT==4)=[];
    SD(TT==4 | DG==1)=[];
    
    infoT(kin,8)=mean(SD);
    infoT(kin,9)=std(SD);
    
    infoT(kin,10)=idx;
    
end

infoQ=infoT;

infoQA=[infoQA;infoQ];

idx
close all
end

save TQRES.mat infoTA infoQA infoDA

