clear all
close all
clc

sizeth2=275;
for idx=[7]

loadaddress;
ad=1;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

for imgid=1:numel(Types)
     
        tol=0.065;

     filename=Types{imgid};
     filename2=strrep(filename,'.tif',''); 
     mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];

     info = imfinfo(segname);
        num_images = numel(info);
  
load([Reshome2 filesep filename2 filesep filename2 'Imgseg.mat'],'Imgseg'); 
MV=max(Imgseg(:))+1;
Imgseg=MV-Imgseg;
Imgseg(Imgseg==MV)=0;
Imgseg(Imgseg==MV-1)=0;

LB=uint16(max(Imgseg,[],3));
%LB = imclearborder(LB);
imgid
          
pcells=unique(LB);

%   stats = regionprops(LB>0,LB,'Area','Centroid','MajorAxisLength','MinorAxisLength','ConvexArea','Eccentricity','MeanIntensity');
  
%       for nk=1:length(stats)    
%                                  xc=round(stats(nk).Centroid(2));
%                                  yc=round(stats(nk).Centroid(1));
% 
%                                 val=stats(nk).MeanIntensity; 
%                                        object = LB == val; 
%                                        sizen=stats(nk).Area;
%                                        R=sizen./(stats(nk).ConvexArea);
%                                        
%                                         if sizen<500 || R<0.85 
%                                             LB(LB==val)=0;
%                                         end
% 
% 
%                             nk
%       end 
%                                                 

         for nk=1:length(pcells)            
            val=pcells(nk); 
            object=LB==val;
            sizek=sum(sum(object)); 
%             object=LB==val;
            stats = regionprops(object,'MajorAxisLength','MinorAxisLength','ConvexArea','Eccentricity');
  Radi=sizek./(stats(1).ConvexArea);
            if sizek<sizeth2 || (Radi<0.75) || length(stats)>1
                LB(object)=0;
            end
            nk;    
         end
     
         pcells=unique(LB);
         
         se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LB == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       LB(objectbor)=0;
         
         end

imwrite(uint16(LB),[Reshome2 filesep filename2 filesep filename2 'FOXL.png']);  

imgid

end
end