function make_ternary_plot2big(DATA,NL) 

% DATA=[PDATABB;NDATABB];

DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;

% NL=prctile(DATAT,5,1);
DATAT(:,1) =255*imadjust(DATAT(:,1)/255,[NL(1) 255]/255,[0 255]/255);
DATAT(:,2) =255*imadjust(DATAT(:,2)/255,[NL(2) 255]/255,[0 255]/255);
DATAT(:,3) =255*imadjust(DATAT(:,3)/255,[NL(3) 255]/255,[0 255]/255);

DATA(:,6:8)=DATAT;

figure()

    valn=DATA(:,6);
     valr=DATA(:,7);
     vals=DATA(:,8);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',3,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
       
%          [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
%         text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel2('Blue - Red', 'Green - Red', 'Blue - Green')      

% title('Raw ternary plot');
% print([Reshome3 filesep  'Raw ternary plot'], '-dpng', '-r300'); 



% DATAT=DATA(:,6:8);
% DATAT(DATAT>255)=255;
% DATA(:,6:8)=DATAT;
% 
% DATACM=rgb2hsv(DATA(:,6:8));
% 
% figure
% 
% HUE=DATACM(:,1)*360;
% h=polar(0,255,'.');hold on
% set(h,'linewidth',0.01)
% set(h,'markersize',0.01)
% for mt=1:size(DATACM,1)
% h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
% set(h,'linewidth',1)
% set(h,'markersize',15)
% set(h,'color',DATA(mt,6:8)/255)
% end

set(gcf,'color','w');
grid off
box off
axis off
%      axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure   


%                                                 a = get(gca,'XTickLabel');
%                                                 set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
%                                                 b = get(gca,'YTickLabel');
%                                                 set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');
% 
%                                                 ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                                 %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                                                                                             set(gcf,'PaperPositionMode','auto')