if idx==1
       
Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_Brainbow2/Selection Shihav/Marie_brainbow8/Tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_Brainbow2/Selection Shihav/Marie_brainbow8/Imagej2';
Reshome2='/media/shihavud/F4D6E812D6E7D342/TEST_BRAINBOW/P';
Reshome3='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/P2';
Reshome4='/media/shihavud/F4D6E812D6E7D342/TEST_BRAINBOW/Mosaic';

elseif idx==2
    
Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160704_Daclin_manip12_137_5/E14P10_Nucbow_137_5_40x_tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160704_Daclin_manip12_137_5/E14P10_Nucbow_137_5_40x_seg';
Reshome2='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160704_Daclin_manip12_137_5/P'; 
Reshome3='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160704_Daclin_manip12_137_5/P2'; 
Reshome4='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160704_Daclin_manip12_137_5/Mosaic';
elseif idx==3
    
Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/3/E14P16_Nucbow_140_3_40x_tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/3/E14P16_Nucbow_140_3_40x_seg';
Reshome2='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/3/P'; 
Reshome3='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/3/P2'; 
Reshome4='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/3/Mosaic'; 

elseif idx==4
    
Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/4/E14P16_Nucbow_140_4_40x_tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/4/E14P16_Nucbow_140_4_40x_seg';
Reshome2='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/4/P'; 
Reshome3='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/4/P2'; 
Reshome4='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160711_Daclin_manip14/4/Mosaic'; 

elseif idx==5
    
Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160626_Daclin_manip12_3/serie_0002_tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160626_Daclin_manip12_3/serie_0002_seg';
Reshome2='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160626_Daclin_manip12_3/P'; 
Reshome3='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160626_Daclin_manip12_3/P2'; 
Reshome4='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160626_Daclin_manip12_3/Mosaic'; 

elseif idx==6
    
Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160928_E14P61_Daclin_Nucbow_manip16_150_1/Tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160928_E14P61_Daclin_Nucbow_manip16_150_1/Seg';
Reshome2='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160928_E14P61_Daclin_Nucbow_manip16_150_1/P'; 
Reshome3='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160928_E14P61_Daclin_Nucbow_manip16_150_1/P2'; 
Reshome4='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/20160928_E14P61_Daclin_Nucbow_manip16_150_1/Mosaic'; 

end

FINR='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/Combined3';
FINB='/media/shihavud/F4D6E812D6E7D342/Marie_2016_NEW/Combined2';