clear all
close all
% 
clc
% BTH=75;
for idx=[3]
     
loadaddress;
% load('DATA1')

load([Reshome2 filesep 'all.mat'],'DATA'); 

load(['FOX' num2str(idx)],'centerF'); 



SPACE=min((pdist2(centerF(:,1:2),DATA(:,4:5))*.31),[],2);

centerF(SPACE>125,:)=[];

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

 DATAori=DATA;
    DATACMori=DATACM;
    
    DT{1}=DATA;
    DTCM{1}=DATACM;
    
    
    
  figure

HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATA(mt,6:8)/255)
end

set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure       
    
    

 for loopin=2:101   
     
     loopin
    
    rdid=randperm(size(DATA,1));
    
    rdidF=randperm(size(centerF,1));
    
DATAn=[DATAori(:,1:3) centerF(rdidF(1:size(DATA,1)),1:2) DATAori(rdid(1:size(DATA,1)),6:11)];

DATACMn=rgb2hsv(DATAn(:,6:8));


HUEn=DATACMn(:,1)*360;
data2n=[DATACMn(:,3).*cosd(HUEn) DATACMn(:,3).*sind(HUEn)];


res=128;
  [bandwidth,density,X,Y]=kde2d(data2n,res,[-255,-255],[255,255]);    
       hG = fspecial('gaussian',[5 5],1);               
                      density = imfilter(density,hG,'symmetric'); 
%                                  density=flipud(density);
                            
        Xin=linspace(-255,255,res);
Yin=linspace(255,-255,res);

Dist=density;
N=size(DATA,1);

vals=zeros(2,N);
for i=1:N
   [vals(1,i),vals(2,i)]=pinky(Xin,Yin,Dist,10);
end

RH=vals(1,:)';
RS=vals(2,:)';

% bin=128;
% PD=hist(data2n(:,1),linspace(-255,255,bin));
%   hG = fspecial('gaussian',[5 5],0.75);
%                
%                       PD2 = imfilter(PD,hG,'symmetric'); 
%                       PD2=PD2./sum(PD2);
%                       
%   px=linspace(-255,255,bin);
%   p= PD2;
%   RH=randpdf(p,px,[size(DATA,1),1]);
%                       
% bin=128;
% PD=hist(data2n(:,2),linspace(-255,255,bin));
%   hG = fspecial('gaussian',[5 5],0.75);
%                
%                       PD2 = imfilter(PD,hG,'symmetric'); 
%                       PD2=PD2./sum(PD2);
% 
%   px=linspace(-255,255,bin);
%   p= PD2;
%   RS=randpdf(p,px,[size(DATA,1),1]);
  
theta=(180./pi.*atan2(RS,RH));

    theta(theta<0)=theta(theta<0)+360;
    
    RB=sqrt(RS.^2+RH.^2);
    RB(RB>255)=255;

DATACMn(:,1)=theta/360;
DATACMn(:,3)=RB;
% DATACMn(:,2)=1;

    DT{loopin}=DATAn;
    DTCM{loopin}=DATACMn;
    
   if loopin==2 
    
    figure
%     DATACMn(:,2)=1;
    DATAn(:,6:8)=hsv2rgb(DATACMn(:,1:3));

HUE=DATACMn(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACMn,1)
h=polar(2*pi*DATACMn(mt,1),DATACMn(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATAn(mt,6:8)/255)
end

set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure  
    
   end
    
 end
 
 for loopin=1:101 
     
      DATA=DT{loopin};
    DATACM=DTCM{loopin};
        


DATAk=DATA;
DATACMk=DATACM;

HUE=DATACM(:,1)*360;

% res=64;
data=[HUE DATACM(:,3)];
data2=[DATACM(:,3).*cosd(HUE) DATACM(:,3).*sind(HUE)];

  [bandwidth,density,X,Y]=kde2d(data2,res,[-255,-255],[255,255]);  
  
%        hG = fspecial('gaussian',[15 15],3);
               
                      density = imfilter(density,hG,'symmetric'); 
%                                  density=flipud(density);
%                        Y=flipud(Y);

 density2=density./sum(density(:)); 
  density=density2;

nk=512/res;
data3=round((data2+256)/nk);
data3(data3<1)=1;
data3(data3>res)=res;

select2=[];

for n=1:size(data3,1)
    
    select2(n,1)=density(data3(n,2),data3(n,1));
    
end
     
     
 cutpid=0;
 for cutp=[75]
 
     cutpid=cutpid+1;
 
 
select2k=select2<quantile(select2,(1-(cutp/100)));

DATAx=DATA(select2k==1,:);
DATACMx=DATACM(select2k==1,:);

  DTA{loopin,cutpid}=DATAx;
    DTCMA{loopin,cutpid}=DATACMx;
    
    
    
    
   if loopin<3 
    
    figure
    
    DATAx(:,6:8)=hsv2rgb(DATACMx(:,1:3));

HUE=DATACMx(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACMx,1)
h=polar(2*pi*DATACMx(mt,1),DATACMx(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATAx(mt,6:8)/255)
end

set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure  
    
   end
    
    
 
 end
 end

  
 
save(['DATAFC' num2str(idx)],'DTA','DTCMA'); 

load(['DATAFC' num2str(idx)],'DTA','DTCMA'); 
 
 ttt=1;
     cutpid=0;
for cutp=[75]
         cutpid=cutpid+1;
    
for BTH=[100]
    
ncoupA=[];
HTHid=0;

for HTH=[6]
    HTHid=HTHid+1;
    STHid=0;
for STH=[90]   
    STHid=STHid+1;
    ncoup=[];
for loopin=1:101
   

     DATA=DTA{loopin,cutpid};
    DATACM=DTCMA{loopin,cutpid};

    tDATA=DATA;
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(DATA(:,4:5),DATA(:,4:5))*.31;

     
%% check conditions    
   Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(Bdist>BTH)=12000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end  

   xyval(xyval(:,13)>=10000,:)=[];
   
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 
if ttt<3
    ttt=ttt+1;

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%
 if ttt==1
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
 else
 LCOLORL=imread([Reshome3 filesep 'FOXLM2.png']);
 end

 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<10000
%   if mean(pos(:))<10000
     
     colorA(pos)=LCOLORCA(pos)+(256*DATA(cell,6)-mean(LCOLORCA(pos)));
      colorB(pos)=LCOLORCB(pos)+(256*DATA(cell,7)-mean(LCOLORCB(pos)));
       colorC(pos)=LCOLORCC(pos)+(256*DATA(cell,8)-mean(LCOLORCC(pos)));
     cell
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.33*CO;
m=1;
    
     figure
  imshow(COF);hold on
  
     for zin=1:size(xyval,1)   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.75) ; hold on
%          end

     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'CLINK_idx' num2str(idx) 'loop' num2str(ttt)],'-a2', '-m4','-p0','-q101','-png', '-r300');
%close all
 
end 
end

 ncoupA{HTHid,STHid}=ncoup;
 [h,p]=ttest2(ncoup(1),ncoup(2:101));
 ncoup(1)
 mean(ncoup(2:101))
 p
 cutp
 BTH
 HTH
 STH
 
end
end

 save([Reshome3 filesep 'CncoupA_' num2str(cutp) '_' num2str(BTH) '.mat'],'ncoupA');  

end

end


end