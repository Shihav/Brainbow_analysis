clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutup=100;
darkest_cells_cutdown=75;

cr=0;

for sisters=2
LM=1;

nidx=1;
rc=[];
nc=[];

HTH=10;
STH=100;
BTH=80;
SATH=0.33;

ts=0;
tm=0;

DR=0;
OLDIST=7;

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);

final_remove_list;

for idx=[1 2 3 5 7 8]
          
loadaddress;
  
load([Reshome2 filesep 'Pall.mat'],'PDATA'); 
PDATA(Prlist{idx},:)=[];
PDATAB=PDATA;

% rid=randperm(size(PDATA,1));
% PDATA=[PDATA(rid,1:5) PDATA(:,6:11)];

load([Reshome2 filesep 'Nall.mat'],'NDATA');
NDATA(Nrlist{idx},:)=[];


% rid=randperm(size(NDATA,1));
% NDATA=[NDATA(rid,1:5) NDATA(:,6:11)];

nc(nidx)=size(PDATA,1);

dmap=pdist2(PDATA(:,4:5),NDATA(:,4:5));
dmapmin=min(dmap);

NDATA((dmapmin<OLDIST)',:)=[];
NDATAB=NDATA;

DATA=PDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multp=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

tests=[DATA(:,6:8)./DATA(:,9:11)];
testm=DATA(:,6:8);
select=max(tests,[],2)>ts & max(testm,[],2)>tm;
DATA=DATA(select==1,:);

filter_data5;
PSDATA=DATA;

DATA=NDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multn=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

tests=[DATA(:,6:8)./DATA(:,9:11)];
testm=DATA(:,6:8);
select=max(tests,[],2)>ts & max(testm,[],2)>tm;
DATA=DATA(select==1,:);

filter_data5;
NSDATA=DATA;

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];

if DR==2    
BMAKE_FILTERED_PLOT;
end   

    tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=2;
     
     ADATA=ADATA(select,:);  
     
     NSDATA=ADATA(ADATA(:,1)==2,:);
     PSDATA=ADATA(ADATA(:,1)==1,:);
if cr==1     
     rid=randperm(size(PDATAB,1));
PSDATA=[PDATAB(rid(1:size(PSDATA,1)),1:5) PSDATA(:,6:11)];

    rid=randperm(size(NDATAB,1));
NSDATA=[NDATAB(rid(1:size(NSDATA,1)),1:5) NSDATA(:,6:11)];
NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
end
     
 
     tDATA=ADATA;
     tDATACM=rgb2hsv(ADATA(:,6:8));
     DATACM=rgb2hsv(ADATA(:,6:8));
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     
%% check conditions    
%    Costmat=SPACEdist/10+HUEdist;
div=HTH/STH;

% %   Costmat=SPACEdist;%HUEdist + SPACEdist*div;
   if sisters <4
   Costmat=1*HUEdist + SPACEdist*0;
   
   else
%     HUEdist(SPACEdist<(STH/2))=SPACEdist(SPACEdist<(STH/2));
    Costmat=0*HUEdist + SPACEdist*1;
   end
   
   Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
%    Costmat(SPACEdist<=(STH/4) & Costmat<20000)=SPACEdist(SPACEdist<=(STH/4) & Costmat<20000)/STH;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;
                           xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];
                 end  
   xyval(xyval(:,13)>=20000,:)=[];
%    xyval(xyval(:,14)==2 & xyval(:,15)==2,:)=[];
   
if DR==1
    BMAKE_SELECTED_PLOT;
end

imp=(xyval(:,14)==1 & xyval(:,15)==1) | (xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1);
xyvals=xyval(imp,:);

if DR==2
    BMAKE_FINAL_PLOT;
end

SD=sum(xyval(:,14)==1 & xyval(:,15)==1);
AD=sum(xyval(:,14)==1 & xyval(:,15)==2) + sum(xyval(:,14)==2 & xyval(:,15)==1);
rc(nidx,:)=[SD AD];

nidx=nidx+1;

FDATACM=DATACM;
Fxyval=xyval;
FDATA=ADATA;

if load_angle==1
    BMAKE_ANGULAR_PLOT
end

close all
end

myC= [0.5 0.8 0.5;
    0.8 0.8 0.8];

figure
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Symmetric division rate = ' num2str(mn,'%0.2f') '%, total link = ' num2str(sum(rc(:))/2)],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST3'],'-a2', '-m6','-p0.02','-png', '-r600');


figure
rc(:,2)=rc(:,2)/2;
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Origin from symmetric division = ' num2str(mn,'%0.2f') '%, total cell = ' num2str(sum(rc(:)))],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
pbaspect([8,6,1])

 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST4'],'-a2', '-m6','-p0.02','-png', '-r600');


end

