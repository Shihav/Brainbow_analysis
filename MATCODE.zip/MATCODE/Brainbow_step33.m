clear all
close all
clc

idx=8;
loadaddress;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};
     mkdir(Reshome4);

for imgid=1:numel(Types)
     
%        if imgid==13
%     tol=0.045;
%     else
        tol=0.065;
%       end
    
     filename=Types{imgid};
     filename2=strrep(filename,'.tif',''); 
  
VV=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVp.png']);  
imwrite(VV,[Reshome4 filesep filename2 'FmaxVpC.png']);  

end