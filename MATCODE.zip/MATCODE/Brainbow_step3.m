clear all
close all

clc

for idx=8

            loadaddress;

            d=dir(fullfile(Datahome,'*.tif*'));
            Types={d.name};

            BKA=[];

            RAK=[];
            GAK=[];
            BAK=[];

            for imgid=1:numel(Types)

                 filename=Types{imgid};
                 filename2=strrep(filename,'.tif','');     
                    oriname=[Datahome filesep filename2 '.tif'];

                           info = imfinfo(oriname);
                    num_images = numel(info);


             load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');   

              load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');  
              load([Reshome2 filesep filename2 filesep filename2 'Imgsegk4.mat'],'Imgsegk4');
            %   
              Imgsegk2max=max(Imgsegk4,[],3);

              resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];

                if exist(resfile, 'file')==2
              delete(resfile);
                end
                 if size(center,1)>0
            %     MATT=[[1:size(center,1)]' center(:,1:2) round(CA(:,10:12)/16) round(CA(:,16:18)/16)];
                 MATT=[[1:size(center,1)]' center(:,1:2) (CA(:,10:12)) (CA(:,16:18))];
                nps=length(unique(Imgsegk2max))-2;

            % nps=size(center,1);

                clear cell
                B = cell(size(MATT,1),size(MATT,2));
            for ii=1:size(MATT,1)
                for jj=1:size(MATT,2)
              B(ii,jj) = {MATT(ii,jj)};
                end
            end

                BK = cell(size(MATT,1),size(MATT,2));
            for ii=1:size(MATT,1)
                for jj=1:size(MATT,2)
              BK(ii,jj+3) = {MATT(ii,jj)};
                end
                  BK(ii,1) = {filename2};
                   BK(ii,2) = {imgid};
                   BK(ii,3) = {nps};
            end

            BKA=[BKA;BK];
            A = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
            C=[A;BK];
            xlswrite(resfile,C,1,'A1') 
                 end      
            end

            AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue','RedS','GreenS','BlueS'};
            C=[AK;BKA];
               resfile = [Reshome2 filesep 'Result.xlsx'];

                if exist(resfile, 'file')==2
              delete(resfile);
                end

            xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')

            save([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');   



            for imgid=1:numel(Types)

                 filename=Types{imgid};
                 filename2=strrep(filename,'.tif','');     

            load([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR'); 

            [Img11gr,zval11gr]=max(ImgGR,[],3);

            imwrite(uint16(cat(3,Img11gr,Img11gr,Img11gr)),[Reshome2 filesep filename2 filesep filename2 'GRAY2.png']); 
            end

end

