function LABELM=color_seg9(inp)

% inp=C;
close all;
% Img14=img14;

I=inp;
gradmagk=[];
hG = fspecial('gaussian',[15 15],3);
for kin=1:3
    
    I(:,:,kin)=imfilter(I(:,:,kin),hG,'replicate');

hy = fspecial('sobel');
hx = hy';
Iy = imfilter(double(I(:,:,kin)), hy, 'replicate');
Ix = imfilter(double(I(:,:,kin)), hx, 'replicate');
gradmagk(:,:,kin) = sqrt(Ix.^2 + Iy.^2);
end

IG=rgb2gray(I);

gradmag=sum(gradmagk,3);

    I = gradmag;%imgN2;
%     figure, imshow(uint8(I))   
%      I=uint16(65535*mat2gray(localnormalize(double(I),75,75)));
    
    Img1=I;
NCHmax=2;
          mean_s=NCHmax/2;  
       mins=0.51;
        maxs=NCHmax/2;
        kernel_s=round(maxs*5);
    
% IM4=Img1; 
%   fname1=strrep(fname,'.tif','');  

Img=Img1;

        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=imcomplement(Img2);
        Img8=imcomplement(Img);

        max3=max(Img3(:));
        min3=min(Img3(:));

        type=16;
     
        types=linspace(mins,maxs,type);
              Chd= uint16(round(type-1)*mat2gray(Img3))+1;
              Imgn=[];
                   for k=1:type
                  
                      h = fspecial('gaussian',[kernel_s kernel_s],types(k));
                                       Imgn(:,:,k) = imfilter(Img8,h,'replicate');
                   end
              adapt_image=zeros(size(Img8));
              
              for k=1:type
                        temp=Imgn(:,:,k);
                      adapt_image(Chd==k)=temp(Chd==k);
                                  
              end

        Img1=uint16(65535*mat2gray(adapt_image));
                 
       Im2=Img1;
%         Im4=uint16(65535*mat2gray(IM4));
       idx=1; 
       tol(idx)=std(double(Im2(:)))/sqrt(3);
       
    MIJ.createImage(Im2);
    MIJ.run('Find Maxima...', sprintf('noise=%d output=[Segmented Particles]',tol(idx)));
    I = MIJ.getCurrentImage;
    
    MIJ.closeAllWindows;
 
    Img11=uint16(65535*mat2gray(I));

%     ImgOut11=uint16(plot_maxima2(Im4,imcomplement(Img11)));

classmap5=bwlabel(Img11);
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));

Img12=bwareaopen(Img11>0,5000);
Img13=(Img11>0)-Img12;

% Img14=imdilate(Img14,ones(5,5));

% Img13(Img14>0)=0;

% lblImg = bwlabel(Img13);

classmap5=bwlabel(Img13);
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));


% LABELM=classmap5;
% classmap=LABELM;
% pcells=unique(classmap);
% 
%          for nk=2:length(pcells)            
%             val=pcells(nk);  
%             object2 = classmap==val;
%             sizek=sum(sum(object2));
% %             IGG=median(IG(object2));
%             
%             if sizek<110 
% %                 if IGG>(65535*0.1) && sizek>45
% %                 else
%                 
%                 classmap(object2)=0;
% %                 end
% %                 Imgsegk(Imgsegk==val)=0;                
%             end
%          end
% 
% classmap5=classmap;
% figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));


classmapR=inp(:,:,1);
classmapG=inp(:,:,2);
classmapB=inp(:,:,3);
sek = ones(5); 
  tol=0.05;
   CTH=13;
                           
classmap4=classmap5; 
pcells=unique(classmap4);
se = ones(5); 


for nid=2:length(pcells)
       
        label = pcells(nid); 
object = classmap4 == label;
ownA=sum(sum(object));

neighbours = imdilate(object, se) & ~object;
neighbourLabels = unique(classmap4(neighbours));
neighbourLabels(1)=[];

Ath=885;

if ~isempty(neighbourLabels)
    if ownA<Ath
    Hk=[];
    for kin=1:length(neighbourLabels)
        
        H1=rgb2hsv([mean(classmapR(classmap4==neighbourLabels(kin)))/256 mean(classmapG(classmap4==neighbourLabels(kin)))/256 mean(classmapB(classmap4==neighbourLabels(kin)))/256]);
        H1=360*H1(:,1);

        H2=rgb2hsv([mean(classmapR(classmap4==label))/256 mean(classmapG(classmap4==label))/256 mean(classmapB(classmap4==label))/256]);
        H2=360*H2(:,1);

        H=abs(H1-H2);
        H(H>180)=360-H(H>180);
        
        
    
    Hk(kin)=H;
    end
    [Hk2,kin]=min(Hk);
    
    areak=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));

    block=classmap4==neighbourLabels(kin) | classmap4==label;
    [X,Y]=find(block==1);
    
    [CH,Ak]= convhull(X,Y);

    H=Hk(kin);

            if ((Ak-areak)/Ak) <tol && H<CTH

                ND=max([label neighbourLabels(kin)]);
                
                object2 = classmap4 == neighbourLabels(kin);

                classmap5(object2)=ND;
                 classmap5(object)=ND;

                middle = imdilate(object2, sek) & imdilate(object, sek);
                classmap5(middle)=ND; 
                
            end
    end
end
nid;
end

figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));

classmap4=classmap5; 
pcells=unique(classmap4);
se = ones(5); 

for nid=2:length(pcells)
       
        label = pcells(nid); 
object = classmap4 == label;
ownA=sum(sum(object));

neighbours = imdilate(object, se) & ~object;
neighbourLabels = unique(classmap4(neighbours));
neighbourLabels(1)=[];

Ath=885;

if ~isempty(neighbourLabels)
    if ownA<Ath
    Hk=[];
    for kin=1:length(neighbourLabels)
        
        H1=rgb2hsv([mean(classmapR(classmap4==neighbourLabels(kin)))/256 mean(classmapG(classmap4==neighbourLabels(kin)))/256 mean(classmapB(classmap4==neighbourLabels(kin)))/256]);
        H1=360*H1(:,1);

        H2=rgb2hsv([mean(classmapR(classmap4==label))/256 mean(classmapG(classmap4==label))/256 mean(classmapB(classmap4==label))/256]);
        H2=360*H2(:,1);

        H=abs(H1-H2);
        H(H>180)=360-H(H>180);
        
        
    
    Hk(kin)=H;
    end
    [Hk2,kin]=min(Hk);
    
    areak=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));

    block=classmap4==neighbourLabels(kin) | classmap4==label;
    [X,Y]=find(block==1);
    
    [CH,Ak]= convhull(X,Y);

    H=Hk(kin);

            if ((Ak-areak)/Ak) <tol && H<CTH

                ND=max([label neighbourLabels(kin)]);
                
                object2 = classmap4 == neighbourLabels(kin);

                classmap5(object2)=ND;
                 classmap5(object)=ND;

                middle = imdilate(object2, sek) & imdilate(object, sek);
                classmap5(middle)=ND; 
                
            end
    end
end
nid;
end

figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));



LABELM=classmap5;
classmap=LABELM;


pcells=unique(classmap);

         for nk=2:length(pcells)            
            val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));
%             IGG=median(IG(object2));
            
            if sizek<200
%                 if IGG>(65535*0.1) && sizek>45
%                 else
                
                classmap(object2)=0;
%                 end
%                 Imgsegk(Imgsegk==val)=0;                
            end
         end
         
         
figure,imshow(label2rgb(classmap,'jet','k','shuffle'));
            
pcells=unique(classmap);

         for nk=2:length(pcells)  
              val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));      
                                         
                                             [X,Y]=find(object2==1);
    
                                          [CH,Ak]= convhull(X,Y);  
                                                                                    
                                          if (abs(double(Ak)-double(sizek))/double(sizek)) >0.25 
                                                classmap(object2)=0;

                                          end
                                          
            nk ;
         end
         
         figure,imshow(label2rgb(classmap,'jet','k','shuffle'));
         
 pcells=unique(classmap);

         for nk=2:length(pcells)  
              val=pcells(nk);  
            object2 = classmap==val;
            
            IGG=max([mean(classmapR(object2)) mean(classmapG(object2)) mean(classmapB(object2))]);
            
%             sizek=sum(sum(object2));  
                                          
                                          if IGG<(65535*0.08)
                                                classmap(object2)=0;

                                          end
                                          
%                                           if sizek

            nk ;
         end
         
         figure,imshow(label2rgb(classmap,'jet','k','shuffle'));
         
          figure,imshow(inp);
       
LABELM=classmap;
classmap5=LABELM;
LABELM=classmap5;

% close all
