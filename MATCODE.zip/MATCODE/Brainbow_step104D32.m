clear all
close all

clc
mn=[130 1429 69 1490];
mn=[525 944 590 879];
mn=[82 1296 845 533];

% mn=[380 642 543 479];
% mn=[545 649 546 648];
idx=3;
borders=10;
borderb=15;

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14P' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_MP' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14N' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_MN' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_RP' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_NP' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_RN' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_NN' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14P' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_OP' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14N' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_ON' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_RP' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_PP' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_RN' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_PN' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_AC' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_A' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_AM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_AM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_B' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_BM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_BM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3FSEG' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_C' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_CM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_CM2' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_Fplus' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_D' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_DM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_DM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_E' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_EM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_EM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3GRAD' '.png']);
A=256*uint16(cat(3,A,A,A));
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_F' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_FM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_FM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3NFSEG' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_G' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_GM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_GM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_Fminus' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_H' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_HM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_HM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_AC' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_I' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_IM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_IM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_J' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_JM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_JM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_RP' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_K' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_KM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_KM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_L' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_LM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_LM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_M' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_N' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_O' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_P' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_RLWO' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_Q' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_QM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_QM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_RLO' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_R' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_RM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_RM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_RLOG' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_S' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_SM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_SM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_RFOG' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_T' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_TM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_TM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_P' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_U' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_UM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_UM2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_N' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_V' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_VM' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_VM2' '.png']);

