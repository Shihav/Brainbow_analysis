  tDATA=ADATALA;
    DATACM=rgb2hsv(ADATALA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LMH);
     BdistB=Bdist<=(BTH*LMB);
     SPACEdistB=SPACEdist<=(STH*LMS);
     SATdistB=SATdist<=(SATH*LMSAT);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=CPL;
     
     if singles==1
     select1=sum(PC,2)==1 & tDATA(:,1)==1;
     select=select | select1;
     end

     
     ADATALA=ADATALA(select,:);  

    tDATA=ADATALA;
     tDATACM=rgb2hsv(ADATALA(:,6:8));
     DATACM=rgb2hsv(ADATALA(:,6:8));
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

   Costmat=1*HUEdist + SPACEdist*0;
   Costmat1 = diag(diag(Costmat)+1);   
   Costmat(Costmat1>0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
 
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;
                             xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];
                            xyval(cp,16:17)=[tDATA(Aida(cp,1),end) tDATA(Aida(cp,2),end)];
                            xyval(cp,18:19)=[tDATA(Aida(cp,1),12) tDATA(Aida(cp,2),12)];
                            xyval(cp,20:21)=[tDATA(Aida(cp,1),13) tDATA(Aida(cp,2),13)];
                 end  
   xyval(xyval(:,13)>=20000,:)=[];

imp=(xyval(:,14)==1 & xyval(:,15)==1) | (xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1);
xyvals=xyval(imp,:);
ADATAS=ADATALA(unique(xyvals(:,8:9)),:);

ADATAL=ADATALA;
ADATAL(unique(xyvals(:,8:9)),:)=[];


xyvalAR=[xyvalAR;xyval];
ADATASAR=[ADATASAR;ADATAS];
xyvalsAR=[xyvalsAR;xyvals];
ADATALA=ADATAL;
