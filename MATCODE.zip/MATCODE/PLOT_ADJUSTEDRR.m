figure()

%     valn=DATA(:,6);
%      valr=DATA(:,7);
%      vals=DATA(:,8);
%      val=(valn+valr+vals);
%      NMI=valn./val; 
%      RMSE=valr./val; 
%      SNR=vals./val; 
%     for n=1:size(DATA,1)
%        ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
%        %terncontour(NMI,RMSE,SNR,Z);hold on;
%     end
%      ternlabel('RED', 'GREEN', 'BLUE')      
% 
% title('Brighten ternary plot');
% % print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Brighten ternary plot'], '-dpng', '-r300'); 
% set(gcf,'color','w');
% export_fig(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Brighten ternary plot'],'-a2', '-m4','-p0','-q101','-png', '-r600');
% 

 figure()
h=scatter(DATA(:,6),DATA(:,9),25,[DATA(:,6)/255 0*DATA(:,6)/255 0*DATA(:,6)/255],'filled');
xlim([0 250]);
ylim([0 128]);
 xlabel('Mean','FontSize', 20,'FontName','Times');
                                            ylabel('Standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Mean vs Standard deviation - RED'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Mean vs Standard deviation - REDM'], '-dpng', '-r300'); 
set(gcf,'color','w');
export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'SisterF4_assignment_idx' num2str(idx)  '_Mean vs Standard deviation - RED'],'-a2', '-m4','-p0','-q101','-png', '-r600');



 figure()
h=scatter(DATA(:,7),DATA(:,10),25,[0*DATA(:,7)/255 DATA(:,7)/255 0*DATA(:,7)/255],'filled');
xlim([0 250]);
ylim([0 128]);
 xlabel('Mean','FontSize', 20,'FontName','Times');
                                            ylabel('Standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Mean vs Standard deviation - GREEN'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Mean vs Standard deviation - GREENM'], '-dpng', '-r300'); 
set(gcf,'color','w');
export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'SisterF4_assignment_idx' num2str(idx)  '_Mean vs Standard deviation - GREEN'],'-a2', '-m4','-p0','-q101','-png', '-r600');

 figure()
h=scatter(DATA(:,8),DATA(:,11),25,[0*DATA(:,8)/255 0*DATA(:,8)/255 DATA(:,8)/255],'filled');
xlim([0 250]);
ylim([0 128]);
 xlabel('Mean','FontSize', 20,'FontName','Times');
                                            ylabel('Standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Mean vs Standard deviation - BLUE'], 'FontSize',24,'FontName','Times') % y-axis label                                           
% print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_Mean vs Standard deviation - BLUEM'], '-dpng', '-r300'); 
set(gcf,'color','w');
export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'SisterF4_assignment_idx' num2str(idx)  '_Mean vs Standard deviation - BLUE'],'-a2', '-m4','-p0','-q101','-png', '-r600');

figure
HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATA(mt,6:8)/256)
end
%                                             ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['HSV distribution'], 'FontSize',24,'FontName','Times') % y-axis label   
                                             a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',12,'FontName','Times');
b = get(gca,'YTickLabel');
set(gca,'YTickLabel',b,'FontName','Times','fontsize',12,'FontName','Times');

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
% print(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)  '_HSV distributionTM'], '-dpng','-r300'); 

set(gcf,'color','w');
export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'SisterF4_assignment_idx' num2str(idx)  '_HSV distributionT'],'-a2', '-m4','-p0','-q101','-png', '-r600');
