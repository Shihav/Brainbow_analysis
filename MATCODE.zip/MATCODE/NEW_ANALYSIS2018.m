clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

zres=[0.52 0.36 0.36 1 0.36 1 0.47 0.47 1 0.36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);

pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];
xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE' ]);
% m=1;
m{3}=[3139 785 2245 854];

count=[];
infoTA=[];
infoQA=[];
infoDA=[];
MATNA=[];
HUE_6A=[];
HUE_32A=[];
clones=[];
CL=[];
 mn=[1 0 1 0];
 lim=[2:32]
for idx=[1 2 3 5 7 8]% 11 12 13 14 15 16 17 18]
   if idx>10
       xyr=0.297;
   else
    xyr=0.31;
   end
%       mn=m{idx};  
     if idx==7
     LW=0.2;
     else
     LW=0.4;
     end
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB',...
    'valAT','valAQ','LINKA','xyvalsAR','RAWFT');

DATA=[PDATABB;NDATABB];
DATAT=DATA(:,6:8);
DATAT(DATAT>=255)=255;
NL=prctile(DATAT,5,1);

AG=imread([Reshome3 filesep 'mosaicG.png']);
AG=AG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
RAWFM=RAWF;
RAWFM(:,2)=10000*(RAWFM(:,1)-1)+RAWFM(:,2);
RAWFK=RAWFM;
xyvalsARM=xyvalsAR;

ADATAS=[];
xyvals=[];
valATC=[];
infoTA=[];

type=[];

for kin=1:size(LINKA,1)    
    val=size(LINKA{kin,1},1);    
        type=[type;val];            
end

unique(type);

for CS=lim
    
    [ADATAS_R_M,xyvals_R_M,ADATAS_R_MR]=crop_cell_link_dyn(RAWFM,xyvalsARM,mn,AG,LINKA,0,CS);
[ADATAS_R_M,xyvals_R_M,ADATAS_R_MRN]=crop_cell_link_dynN(ADATAS_R_M,xyvals_R_M,mn,AG,LINKA,0,CS);

RAWF=ADATAS_R_M;
xyvalsAR=xyvals_R_M;

if size(RAWF,1)>0

valA=[];
for kin=1:size(LINKA,1)    
    val=LINKA{kin,1};    
    if size(val,1)==CS       
        valA=[valA;val];        
    end    
end
valATC{CS}=valA;
valAT=valA;
valA=unique(valA);

ADATAS{CS}=RAWF(ismember(RAWF(:,2),valA),:);
xyvals{CS}=xyvalsAR(ismember(xyvalsAR(:,24),valA) & ismember(xyvalsAR(:,25),valA),:);%xyvalsAR(ismember(xyvalsAR(:,25),valA),:)];

ADATAS_T=ADATAS{CS};
% DG=[1 0 0; 0 1 0; 0 0 1];
% ADATAS_T(:,2)=10000*(ADATAS_T(:,1)-1)+ADATAS_T(:,2);
TAG=zeros(size(ADATAS_T,1),1);

for kin=1:CS:size(valAT,1)
 ar=valAT(kin:kin+CS-1);
 
 TAG(ismember(ADATAS_T(:,2),ar))=kin;

end

    if mod(size(TAG,1),CS)==0

    pcells=unique(TAG);
    infoT=[];
    LN=zeros(size(ADATAS_T,1),2);
    ADATAS_T=[ADATAS_T LN];
    for kin=1:length(pcells)

       TEM=ADATAS_T(TAG==pcells(kin),:);
        infoT(kin,1)=sum(TEM(:,1)==1);
        DATAT=TEM(:,6:8);

        DATAT(DATAT>255)=255;
        DATAT(:,1) =255*imadjust(DATAT(:,1)/255,[NL(1) 255]/255,[0 255]/255);
        DATAT(:,2) =255*imadjust(DATAT(:,2)/255,[NL(2) 255]/255,[0 255]/255);
        DATAT(:,3) =255*imadjust(DATAT(:,3)/255,[NL(3) 255]/255,[0 255]/255);

        DATACM=rgb2hsv(DATAT);

        HUE=DATACM(:,1)*360;
        ADATAS_T(TAG==pcells(kin),15)=HUE;
        if sum(TEM(:,1)==1)==CS
            ADATAS_T(TAG==pcells(kin),14)=1;
        else
            ADATAS_T(TAG==pcells(kin),14)=-sum(TEM(:,1)==1);
        end


    end
    ADATAS{CS}=ADATAS_T;
    infoTA{CS}=[infoT];

    LR=ismember(RAWFM(:,2),RAWF(:,2));
    RAWFM(LR,:)=[];
    xyvalsARM(ismember(xyvalsARM(:,24),RAWF(:,2)),:)=[];
    LINKA(LR,:)=[];
    else
        ADATAS{CS}=[];
        infoTA{CS}=[];
        valATC{CS}=[];
        xyvals{CS}=[];
        
    end

else
ADATAS{CS}=[];
infoTA{CS}=[];
valATC{CS}=[];
xyvals{CS}=[];
end

end

ADATAS_F=ADATAS;
infoTA_F=infoTA;
valATC_F=valATC;
xyvals_F=xyvals;


MATN=[];


ADATAS_PA=[];
ADATAS_NA=[];
xyvals_PA=[];
xyvals_NA=[];

for kin=lim
    
    ADATAS_PAt=ADATAS{kin};
    if size(ADATAS_PAt,1)>0
    ADATAS_PAt=ADATAS_PAt(ADATAS_PAt(:,14)==1,:);
    
    xyvals_PAt=xyvals{kin};
    xyvals_PAt=xyvals_PAt(ismember(xyvals_PAt(:,24),ADATAS_PAt(:,2)),:);
    
    ADATAS_PA=[ADATAS_PA;ADATAS_PAt];
    xyvals_PA=[xyvals_PA;xyvals_PAt];
     
    ADATAS_NAt=ADATAS{kin};
    ADATAS_NAt=ADATAS_NAt(ADATAS_NAt(:,14)<1,:);
    
    xyvals_NAt=xyvals{kin};
    xyvals_NAt=xyvals_NAt(ismember(xyvals_NAt(:,24),ADATAS_NAt(:,2)),:);
    
    ADATAS_NA=[ADATAS_NA;ADATAS_NAt];
    xyvals_NA=[xyvals_NA;xyvals_NAt];
    end
    
    
    
end

ADATAS_P6=[];
ADATAS_N6=[];
xyvals_P6=[];
xyvals_N6=[];

ADATAS_P32=[];
ADATAS_N32=[];
xyvals_P32=[];
xyvals_N32=[];
HUE_6=[];
HUE_32=[];

for kin=2:6
    
    ADATAS_PAt=ADATAS{kin};
    if size(ADATAS_PAt,1)>0
    ADATAS_PAt=ADATAS_PAt(ADATAS_PAt(:,14)==1,:);
    
    xyvals_PAt=xyvals{kin};
    xyvals_PAt=xyvals_PAt(ismember(xyvals_PAt(:,24),ADATAS_PAt(:,2)),:);
    
    ADATAS_P6=[ADATAS_P6;ADATAS_PAt];
    xyvals_P6=[xyvals_P6;xyvals_PAt];
    HUE_6=[HUE_6;ADATAS_P6(:,15)];
     
    ADATAS_NAt=ADATAS{kin};
    ADATAS_NAt=ADATAS_NAt(ADATAS_NAt(:,14)<1,:);
    
    xyvals_NAt=xyvals{kin};
    xyvals_NAt=xyvals_NAt(ismember(xyvals_NAt(:,24),ADATAS_NAt(:,2)),:);
    
    ADATAS_N6=[ADATAS_N6;ADATAS_NAt];
    xyvals_N6=[xyvals_N6;xyvals_NAt];
    HUE_6=[HUE_6;ADATAS_N6(:,15)];
    end
    
    
end

for kin=7:32
    
    ADATAS_PAt=ADATAS{kin};
    if size(ADATAS_PAt,1)>0
    ADATAS_PAt=ADATAS_PAt(ADATAS_PAt(:,14)==1,:);
    
    xyvals_PAt=xyvals{kin};
    xyvals_PAt=xyvals_PAt(ismember(xyvals_PAt(:,24),ADATAS_PAt(:,2)),:);
    
    ADATAS_P32=[ADATAS_P32;ADATAS_PAt];
    xyvals_P32=[xyvals_P32;xyvals_PAt];
    if kin<33
    HUE_32=[HUE_32;ADATAS_P32(:,15)];
    end
     
    ADATAS_NAt=ADATAS{kin};
    ADATAS_NAt=ADATAS_NAt(ADATAS_NAt(:,14)<1,:);
    
    xyvals_NAt=xyvals{kin};
    xyvals_NAt=xyvals_NAt(ismember(xyvals_NAt(:,24),ADATAS_NAt(:,2)),:);
    
    ADATAS_N32=[ADATAS_N32;ADATAS_NAt];
    xyvals_N32=[xyvals_N32;xyvals_NAt];
    if kin<33
    HUE_32=[HUE_32;ADATAS_N32(:,15)];
    end
    end
    
    
end





for kin=2:6
    
    temp=infoTA_F{kin};
    pclone=sum(temp==kin);
    nclone=sum(temp<kin);
    MATN(kin-1,1)=kin;
    MATN(kin-1,2)=pclone;
    MATN(kin-1,3)=nclone;
    
    for pin=1:kin-1
        MATN(kin-1,3+pin)=sum(temp==pin);
        
    end
    
end

temp6=[];
temp32=[];
for kin=2:6
    
    temp=infoTA_F{kin};
    temp6=[temp6;temp];
    
end

for kin=7:32
    
    temp=infoTA_F{kin};
    temp32=[temp32;temp];
    
end

for kin=lim
    
    temp=infoTA_F{kin};
    CL(pool(idx),kin)=size(temp,1);
    
end

clones(pool(idx),1)=size(temp6,1);
clones(pool(idx),2)=size(temp32,1);

save([Reshome2 filesep '36DATA2' num2str(idx) '.mat'],'ADATAS_F','infoTA_F','valATC_F','xyvals_F','MATN','ADATAS_NA','ADATAS_PA',...
    'xyvals_NA','xyvals_PA','ADATAS_N6','ADATAS_P6','xyvals_N6','xyvals_P6','ADATAS_N32','ADATAS_P32','xyvals_N32','xyvals_P32');


   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'CLONE_M' num2str(pool(idx)) '.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end


myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Clones of\tAll FoxJ1+\tNot all FoxJ1+\t1 FoxJ1+\t2 FoxJ1+\t3 FoxJ1+\t41 FoxJ1+\t5 FoxJ1+\n');


    for ii=1:size(MATN,1)

        fprintf(myfile,['Clones of ' num2str(MATN(ii,1))]);
        fprintf(myfile,'\t');
         
        fprintf(myfile,num2str(MATN(ii,2)));
        fprintf(myfile,'\t');
        
        fprintf(myfile,num2str(MATN(ii,3))); 
        fprintf(myfile,'\t');
        
%         if ii==1
%         fprintf(myfile,[num2str(MATN(ii,4)) '\t']); 
%         fprintf(myfile,'\n');   
%         elseif ii==2
%         fprintf(myfile,[num2str(MATN(ii,4)) '\t' num2str(MATN(ii,5)) '\t']); 
%         fprintf(myfile,'\n'); 
%         elseif ii==3
%         fprintf(myfile,[num2str(MATN(ii,4)) '\t' num2str(MATN(ii,5)) '\t' num2str(MATN(ii,6)) '\t']); 
%         fprintf(myfile,'\n'); 
%         elseif ii==4
%         fprintf(myfile,[num2str(MATN(ii,4)) '\t' num2str(MATN(ii,5)) '\t' num2str(MATN(ii,6)) '\t' num2str(MATN(ii,7)) '\t']); 
%         fprintf(myfile,'\n'); 
%         elseif ii==5
        fprintf(myfile,[num2str(MATN(ii,4)) '\t' num2str(MATN(ii,5)) '\t' num2str(MATN(ii,6)) '\t' num2str(MATN(ii,7)) '\t' num2str(MATN(ii,8)) '\t']); 
        fprintf(myfile,'\n'); 
%         end
    end
    
    A=sum(MATN,1);
    
    fprintf(myfile,'Total clones of 2-6');
        fprintf(myfile,'\t');
         
        fprintf(myfile,num2str(A(1,2)));
        fprintf(myfile,'\t');

        fprintf(myfile,num2str(A(1,3))); 
        fprintf(myfile,'\t\n');
 fclose(myfile);   

 MATNA{pool(idx)}=MATN;
 
 HUE_6A=[HUE_6A;HUE_6];
 HUE_32A=[HUE_32A;HUE_32];
idx
close all
end

% resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'CLONE_ALLTYPE.xls'];
% if exist(resfile3, 'file')==2
% delete(resfile3);
% end
% 
% 
% myfile = fopen(resfile3 ,'wt'); 
% % fprintf(myfile,'Mosaic_id\tTotal clone\tClones of 2\tClones of 3\tClones of 4-6\tClones of 7-32\t\n');
% 
% 
%     for ii=1:14
%         
%         for kin=1:32
% 
%         fprintf(myfile,[num2str(CL(ii,kin))]);
%         fprintf(myfile,'\t');
%         end
%         fprintf(myfile,'\n');
%     end
%     
% fclose(myfile);  



% resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'CLONE_TYPE.xls'];
% if exist(resfile3, 'file')==2
% delete(resfile3);
% end
% 
% 
% myfile = fopen(resfile3 ,'wt'); 
% fprintf(myfile,'Mosaic_id\tTotal clone\tClones of 2-6\tClones of 7-32\t\n');
% 
% 
%     for ii=1:14
% 
%         fprintf(myfile,['M ' num2str(ii)]);
%         fprintf(myfile,'\t');
%          
%         fprintf(myfile,num2str(clones(ii,1)+clones(ii,2)));
%         fprintf(myfile,'\t');
% 
%         fprintf(myfile,num2str(clones(ii,1))); 
%         fprintf(myfile,'\t');
%         
%         fprintf(myfile,num2str(clones(ii,2)));
%         fprintf(myfile,'\t\n');
%     end
%     
% fclose(myfile);   





% resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'All_CLONE_FOXJ1.xls'];
% if exist(resfile3, 'file')==2
% delete(resfile3);
% end
% 
% 
% myfile = fopen(resfile3 ,'wt'); 
% fprintf(myfile,'Mosaic id\tClones of 2\tClones of 3\tClones of 4\tClones of 5\tClones of 6\tAll clones from 2-6\n');
% 
% 
%     for ii=1:14
%         MATN=MATNA{ii};
% 
%         fprintf(myfile,['M ' num2str(ii)]);
%         fprintf(myfile,'\t');
%          
%         fprintf(myfile,num2str(MATN(1,2)));
%         fprintf(myfile,'\t');
% 
%         fprintf(myfile,num2str(MATN(2,2))); 
%         fprintf(myfile,'\t');
%         
%         fprintf(myfile,num2str(MATN(3,2)));
%         fprintf(myfile,'\t');
%                         
%         fprintf(myfile,num2str(MATN(4,2)));
%         fprintf(myfile,'\t');        
%                 
%         fprintf(myfile,num2str(MATN(5,2)));
%         fprintf(myfile,'\t');        
%                 
%         fprintf(myfile,num2str(sum(MATN(:,2))));
%         fprintf(myfile,'\t\n');
%     end
%     
% fclose(myfile);   


% resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'NOT_All_CLONE_FOXJ1.xls'];
% if exist(resfile3, 'file')==2
% delete(resfile3);
% end
% 
% 
% myfile = fopen(resfile3 ,'wt'); 
% fprintf(myfile,'Mosaic id\tClones of 2\tClones of 3\tClones of 4\tClones of 5\tClones of 6\tAll clones from 2-6\n');
% 
% 
%     for ii=1:14
%         MATN=MATNA{ii};
% 
%         fprintf(myfile,['M ' num2str(ii)]);
%         fprintf(myfile,'\t');
%          
%         fprintf(myfile,num2str(MATN(1,3)));
%         fprintf(myfile,'\t');
% 
%         fprintf(myfile,num2str(MATN(2,3))); 
%         fprintf(myfile,'\t');
%         
%         fprintf(myfile,num2str(MATN(3,3)));
%         fprintf(myfile,'\t');
%                         
%         fprintf(myfile,num2str(MATN(4,3)));
%         fprintf(myfile,'\t');        
%                 
%         fprintf(myfile,num2str(MATN(5,3)));
%         fprintf(myfile,'\t');        
%                 
%         fprintf(myfile,num2str(sum(MATN(:,3))));
%         fprintf(myfile,'\t\n');
%     end
%     
% fclose(myfile);   

% HUE_6A=unique(HUE_6A);
% HUE_32A=unique(HUE_32A);
close all
save HUE_6A HUE_6A
save HUE_32A HUE_32A
   
addpath('C:\Users\shiha\Downloads\circstat2010b')

data1=HUE_6A;
data2=HUE_32A;
% [p,h,stats] = ranksum(data1,data2)
% 
% [h1,p1] = kstest(data1);
% [h2,p2] = kstest(data2);
[pval, k, K] = circ_kuipertest(degtorad(data1'),degtorad(data2'))

% h=polarhistogram(degtorad(data1'),36,'Normalization','pdf','DisplayStyle','bar')
% Center=[5:10:355];
% col2=hsv2rgb([Center'/360 ones(36,1) 1*ones(36,1)]);
% h=polarhistogram(degtorad(data1'),36,'Normalization','pdf','DisplayStyle','bar','FaceColor',col2','FaceAlpha',.3)
% for kin=1:size(Yin2,2)
% 
% h = patch(Xin2(:,kin), Yin2(:,kin), col2(kin,:));
% alpha(h, .5)       %# note: this switches to OpenGL renderer
% set(h,'EdgeColor','none','Linewidth',.1);  
%                        hold on                                                         
% end
col=[.8 .1 .1; 0.1 0.1 0.8; 0.5 0.5 0.5];

                                            minS=0;
                                            maxS=360;

                                            Distk=[0:10:360];
                                            Center=[5:10:355];
%                                             figure()
                                            [n1,x11] = histc(data1',Distk);
                                            n1(37)=[];
                                             [n2,x22] = histc(data2',Distk);
                                            n2(37)=[];
%                                              [n3,x33] = histc(data3',Distk);
%                                             n3(19)=[];
                                                                                     
        n11=100*n1/sum(n1);
            n22=100*n2/sum(n2);


figure
           
           MVAL=max([n11 n22]);
   [t,r] = rose(degtorad(data2'),36); 
ADJ=n22(1)./r(2);
r=r*ADJ;

%  h2=compass(n22.*cosd(Center),n22.*sind(Center));
%                     set(h2,'Color',[1 1 1],'linewidth',0.001) 
%                     hold on

rMax = MVAL;
dd=[10:30:340];
h2 = compass(15.*cosd(dd),15.*sind(dd));
set(h2,'Color',[1 1 1],'linewidth',0.001);hold on 

%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t,r);
Cut=1;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;
col2=hsv2rgb([Center'/360 ones(36,1) 160*ones(36,1)])/255;
for kin=1:size(Yin2,2)

h = patch(Xin2(:,kin), Yin2(:,kin), 'w');
alpha(h, .5)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.1 0.1 0.8],'Linewidth',1);  
                       hold on                                                         
end
%   [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n22.*cosd(Center),n22.*sind(Center),0.99);
%      plot(arrowx,arrowy,'Color',[0.1 0.1 0.8],'linewidth',0.75);

deg=0.1;
ang=deg/(2*pi);

[t,r] = rose(degtorad(data1'),36);               %# this does not generate a plot
ADJ=n11(1)./r(2);
r=r*ADJ;
%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t+ang/7,r);
Cut=1;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;
col2=hsv2rgb([Center'/360 ones(36,1) 255*ones(36,1)])/255;
for kin=1:size(Yin2,2)

h = patch(Xin2(:,kin), Yin2(:,kin), 'w');
alpha(h, .5)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.8 0.1 0.1],'Linewidth',1);  
                       hold on                                                         
end
% h = patch(Xin2, Yin2, 'g');
% alpha(h, 1)       %# note: this switches to OpenGL renderer
% set(h,'EdgeColor',[0.8 0.1 0.1],'Linewidth',1);  
%                        hold on                                                         

 
%   [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n11.*cosd(Center+deg),n11.*sind(Center+deg),0.99);
%      plot(arrowx,arrowy,'Color',[0.8 0.1 0.1],'linewidth',0.75);                      
set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure 
% title(['P value =' num2str(pval)],'FontName','Times','fontsize',20);
% text(-13,1,'Clones of 2 - 6','FontName','Times','fontsize',10,'Color',[0.8 0.1 0.1]);
% text(-13,-1,'Clones of 7 - 32','FontName','Times','fontsize',10,'Color',[0.1 0.1 0.8]);
% text(-35,21,'Others','FontName','Times','fontsize',15,'Color',[0.5 0.5 0.5]);
       
                                           
%                                                                                 
%                                                 ax = gca;
%                                                 grid off
%                                                 
%                                                         a = get(gca,'XTickLabel');
%                                                 set(gca,'XTickLabel',a,'FontName','Times','fontsize',10);
%                                                 b = get(gca,'YTickLabel');
%                                                 set(gca,'YTickLabel',b,'FontName','Times','fontsize',10);

%                                                                                             set(gcf,'PaperPositionMode','auto')
%  set(gcf,'PaperPositionMode','auto')
%  export_fig([FR filesep 'Vector_angle9'],'-native', '-a2', '-m4','-q101','-png', '-r600');
%                                                         print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'HUE_DISTRIBUTION_VARIATION'], '-dpng', '-r600');
%                                                                                         set(gcf,'Units','inches');
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'HUE_DISTRIBUTION_VARIATION'],'-a1', '-m3','-p0','-q101','-png', '-r600');
  % screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% % print -dpdf -painters epsFig

  
%    print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'HUE_DISTRIBUTION_VARIATION.pdf'], '-dpdf', '-r600');     
   
pval

 
