

load countA.mat 'countA'
close all

clc
% mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT']);

load TQRES.mat infoTA infoQA infoDA



myC= [0.9 0.7 0.7;
    0.7 0.9 0.7;
    0.7 0.7 0.9];
k=1;
rc=[];
temt=zeros(14,3);
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=countA{kin};
    
  rc(k,1)=tem(9,3)/2;    
%   rc(k,1)=tem(9,3)/2+tem(4,3)/2;  
  rc(k,2)=tem(10,3)/3;
  rc(k,3)=tem(11,3)/4;
   
  k=k+1;
  
  temt=temt+tem;
  
  
   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' num2str(kin) 'Count.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
% xlswrite(resfile3,SUMR,1,'A1')
% close all

MATN=tem;

myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Catagoy\tEPENDYNAL\tNEURAL\tTOTAL\t\n');

tp={'Brainbow','Singles','Neural only','Very frequent','Remaining','Symmetric','Asymmteric','Doublet', 'Triplet', 'Quadruplet','double division'};

% fprintf(myfile,'Cell ID\tG mean\t\n');
% fprintf(myfile,'%g\t%g\n',MATN');


    for ii=2:size(MATN,1)-2
        for jj=1:size(MATN,2)+1
            if jj==1
        fprintf(myfile,tp{1,ii-1});
        fprintf(myfile,'\t');
            elseif jj>1 && jj<(size(MATN,2)+1)
        fprintf(myfile,num2str(MATN(ii,jj-1))); 
        fprintf(myfile,'\t');
            else
        fprintf(myfile,num2str(MATN(ii,jj-1))); 
        fprintf(myfile,'\t\n');
            end
        end
    end



% sa = size(MATN);
% fprintf(myfile,[repmat('%g\t',1,sa(2)-1) '%g\n'],MATN.');
fclose(myfile);
  
  
  
    
end

   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'Total Count.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end

MATN=temt;

myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Catagoy\tEPENDYNAL\tNEURAL\tTOTAL\t\n');

tp={'Brainbow','Singles','Neural only','Very frequent','Remaining','Symmetric','Asymmteric','Doublet', 'Triplet', 'Quadruplet','double division'};

% fprintf(myfile,'Cell ID\tG mean\t\n');
% fprintf(myfile,'%g\t%g\n',MATN');


    for ii=2:size(MATN,1)-2
        for jj=1:size(MATN,2)+1
            if jj==1
        fprintf(myfile,tp{1,ii-1});
        fprintf(myfile,'\t');
            elseif jj>1 && jj<(size(MATN,2)+1)
        fprintf(myfile,num2str(MATN(ii,jj-1))); 
        fprintf(myfile,'\t');
            else
        fprintf(myfile,num2str(MATN(ii,jj-1))); 
        fprintf(myfile,'\t\n');
            end
        end
    end



% sa = size(MATN);
% fprintf(myfile,[repmat('%g\t',1,sa(2)-1) '%g\n'],MATN.');
fclose(myfile);
  
  
  


figure
H=bar(rc,0.5,'stacked');
% H=bar(rc./repmat(sum(rc,2),[1 3]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:3
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of clusters'],'FontSize', 14,'FontName','times') % y-axis label
title(['Cells that divided twice = ' num2str(100*(1-mn),'%0.2f') '%'],'FontSize', 15,'FontName','times');

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
% ylim([0 1.05])
pbaspect([8,6,1])

set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'Cluster ratio'],'-a2', '-m6','-p0.02','-png', '-r600');

figure
H=bar(rc,0.5,'stacked');
H=bar(rc./repmat(sum(rc,2),[1 3]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:3
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of clusters normalized'],'FontSize', 14,'FontName','times') % y-axis label
title(['Cells that divided twice = ' num2str(100*(1-mn),'%0.2f') '%'],'FontSize', 15,'FontName','times');

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
% ylim([0 1.05])
pbaspect([8,6,1])

 set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'Cluster ratio2'],'-a2', '-m6','-p0.02','-png', '-r600');



myC= [0.7 0.7 0.7;
    0.37 0.37 0.37;
    0.7 0.7 0.9];
k=1;
rc=[];
temt=zeros(14,3);
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=countA{kin};
    
  rc(k,1)=tem(1,1);    
%   rc(k,1)=tem(9,3)/2+tem(4,3)/2;  
  rc(k,2)=tem(1,2);
%   rc(k,3)=tem(1,3)/4;
   
  k=k+1;
  
  temt=temt+tem;
    
end


figure
H=bar(rc,0.5,'stacked');
% H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Number of positives'],'FontSize', 14,'FontName','times') % y-axis label
title(['Ratio of ependymal cells = ' num2str(100*(mn),'%0.2f') '%'],'FontSize', 15,'FontName','times');

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
% ylim([0 1.05])
pbaspect([8,6,1])

set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'Epen ratio'],'-a2', '-m6','-p0.02','-png', '-r600');

figure
H=bar(rc,0.5,'stacked');
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of positives'],'FontSize', 14,'FontName','times') % y-axis label
title(['Normalized Ratio of ependymal cells = ' num2str(100*(mn),'%0.2f') '%'],'FontSize', 15,'FontName','times');

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
% ylim([0 1.05])
pbaspect([8,6,1])

set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'Epen ratio 2'],'-a2', '-m6','-p0.02','-png', '-r600');


