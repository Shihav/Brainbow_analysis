clear all
close all


m{3}=[2703 1138 2512 504];
m{10}=[1 0 1 0];
m{3}=[3139 785 2245 854];
% m{3}=[1309 658 758 384];



sisters=100;

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT']);

for idx=[10]
    
    mn=m{idx};
    
loadaddress;

if idx==10
    nk=m{3};
LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(3) 'ang' num2str(14)  'CG' '.png']); 
AG=LCOLORG;
LCOLORG=LCOLORG(nk(1):size(AG,1)-nk(2),nk(3):size(AG,2)-nk(4),:);
else
LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
end
AG=LCOLORG;
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_1_' 'RAW.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_1_' 'RAW_crop.png']);
end

LCOLORG1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) 'SINGLEP' '.png']);
LCOLORG2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) 'SINGLEN' '.png']);
LCOLORG=LCOLORG1+LCOLORG2;
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_2_' 'SINGLE.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_2_' 'SINGLE_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) 'DOUBLETN' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_3_' 'DOUBLETN.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_3_' 'DOUBLETN_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_RB2' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_4_' 'R2LET.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_4_' 'R2LET_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) '_RAWF' '.png']);
AG=imread([Reshome3 filesep 'mosaicG.png']);
LCOLORG=LCOLORG+0.5*AG;
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_5_' 'RAWF.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_5_' 'RAWF_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_DSLOG' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_6_' 'DOUBLET_SYM.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_6_' 'DOUBLET_SYM_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_DASBLO' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_7_' 'DOUBLET_ASYM.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_7_' 'DOUBLET_ASYM_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_DBLO' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_8_' 'DOUBLET.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_8_' 'DOUBLET_crop.png']);
end

% LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_QB2LOG' '.png']);
% imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_9_' 'QUADROP2LET.png']);
% LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
% imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_9_' 'QUADROP2LET_crop.png']);

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_TBLO' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_9_' 'TRIPLET.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_9_' 'TRIPLET_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_QBLO' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_10_' 'QUADROPLET.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_10_' 'QUADROPLET_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_MBLO' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_11_' 'MLET.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_11_' 'MLET_crop.png']);
end

LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_RBLO' '.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_12_' 'RLET.png']);

if idx==3
LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_12_' 'RLET_crop.png']);
end

% LCOLORG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14) '_R2LO' '.png']);
% imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_12_' 'R2LET.png']);
% LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
% imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\REPORT\' 'idx' num2str(idx) '_12_' 'R2LET_crop.png']);

end