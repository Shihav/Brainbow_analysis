clear all
close all

NA=[];
FA=[];

NAB=[];
FAB=[];

for idx=[1 2 3 5 7 8]
    
    cid=1
    HTH=6.5
    STH=90
    BTH=80

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 
DATAT=DATA(:,6:8);
DATACM=rgb2hsv(DATAT(:,1:3));

mkdir([FINR filesep 'RESULT_M' num2str(idx)]);

% PLOT_ADJUSTEDRR

load(['FOX' num2str(idx)],'centerF'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

bpcells=size(DATA,1)

%PLOT_ADJUSTED

load(['DATAF' num2str(idx)],'DTA','DTCMA'); 

load([Reshome3 filesep 'ncoupA_' num2str(0) '_' num2str(BTH) '.mat'],'ncoupA'); 

 ncoup=ncoupA{4,4};
 
 Rmat=ncoup(1)
 
 RRmat=mean(ncoup(2:101))
 
[h,p]=ttest2(ncoup(1),ncoup(2:101)) 

Pmat=p  
 
  CENTER=imread([Reshome3 filesep 'CENTER.png']);  

MASK=imread([FINB filesep 'AREA' num2str(idx) '.png']);

LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

BW=LCOLORL>0;

se = strel('disk',400,8);


BW2 = imdilate(BW,se);

BMASK=BW2 & MASK;

% BMASK = bwconvhull(BMASK)

 areaB=(sum(sum(BMASK>0))*0.31*0.31)/1000000
 
imwrite(uint16(65535*BMASK),[FINR filesep 'RESULT_M' num2str(idx) filesep 'BAREA' num2str(idx) '.png']);
imwrite(uint16(65535*MASK),[FINR filesep 'RESULT_M' num2str(idx) filesep 'AREA' num2str(idx) '.png']);

CENTER(MASK==0)=0;
  fpc=sum(sum(CENTER>0))
  
  CENTER=imread([Reshome3 filesep 'CENTER.png']);   
  CENTER(BMASK==0)=0;
  bfpc=sum(sum(CENTER>0))
  
  areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
  
  FMAT=[];
  FMAT(1,1)=bpcells;
   FMAT(1,2)=Rmat;
   FMAT(1,3)=RRmat;
   FMAT(1,4)=p;
    FMAT(1,5)=fpc;
    FMAT(1,6)=areaV;
    FMAT(1,7)=areaB;
    FMAT(1,8)=bfpc;
    
NA{idx}=ncoup;
FA{idx}=FMAT;
 
end

for idx=[1 2 3 5 7 8]
    
    cid=1
    HTH=6.5
    STH=90
    BTH=80

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 
DATAT=DATA(:,6:8);
DATACM=rgb2hsv(DATAT(:,1:3));

mkdir([FINR filesep 'RESULT_M' num2str(idx)]);

%PLOT_ADJUSTEDRR

load(['FOX' num2str(idx)],'centerF'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

bpcells=size(DATA,1)

%PLOT_ADJUSTED

load(['DATAB' num2str(idx)],'DTA','DTCMA'); 

load([Reshome3 filesep 'BncoupA_' num2str(0) '_' num2str(BTH) '.mat'],'ncoupA'); 

 ncoup=ncoupA{4,4};
 
 Rmat=ncoup(1)
 
 RRmat=mean(ncoup(2:101))
 
[h,p]=ttest2(ncoup(1),ncoup(2:101)) 

Pmat=p
   
 
  CENTER=imread([Reshome3 filesep 'CENTER.png']);  

MASK=imread([FINB filesep 'AREA' num2str(idx) '.png']);

CENTER(MASK==0)=0;
  fpc=sum(sum(CENTER>0))
  
  areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
  
  FMAT=[];
  FMAT(1,1)=bpcells;
   FMAT(1,2)=Rmat;
   FMAT(1,3)=RRmat;
   FMAT(1,4)=p;
    FMAT(1,5)=fpc;
    FMAT(1,6)=areaV;
    
NAB{idx}=ncoup;
FAB{idx}=FMAT;
 
end


   n=1
DATAn=[];
for idx=[1 2 3 5 7 8]
    DATAn(n,:)=FA{idx};
    n=n+1
end


n=1
DATA=[];
for idx=[1 2 3 5 7 8]
    DATA(n,:)=NA{idx};
    n=n+1
end

 Colors=[0.5 0.5 0.5];
figure
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
%title('Cell density','FontSize', 20,'FontWeight','bold','FontName','times')
% pbaspect([5,4,1])
                                                                                                                                                                                                                                 
%                                             xlim([-1 150])
                                           
% labels = {'line1 line2','line1 line2','line1 line2'};


% x_labels{1} = {'M1';[num2str(DATAn(1,1)) 'cells)']};
% x_labels{2} = {'M2';[num2str(DATAn(2,1)) 'cells)']};
% x_labels{3} = {'M3';[num2str(DATAn(3,1)) 'cells)']};

% labels = {['M1 (' num2str(DATAn(1,1)) 'cells)'],['M2 (' num2str(DATAn(2,1)) 'cells)'],['M3 (' num2str(DATAn(3,1)) 'cells)'],...
%     ['M4 (' num2str(DATAn(4,1)) 'cells)'],['M5 (' num2str(DATAn(5,1)) 'cells)'],['M6 (' num2str(DATAn(6,1)) 'cells)']};
% labels = cellfun(@(x) strrep(x,' ','\newline'), labels,'UniformOutput',false);
% a = gca;
% a.XTickLabel = labels;     


% UnivarScatter(100*DATA(:,2:51)','Label',{'M1','M2','M3','M4','M5','M6'},'PointSize',6,'Width',0.5,'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);
 ylim([10 70])

       hold on
       
 n=1
DATA=[];
for idx=[1 2 3 5 7 8]
    DATA(n,:)=NAB{idx};
    n=n+1
end

 Colors=[0.7 0 0];
hold on
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
% UnivarScatter(100*DATA(:,2:51)','Label',{'M1','M2','M3','M4','M5','M6'},'PointSize',6,'Width',0.5,'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);     

 Colors=[0.1 0.65 0.1];
hold on
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
% UnivarScatter2(repmat(DATA(:,1),[1 3])','Label',{'M1','M2','M3','M4','M5','M6'},'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);   

% scatter([1:6],DATA(:,1))

scatter(1:6,100*DATA(:,1),'MarkerEdgeColor',Colors/1.5,...
              'MarkerFaceColor',Colors,...
              'LineWidth',0.5)
          
  text(1:6,100*DATA(:,1)-4,[num2str(100*DATA(:,1),'%.2f')],'color',[0.2 0.4 0.2],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times')        
          
          
%                                             legend_handle=legend('Random FoxJ1','Random Brainbow','Data');
%                                             legend_markers = findobj(get(legend_handle, 'Children'));
% for i = 3
%     set(legend_markers(i), 'Color',[0 0.6 0]);
% end
% 
% for i = 1
%     set(legend_markers(i), 'Color',[0.2 0.2 0.2]);
% end
% 
% for i = 2
%     set(legend_markers(i), 'Color',[0.5 0.0 0.0]);
% end
%                                             
%                                             xlabel('Area Bin (\mum^2)','FontSize', 17,'FontName','times') % x-axis label
% x_labels=[];
% x_labels{2} = sprintf('M1\n(%d cells)',DATAn(1,1));
% x_labels{4} = sprintf('M2\n(%d cells)',DATAn(2,1));
% x_labels{6} = sprintf('M3\n(%d cells)',DATAn(3,1));
% x_labels{8} = sprintf('M4\n(%d cells)',DATAn(4,1));
% x_labels{10} = sprintf('M5\n(%d cells)',DATAn(5,1));
% % x_labels{12} = sprintf('M6\n(%d cells)',DATAn(6,1));
% % x_labels{1} = '';
% % x_labels{3} = '';
% % x_labels{5} = '';
% % x_labels{7} = '';
% % x_labels{9} = '';
% x_labels{12} = '';
% set(gca,'XTickLabel', {'','',''});
% [hx,hy] = format_ticks(gca,x_labels);
%  xlabel(['Percentage of cells coupled'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label

set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels



                                            ylabel(['Percentage of cells coupled'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
                                                legend('boxoff')
xlim([0.5 6.5])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([10,8,1])

%                                                     title('P1 BETACAT SAS6 replicates','FontSize', 20,'FontName','times');
                                                                                                        
%   text(1.65, 350,['Sig. diff. = ' num2str(H,'%d')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 % text(1.5, 370,['P value = ' num2str(P,'%.3f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
%  text(1.5, 360,['Mutant mean = ' num2str(mean(dataM),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 %text(1.5, 350,['Wild mean = ' num2str(mean(dataW),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     
  
loadaddress;



export_fig([FINR filesep 'COMP_RATIOB'],'-a2', '-m6','-p0.02','-png', '-r600');
% axis tight
  set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters epsFig
  
  
   print([FINR filesep 'COMP_RATIOB'], '-dpdf', '-r600');  


   
   
   
   
   
   n=1
DATA=[];
for idx=[1 2 3 5 7 8]
    DATA(n,:)=FA{idx};
    n=n+1
end

 Colors=[0.5 0.5 0.5];
figure

                                                                                                                                                                                                                                 
%                                             xlim([-1 150])
%                                             ylim([10 70])
                                            
                                            
   

 Colors=[0.1 0.65 0.1];
hold on
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
% UnivarScatter2(repmat(DATA(:,1),[1 3])','Label',{'M1','M2','M3','M4','M5','M6'},'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);   

% scatter([1:6],DATA(:,1))

scatter(1:6,DATA(:,5)./DATA(:,6),'MarkerEdgeColor',Colors/1.5,...
              'MarkerFaceColor',Colors,...
              'LineWidth',0.5)
%                                             legend_handle=legend('Random FoxJ1','Random Brainbow','Data');
%                                             legend_markers = findobj(get(legend_handle, 'Children'));
% for i = 3
%     set(legend_markers(i), 'Color',[0 0.6 0]);
% end
% 
% for i = 1
%     set(legend_markers(i), 'Color',[0.2 0.2 0.2]);
% end
% 
% for i = 2
%     set(legend_markers(i), 'Color',[0.5 0.0 0.0]);
% end
%                                             
%                                             xlabel('Area Bin (\mum^2)','FontSize', 17,'FontName','times') % x-axis label
                                            ylabel(['Ependymal cells per mm^2'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
                                                legend('boxoff')
xlim([0.5 6.5])
ylim([2000 10000])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([6,8,1])

%                                                     title('P1 BETACAT SAS6 replicates','FontSize', 20,'FontName','times');
                                                                                                        
%   text(1.65, 350,['Sig. diff. = ' num2str(H,'%d')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 % text(1.5, 370,['P value = ' num2str(P,'%.3f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
%  text(1.5, 360,['Mutant mean = ' num2str(mean(dataM),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 %text(1.5, 350,['Wild mean = ' num2str(mean(dataW),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 
 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     
  
loadaddress;



export_fig([FINR filesep 'COMP_AREA'],'-a2', '-m6','-p0.02','-png', '-r600');
% axis tight
  set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters epsFig
  
  
   print([FINR filesep 'COMP_AREA'], '-dpdf', '-r600');  
   

   
   
   
      
   n=1
DATA=[];
for idx=[1 2 3 5 7 8]
    DATA(n,:)=FA{idx};
    n=n+1
end

 Colors=[0.5 0.5 0.5];
figure

                                                                                                                                                                                                                                 
%                                             xlim([-1 150])
%                                             ylim([10 70])
                                            
                                            
   

 Colors=[0.1 0.65 0.1];
hold on
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
% UnivarScatter2(repmat(DATA(:,1),[1 3])','Label',{'M1','M2','M3','M4','M5','M6'},'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);   

% scatter([1:6],DATA(:,1))

scatter(1:6,DATA(:,1)./DATA(:,7),'MarkerEdgeColor',Colors/1.5,...
              'MarkerFaceColor',Colors,...
              'LineWidth',0.5)
%                                             legend_handle=legend('Random FoxJ1','Random Brainbow','Data');
%                                             legend_markers = findobj(get(legend_handle, 'Children'));
% for i = 3
%     set(legend_markers(i), 'Color',[0 0.6 0]);
% end
% 
% for i = 1
%     set(legend_markers(i), 'Color',[0.2 0.2 0.2]);
% end
% 
% for i = 2
%     set(legend_markers(i), 'Color',[0.5 0.0 0.0]);
% end
%                                             
%                                             xlabel('Area Bin (\mum^2)','FontSize', 17,'FontName','times') % x-axis label
                                            ylabel(['Brainbow+ ependymal cells per mm^2'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
                                                legend('boxoff')
xlim([0.5 6.5])
ylim([0 2000])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([6,8,1])

%                                                     title('P1 BETACAT SAS6 replicates','FontSize', 20,'FontName','times');
                                                                                                        
%   text(1.65, 350,['Sig. diff. = ' num2str(H,'%d')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 % text(1.5, 370,['P value = ' num2str(P,'%.3f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
%  text(1.5, 360,['Mutant mean = ' num2str(mean(dataM),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 %text(1.5, 350,['Wild mean = ' num2str(mean(dataW),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 
 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     
  
loadaddress;



export_fig([FINR filesep 'COMP_BAREA'],'-a2', '-m6','-p0.02','-png', '-r600');
% axis tight
  set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters epsFig
  
  
   print([FINR filesep 'COMP_BAREA'], '-dpdf', '-r600');  
   
   
   
   
   
   
  n=1
DATA=[];
for idx=[1 2 3 5 7 8]
    DATA(n,:)=FA{idx};
    n=n+1
end

 Colors=[0.5 0.5 0.5];
figure

                                                                                                                                                                                                                                 
%                                             xlim([-1 150])
%                                             ylim([10 70])
                                            
                                            
   

 Colors=[0.1 0.65 0.1];
hold on
% UnivarScatter(DataArray,'Label',{'Wild type','Mutant type'},'MarkerFaceColor',Colors,'SEMColor',Colors/1.1,'StdColor',Colors/1.2);
% UnivarScatter2(repmat(DATA(:,1),[1 3])','Label',{'M1','M2','M3','M4','M5','M6'},'MarkerFaceColor',Colors,'MarkerEdgeColor',Colors/1.5);   

% scatter([1:6],DATA(:,1))

scatter(1:6,100*DATA(:,1)./DATA(:,8),'MarkerEdgeColor',Colors/1.5,...
              'MarkerFaceColor',Colors,...
              'LineWidth',0.5)
%                                             legend_handle=legend('Random FoxJ1','Random Brainbow','Data');
%                                             legend_markers = findobj(get(legend_handle, 'Children'));
% for i = 3
%     set(legend_markers(i), 'Color',[0 0.6 0]);
% end
% 
% for i = 1
%     set(legend_markers(i), 'Color',[0.2 0.2 0.2]);
% end
% 
% for i = 2
%     set(legend_markers(i), 'Color',[0.5 0.0 0.0]);
% end
%                                             
%                                             xlabel('Area Bin (\mum^2)','FontSize', 17,'FontName','times') % x-axis label
                                            ylabel(['Brainbow+ percentage'],'FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
                                                legend('boxoff')
xlim([0.5 6.5])
ylim([0 25])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([6,8,1])

%                                                     title('P1 BETACAT SAS6 replicates','FontSize', 20,'FontName','times');
                                                                                                        
%   text(1.65, 350,['Sig. diff. = ' num2str(H,'%d')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 % text(1.5, 370,['P value = ' num2str(P,'%.3f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
%  text(1.5, 360,['Mutant mean = ' num2str(mean(dataM),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 %text(1.5, 350,['Wild mean = ' num2str(mean(dataW),'%.2f')],'FontSize', 12,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','times');
 
 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     
  
loadaddress;



export_fig([FINR filesep 'COMP_BRATIO'],'-a2', '-m6','-p0.02','-png', '-r600');
% axis tight
  set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,...
    'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
% print -dpdf -painters epsFig
  
  
   print([FINR filesep 'COMP_BRATIO'], '-dpdf', '-r600');  
   
