clear all
close all

clc

% Datahome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\Tiffv';
% Reshome='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\ImageJ';
% Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Marie_brainbow8\MATLAB';

% Datahome='/import/pr_ciltex/TEST_BRAINBOW/Tiff';
% Reshome='/import/pr_ciltex/TEST_BRAINBOW/Imagej2';
% Reshome2='/import/pr_ciltex/TEST_BRAINBOW/Process';

Datahome='/media/shihavud/F4D6E812D6E7D342/Marie_Brainbow2/Sélection Shihav/Marie_brainbow8/Tiff';
Reshome='/media/shihavud/F4D6E812D6E7D342/Marie_Brainbow2/Sélection Shihav/Marie_brainbow8/Imagej2';
Reshome2='/media/shihavud/F4D6E812D6E7D342/TEST_BRAINBOW/P';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

RAK=[];
GAK=[];
BAK=[];

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
        
               info = imfinfo(oriname);
        num_images = numel(info);
     
        ImgGR=uint8([]);
        kn=1;
        for k = 4:4:num_images
            I = uint8(double(imread(oriname, k))/16);
              ImgGR(:,:,kn)=I;   
              kn=kn+1
        end
        
%   ImgGR_STD=std(double(ImgGR(:)));      
  save([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR');  
 % clear ImgGR
        
        ImgR=uint8([]);
        kn=1;
        for k = 1:4:num_images
           I = uint8(double(imread(oriname, k))/16);
              ImgR(:,:,kn)=I;   
              kn=kn+1
        end
        
%   ImgR_STD=std(double(ImgR(:)));      
  save([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR');  
 % clear ImgR
        
        ImgG=uint8([]);
        kn=1;
        for k = 2:4:num_images
            I = uint8(double(imread(oriname, k))/16);
              ImgG(:,:,kn)=I;   
              kn=kn+1
        end
        
%   ImgG_STD=std(double(ImgG(:)));      
  save([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG');  
 % clear ImgG
        
        ImgB=uint8([]);
        kn=1;
        for k = 3:4:num_images
             I = uint8(double(imread(oriname, k))/16);
              ImgB(:,:,kn)=I;   
              kn=kn+1
        end
        
%   ImgB_STD=std(double(ImgB(:)));      
  save([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB');  
 % clear ImgB
        
info = imfinfo(segname);
        num_images = numel(info);
        Imgseg=[];
        for k = 1:num_images
            I = imread(segname, k);
              Imgseg(:,:,k)=I;   
              k
        end 
% 
pcells=unique(Imgseg);
Imgsegk=Imgseg;
Imgsegk(Imgseg==0)=max(pcells)+1;
Imgsegk=max(pcells)+1-Imgsegk;
Imgsegk(Imgsegk==max(pcells))=0;
clear Imgseg 



% Imgsegk=uint16(Imgsegk);
% 
Imgsegk2=uint16(Imgsegk);

pcells=unique(Imgsegk);
se=ones(3);
val3d=[];
ImgS=(ImgR+ImgG+ImgB+0.2*ImgGR)/3.2;

         for nk=2:length(pcells)
            
            val=pcells(nk);   
object=Imgsegk==pcells(nk);
val3d(nk)=mean(ImgS(object)); 
%              Imgsegk2(object)=mean(ImgS(object));                                 
nk
         end


[Y,I] = sort(val3d,2);

         for nk=2:length(pcells)
            
            val=pcells(nk);   
object=Imgsegk==pcells(nk);
% val3d(nk)=mean(ImgS(object)); 
             Imgsegk2(object)=I(nk)-1;                                 
nk
         end

Imgsegk=Imgsegk2;
save([Reshome2 filesep filename2 filesep filename2 'Imgsegk.mat'],'Imgsegk'); 
% 
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk.mat'],'Imgsegk'); 


     ImgR(Imgsegk==0)=0;
     ImgG(Imgsegk==0)=0;
     ImgB(Imgsegk==0)=0;
     ImgGR(Imgsegk==0)=0;     

[Img11r,zval11r]=max(ImgR,[],3);
[Img11g,zval11g]=max(ImgG,[],3);
[Img11b,zval11b]=max(ImgB,[],3);
[Img11gr,zval11gr]=max(ImgGR,[],3);


save([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2');         

load([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2'); 

Imgsegk=Imgsegk2;
clear Imgsegk2

CO=uint8(cat(3,Img11r,Img11g,Img11b));
CGO=uint8(cat(3,Img11gr,Img11gr,Img11gr));
COF=CO+0.3*CGO;

imwrite(uint8(COF),[Reshome2 filesep filename2 filesep filename2 'Ori.png']);  
imwrite(uint8(CO),[Reshome2 filesep filename2 filesep filename2 'OriC.png']);  

        tol=0.065;
    
classmap=max(Imgsegk,[],3);
      
I2cpsegb=classmap>0;
     T1=im2bw(I2cpsegb);
                           T2=T1;
                           T3 = imclearborder(T2);
                           
classmap4=classmap; 
classmap(T3==0)=0;
pcells=unique(classmap);

         for nk=2:length(pcells)            
            val=pcells(nk);            
            sizek=sum(sum(classmap==val));            
            if sizek<275
                classmap(classmap==val)=0;
                Imgsegk(Imgsegk==val)=0;
                
            end
            nk 
         end
classmap((T2-T3)==1)=classmap4((T2-T3)==1);         
classmap2=classmap;

classmapR=uint8(255*ones(size(classmap,1),size(classmap,2)));
classmapG=uint8(255*ones(size(classmap,1),size(classmap,2)));
classmapB=uint8(255*ones(size(classmap,1),size(classmap,2)));

pcells=unique(classmap2);
classmapk=classmap2;

se1=ones(3);
se2=ones(3);
CVA=[];
CSA=[];

         for nk=2:length(pcells)
            
            val=pcells(nk);
             object = classmap2==val;
                              objectcore1 = imerode(object, se1);
                              objectcore2 = imerode(object, se2);
                              objectbor=object-objectcore1;
                            
                              
                              RV=quantile(double(Img11r(objectcore2==1)),.5);
                              GV=quantile(double(Img11g(objectcore2==1)),.5);
                              BV=quantile(double(Img11b(objectcore2==1)),.5);
                              GRV=quantile(double(Img11gr(objectcore2==1)),.5);
                                                            
                              RS=std(double(Img11r(objectcore2==1)));
                              GS=std(double(Img11g(objectcore2==1)));
                              BS=std(double(Img11b(objectcore2==1)));
                              GRS=std(double(Img11gr(objectcore2==1)));
                              
                              [CVK,PP]=max([RV GV BV]);
                               CV=max([RV GV BV]);
                              SA=[RS GS BS];
                              CS=SA(PP);
                              CVA=[CVA; CV];
                               CSA=[CSA; CS];
                              
                              if (CV>(3276/255)) && (double(CS)/CV)<1
%                                 TRUE=RV>(2*ImgR_STD) || GV>(2*ImgG_STD) || BV>(2*ImgB_STD);
%                               if TRUE && (double(CS)/CV)<1
                                  
                              RV=quantile(Img11r(objectcore2==1),.5);
                              GV=quantile(Img11g(objectcore2==1),.5);
                              BV=quantile(Img11b(objectcore2==1),.5);
                              GRV=quantile(Img11gr(objectcore2==1),.5);
                                  
                              classmapR(objectbor==1)=(RV+0.0*GRV)/2;
                              classmapG(objectbor==1)=(GV+0.0*GRV)/2;
                              classmapB(objectbor==1)=(BV+0.0*GRV)/2;
                              
                              classmapR(objectcore1==1)=RV+0.0*GRV;
                              classmapG(objectcore1==1)=GV+0.0*GRV;
                              classmapB(objectcore1==1)=BV+0.0*GRV;
                              
                              else
                                  
                                  classmapk(classmap2==val)=0;
                                     Imgsegk(Imgsegk==val)=0;
                                  
                              end
             
nk
         end
         
         imgid
              
         classmap3=uint8((cat(3,classmapR,classmapG,classmapB)));
imwrite(uint8(classmap3),[Reshome2 filesep filename2 filesep filename2 'FinalmapI.png']);

I2cpsegb=classmapk>0;
     T1=im2bw(I2cpsegb);
                           T2=T1;
                           T3 = imclearborder(T2);
                           
classmap4=classmapk; 
%classmap4(T3==0)=0;
classmap5=classmap4;
pcells=unique(classmap4);
se = ones(5); 
sek = ones(3); 


for nid=2:length(pcells)
       
        label = pcells(nid); 
object = classmap4 == label;
ownA=sum(sum(object));

neighbours = imdilate(object, se) & ~object;
neighbourLabels = unique(classmap4(neighbours));
neighbourLabels(1)=[];

if ~isempty(neighbourLabels)
    if ownA<550
    areak=[];
    for kin=1:length(neighbourLabels)
    
    areak(kin)=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));
    end
    [areak,kin]=min(areak);
    
    block=classmap4==neighbourLabels(kin) | classmap4==label;
    [X,Y]=find(block==1);
    
    [CH,Ak]= convhull(X,Y);
    
    
    R1=median(classmapR(classmap4==neighbourLabels(kin)))/1;
    R2=median(classmapR(classmap4==label))/1;
    
        G1=median(classmapG(classmap4==neighbourLabels(kin)))/1;
    G2=median(classmapG(classmap4==label))/1;
    
        B1=median(classmapR(classmap4==neighbourLabels(kin)))/1;
    B2=median(classmapR(classmap4==label))/1;
    
    CDF=max([abs(R1-R2) abs(G1-G2) abs(B1-B2)]);
    
    
    
            if ((Ak-areak)/Ak) <tol && CDF<20
                
                ND=max([label neighbourLabels(kin)]);
                
                object2 = classmap4 == neighbourLabels(kin);

                classmap5(object2)=ND;
                 classmap5(object)=ND;

                middle = imdilate(object2, sek) & imdilate(object, sek);
                classmap5(middle)=ND;
                
                object3d1=Imgsegk==label;
                object3d2=Imgsegk==neighbourLabels(kin);
                middleD = imdilate(object3d1,ones(3,3,3)) & imdilate(object3d2,ones(3,3,3));
                Imgsegk(object3d1)=ND;
                Imgsegk(object3d2)=ND;
                Imgsegk(middleD)=ND;
                
            end
    end
end
nid

end

classmapR=uint8(255*ones(size(classmap,1),size(classmap,2)));
classmapG=uint8(255*ones(size(classmap,1),size(classmap,2)));
classmapB=uint8(255*ones(size(classmap,1),size(classmap,2)));

LmapR=uint8(255*ones(size(classmap,1),size(classmap,2)));
LmapG=uint8(255*ones(size(classmap,1),size(classmap,2)));
LmapB=uint8(255*ones(size(classmap,1),size(classmap,2)));

pcells=unique(classmap5);

         for nk=2:length(pcells)            
            val=pcells(nk);            
            sizek=sum(sum(classmap5==val));            
            if sizek<220
                classmap5(classmap5==val)=0;
                   Imgsegk(Imgsegk==val)=0;
            end
            nk    
         end   
         
pcells=unique(classmap5);
classmapk2=classmap5;
Finalmap=zeros(size(classmap5));
% se=ones(3);

se1=ones(3);
se2=ones(3);

         for nk=2:length(pcells)
            
            val=pcells(nk);
             object = classmap5==val;
                              objectcore1 = imerode(object, se1);
                              objectcore2 = imerode(object, se2);
                              objectbor=object-objectcore1;
                                 
                              RV=quantile(double(Img11r(objectcore2==1)),.5);
                              GV=quantile(double(Img11g(objectcore2==1)),.5);
                              BV=quantile(double(Img11b(objectcore2==1)),.5);
                              GRV=quantile(double(Img11gr(objectcore2==1)),.5);
                                  
                              classmapR(objectbor==1)=RV/2;
                              classmapG(objectbor==1)=GV/2;
                              classmapB(objectbor==1)=BV/2;
                              
                              classmapR(objectcore1==1)=RV;
                              classmapG(objectcore1==1)=GV;
                              classmapB(objectcore1==1)=BV;
                                  
                               Finalmap(object)=val;                                  
nk;
         end
imgid
  classmap3=uint8((cat(3,classmapR,classmapG,classmapB)));
imwrite(uint8(classmap3),[Reshome2 filesep filename2 filesep filename2 'FinalmapC.png']);
imwrite(uint16(Finalmap),[Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);



classmapk=max(Imgsegk,[],3);
I2cpsegb=classmapk>0;
     T1=im2bw(I2cpsegb);
                           T2=T1;
                           T3 = imclearborder(T2);
                           
classmap4=classmapk; 
classmap5=classmap4;
pcells=unique(classmap4);
se = ones(5); 
sek = ones(3); 

for nid=2:length(pcells)
       
        label = pcells(nid); 
object = classmap4 == label;
ownA=sum(sum(object));

neighbours = imdilate(object, se) & ~object;
neighbourLabels = unique(classmap4(neighbours));
neighbourLabels(1)=[];

if ~isempty(neighbourLabels)
    if ownA<550
    areak=[];
    for kin=1:length(neighbourLabels)
    
    areak(kin)=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));
    end
    [areak,kin]=min(areak);
    
    block=classmap4==neighbourLabels(kin) | classmap4==label;
    [X,Y]=find(block==1);
    
    [CH,Ak]= convhull(X,Y);
    
            if ((Ak-areak)/Ak) <tol
                
                object2 = classmap4 == neighbourLabels(kin);
                classmap5(object2)=label;
                middle = imdilate(object2, sek) & imdilate(object, sek);
                classmap5(middle)=label;  
            end
    end
end
end

imwrite(uint8(255*(classmap5>0)),[Reshome2 filesep filename2 filesep filename2 'FOXJ1map.png']);

% Imgsegk2=zeros(size(Imgsegk));
% 
% pcells=unique(Finalmap);
% se=ones(3);
% 
%          for nk=2:length(pcells)
%             
%             val=pcells(nk);   
%              Imgsegk2(Imgsegk==val)=val;                                 
% nk
%          end
% save([Reshome2 filesep filename2 filesep filename2 'Imgsegk2.mat'],'Imgsegk2'); 

end
