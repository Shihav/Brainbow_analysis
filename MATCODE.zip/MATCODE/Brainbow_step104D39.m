clear all
close all

COLORA=[];

m{3}=[3139 785 2245 854];
sisters=100;
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL']);


for idx=[3]
    
    idxt=idx;
    
    loadaddress2;
%     LCOLORLM=imread([Reshome3 filesep 'NFinalmapM3.png']);
%     imwrite(uint16(LCOLORLM),[Reshome3 filesep 'NFinalmapM2.png']);
%     
%     LCOLORCP=imread([Reshome3 filesep 'NmosaicO3.png']);
%     imwrite(LCOLORCP,[Reshome3 filesep 'NmosaicO2.png']);
%     
%     LCOLORLM=imread([Reshome3 filesep 'NFinalmapM4.png']);
%     imwrite(uint16(LCOLORLM),[Reshome3 filesep 'NFinalmapM.png']);
%     
%     LCOLORCP=imread([Reshome3 filesep 'NmosaicO4.png']);
%     imwrite(LCOLORCP,[Reshome3 filesep 'NmosaicO.png']);
%     
%     
%     LCOLORLM=imread([Reshome3 filesep 'PFinalmapM3.png']);
%     imwrite(uint16(LCOLORLM),[Reshome3 filesep 'PFinalmapM2.png']);
%     
%     LCOLORCP=imread([Reshome3 filesep 'PmosaicO3.png']);
%     imwrite(LCOLORCP,[Reshome3 filesep 'PmosaicO2.png']);
%     
%     LCOLORLM=imread([Reshome3 filesep 'PFinalmapM4.png']);
%     imwrite(uint16(LCOLORLM),[Reshome3 filesep 'PFinalmapM.png']);
%     
%     LCOLORCP=imread([Reshome3 filesep 'PmosaicO4.png']);
%     imwrite(LCOLORCP,[Reshome3 filesep 'PmosaicO.png']);
    
    
    LCOLORLM=imread([Reshome3 filesep 'NFinalmapM2.png']);
    LCOLORCP=imread([Reshome3 filesep 'NmosaicOP.png']);
    
     mn=m{idx};
    AG=LCOLORLM;
    LCOLORG=LCOLORLM;
    LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
    imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'LABELN.png']);
    
    LABELM=LCOLORG;       
    pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
objectcore_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imerode(object, se);
                              objectbor=(object-objectcore)>0;
                       objectbor_map(objectbor)=1;
                       objectcore_map(objectcore)=LABELM(objectcore);
                             
         end
    
    imwrite(uint8(255*objectbor_map),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'BORDERN2.png']);
    imwrite(uint16(objectcore_map),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'COREN2.png']);
    
    LCOLORG=LCOLORCP;
    LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);    
    imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'COLORN.png']);
    
    LCOLORG=imread([Reshome3 filesep 'ALL_RCR.png']);
    LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);    
    imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'COLORN2.png']);
    


        LCOLORLM=imread([Reshome3 filesep 'PFinalmapM2.png']);
    LCOLORCP=imread([Reshome3 filesep 'PmosaicOP.png']);
    
     mn=m{idx};
    AG=LCOLORLM;
    LCOLORG=LCOLORLM;
    LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
    imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'LABELP.png']);
    
    LABELM=LCOLORG;       
    pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
objectcore_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imerode(object, se);
                              objectbor=(object-objectcore)>0;
                       objectbor_map(objectbor)=1;
                       objectcore_map(objectcore)=LABELM(objectcore);
                             
         end
    
    imwrite(uint8(255*objectbor_map),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'BORDERP2.png']);
    imwrite(uint16(objectcore_map),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'COREP2.png']);
    
    LCOLORG=LCOLORCP;
    LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);    
    imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'COLORP.png']);
    
    LCOLORG=imread([Reshome3 filesep 'ALL_FCR.png']);
    LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);    
    imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'idx' num2str(idx) '_1_' 'COLORP2.png']);

close all
    
end