clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36 .36 .36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);
mkfig=1;
countAS=[];
xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
% mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14)]);
% mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\HUE' ]);
% mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF' ]);
% m=1;
m{3}=[3139 785 2245 854];
m{10}=[1 0 1 0];
multa(10,:)=multa(3,:);
count=[];
for idx=[1]% 2 3 5 7 8 11 12 13 14 15 16 17 18]
    
    mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF2\' 'M' num2str(pool(idx))]);
      mn=[1 0 1 0];  
     if idx==7
     LW=0.2;
     elseif idx==11
     LW=0.2;
     elseif idx==10
     LW=2;
     elseif idx==12
     LW=0.8;
     else
     LW=0.4;
     end
     
        if idx==10
     LW2=.5*LW;
        else
     LW2=2*LW;
        end
     
     
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB','valAT','valAQ','LINKA'); 

load([Reshome2 filesep '36DATA2' num2str(idx) '.mat'],'ADATAS_F','infoTA_F','valATC_F','xyvals_F','MATN','ADATAS_NA','ADATAS_PA',...
    'xyvals_NA','xyvals_PA','ADATAS_N6','ADATAS_P6','xyvals_N6','xyvals_P6','ADATAS_N32','ADATAS_P32','xyvals_N32','xyvals_P32');

DATA=[PDATABB;NDATABB];
DATAT=DATA(:,6:8);
DATAT(DATAT>=255)=255;
NL=prctile(DATAT,5,1)

if idx==10
    nk=m{3};
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(3) 'ang' num2str(14)  'CG' '.png']); 
AG=LCOLORG;
LCOLORG=LCOLORG(nk(1):size(AG,1)-nk(2),nk(3):size(AG,2)-nk(4),:);
elseif idx>10
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
else
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
end
AG=LCOLORG;
% LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

if mkfig==1

loadaddress;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 
 
load_pic
create_HM
HM=round(HM);
shift2=HM;

shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];
m=1;

pic=[];
pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL_AC.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);   
                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j}; 
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A_RAW_COLOR.png']);

AG=imread([Reshome3 filesep 'mosaicG.png']);
AG=AG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

imwrite(AG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_B_RAW_FOXJ1.png']);

LCOLORC=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A_RAW_COLOR.png']);

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);
 
 LCOLORCA=multp(1)*LCOLORCA;
 LCOLORCB=multp(2)*LCOLORCB;
 LCOLORCC=multp(3)*LCOLORCC;
 
 CL=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);

LCOLORG=CL+0.0*AG;    
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A_RAW_COLOR.png']);

end
% count(1,1)=size(PDATABB,1);
% count(1,2)=size(NDATABB,1);
select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(1,1)=size(PDATABB,1);
count(1,2)=size(NDATABB,1);

close all


if mkfig==1
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL.png']);
% 
% LCOLORG=makes_cell_imagesM([PDATABB;NDATABB],multp,multn,Reshome3,0,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_V2_without_FOXJ1_border.png']);
% 
% LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_V2_without_FOXJ1_border.png']);
% LCOLORG=makes_ID_imagesM([PDATABB;NDATABB],LCOLORG,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
% imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_ID.png']);

make_ternary_plot2big([PDATABB;NDATABB],NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% print(gcf,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_TERN','-dpdf']);

make_hue_plot2big([PDATABB;NDATABB],NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2bigS([PDATABB;NDATABB],NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_C_ALL_SEG_CELL_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

ADATAS_D_M=ADATAS_PA;
xyvals_D_M=xyvals_PA;
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

close all

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_V2_without_line.png']);

% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'DOUBLET_F1'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_HUE_VAL2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_HUE_SAT2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line2([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_D_ALL_FPLUS_CLONES_TERN2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

ADATAS_D_M=ADATAS_P6;
xyvals_D_M=xyvals_P6;
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

close all

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_V2_without_line.png']);

% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'DOUBLET_F1'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_HUE_VAL2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_HUE_SAT2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line2([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_E_2-6_FPLUS_CLONES_TERN2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

end


ADATAS_D_M=ADATAS_P32;
xyvals_D_M=xyvals_P32;
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

close all

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_V2_without_line.png']);

% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'DOUBLET_F1'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_HUE_VAL2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_HUE_SAT2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line2([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_F_7-32_FPLUS_CLONES_TERN2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

ADATAS_D_M=ADATAS_NA;
xyvals_D_M=xyvals_NA;
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

close all

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_V2_without_line.png']);

% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'DOUBLET_F1'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_HUE_VAL2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_HUE_SAT2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line2([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_G_ALL_FMINUS_CLONES_TERN2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

ADATAS_D_M=ADATAS_N6;
xyvals_D_M=xyvals_N6;
PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

close all

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_V2_without_line.png']);

% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'DOUBLET_F1'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_HUE_VAL2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_HUE_SAT2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line2([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_H_2-6_FMINUS_CLONES_TERN2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

ADATAS_D_M=ADATAS_N32;
xyvals_D_M=xyvals_N32;

PDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==1,:);
NDATABB=ADATAS_D_M(ADATAS_D_M(:,1)==2,:);
xyval=xyvals_D_M;
count(6,1)=size(PDATABB,1);
count(6,2)=size(NDATABB,1);

close all

if mkfig==1
[LCOLORG,LCOLORG2]=makes_linked_imagesM([PDATABB;NDATABB],xyval,LW,sisters,idx,'_DB',multp,multn,Reshome3,1,mn,0);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES.png']);
imwrite(LCOLORG2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_V2_without_line.png']);

% make_hue_plot2big([PDATABB;NDATABB])
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) 'DOUBLET_F1'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
make_hue_plot2line([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_HUE_VAL'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_HUE_SAT'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_TERN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2line2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_HUE_VAL2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2lineS2([PDATABB;NDATABB],xyval,2*LW,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_HUE_SAT2'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_ternary_plot2line2([PDATABB;NDATABB],xyval,1*LW2,NL)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_I_7-32_FMINUS_CLONES_TERN2'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end

close all

end