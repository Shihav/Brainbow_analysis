clear all
close all
clc

load rc.mat 'rc'
load countAS.mat 'countAS'
load countA.mat 'countA'
load ZDD.mat symzd asymzd symzdA asymzdA symxd asymxd symyd asymyd
load TQRES.mat infoTA infoQA

infoTA(infoTA(:,1)==0,:)=[];
infoQA(infoQA(:,1)==0,:)=[];

pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];
pid=infoTA(:,10);

for kin=1:18    
    pid(infoTA(:,10)==kin)=pool(kin);    
end

MATN=[[1:size(infoTA)]' infoTA(:,1) pid];
MATN(isnan(MATN))=0;

resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'TRIPLET' '_data.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end

myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Triplet ID \tNumber of Ependymal cells\tMosaic ID\t\n');


    for ii=1:size(MATN,1)
        for jj=1:size(MATN,2)
            if jj==1
%                 fprintf(myfile,'M');
        fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
            elseif jj==2
%                 fprintf(myfile,'E');
        fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
%             elseif jj>2 && jj<size(MATN,2)
%        fprintf(myfile,num2str(MATN(ii,jj)));
%         fprintf(myfile,'\t');
            else
        fprintf(myfile,num2str(MATN(ii,jj))); 
        fprintf(myfile,'\t\n');
            end
        end
    end


mat=[];
mat(1,1)=sum(infoTA(:,1)==1);
mat(1,2)=sum(infoTA(:,1)==2);
mat(1,3)=sum(infoTA(:,1)==3);

myC=[1 0.6 0.6];

figure

hold on
    h=bar(1,mat(1,1),0.5);
        set(h,'FaceColor',[0.2 0.2 1]);
        set(h,'EdgeColor','none');
       set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(2,mat(1,2),0.5);
        set(h,'FaceColor',[0.2 1 0.2]);
        set(h,'EdgeColor','none');
        set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(3,mat(1,3),0.5);
        set(h,'FaceColor',[1 0.2 0.2]);
        set(h,'EdgeColor','none');
        set(get(h,'Children'),'FaceAlpha',0.6);
hold off

for kin=1:size(mat,2)   
  text(kin,mat(1,kin)-4,[num2str(mat(1,kin),'%0.0f')],'HorizontalAlignment','center','VerticalAlignment', 'top','FontName','Arial','fontsize',10,'Color',[0 0 0]);                                        
end 




ylabel(['Count'],'FontSize', 14,'FontName','times') % y-axis label
xlabel(['Number of ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
title('Ependymal cell distribution within triplets','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 3.5])
% ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:3,...                         %# Change the axes tick marks
        'XTickLabel',{'1','2','3'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'TRIPLET'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'TRIPLET.pdf'], '-dpdf', '-r600');  




pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];
pid=infoQA(:,10);

for kin=1:18    
    pid(infoQA(:,10)==kin)=pool(kin);    
end

MATN=[[1:size(infoQA)]' infoQA(:,1) pid];
MATN(isnan(MATN))=0;

resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'QUADRUPLET' '_data.xls'];
if exist(resfile3, 'file')==2
delete(resfile3);
end

myfile = fopen(resfile3 ,'wt'); 
fprintf(myfile,'Quadruplet ID \tNumber of Ependymal cells\tMosaic ID\t\n');

    for ii=1:size(MATN,1)
        for jj=1:size(MATN,2)
            if jj==1
%                 fprintf(myfile,'M');
        fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
            elseif jj==2
%                 fprintf(myfile,'E');
        fprintf(myfile,num2str(MATN(ii,jj)));
        fprintf(myfile,'\t');
%             elseif jj>2 && jj<size(MATN,2)
%        fprintf(myfile,num2str(MATN(ii,jj)));
%         fprintf(myfile,'\t');
            else
        fprintf(myfile,num2str(MATN(ii,jj))); 
        fprintf(myfile,'\t\n');
            end
        end
    end

mat=[];
mat(1,1)=sum(infoQA(:,1)==1);
mat(1,2)=sum(infoQA(:,1)==2);
mat(1,3)=sum(infoQA(:,1)==3);
mat(1,4)=sum(infoQA(:,1)==4);

myC=[1 0.6 0.6];

figure

hold on
    h=bar(1,mat(1,1),0.5);
        set(h,'FaceColor',[0.2 0.2 1]);
        set(h,'EdgeColor','none');
       set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(2,mat(1,2),0.5);
        set(h,'FaceColor',[0.2 1 0.2]);
        set(h,'EdgeColor','none');
        set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(3,mat(1,3),0.5);
        set(h,'FaceColor',[1 0.2 0.2]);
        set(h,'EdgeColor','none');
        set(get(h,'Children'),'FaceAlpha',0.6);
                    h=bar(4,mat(1,4),0.5);
        set(h,'FaceColor',[1 0.2 1]);
        set(h,'EdgeColor','none');
        set(get(h,'Children'),'FaceAlpha',0.6);
hold off

for kin=1:size(mat,2)   
  text(kin,mat(1,kin)-4,[num2str(mat(1,kin),'%0.0f')],'HorizontalAlignment','center','VerticalAlignment', 'top','FontName','Arial','fontsize',10,'Color',[0 0 0]);                                        
end 




ylabel(['Count'],'FontSize', 14,'FontName','times') % y-axis label
xlabel(['Number of ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
title('Ependymal cell distribution within quadruplets','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 4.5])
% ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:4,...                         %# Change the axes tick marks
        'XTickLabel',{'1','2','3','4'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'QUADRUPLET'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'QUADRUPLET.pdf'], '-dpdf', '-r600');  





DataArray=100*ones(max([length(symzd) length(asymzd)])/2,2);
DataArray(1:length(symzd)/2,1)=symzd(1:2:end);
DataArray(1:length(asymzd)/2,2)=asymzd(1:2:end);

DataArray(DataArray==100)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.4];

figure
UnivarScatter(DataArray,'PointSize',12,'Width',.4,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Z distance (\mum)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 30])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'Symmetric','Asymmetric'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Z DIST SYM vs ASYM'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Z DIST SYM vs ASYM.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Z DIST SYM vs ASYM' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:length(symzd)/2,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM')

MATN=DataArray(1:length(asymzd)/2,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM')



symzd=symxd;
asymzd=asymxd;

DataArray=100*ones(max([length(symzd) length(asymzd)])/2,2);
DataArray(1:length(symzd)/2,1)=symzd(1:2:end);
DataArray(1:length(asymzd)/2,2)=asymzd(1:2:end);

DataArray(DataArray==100)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.4];

figure
UnivarScatter(DataArray,'PointSize',12,'Width',.4,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['X distance (\mum)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 125])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'Symmetric','Asymmetric'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'X DIST SYM vs ASYM'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'X DIST SYM vs ASYM.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'X DIST SYM vs ASYM' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:length(symzd)/2,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM')

MATN=DataArray(1:length(asymzd)/2,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM')



symzd=symyd;
asymzd=asymyd;

DataArray=100*ones(max([length(symzd) length(asymzd)])/2,2);
DataArray(1:length(symzd)/2,1)=symzd(1:2:end);
DataArray(1:length(asymzd)/2,2)=asymzd(1:2:end);

DataArray(DataArray==100)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.4];

figure
UnivarScatter(DataArray,'PointSize',12,'Width',.4,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Y distance (\mum)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 125])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'Symmetric','Asymmetric'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Y DIST SYM vs ASYM'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Y DIST SYM vs ASYM.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Y DIST SYM vs ASYM' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:length(symzd)/2,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'SYM')

MATN=DataArray(1:length(asymzd)/2,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'ASYM')





DataArray=zeros(8,2);
DataArray(1:6,1)=rc(1:6,1)./rc(1:6,2);
DataArray(1:8,2)=rc(7:14,1)./rc(7:14,2);

DataArray(DataArray==0)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.9];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Ependymal / Non Ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 1.5])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'E14','E13'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'EPEN vs NONEPEN'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'EPEN vs NONEPEN.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'EPEN vs NONEPEN' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:6,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E14')

MATN=DataArray(1:8,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E13')




DataArray=zeros(8,2);
DataArray(1:6,1)=rc(1:6,14);
DataArray(1:8,2)=rc(7:14,14);

DataArray(DataArray==0)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.9];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Doublets / (Triplets and Quadruplets)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 3.25])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'E14','E13'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Dub_VS_Trip_plus_quad_ratio'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Dub_VS_Trip_plus_quad_ratio.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Dub_VS_Trip_plus_quad_ratio' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:6,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E14')

MATN=DataArray(1:8,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E13')



DataArray=zeros(8,2);
DataArray(1:6,1)=rc(1:6,11)./rc(1:6,12);
DataArray(1:8,2)=rc(7:14,11)./rc(7:14,12);

DataArray(DataArray==0)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.9];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Symmetric / Asymmetric division'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 3.5])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'E14','E13'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Sym_VS_Asym_ratio'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Sym_VS_Asym_ratio.pdf'], '-dpdf', '-r600');  

    resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Sym_VS_Asym_ratio' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:6,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E14')

MATN=DataArray(1:8,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E13')



DataArray=zeros(8,2);
DataArray(1:6,1)=100*(2*rc(1:6,11))./(2*rc(1:6,11)+rc(1:6,12));
DataArray(1:8,2)=100*(2*rc(7:14,11))./(2*rc(7:14,11)+rc(7:14,12));

DataArray(DataArray==0)=nan;

    Colors=[0.4 0.9 0.4; 0.4 0.4 0.9];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Origin from symmetric division (%)'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
ylim([0 100])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'E14','E13'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Origin_from_Symmetry'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Origin_from_Symmetry.pdf'], '-dpdf', '-r600'); 

   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'Origin_from_Symmetry' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:6,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E14')

MATN=DataArray(1:8,2);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,'E13')
