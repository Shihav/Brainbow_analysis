imgid
pcells=unique(LABELM);
% CA=[];

% ImgR=LCOLOR5(:,:,1);
% ImgG=LCOLOR5(:,:,2);
% ImgB=LCOLOR5(:,:,3);

id=1;
CA=[];

VA=[];
         for nk=[153 151 144 137 169 163 134 126 102 98 60 62 48 46 52 39 18 16]          
            val=nk; 
           
object3d=Imgsegk3==val;
                RA=2*double(ImgR(object3d));
                 GA=2*double(ImgG(object3d));
                  BA=4*double(ImgB(object3d));   
                  
                  
               VA{id,1}=uint8(RA); 
                VA{id,2}=uint8(GA);
                 VA{id,3}=uint8(BA);
                  
                  
                  
             
                   object = LABELM == val;         
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA(id,10:11)=cent;
            
            CA(id,1:9)=[mean(RA) mean(GA) mean(BA) median(RA) median(GA) median(BA) std(RA) std(GA) std(BA)]; 
          id=id+1
         end 
         CA1=CA;
 save([Reshome2 filesep filename2 filesep filename2 'CA1.mat'],'CA1','VA');  
 
COK(:,:,1)=2*CO(:,:,1);
COK(:,:,2)=2*CO(:,:,2);
COK(:,:,3)=4*CO(:,:,3);
 
 
  figure
  imagesc(imresize(COK,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*CA(zin,11)+30,m*CA(zin,10)-30,num2str(zin),'FontSize',5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*CA(zin,11)+10,m*CA(zin,10)-10,[char(10) '(' num2str(round((CA(zin,1)))) ',' num2str(round((CA(zin,2)))) ','...
          num2str(round((CA(zin,3)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*CA(zin,11)+5,m*CA(zin,10)-10,[char(10) char(10) '(' num2str(round((CA(zin,4)))) ',' num2str(round((CA(zin,5)))) ','...
          num2str(round((CA(zin,6)))) ')'],'FontSize',3,'FontName','Times','Color',[.65 .95 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
              text(m*CA(zin,11)+0,m*CA(zin,10)-10,[char(10) char(10) char(10) '(' num2str(round((CA(zin,7)))) ',' num2str(round((CA(zin,8)))) ','...
          num2str(round((CA(zin,9)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method1'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method1' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method1' '.png']);
  
    resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method1.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(CA1(:,1:9));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'R mean', 'G mean', 'B mean', 'R median', 'G median', 'B median', 'R std', 'G std', 'B std'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')

















































resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method1.xlsx'];
TDt = xlsread(resfile3,'sheet1');

P1=[];
for kin=1:2:size(TDt,1)
    
    R1=mean([abs(TDt(kin,1)-TDt(kin+1,1)) abs(TDt(kin,4)-TDt(kin+1,4))])/mean([TDt(kin,7) TDt(kin+1,7)]);
    G1=mean([abs(TDt(kin,2)-TDt(kin+1,2)) abs(TDt(kin,5)-TDt(kin+1,5))])/mean([TDt(kin,8) TDt(kin+1,8)]);
    B1=mean([abs(TDt(kin,3)-TDt(kin+1,3)) abs(TDt(kin,6)-TDt(kin+1,6))])/mean([TDt(kin,9) TDt(kin+1,9)]);
    
    D1=(R1+G1+B1)./3;
P1=[P1;D1];   
    
end

PO1=mean(P1);


resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method2.xlsx'];
TDt = xlsread(resfile3,'sheet1');

P2=[];
for kin=1:2:size(TDt,1)
    
    R1=mean([abs(TDt(kin,1)-TDt(kin+1,1)) abs(TDt(kin,4)-TDt(kin+1,4))])/mean([TDt(kin,7) TDt(kin+1,7)]);
    G1=mean([abs(TDt(kin,2)-TDt(kin+1,2)) abs(TDt(kin,5)-TDt(kin+1,5))])/mean([TDt(kin,8) TDt(kin+1,8)]);
    B1=mean([abs(TDt(kin,3)-TDt(kin+1,3)) abs(TDt(kin,6)-TDt(kin+1,6))])/mean([TDt(kin,9) TDt(kin+1,9)]);
    
    D1=(R1+G1+B1)./3;
P2=[P2;D1];   
    
end

PO2=mean(P2);

resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method3.xlsx'];
TDt = xlsread(resfile3,'sheet1');

P3=[];
for kin=1:2:size(TDt,1)
    
    R1=mean([abs(TDt(kin,1)-TDt(kin+1,1)) abs(TDt(kin,4)-TDt(kin+1,4))])/mean([TDt(kin,7) TDt(kin+1,7)]);
    G1=mean([abs(TDt(kin,2)-TDt(kin+1,2)) abs(TDt(kin,5)-TDt(kin+1,5))])/mean([TDt(kin,8) TDt(kin+1,8)]);
    B1=mean([abs(TDt(kin,3)-TDt(kin+1,3)) abs(TDt(kin,6)-TDt(kin+1,6))])/mean([TDt(kin,9) TDt(kin+1,9)]);
    
    D1=(R1+G1+B1)./3;
P3=[P3;D1];   
    
end

PO3=mean(P3);

resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method4.xlsx'];
TDt = xlsread(resfile3,'sheet1');

P4=[];
for kin=1:2:size(TDt,1)
    
    R1=mean([abs(TDt(kin,1)-TDt(kin+1,1)) abs(TDt(kin,4)-TDt(kin+1,4))])/mean([TDt(kin,7) TDt(kin+1,7)]);
    G1=mean([abs(TDt(kin,2)-TDt(kin+1,2)) abs(TDt(kin,5)-TDt(kin+1,5))])/mean([TDt(kin,8) TDt(kin+1,8)]);
    B1=mean([abs(TDt(kin,3)-TDt(kin+1,3)) abs(TDt(kin,6)-TDt(kin+1,6))])/mean([TDt(kin,9) TDt(kin+1,9)]);
    
    D1=(R1+G1+B1)./3;
P4=[P4;D1];   
    
end

PO4=mean(P4);

resfile3 = [Reshome2 filesep filename2 filesep filename2 '-method5.xlsx'];
TDt = xlsread(resfile3,'sheet1');

P5=[];
for kin=1:2:size(TDt,1)
    
    R1=mean([abs(TDt(kin,1)-TDt(kin+1,1)) abs(TDt(kin,4)-TDt(kin+1,4))])/mean([TDt(kin,7) TDt(kin+1,7)]);
    G1=mean([abs(TDt(kin,2)-TDt(kin+1,2)) abs(TDt(kin,5)-TDt(kin+1,5))])/mean([TDt(kin,8) TDt(kin+1,8)]);
    B1=mean([abs(TDt(kin,3)-TDt(kin+1,3)) abs(TDt(kin,6)-TDt(kin+1,6))])/mean([TDt(kin,9) TDt(kin+1,9)]);
    
    D1=(R1+G1+B1)./3;
P5=[P5;D1];   
    
end

PO5=mean(P5);



figure

col=lines(5)./1.1;

  valuesmean=[P1 P2 P3 P4 P5];
                                                                                  
  hb = bar(valuesmean,0.6);
                                                                                        hbc = get(hb, 'Children');
                                                                                        set(hbc{1}, 'FaceColor', col(1,:));
                                                                                         set(hbc{2}, 'FaceColor', col(2,:));
                                                                                         set(hbc{3}, 'FaceColor', col(3,:));
                                                                                           set(hbc{4}, 'FaceColor', col(4,:));
                                                                                             set(hbc{5}, 'FaceColor', col(5,:));
                                                                                                                                                                       
                                                                                        hbch1 = get(hbc{1}, 'FaceColor');
                                                                                        hbch2 = get(hbc{2}, 'FaceColor');
                                                                                         hbch3 = get(hbc{3}, 'FaceColor');
                                                                                                 hbch4 = get(hbc{4}, 'FaceColor');
                                                                                                         hbch5 = get(hbc{5}, 'FaceColor');
                                                                                        hl = legend(hb,['Extraction from entire cell' ': '  'mean = ' num2str(PO1)],...
                                                                                                    ['Extraction from eroded cell' ': ' 'mean = ' num2str(PO2)],...
                                                                                                    ['Extraction from mean +-STD per cell' ': '  'mean = ' num2str(PO3)],...
                                                                                                    ['Extraction from largest plane per cell' ': '  'mean = ' num2str(PO4)],...
                                                                                                    ['Extraction from brightest plane per cell' ': '  'mean = ' num2str(PO5)]);
  set(hl,'FontSize', 10,'FontName','Times');

                                                                                        hc = findobj(hl, '-property', 'FaceColor');
                                                                                        set(hc(1), 'FaceColor', hbch5)
                                                                                        set(hc(2), 'FaceColor', hbch4)
                                                                                        set(hc(3), 'FaceColor', hbch3)
                                                                                            set(hc(4), 'FaceColor', hbch2)
                                                                                        set(hc(5), 'FaceColor', hbch1)
                                                                                   


xlim([-0.125 10.125])
ylim([0 1.5])

title(['RGB extraction method analysis'],'FontName','Times','fontsize',20);
xlabel('Couple cells ID','FontSize',16,'FontName','Times');
ylabel('RGB distance by mean STD', 'FontSize', 16,'FontName','Times') % y-axis label
ax = gca;
grid off
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',10);
b = get(gca,'YTickLabel');
set(gca,'YTickLabel',b,'FontName','Times','fontsize',10);
%                                                                                             set(gcf,'PaperPositionMode','auto')
set(gcf,'PaperPositionMode','auto')
%  export_fig([FR filesep 'Vector_angle9'],'-native', '-a2', '-m4','-q101','-png', '-r600');
print([Reshome2 filesep filename2 filesep filename2 ' extraction method analysis'], '-dpng', '-r600');
