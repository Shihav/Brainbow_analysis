clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36 .36 .36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);
mkfig=1;
countAS=[];
xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14)]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\HUE' ]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF' ]);
% m=1;
m{3}=[3139 785 2245 854];
m{10}=[1 0 1 0];
multa(10,:)=multa(3,:);
count=[];
for idx=[12]
    
    mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF\' 'M' num2str(pool(idx))]);
      mn=[1 0 1 0];  
     if idx==7
     LW=0.2;
     elseif idx==11
     LW=0.2;
     elseif idx==10
     LW=2;
     elseif idx==12
     LW=0.8;
     else
     LW=0.4;
     end
     
        if idx==10
     LW2=.5*LW;
        else
     LW2=2*LW;
        end
     
     
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB','valAT','valAQ','LINKA'); 


if idx==10
    nk=m{3};
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(3) 'ang' num2str(14)  'CG' '.png']); 
AG=LCOLORG;
LCOLORG=LCOLORG(nk(1):size(AG,1)-nk(2),nk(3):size(AG,2)-nk(4),:);
elseif idx>10
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
else
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
end


loadaddress;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 
 
load_pic
create_HM
HM=round(HM);
shift2=HM;

shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];
m=1;

pic=[];
pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL_A.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);   
                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j}; 
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL_A.png']);

pic=[];
pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL_AC.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);   
                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j}; 
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL_AC.png']);

pic=[];
pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);   
                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j}; 
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL.png']);

pic=[];
pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALLC.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);   
                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j}; 
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALLC.png']);

idx
close all
end


for idx=[10]
nk=[3139 785 2245 854];        
pic=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(3)) '_A0_ALL_A.png']);
pic=pic(nk(1):size(pic,1)-nk(2),nk(3):size(pic,2)-nk(4),:);
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL_A.png']);

pic=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(3)) '_A0_ALL_AC.png']);
pic=pic(nk(1):size(pic,1)-nk(2),nk(3):size(pic,2)-nk(4),:);
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL_AC.png']);

pic=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(3)) '_A0_ALL.png']);
pic=pic(nk(1):size(pic,1)-nk(2),nk(3):size(pic,2)-nk(4),:);
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL.png']);

pic=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(3)) '_A0_ALLC.png']);
pic=pic(nk(1):size(pic,1)-nk(2),nk(3):size(pic,2)-nk(4),:);
imwrite(pic,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALLC.png']);


idx
close all
end

