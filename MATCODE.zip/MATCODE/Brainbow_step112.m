clear all
close all
% 
clc


DD=10;

for idx=[1 2 3 5 7 8]
    
    cid=1
    HTH=6.5
    STH=90
    BTH=80

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 
DATAT=DATA(:,6:8);
DATACM=rgb2hsv(DATAT(:,1:3));

mkdir([FINR filesep 'RESULT_M' num2str(idx)]);

% PLOT_ADJUSTEDRR

load(['FOX' num2str(idx)],'centerF'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

bpcells=size(DATA,1)

%PLOT_ADJUSTED

load(['DATAF' num2str(idx)],'DTA','DTCMA'); 

load([Reshome3 filesep 'ncoupA_' num2str(0) '_' num2str(BTH) '.mat'],'ncoupA'); 

 ncoup=ncoupA{4,4};
 
 Rmat=ncoup(1)
 
 RRmat=mean(ncoup(2:101))
 
[h,p]=ttest2(ncoup(1),ncoup(2:101)) 

Pmat=p
   
 
  CENTER=imread([Reshome3 filesep 'CENTER.png']);  

MASK=imread([FINB filesep 'AREA' num2str(idx) '.png']);

CENTER(MASK==0)=0;
  fpc=sum(sum(CENTER>0))
  
  areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
  
  FMAT=[];
  FMAT(1,1)=bpcells;
   FMAT(1,2)=Rmat;
   FMAT(1,3)=RRmat;
   FMAT(1,4)=p;
    FMAT(1,5)=fpc;
    FMAT(1,6)=areaV;
    
    resfile3 = [FINR filesep 'RESULT_M' num2str(idx) filesep 'FRANDOM'  num2str(idx) 'Data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=FMAT;
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'Brainbow+ cells', 'Coupling ratio', 'Random coupling ratio', 'P value', 'Foxj1 positive cell', 'Imaged area (mm^2)'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')

     resfile3 = [FINR filesep 'RESULT_M' num2str(idx) filesep 'FRANDOM_RATIO'  num2str(idx) 'Data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=ncoup(2:101)';
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'Random coupling ratio'};
C=[A;B];
xlswrite(resfile3,C,1,'A1') 

close all

 
end




for idx=[1 2 3 5 7 8]
    
    cid=1
    HTH=6.5
    STH=90
    BTH=80

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 
DATAT=DATA(:,6:8);
DATACM=rgb2hsv(DATAT(:,1:3));

mkdir([FINR filesep 'RESULT_M' num2str(idx)]);

%PLOT_ADJUSTEDRR

load(['FOX' num2str(idx)],'centerF'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

bpcells=size(DATA,1)

%PLOT_ADJUSTED

load(['DATAB' num2str(idx)],'DTA','DTCMA'); 

load([Reshome3 filesep 'BncoupA_' num2str(0) '_' num2str(BTH) '.mat'],'ncoupA'); 

 ncoup=ncoupA{4,4};
 
 Rmat=ncoup(1)
 
 RRmat=mean(ncoup(2:101))
 
[h,p]=ttest2(ncoup(1),ncoup(2:101)) 

Pmat=p
   
 
  CENTER=imread([Reshome3 filesep 'CENTER.png']);  

MASK=imread([FINB filesep 'AREA' num2str(idx) '.png']);

CENTER(MASK==0)=0;
  fpc=sum(sum(CENTER>0))
  
  areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
  
  FMAT=[];
  FMAT(1,1)=bpcells;
   FMAT(1,2)=Rmat;
   FMAT(1,3)=RRmat;
   FMAT(1,4)=p;
    FMAT(1,5)=fpc;
    FMAT(1,6)=areaV;
    
    resfile3 = [FINR filesep 'RESULT_M' num2str(idx) filesep 'BRANDOM'  num2str(idx) 'Data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=FMAT;
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'Brainbow+ cells', 'Coupling ratio', 'Brainbow Random coupling ratio', 'P value', 'Foxj1 positive cell', 'Imaged area (mm^2)'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')

     resfile3 = [FINR filesep 'RESULT_M' num2str(idx) filesep 'BRANDOM_RATIO'  num2str(idx) 'Data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=ncoup(2:101)';
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'Brainbow Random coupling ratio'};
C=[A;B];
xlswrite(resfile3,C,1,'A1') 

close all

 
end

