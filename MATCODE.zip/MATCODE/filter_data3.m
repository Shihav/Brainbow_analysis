DATACM=rgb2hsv(DATA(:,6:8));
% HUE=DATACM(:,1)*360; 

% if SU==1
%     
% SV=SVTH;
%     
% else

SV=quantile(DATACM(:,3),((darkest_cells_cut/100)));
%SV=65;
% end

% raw1=HUE>=(360-wd2) | HUE<=(0+wd2);
% raw2=HUE>=(120-wd2) & HUE<=(120+wd2);
% raw3=HUE>=(240-wd2) & HUE<=(240+wd2);
raw4=DATACM(:,3)<=(SV);

select=raw4;
DATA(select==1,:)=[];

