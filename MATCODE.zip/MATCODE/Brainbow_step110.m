clear all
close all
% 
clc

DD=10;

for idx=[1 2 3 5 7 8]
    
    cutp=0
    HTH=5
    STH=100
    BTH=75
    
    if cutp==0
        cid=1;
    elseif cutp==25
        cid=2;
    elseif cutp==50
        cid=3;
    elseif cutp==75
        cid=4;
    end

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
 
load(['DATAF' num2str(idx)],'DTA','DTCMA'); 

  DATA=DTA{2,1};
    DATACM=DTCMA{2,1};
     DATA(:,6:8)=hsv2rgb(DATACM);

%PLOT_ADJUSTEDR

ncoupA=[];
ncA=[];
HTHid=0;

    HTHid=HTHid+1;
    STHid=0;
   
    STHid=STHid+1;
    ncoup=[];
    nc=[];
for loopin=2
   
   DATA=DTA{loopin,cid};
    DATACM=DTCMA{loopin,cid};
    
    DATA(:,6:8)=hsv2rgb(DATACM);
    
    
    
%      PLOT_ADJUSTED
    
%     if loopin==2
%      PLOT_REMOVEDR
%     end
    
    tDATA=DATA;
    
    Bdist=pdist2(DATACM(:,3),DATACM(:,3));

     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     
     SPACEdist=pdist2(DATA(:,4:5),DATA(:,4:5))*.31;
    
%% check conditions    
   Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(Bdist>BTH)=12000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  

        cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
        NBP2=size(D,2);
        idbox1=[1:NBP1];
        idbox2=[1:NBP2];
        Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end               

   xyval(xyval(:,13)>=10000,:)=[];
   
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 nc(loopin)=size(xyval,1);
 
if loopin==2
 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%  LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
  LCOLORL=imread([Reshome3 filesep 'FOXLM2.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
%  CENTER=imread([Reshome3 filesep 'CENTER.png']);
% LCOLORG(LCOLORL==0)=0; 


% sum(sum(CENTER>0))
 
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
%                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');

                           labeledImage = bwlabel(I2cpsegb>0, 4);
% LCOLORL

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
     
     if sum(pos(:))<10000
     
     colorA(pos)=LCOLORCA(pos)+(256*DATA(cell,6)-mean(LCOLORCA(pos)));
      colorB(pos)=LCOLORCB(pos)+(256*DATA(cell,7)-mean(LCOLORCB(pos)));
       colorC(pos)=LCOLORCC(pos)+(256*DATA(cell,8)-mean(LCOLORCC(pos)));
     cell;
     end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.2*CO;


%  figure
% 
% HUE=DATACM(:,1)*360;
% h=polar(0,255,'.');hold on
% set(h,'linewidth',0.01)
% set(h,'markersize',0.01)
% for mt=1:size(DATACM,1)
% h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
% set(h,'linewidth',1)
% set(h,'markersize',6)
% set(h,'color',DATA(mt,6:8)/255)
% end
% 
% set(gcf,'color','w');
% grid off
% box off
% axis off
% 
%     for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));
%            HUE1=DATACM1(:,1)*360;
%            x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
%            y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
%          text(x1+3,y1-5,num2str(zin),'FontSize',3,'FontName','Times','Color',[0 0 0],'HorizontalAlignment','center','VerticalAlignment', 'top');  
%         
% %          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM(zin,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(Connection(zin))],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
% %           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
% %           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%   
%      for zin=1:size(xyval,1)   
%          
%          DATACM1=rgb2hsv(xyval(zin,5:7));
%          DATACM2=rgb2hsv(xyval(zin,10:12));
% 
% HUE1=DATACM1(:,1)*360;
% HUE2=DATACM2(:,1)*360;
% 
% x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
% x2=DATACM2(:,3)*cos(2*pi*DATACM2(:,1));
% 
% y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
% y2=DATACM2(:,3)*sin(2*pi*DATACM2(:,1));
%          
%    U=x2-x1;
%    V=y2-y1;
%    Z=sqrt(U.^2+V.^2);   
%   quiver(x1,y1,U,V,0,'color',[0 0 0],'maxheadsize',0.05,'linewidth',0.25) ; hold on
% %          end
%    
%      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
% 
% export_fig(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx) '_Hue_couple'],'-a2', '-m4','-p0.02','-q101','-png', '-r600');
% 
%       close all    

     figure
     m=2
  imshow(imresize(COF,m));hold on

%     for zin=1:size(tDATA,1)       
%           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(zin),'FontSize',3,'FontName','Times','Color',[1 1 0],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,[char(10) num2str(round(DATACM(zin,1)*360))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
% 
%          
%          %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(Connection(zin))],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
% %           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
% %           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
  
%      for zin=1:size(xyval,1)   
%          
%    U=m*xyval(zin,4)-m*xyval(zin,2);
%    V=m*xyval(zin,3)-m*xyval(zin,1);
%    Z=sqrt(U.^2+V.^2);   
%   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.5) ; hold on
% %          end
% 
%      end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig([FINR filesep 'Random' num2str(idx)],'-a2', '-m4','-p0','-q101','-png', '-r600');

      close all    
      
%       
%            figure
%      m=2
%   imshow(imresize(COF,m));hold on
% 
% %     for zin=1:size(tDATA,1)       
% %          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM(zin,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(Connection(zin))],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
% % %           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
% % %           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %      end
%   
% %      for zin=1:size(xyval,1)   
% %          
% %    U=m*xyval(zin,4)-m*xyval(zin,2);
% %    V=m*xyval(zin,3)-m*xyval(zin,1);
% %    Z=sqrt(U.^2+V.^2);   
% %   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.5) ; hold on
% % %          end
% % 
% %      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
% 
% export_fig(['G:\Marie_2016_NEW\Combined2' filesep 'SisterF4_assignment_idx' num2str(idx)],'-a2', '-m4','-p0','-q101','-png', '-r600');

      close all   
      
end 
end


end