clear all
close all

clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\IMAGEJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB';
% Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\FINAL';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];


   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);

DATA=cells2.data.Sheet1;
% DATA(end-1:end,:)=[];
ID=DATA(:,1);

DATA(:,1)=[];

% DATA=DATA(1:28,:)

figure()

    valn=DATA(:,5);
     valr=DATA(:,6);
     vals=DATA(:,7);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATA(n,5:7)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution 4');
print([Reshome2 filesep  'Color distribution 4'], '-dpng', '-r300'); 
% print(['aPerf_terplot_synTissue'], '-dpdf', '-r300');
% print(['aPerf_terplot_synTissue'], '-dpng', '-r300');




FP=DATA(DATA(:,2)==1,1);

% pos=[];
val=[];
for pid=1:length(FP)
val(pid)=sum(ID==pid);
% val(pid)=DATA(pos(pid),2);
end

figure
scatter(FP,val) 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
colk=pink(length(FP))/1.25;

h=scatter(FP,val,90*(mat2gray(val)+0.5),colk,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
 colormap((pink));  %# Change the colormap to gray (so higher values are
    %   colorbar                       %#   black and lower values are white)
    caxis manual
    caxis([1 length(FP)])
    colorbar


for pid=1:length(FP)
   text(FP(pid)+7,val(pid)+1,num2str(val(pid)/FP(pid),'%.2f'),'FontSize',9,'FontName','Times','Color',colk(pid,:),'HorizontalAlignment','left','VerticalAlignment', 'top');
end
 xlabel('FoxJ1 positives','FontSize', 20,'FontName','Times');
                                            ylabel('Brainbow positives', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Rate of Brainbow positive cells'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 5'], '-dpng', '-r300'); 





 figure()
 [nc,hc]=hist(DATA(:,5),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'r','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(DATA(:,6),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'g','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(DATA(:,7),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'b','LineStyle','-','LineWidth',2);
 
  hold on
  [hleg1, hobj1]=legend(['STD = ' num2str(std(DATA(:,5)))],['STD = ' num2str(std(DATA(:,6)))],['STD = ' num2str(std(DATA(:,7)))],'Location','northeast');
legend('boxoff')

set(hleg1,'FontSize',16,'FontName','Times');  

xlim([0 255])

  xlabel('Spectrum','FontSize', 20,'FontName','Times');
                                            ylabel('Probability', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution'], '-dpng', '-r300'); 



 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter(DATA(:,5),DATA(:,6),50*(mat2gray(DATA(:,7))+0.5),DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution 2'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 2'], '-dpng', '-r300'); 


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter3(DATA(:,5),DATA(:,6),DATA(:,7),sum(DATA(:,5:7),2)/5,DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
view(38,18)

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution 3'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 3'], '-dpng', '-r300'); 

for imgid=1:numel(Types)
  
     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
        
     LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
        
       load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');
        load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');  
        
        
        
       wgt=1;
        norm=[size(LABEL,1) size(LABEL,2) wgt*65535 wgt*65535 wgt*65535];
%            norm=[1024 1024 wgt*65535 wgt*65535 wgt*65535];
           center2=center./repmat(norm,size(center,1),1);
           
           
            norm2=[1 1 1 1 1 1 1 1 1 4096 4096 4096 4096 4096 4096 4096 4096 4096];
           CA2=CA./repmat(norm2,size(CA,1),1);
           
           [COPx,COPy]=terncoords(CA2(:,4),CA2(:,5),CA2(:,6));
           COP=[COPx COPy];
           
           CO=[CA2(:,[4:6 13:18]) center2(:,[1:2])]; 
     
                  DS = single(pdist2(CO(:,10:11),CO(:,10:11),'euclidean')); 
                  DC = single(pdist2(CO(:,1:9),CO(:,1:9),'euclidean')); 
                  
                  D = single(pdist2(CO,CO,'euclidean'));
                  D(D==0)=11;
                  DS(DS==0)=11;
                    DC(DC==0)=11;      
       cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];
         diffval=[];
   
                xyval=[];
            cdiffval=[];
              sdiffval=[];
                diffval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     diffval(cp,1)=D(Aida(cp,1),Aida(cp,2));
                     sdiffval(cp,1)=DS(Aida(cp,1),Aida(cp,2));
                     cdiffval(cp,1)=DC(Aida(cp,1),Aida(cp,2));

                     xyval(cp,1:2)=[center(Aida(cp,1),1) center(Aida(cp,1),2)];
                        xyval(cp,3:4)=[center(Aida(cp,2),1) center(Aida(cp,2),2)];
                         xyval(cp,5:7)=[center(Aida(cp,1),3) center(Aida(cp,1),4) center(Aida(cp,1),5)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[center(Aida(cp,2),3) center(Aida(cp,2),4) center(Aida(cp,2),5)];

                 end   
                 
                 
         figure
      m=4;
     Imk2=imresize(LCOLOR4,m);
     
   figure

  imagesc(Imk2);hold on

     for zin=1:size(cosmat,1)       
         if  diffval(zin)<0.25      

   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[.75 .75 0],'maxheadsize',100/Z,'linewidth',0.5) ; hold on
         end

     end
     axis equal
   
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction4'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction4.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction4.png']);
          
                 
   save([Reshome2 filesep filename2 filesep filename2 'val.mat'],'diffval','cdiffval','sdiffval','xyval','CO');                          
        
       tDATA=DATA(ID==imgid,:);

figure()

    valn=tDATA(:,5);
     valr=tDATA(:,6);
     vals=tDATA(:,7);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution ternary');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution 4'], '-dpng', '-r300');  
        



figure()

    valn=CA(:,1);
     valr=CA(:,2);
     vals=CA(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution mean ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution mean ratio'], '-dpng', '-r300');  

figure()

    valn=CA(:,1);
     valr=CA(:,2);
     vals=CA(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution mean ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution mean ratio'], '-dpng', '-r300');  
        
figure()

    valn=CA(:,4);
     valr=CA(:,5);
     vals=CA(:,6);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution median ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution median ratio'], '-dpng', '-r300');  

figure()

    valn=CA(:,7);
     valr=CA(:,8);
     vals=CA(:,9);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution STD ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution STD ratio'], '-dpng', '-r300');  


figure()

    valn=CA(:,10);
     valr=CA(:,11);
     vals=CA(:,12);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution mean');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution mean'], '-dpng', '-r300');  
        
figure()

    valn=CA(:,13);
     valr=CA(:,14);
     vals=CA(:,15);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution median');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution median'], '-dpng', '-r300');  

figure()

    valn=CA(:,16);
     valr=CA(:,17);
     vals=CA(:,18);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution STD ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution STD'], '-dpng', '-r300'); 
close all

end



AK = {'Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue'};
C=[AK;BKA];

xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')






