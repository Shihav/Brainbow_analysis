%  set(gca,'XTick',1:12,...                         %# Change the axes tick marks
%         'XTickLabel',{'M5-C-E14-F','M6-C-E14-F','M3-C-E14-F','M1-C-E14-F','M9-C-D','M11-D-D','M4-D-E14-F','M10-D-D','M12-D-D','M8-R-F','M2-R-E14-F','M7-R-D'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
% xticklabel_rotate([],90,{'M5-C-E14-F','M6-C-E14-F','M3-C-E14-F','M1-C-E14-F','M9-C-D','M11-D-D','M4-D-E14-F','M10-D-D','M12-D-D','M8-R-F','M2-R-E14-F','M7-R-D'});


 set(gca,'XTick',1:14,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M6','M3','M1','M9','M11','M4','M13','M14','M10','M12','M8','M2','M7'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
% xticklabel_rotate([],90,{'M5','M6','M3','M1','M9','M11','M4','M10','M12','M8','M2','M7'});