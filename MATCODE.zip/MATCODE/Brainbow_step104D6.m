clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=80;
Bdiff_allowed=80;
Hdiff_allowed=13;
Sdiff_allowed=70;

Hdiff_max=20;
Sdiff_max=140;

% Hdiff_allowed1=15;
% Sdiff_allowed1=75;
% Sdiff_allowed2=100;
load_angle=1;

D_th=2;
T_th=sqrt(2);


for idx=[1 2 3 5]
    
% Hdiff_allowed=15;
% Sdiff_allowed=75;
     
loadaddress;
% load('DATA1')

load([Reshome2 filesep 'all.mat'],'DATA'); 
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek;

load([Reshome2 filesep 'all3.mat'],'tDATA','DATACM'); 

load(['FOX' num2str(idx)],'centerF'); 

SPACE=min((pdist2(centerF(:,1:2),tDATA(:,4:5))*.31),[],2);

centerF(SPACE>dist_from_brainbow_allowed,:)=[];

  

     DATA=tDATA;

    tDATA=DATA;
   
                xyval=[];
                load_listM3;
                Aida=[];
                cpk=0;
                 for cp=1:length(AR)
                     
                     cpk=cpk+1;
%                      point=min(cosmatw(:));
%                      [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[AR(cp,1) AR(cp,2)]];
% 
%                      idbox1(ismember(idbox1,Aida(:,1)))=[];
%                         idbox2(ismember(idbox2,Aida(:,2)))=[];
%                      cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cpk,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cpk,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cpk,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cpk,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cpk,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cpk,13)=length(AR);
%                             xyval(cp,14:16)=[DATACM(Aida(cp,1),1) DATACM(Aida(cp,1),2) DATACM(Aida(cp,1),3)];
%                               xyval(cp,17:19)=[DATACM(Aida(cp,2),1) DATACM(Aida(cp,2),2) DATACM(Aida(cp,2),3)];
                      cpk=cpk+1;
%                       Aida=[Aida;[AR(cp,2) AR(cp,1)]];
% 
%                      idbox1(ismember(idbox1,Aida(:,1)))=[];
%                         idbox2(ismember(idbox2,Aida(:,2)))=[];
%                      cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cpk,1:2)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                        xyval(cpk,3:4)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                         xyval(cpk,5:7)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                         xyval(cpk,8:9)=[Aida(cp,2) Aida(cp,1)];
                           xyval(cpk,10:12)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                           xyval(cpk,13)=length(AR);




                 end   
   
  
   
   
  

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);

 for cell=1:size(tDATA,1)
     
     val=LCOLORL(tDATA(cell,4),tDATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000
%   if mean(pos(:))<10000
     
%      colorA(pos)=LCOLORCA(pos)+(256*tDATA(cell,6)-mean(LCOLORCA(pos)));
%       colorB(pos)=LCOLORCB(pos)+(256*tDATA(cell,7)-mean(LCOLORCB(pos)));
%        colorC(pos)=LCOLORCC(pos)+(256*tDATA(cell,8)-mean(LCOLORCC(pos)));
       
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell;
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.2*CO;
m=1;
    
     figure
  imshow(COF);hold on
  
%   imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(ttt-1) '.png']);
  
     for zin=1:size(xyval,1)   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.75) ; hold on
  
  dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
  
%     text(m*mean([xyval(zin,2) xyval(zin,4)]),m*mean([xyval(zin,1) xyval(zin,3)]),[char(10) num2str(round(dg))],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
  
  
  
  
%          end

     end
     
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));
%            HUE1=DATACM1(:,1)*360;
%            x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
%            y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
%          text(x1+3,y1-5,num2str(zin),'FontSize',3,'FontName','Times','Color',[0 0 0],'HorizontalAlignment','center','VerticalAlignment', 'top');  
%         
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',2.5,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
%           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     
     
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loopS' num2str(5)],'-a2', '-m6','-p0','-q101','-png', '-r600');
%close all

% 
% make_hue_plot(tDATA,DATACM)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'HUE' num2str(0)],'-a2', '-m6','-p0','-q101','-png', '-r600');

save([Reshome2 filesep 'linkS.mat'],'xyval'); 

end


