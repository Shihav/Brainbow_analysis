
  
   RS=xyvalt(:,4)-xyvalt(:,2);
   RH=xyvalt(:,3)-xyvalt(:,1);
  
  theta=(180./pi.*atan2(RH,-RS));

    theta(theta<0)=theta(theta<0)+360;
    theta=theta';
    
    col=[.8 .1 .1; 0.1 0.1 0.8; 0.5 0.5 0.5];

                                            minS=0;
                                            maxS=360;

                                            Distk=[0:20:360];
                                            Center=[10:20:350];
%                                             figure()
                                            [n1,x11] = histc(theta,Distk);
                                            n1(19)=[];
%                                              [n2,x22] = histc(data2',Distk);
%                                             n2(19)=[];
%                                              [n3,x33] = histc(data3',Distk);
%                                             n3(19)=[];
                                                                                     
        n11=100*n1/sum(n1);
%             n22=100*n2/sum(n2);
%                 n33=100*n3/sum(n3);
                                                                          valuesmean=[n11'];                        
                                                                                   index = Distk; 
%                                                                                    center2=[5 95 185 275];
% %                                                                                    n44=n33;
%                                                                                    n44(1:4)=25%max([n33 n22 n11]);
    
    
    
           
  figure
           
           MVAL=max([n11]);
   [t,r] = rose(degtorad(theta),18); 
ADJ=MVAL./max(r);
r=r*ADJ;

 h2=compass(n11.*cosd(Center),n11.*sind(Center));
                    set(h2,'Color',[0.1 0.1 0.1],'linewidth',0.1) 
                    hold on

% rMax = MVAL;
% h2 = compass(MVAL, 2);
% set(h2,'Color',[1 1 1],'linewidth',0.001) 

%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t,r);
Cut=1.4;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;

for kin=1:size(Xin,2)
h = patch(Xin2(:,kin), Yin2(:,kin), [0.5 0.5 0.5]);
alpha(h, 0.25)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.1 0.1 0.1],'LineStyle','-','Linewidth',.5);


% if sum(Xin2(:,kin)==0)==5
% else
% hh1 = hatchfill(h, 'single',Center(kin)+90, 2);
% set(hh1, 'Color',[0.1 0.1 0.8])
% end
% hh = hatchfill(h,'single', 45,3,[0.1 0.1 0.8]);
% set(hh,'color','b','linewidth',2);
                       hold on                                                         
end
  [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n11.*cosd(Center),n11.*sind(Center),0.99);
     plot(arrowx,arrowy,'Color',[0.1 0.1 0.1],'linewidth',1);

                    
       
%                                             title('Angular (360) beating direction histogram','FontName','Times','fontsize',20);
                                                                                
                                                ax = gca;
                                                grid off
                                                
                                                        a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','Times','fontsize',10);
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','Times','fontsize',10);

%                                                                                             set(gcf,'PaperPositionMode','auto')
%  set(gcf,'PaperPositionMode','auto')
% %  export_fig([FR filesep 'Vector_angle9'],'-native', '-a2', '-m4','-q101','-png', '-r600');
%                                                         print([FR filesep 'Vector_angle10'], '-dpng', '-r600');
%                                                                                         set(gcf,'Units','inches');
% screenposition = get(gcf,'Position');
% set(gcf,...
%     'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% % print -dpdf -painters epsFig
%   
%   
%    print([FR filesep 'Vector_angle10'], '-dpdf', '-r300');     
%    
   
   