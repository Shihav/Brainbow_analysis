clear all
close all

clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\IMAGEJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB';
Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB2';
% Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\FINAL';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

% load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
%    cells2 = importdata([Reshome2 filesep 'Result.xlsx']);
%  
% 
% 
% DATA=cells2.data.Sheet1;


load([Reshome2 filesep 'c2count.mat'],'C2count'); 
% load([Reshome2 filesep 'c2count.mat'],'C2count','DLIST','YA'); 

list=find(C2count(:,1)>.1);
C2count=C2count(list,:);
figure()
%  [nc,hc]=hist(C2count(:,1),linspace(0,1,10));
%  nc=nc/sum(nc); 
%  plot(hc,nc,'r','LineStyle','-','LineWidth',2);
% 
%  hold on
%  [nc,hc]=hist(C2count(:,2),linspace(0,1,10));
%  nc=nc/sum(nc); 
%  plot(hc,nc,'g','LineStyle','-','LineWidth',2);

bar(C2count(:,1:2))
ylim([0 1.1])
%  hold on
%  [nc,hc]=hist(reshape(C2count(:,3:102),100*size(C2count,1),1),linspace(0,1,25));
%  nc=nc/sum(nc); 
%  plot(hc,nc,'b','LineStyle','-','LineWidth',2);
 
  hold on
  [hleg1, hobj1]=legend(['DATA'],['RANDOM'],'Location','northwest');
legend('boxoff')

set(gca,'XTick',1:length(list))
 ax = gca;
 set(ax,'XTickLabel',list);

set(hleg1,'FontSize',16,'FontName','Times');  

% xlim([0 1])

  xlabel('Image id','FontSize', 20,'FontName','Times');
                                            ylabel('% coupled', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Coupling probability'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome3 filesep  'Coupling distribution'], '-dpng', '-r300'); 