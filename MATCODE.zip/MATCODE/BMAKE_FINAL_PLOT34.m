% ADATAS=ADATA(unique(xyvals(:,8:9)),:);
% ADATAS=ADATA;

PSDATA=ADATAS(ADATAS(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM2.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
COFB=uint16(zeros(size(COF1)));
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATAS(ADATAS(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM2.png']);
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
% imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_R' '.png']);

imwrite(COF1+COF2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_RF' '.png']);

  figure
  imshow(COFB);hold on
%   tDATA=PSDATA;
%      for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));  
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%      
%    tDATA=NSDATA;
%      for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));  
%            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
%               text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
     

     for zin=1:size(xyvals,1) 
         
         if xyvals(zin,14)==1 && xyvals(zin,15)==1
             CC=[1 1 1];
         elseif xyvals(zin,14)==1 && xyvals(zin,15)==2
             CC=[1 1 0];
         elseif xyvals(zin,14)==2 && xyvals(zin,15)==1
             CC=[1 1 0]; 
         elseif xyvals(zin,14)==2 && xyvals(zin,15)==2
             CC=[0.5 1 .5];
         end
         
   U=m*xyvals(zin,4)-m*xyvals(zin,2);
   V=m*xyvals(zin,3)-m*xyvals(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyvals(zin,2),m*xyvals(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',LW) ; hold on
%   dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
%     text(m*mean([xyval(zin,2) xyval(zin,4)])+1,m*mean([xyval(zin,1) xyval(zin,3)])-1,[char(10) num2str(round(dg))],'FontSize',3,'FontName','Times','Color',[1 1 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');

     end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_RLF'],'-a2', '-m6','-p0','-q101','-png', '-r600');

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK']);

LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);

AG=LCOLORG;

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
% imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF_other' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);
% B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
% imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF_other' '.png']);

A=remove_line(A,A1);
% B=remove_line(B,B1);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO' '.png']);
% imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_other' '.png']);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG' '.png']);
% imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_other' '.png']);

