B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
CLR=[1 .8 .7];
if size(B,3)==3
ck7=Bor_create(B,[1 size(B,1) 1 size(B,2)],10,65535*CLR,1);
else
ck7=Bor_createG(B,[1 size(B,1) 1 size(B,2)],10,65535*CLR,1);
end
ck=imresize(B,[size(A,1) size(A,2)],'nearest');
% ck77=imresize(B,[size(A,1)/2-borderb size(A,2)/2-borderb],'nearest');
% if size(B,3)==3
% ck=Bor_create(ck,[1 size(ck,1) 1 size(ck,2)],15,65535*CLR,1);
% else
% ck=Bor_createG(ck,[1 size(ck,1) 1 size(ck,2)],15,255*CLR,1);    
% end
% A(size(A,1)/2+0:size(A,1)-borderb,size(A,2)/2+0:size(A,2)-borderb,:)=ck77;
A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:)=ck7;