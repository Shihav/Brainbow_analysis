function [ADATAS_DSYM_M,xyvals_DSYM_M,ADATAS_DSYM_MR]=crop_cell_link(ADATAS_DSYM,xyvals_DSYM,mn,AG,mod)
% mod=0;
if mod ==1
ADATAS_DSYM(:,2)=10000*(ADATAS_DSYM(:,1)-1)+ADATAS_DSYM(:,2);
end


TAG=zeros(size(ADATAS_DSYM,1),1);
for kin=1:1:size(xyvals_DSYM,1)
 ar=xyvals_DSYM(kin,24:25);
 
 TAG(ismember(ADATAS_DSYM(:,2),ar))=kin;

end

ADATAS_DSYM_M=[];
pcells=unique(TAG);
infoT=[];
DG=[1 0;0 1];
for kin=1:length(pcells)
    
    TEM=ADATAS_DSYM(TAG==pcells(kin),:);
    select=TEM(:,4)>mn(1) & TEM(:,4)<(size(AG,1)-mn(2)) & TEM(:,5)>mn(3) & TEM(:,5)<(size(AG,2)-mn(4));
    if sum(select)==size(TEM,1)
    ADATAS_DSYM_M=[ADATAS_DSYM_M;TEM];
    end
end

% if size(ADATAS_DSYM_M,1)==0
%     xyvals_DSYM_M=[];
% else
xyvals_DSYM_M=xyvals_DSYM(ismember(xyvals_DSYM(:,24),ADATAS_DSYM_M(:,2)),:);
% end
ADATAS_DSYM_MR=ADATAS_DSYM;
select=ADATAS_DSYM_MR(:,4)>mn(1) & ADATAS_DSYM_MR(:,4)<(size(AG,1)-mn(2)) & ADATAS_DSYM_MR(:,5)>mn(3) & ADATAS_DSYM_MR(:,5)<(size(AG,2)-mn(4));
ADATAS_DSYM_MR=ADATAS_DSYM_MR(select,:);
ADATAS_DSYM_MR(ismember(ADATAS_DSYM_MR(:,2),ADATAS_DSYM_M(:,2)),:)=[];