clear all
close all

clc

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36];

slice=ceil(25./zres)+1

slice1=ceil(2./zres)+1



% for idx=[12]
% 
% loadaddress;
% 
% d=dir(fullfile(Datahome,'*.tif*'));
% Types={d.name}; 
% 
% % Types2=[];
% % sq=1;
% % list=[4 8 9 10 11 14 15 16:30 32:41];
% % 
% % for kin=list
% % Types2{sq}=Types{kin};
% % sq=sq+1
% % end
% % 
% % Types=Types2;
%  
% load_pic
% create_HM
% HM=round(HM);
% shift2=HM;
% 
% shift=fliplr(shift2);
% 
% dimm1=max(shift2(:,1))+DY;
% dimm2=max(shift2(:,2))+DX;
% 
% shift=[shift(:,1)+DX shift(:,2)+DY];
% m=1;
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'mosaicG.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'mosaicG.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ALL.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=max(cat(4,pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:),pic1{j}),[],4);                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'All.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'POverlayM3.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'PmosaicO.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'POverlayM2.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'POverlayM2.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'POverlayM1.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'PmosaicOP.png']);
%   
% pic=[];    
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'PFinalmapM.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024); 
% imwrite(pic,[Reshome3 filesep 'PFinalmapM.png']);  
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'PZPOS.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'PZPOSmosiac.png']);
% 
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM3.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'NmosaicO.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM2.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'NOverlayM2.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM1.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'NmosaicOP.png']);
%   
% pic=[];    
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'NFinalmapM.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024); 
% imwrite(pic,[Reshome3 filesep 'NFinalmapM.png']);  
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'NZPOS.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
% imwrite(pic,[Reshome3 filesep 'NZPOSmosiac.png']);
% 
% pic=[];
% pic1=[];
% load_pic;
% for worklistn=1:numel(Types)
%      filename2=strrep(Types{worklistn},'.tif','');    
%      LCOLOR4=imread([Reshome5 filesep filename2 filesep filename2 'ZMAP.png']);
%      pic1{worklistn}=LCOLOR4;
% end
% for j=numel(Types):-1:1
%                 pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
% end
% pic=pic(1:dimm2+1024,1:dimm1+1024); 
% imwrite(pic,[Reshome3 filesep 'ZMAP.png']);  
% 
% end


for idx=[12]

loadaddress;

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

typ=1;
ang=0;

 LCOLORC=imread([Reshome3 filesep 'NmosaicOP.png']);
 LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);
 
 LCOLORZ=imread([Reshome3 filesep 'ZMAP.png']);  
 LCOLORZPOS=imread([Reshome3 filesep 'NZPOSmosiac.png']); 
 
 
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
 ImgRZ=LCOLORZPOS(:,:,1);
 ImgGZ=LCOLORZPOS(:,:,2);
 ImgBZ=LCOLORZPOS(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

% imwrite(uint16(LABELM),[Reshome3 filesep 'NmosaicLM.png'])


% LABEL=LABELM;
LABEL=imerode(LABELM,ones(1,1));

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];
% DATA=NDATA;
DATA=[];
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;      
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
%               [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));
              
% center(nk-1,3:8)=[mean(ImgR(object))/255 mean(ImgG(object))/255 mean(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 
center(nk-1,3:8)=[median(ImgR(object))/255 median(ImgG(object))/255 median(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 

                            
                            %             CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
%             CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
 DATA(nk-1,1:11)=[1 nk-1 length(pcells)-1 center(nk-1,1:8)];
 
 
 Zcell=median([ImgRZ(object);ImgGZ(object);ImgBZ(object)]);
 Zapi=median([LCOLORZ(object)]);
 
 
 DATA(nk-1,12)=round(Zcell/256)+slice1(idx);
 
 DATA(nk-1,13)=round(Zapi/256);


          nk
         end 
         
         NDATA=DATA;
         
save([Reshome2 filesep 'Nall3.mat'],'NDATA'); 
idx


end

for idx=[12]

loadaddress;

% load([Reshome2 filesep 'Pall.mat'],'PDATA');

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

typ=1;
ang=0;

 LCOLORC=imread([Reshome3 filesep 'PmosaicOP.png']);
 LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);
 
 LCOLORZ=imread([Reshome3 filesep 'ZMAP.png']);  
 LCOLORZPOS=imread([Reshome3 filesep 'PZPOSmosiac.png']); 
 
 
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
 ImgRZ=LCOLORZPOS(:,:,1);
 ImgGZ=LCOLORZPOS(:,:,2);
 ImgBZ=LCOLORZPOS(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

% imwrite(uint16(LABELM),[Reshome3 filesep 'NmosaicLM.png'])


% LABEL=LABELM;
LABEL=imerode(LABELM,ones(1,1));

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];

% DATA=PDATA;
DATA=[];
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;      
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
%               [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));
              
% center(nk-1,3:8)=[mean(ImgR(object))/255 mean(ImgG(object))/255 mean(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 
center(nk-1,3:8)=[median(ImgR(object))/255 median(ImgG(object))/255 median(ImgB(object))/255 std(double(ImgR(object)))/255 std(double(ImgG(object)))/255 std(double(ImgB(object)))/255]; 

                            
                            %             CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
%             CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
 DATA(nk-1,1:11)=[1 nk-1 length(pcells)-1 center(nk-1,1:8)];
%  
%  
 Zcell=median([ImgRZ(object);ImgGZ(object);ImgBZ(object)]);
 Zapi=median([LCOLORZ(object)]);
 
 
 DATA(nk-1,12)=round(Zcell/256)-25;
 
 DATA(nk-1,13)=round(Zapi/256);


          nk
         end 
         
         PDATA=DATA;
         
save([Reshome2 filesep 'Pall2.mat'],'PDATA'); 
idx

end