function [LCOLORG,LCOLORG2]=makes_ID_imagesM(ADATAS,LCOLORG,LW,sisters,idx,name,multp,multn,Reshome3,border,mn,F)

% make_hue_plot2(ADATAS)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) name],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% make_hue_plot2S(ADATAS)
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) name],'-a2', '-m6','-p0','-q101','-png', '-r600');

AG=imread([Reshome3 filesep 'mosaicG.png']);
PSDATA=ADATAS(ADATAS(:,1)==1,:);
% tDATA=PSDATA;
% LCOLORC=imread([Reshome3 filesep 'PmosaicO2.png']);
% LCOLORL=imread([Reshome3 filesep 'PFinalmapM2.png']);
% % LCOLORL2=imdilate(LCOLORL,ones(3));
% % AG(cat(3,LCOLORL2,LCOLORL2,LCOLORL2)>1)=0;
% mult=multp;
% 
% if border == 0
% make_CL;
% 
% elseif border==1
%  make_CL_B;   
% end
% 
% 
% COF1=CL;
% COFB=uint16(zeros(size(COF1)));
% 
NSDATA=ADATAS(ADATAS(:,1)==2,:);
% tDATA=NSDATA;
% LCOLORC=imread([Reshome3 filesep 'NmosaicO2.png']);
% LCOLORL=imread([Reshome3 filesep 'NFinalmapM2.png']);
% LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
% 
% mult=multn;
% make_CL;
% COF2=CL;
m=1;  
% imwrite(COF1+COF2,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'FCROP' num2str(14) name '.png']);

figure
  imshow(LCOLORG);hold on

  tDATA=PSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           zin
     end
     
   tDATA=NSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
              text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
              zin
     end


%   figure
%   imshow(COFB);hold on
% 
%      for zin=1:size(xyvals,1) 
%          
% %          if xyvals(zin,14)==1 && xyvals(zin,15)==1
% %              CC=[1 1 1];
% %          elseif xyvals(zin,14)==1 && xyvals(zin,15)==2
% %              CC=[1 1 0];
% %          elseif xyvals(zin,14)==2 && xyvals(zin,15)==1
% %              CC=[1 1 0]; 
% %          elseif xyvals(zin,14)==2 && xyvals(zin,15)==2
% %              CC=[0.5 1 .5];
% %          end
% 
% CC=[1 1 1];
%          
%    U=m*xyvals(zin,4)-m*xyvals(zin,2);
%    V=m*xyvals(zin,3)-m*xyvals(zin,1);
% %    Z=sqrt(U.^2+V.^2);   
%   quiver(m*xyvals(zin,2),m*xyvals(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',LW) ; hold on
%   
%   
%   
%      end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'FCROP' num2str(14) name 'L'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F6.png'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK']);

% AG=imread([Reshome3 filesep 'mosaicG.png']);
% A=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F6.png']);
A=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'FCROP' num2str(14) name 'L' '.png']);
if size(A,3)==1
    A=cat(3,A,A,A);
end
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
% imwrite(A,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'FCROP' num2str(14)  name 'L' '.png']);
% A1=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' num2str(idx) '\' num2str(idx) 'FIG6_F5.png']);
A1=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'FCROP' num2str(14)  name '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
% imwrite(A1,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'FCROP' num2str(14)  name '.png']);

A=remove_line(A,A1);

if F==0
LCOLORG=256*uint16(A)+A1;
LCOLORG2=A1;
else
LCOLORG=256*uint16(A)+A1+0.5*AG;  
LCOLORG2=A1+0.5*AG;  
end


LCOLORG=LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);
LCOLORG2=LCOLORG2(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

close all


% imwrite(256*uint16(A)+A1,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'FCROP' num2str(14)  name 'LO' '.png']);
% imwrite(256*uint16(A)+A1+0.5*AG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'FCROP' num2str(14)  name 'LOG' '.png']);


