function h = ternlabel2(A, B, C)
r(1) = text(0.5, -0.075, A, 'horizontalalignment', 'center','FontName','Times','FontSize', 16);
r(2) = text(1-0.35*sin(deg2rad(30)), 0.5, B, 'rotation', -60, 'horizontalalignment', 'center','FontName','Times','FontSize', 16);
r(3) = text(0.35*sin(deg2rad(30)), 0.5, C, 'rotation', 60, 'horizontalalignment', 'center','FontName','Times','FontSize', 16);

if nargout > 0
    h = r;
end;