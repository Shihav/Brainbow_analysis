AK=[340 10 40 70 100 130 160 190 220 250 280 310 340];
BK=[20 50 80 110 140 170 200 230 260 290 320 350 20];
% xyval=txyval;

for anga=1:length(AK)
    
    close all
    
    DATA=FDATA;
    DATACM=FDATACM;
    xyval=Fxyval;
    HUE=DATACM(:,1)*360;
 if anga==1


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;

 elseif anga==13 


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;

 else
    select=DATACM(:,3)>5 & HUE>=AK(anga) & HUE<BK(anga);
 end
 
DATAz=DATA(select,:);
DATACMz=DATACM(select,:);
%  make_hue_plot(DATAz,DATACMz)
 
 cells1=find(select==1);
 linefrom=ismember(xyval(:,8),cells1);
 
DATAz=DATA(cells1,:);
DATACMz=DATACM(cells1,:);
%  make_hue_plot(DATAz,DATACMz)
 
 
 cells2=unique(xyval(linefrom,9));
 
   DATAz=DATA(cells2,:);
DATACMz=DATACM(cells2,:);
%  make_hue_plot(DATAz,DATACMz)
 
 cells=unique([cells1;cells2]);
 
 linefrom1=ismember(xyval(:,8),cells);
 linefrom2=ismember(xyval(:,9),cells);
 linefrom=linefrom1 | linefrom2;
 
 xyval=xyval(linefrom==1,:);
 
 
DATA=DATA(cells,:);
DATACM=DATACM(cells,:);

DATAk=DATA;
DATACMk=DATACM;

ADATA=DATA;

% make_hue_plot(DATAk,DATACMk)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'angHUE' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');

PSDATA=ADATA(ADATA(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATA(ADATA(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
% imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_R' '.png']);


  figure
  imshow(COF1+COF2);hold on
  tDATA=PSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
   tDATA=NSDATA;
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
              text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     for zin=1:size(xyval,1) 
         
         if xyval(zin,14)==1 && xyval(zin,15)==1
             CC=[1 1 1];
         elseif xyval(zin,14)==1 && xyval(zin,15)==2
             CC=[1 1 0];
         elseif xyval(zin,14)==2 && xyval(zin,15)==1
             CC=[1 1 0];  
         elseif xyval(zin,14)==2 && xyval(zin,15)==2
             CC=[0.6 0.6 .9];
         end
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',.75) ; hold on
%   dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
%     text(m*mean([xyval(zin,2) xyval(zin,4)])+1,m*mean([xyval(zin,1) xyval(zin,3)])-1,[char(10) num2str(round(dg))],'FontSize',3,'FontName','Times','Color',[1 1 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');

     end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
  

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');

end