
clear all
close all
% 
clc

DD=10;

for idx=[5]
    
%     cutp=0
%     HTH=5
%     STH=100
%     BTH=75
%     
%     if cutp==0
%         cid=1;
%     elseif cutp==25
%         cid=2;
%     elseif cutp==50
%         cid=3;
%     elseif cutp==75
%         cid=4;
%     end

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;

load(['FOX' num2str(idx)],'centerF'); 

SPACE=min((pdist2(centerF(:,1:2),DATA(:,4:5))*.31),[],2);

centerF(SPACE>100,:)=[];

% cut=0.99;
% rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
%  mult=255./ rangek;
%   DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

 DATAori=DATA;
    DATACMori=DATACM;
    
    DT{1}=DATA;
    DTCM{1}=DATACM;

 for loopin=2   
     
     loopin
    
    rdid=randperm(size(DATA,1));
    
    rdidF=randperm(size(centerF,1));
    
DATAn=[DATAori(:,1:3) centerF(rdidF(1:size(DATA,1)),1:2) DATAori(rdid(1:size(DATA,1)),6:11)];

DATACMn=rgb2hsv(DATAn(:,6:8));


HUEn=DATACMn(:,1)*360;
data2n=[DATACMn(:,3).*cosd(HUEn) DATACMn(:,3).*sind(HUEn)];


res=128;
  [bandwidth,density,X,Y]=kde2d(data2n,res,[-255,-255],[255,255]);    
       hG = fspecial('gaussian',[5 5],1);               
                      density = imfilter(density,hG,'symmetric'); 
                                 density=flipud(density);
                            
        Xin=linspace(-255,255,res);
Yin=linspace(255,-255,res);

Dist=density;
N=size(DATA,1);

SN1=floor(N*.45);
SN2=floor(N*.45);
ASN=N-SN1-SN2;



vals=zeros(2,SN1);
for i=1:SN1
   [vals(1,i),vals(2,i)]=pinky(Xin,Yin,Dist,10);
end

RH1=vals(1,:)';
RS1=vals(2,:)';

HR=0 + 3.*randn(SN1,1);
SR=0 + 30.*randn(SN2,1);

RH2=RH1+HR;
RS2=RS1+SR;

vals=zeros(2,ASN);
for i=1:ASN
   [vals(1,i),vals(2,i)]=pinky(Xin,Yin,Dist,10);
end

ASH1=vals(1,:)';
ASS1=vals(2,:)';

RH=[RH1;RH2;ASH1];
RS=[RS1;RS2;ASS1];
  
theta=(180./pi.*atan2(RS,RH));

    theta(theta<0)=theta(theta<0)+360;
    
    RB=sqrt(RS.^2+RH.^2);
    RB(RB>255)=255;

DATACMn(:,1)=theta/360;
DATACMn(:,3)=RB;

    DT{loopin}=DATAn;
    DTCM{loopin}=DATACMn;
    
 end
 
 for loopin=1:101 
     
      DATA=DT{loopin};
    DATACM=DTCM{loopin};
        


DATAk=DATA;
DATACMk=DATACM;

HUE=DATACM(:,1)*360;

% res=64;
data=[HUE DATACM(:,3)];
data2=[DATACM(:,3).*cosd(HUE) DATACM(:,3).*sind(HUE)];

  [bandwidth,density,X,Y]=kde2d(data2,res,[-255,-255],[255,255]);  
  
%        hG = fspecial('gaussian',[9 9],1.5);
               
                      density = imfilter(density,hG,'symmetric'); 
                                 density=flipud(density);
                       Y=flipud(Y);
nk=512/res;
data3=round((data2+255)/nk);
data3(data3<1)=1;
data3(data3>res)=res;

select2=[];

for n=1:size(data3,1)
    
    select2(n,1)=density(data3(n,1),data3(n,2));
    
end
     
     
 cutpid=0;
 for cutp=[0]
 
     cutpid=cutpid+1;
 
 
select2k=select2<quantile(select2,(1-(cutp/100)));

DATAx=DATA(select2k==1,:);
DATACMx=DATACM(select2k==1,:);

  DTA{loopin,cutpid}=DATAx;
    DTCMA{loopin,cutpid}=DATACMx;
 
 end
 end

end
 