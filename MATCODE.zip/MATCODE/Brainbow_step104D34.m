clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100];
darkest_cells_cutdownA=[0];

zres=[0.52 0.36 0.36 1 0.36 1 0.47 0.47 1 0.36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);

ftype=7;
DRF2=0;
DRF=0; %% plot filtering steps
DRS=0; %% plot selected cells
DR=0; %% make final link plot
DH=0; %% draw hue plot
GL=0.0; %% Gray image weight

DDM=0; %% Directional plots
DRAP=0; %% make all plots
MPL=0; %% make post links

singles=0;

CPL=2; %% Allowed number of unique min colored cells

cr=0;

MAT=[];

symd=[];
asymd=[];

symhd=[];
asymhd=[];

symzd=[];
asymzd=[];

symdA=[];
asymdA=[];

symhdA=[];
asymhdA=[];

symzdA=[];
asymzdA=[];

SRT=0.475; %% line length

load multa.mat multa

for sisters=3:7
LMH=1;
LMB=1;
LMS=1;
LMSAT=1;

nidx=1;
rc=[];
rcp=[];
nc=[];

HTH=10;
STH=100;
BTH=100;
SATH=0.33;

ts=0;
tm=0;

OLDIST=13;

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);

final_remove_list;

AL=[];

for idx=[3]
    
    idx=(sisters-2)*10+idx;
    
     if idx==7
     LW=0.4;
     else
     LW=0.8;
     end
    
    xyvalAR=[];
    ADATAAR=[];
    xyvalsAR=[];
    ADATASAR=[];
    ADATALA=[];
    ADATALA2=[];
    DATARMA=[];
    
    xyvals_symAR=[];
    xyvals_asymAR=[];
    xyvals_otherAR=[];
    
    ADATAS_symAR=[];
    ADATAS_asymAR=[];
    ADATAS_otherAR=[];
    
for darkest_cells_cutid=1:length(darkest_cells_cutupA) 
    
    darkest_cells_cutup=darkest_cells_cutupA(darkest_cells_cutid);
    darkest_cells_cutdown=darkest_cells_cutdownA(darkest_cells_cutid);
    
idxt=mod(idx,10);         
loadaddress2;

load([Reshome2 filesep 'DATALEFT' num2str(idx) '.mat'],'DATALEFT'); 
% multp=[1 1 1]; 

PDATA=DATALEFT(DATALEFT(:,1)==1,:);
PDATAB=PDATA;

NDATA=DATALEFT(DATALEFT(:,1)==2,:);
NDATAB=NDATA;

MAT(idx,1)=size(PDATAB,1);
MAT(idx,2)=size(NDATAB,1);


DATA=PDATA;
idxt=mod(idx,10);

multp=multa(idxt,:);
multn=multa(idxt,:);

% DALLDATA=[PDATA;NDATA];

% make_hue_plot2(DALLDATA)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\PMAT\' 'ZLINK_idx' num2str(idx) 'RHue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');
% make_hue_plot2S(DALLDATA)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\PMAT\' 'ZLINK_idx' num2str(idx) 'RSHue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');




% make_hue_plot2(DATA)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\PMAT\' 'ZLINK_idx' num2str(idx) 'BHue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');
% make_hue_plot2S(DATA)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\PMAT\' 'ZLINK_idx' num2str(idx) 'BSHue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');



% rangek=[quantile(DALLDATA(:,6),cut) quantile(DALLDATA(:,7),cut) quantile(DALLDATA(:,8),cut)];
% rangek(rangek>255)=255;
% mult=255./rangek; 
% multp=mult;
%   
% DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATAT=DATA(:,6:8);
% DATAT(DATAT>255)=255;
% DATA(:,6:8)=DATAT;

% make_hue_plot2(DATA)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\PMAT\' 'ZLINK_idx' num2str(idx) 'AHue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');
% make_hue_plot2S(DATA)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\PMAT\' 'ZLINK_idx' num2str(idx) 'ASHue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 



% select=sum(DATA(:,6:8)>254,2)<3;    
% DATA=DATA(select==1,:);
% 
% tests=[DATA(:,6:8)./DATA(:,9:11)];
% testm=DATA(:,6:8);
% select=max(tests,[],2)>ts & max(testm,[],2)>tm;
% DATA=DATA(select==1,:);

PDATABB=DATA;
PDATABB(:,1)=1;

if ftype==5
filter_data5;
elseif ftype==6
filter_data6;
end
PSDATA=DATA;

DATA=NDATA;
% rangek=[quantile(DALLDATA(:,6),cut) quantile(DALLDATA(:,7),cut) quantile(DALLDATA(:,8),cut)];
% rangek(rangek>255)=255;
% mult=255./rangek; 
% multn=mult;
% multa(idx,:)=multn;
%   
% DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATAT=DATA(:,6:8);
% DATAT(DATAT>255)=255;
% DATA(:,6:8)=DATAT;
% 
% select=sum(DATA(:,6:8)>254,2)<3;    
% DATA=DATA(select==1,:);
% 
% tests=[DATA(:,6:8)./DATA(:,9:11)];
% testm=DATA(:,6:8);
% select=max(tests,[],2)>ts & max(testm,[],2)>tm;
% DATA=DATA(select==1,:);

NDATABB=DATA;
NDATABB(:,1)=2;

if ftype==5
filter_data5;
elseif ftype==6
filter_data6;
end
NSDATA=DATA;

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
ADATAB=[PDATABB;NDATABB];

if ftype==7
filter_data7;
end

if DRF==1    
BMAKE_FILTERED_PLOT2;

make_hue_plot2S(ADATA)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_F_' num2str(darkest_cells_cutid) '_HS'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end   

    tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LMH);
     BdistB=Bdist<=(BTH*LMB);
     SPACEdistB=SPACEdist<=(STH*LMS);
     SATdistB=SATdist<=(SATH*LMSAT);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=CPL;
     
     if singles==1
     select1=sum(PC,2)==1 & tDATA(:,1)==1;
     select=select | select1;
     end
  DATABK=ADATA;
     ADATA=ADATA(select,:);  
     
     DATARM=DATABK(select==0,:);
     
if DRF2==1       
BMAKE_FILTERED_PLOT3;

make_hue_plot2S(ADATA)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_F_' num2str(darkest_cells_cutid) '_HSR'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end
     
     NSDATA=ADATA(ADATA(:,1)==2,:);
     PSDATA=ADATA(ADATA(:,1)==1,:);
if cr==1     
     rid=randperm(size(PDATAB,1));
PSDATA=[PDATAB(rid(1:size(PSDATA,1)),1:5) PSDATA(:,6:end)];

    rid=randperm(size(NDATAB,1));
NSDATA=[NDATAB(rid(1:size(NSDATA,1)),1:5) NSDATA(:,6:end)];


%      rid=randperm(size(PSDATA,1));
% PSDATA=[PSDATA(rid(1:size(PSDATA,1)),1:5) PSDATA(:,6:end)];
% 
%     rid=randperm(size(NSDATA,1));
% NSDATA=[NSDATA(rid(1:size(NSDATA,1)),1:5) NSDATA(:,6:end)];

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
end
     
 
     tDATA=ADATA;
     tDATACM=rgb2hsv(ADATA(:,6:8));
     DATACM=rgb2hsv(ADATA(:,6:8));
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     
%% check conditions    
%    Costmat=SPACEdist/10+HUEdist;
div=HTH/STH;

% %   Costmat=SPACEdist;%HUEdist + SPACEdist*div;
   if sisters <7
   Costmat=1*HUEdist + SPACEdist*0;
   
   else
%     HUEdist(SPACEdist<(STH/2))=SPACEdist(SPACEdist<(STH/2));
    Costmat=0*HUEdist + SPACEdist*1;
   end
   Costmat1 = diag(diag(Costmat)+1);
   
   Costmat(Costmat1>0)=20000;
%    Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
%    Costmat(SPACEdist<=(STH/4) & Costmat<20000)=SPACEdist(SPACEdist<=(STH/4) & Costmat<20000)/STH;


    DF=Costmat<HTH;

NB=[];    
DFF=sum(DF);

%         for cp2=1:size(tDATA,1)
%             if DFF(cp2)>0;
%             PO=find(DF(cp2,:)==1);
%                  [list,POS]= min(SD(cp2,PO));
%                  NB(cp2,1:2)=[PO(POS) list];
%             end
%         end


cp=1;
    xyval=[];
    
    for cp1=1:size(tDATA,1)
         if DFF(cp1)>0;
           cp2A=find(DF(cp1,:)==1);    
                  for cin=1:length(cp2A)
                      cp2=cp2A(cin);
%                       cp2=
                     xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
                        xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
                         xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
                         xyval(cp,8:9)=[cp1 cp2];
                           xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
                           xyval(cp,13)=DF(cp1,cp2);
                           xyval(cp,14:15)=[tDATA(cp1,1) tDATA(cp2,1)];
                            xyval(cp,16:17)=[tDATA(cp1,end) tDATA(cp2,end)];
                            xyval(cp,18:19)=[tDATA(cp1,12) tDATA(cp2,12)];
                            xyval(cp,20:21)=[tDATA(cp1,13) tDATA(cp2,13)];
                           cp=cp+1;
                  end
%             end
        end
    end 

  



%    
%    D=Costmat;  
%           cosmatw=D;
%         cosmat=D;
%         NBP1=size(D,1);
%          NBP2=size(D,2);
%        idbox1=[1:NBP1];
%         idbox2=[1:NBP2];
%          Aida=[];  
%                 xyval=[];
%                  for cp=1:min([NBP1 NBP2])
%                      point=min(cosmatw(:));
%                      [Aid,Bid]=find(cosmatw==point);
%                       Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];
% 
%                      idbox1(ismember(idbox1,Aida(:,1)))=[];
%                         idbox2(ismember(idbox2,Aida(:,2)))=[];
%                      cosmatw=cosmat(idbox1,idbox2);   
% 
%                      xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
%                         xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
%                          xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
%                          xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
%                            xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
%                            xyval(cp,13)=point;
%                            xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];
%                             xyval(cp,16:17)=[tDATA(Aida(cp,1),end) tDATA(Aida(cp,2),end)];
%                             xyval(cp,18:19)=[tDATA(Aida(cp,1),12) tDATA(Aida(cp,2),12)];
%                             xyval(cp,20:21)=[tDATA(Aida(cp,1),13) tDATA(Aida(cp,2),13)];
%                  end  
%    xyval(xyval(:,13)>=20000,:)=[];
%    xyval(xyval(:,14)==2 & xyval(:,15)==2,:)=[];

imp=(xyval(:,14)==1 & xyval(:,15)==1) | (xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1);
xyvals=xyval(imp,:);
ADATAS=ADATA(unique(xyvals(:,8:9)),:);

imp=(xyval(:,14)==1 & xyval(:,15)==1);
xyvals_sym=xyval(imp,:);
ADATAS_sym=ADATA(unique(xyvals_sym(:,8:9)),:);

imp=((xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1));
xyvals_asym=xyval(imp,:);
ADATAS_asym=ADATA(unique(xyvals_asym(:,8:9)),:);

imp=(xyval(:,14)==2 & xyval(:,15)==2);
xyvals_other=xyval(imp,:);
ADATAS_other=ADATA(unique(xyvals_other(:,8:9)),:);



ADATAL=ADATA;
ADATAL(unique(xyvals(:,8:9)),:)=[];

ADATAL2=ADATA;
ADATAL2(unique(xyval(:,8:9)),:)=[];

xyvalAR=[xyvalAR;xyval];
ADATAAR=[ADATAAR;ADATA];
ADATASAR=[ADATASAR;ADATAS];
xyvalsAR=[xyvalsAR;xyvals];
ADATALA=[ADATALA;ADATAL];
ADATALA2=[ADATALA2;ADATAL2];
DATARMA=[DATARMA;DATARM];

xyvals_symAR=[xyvals_symAR;xyvals_sym];
xyvals_asymAR=[xyvals_asymAR;xyvals_asym];
xyvals_otherAR=[xyvals_otherAR;xyvals_other];

ADATAS_symAR=[ADATAS_symAR;ADATAS_sym];
ADATAS_asymAR=[ADATAS_asymAR;ADATAS_asym];
ADATAS_otherAR=[ADATAS_otherAR;ADATAS_other];



end

if MPL==1
    MAKE_POST_LINK
end

MAT(idx,3)=size(ADATAAR(ADATAAR(:,1)==1,:),1);
MAT(idx,4)=size(ADATAAR(ADATAAR(:,1)==2,:),1);

DATALEFT=[ADATALA2;DATARMA];
DATALEFT=DATALEFT(:,1:13);
save([Reshome2 filesep 'DATALEFT' num2str(idx+10) '.mat'],'DATALEFT'); 

save([Reshome2 filesep 'CELLS' num2str(idx) '.mat'],'ADATASAR');
save([Reshome2 filesep 'LINKS' num2str(idx) '.mat'],'xyvalsAR');



if DH==1
make_hue_plot2(ADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');

PADATAB=ADATAB(ADATAB(:,1)==1,:);
make_hue_plot2(PADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) 'P'],'-a2', '-m6','-p0','-q101','-png', '-r600');

NADATAB=ADATAB(ADATAB(:,1)==2,:);
make_hue_plot2(NADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) 'N'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2(ADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');

PADATAAR=ADATAAR(ADATAAR(:,1)==1,:);
make_hue_plot2(PADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) '_RP'],'-a2', '-m6','-p0','-q101','-png', '-r600');

NADATAAR=ADATAAR(ADATAAR(:,1)==2,:);
make_hue_plot2(NADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) '_RN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(ADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(PADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) 'P'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(NADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) 'N'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(ADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(PADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) '_RP'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(NADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) '_RN'],'-a2', '-m6','-p0','-q101','-png', '-r600');


end

xyval=xyvalAR;
ADATA=ADATAAR;

if DRS==1
    BMAKE_SELECTED_PLOT34;
end

if DDM==1
    BMAKE_DIRECTION_PLOT;
end

xyval=xyvalAR;
ADATA=ADATAAR;

xyvals=xyvalsAR;
ADATAS=ADATASAR;

xyvals_sym=xyvals_symAR;
xyvals_asym=xyvals_asymAR;
xyvals_other=xyvals_otherAR;

ADATAS_sym=ADATAS_symAR;
ADATAS_asym=ADATAS_asymAR;
ADATAS_other=ADATAS_otherAR;

if DR==1
    BMAKE_FINAL_PLOT34;
%     BMAKE_FINAL_PLOT3;
end





SD=sum(xyval(:,14)==1 & xyval(:,15)==1);
AD=sum(xyval(:,14)==1 & xyval(:,15)==2) + sum(xyval(:,14)==2 & xyval(:,15)==1);
rc(nidx,:)=[SD AD];

SDP=xyval((xyval(:,14)==1 & xyval(:,15)==1),16:17);
ADP=xyval((xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1),16:17);
rcp(nidx,:)=[sum(SDP(:)) sum(ADP(:))];

SDP=xyval((xyval(:,14)==1 & xyval(:,15)==1),:);
ADP=xyval((xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1),:);

SDPD=mean(sqrt((SDP(:,1)-SDP(:,3)).^2+(SDP(:,2)-SDP(:,4)).^2)*.31);
ADPD=mean(sqrt((ADP(:,1)-ADP(:,3)).^2+(ADP(:,2)-ADP(:,4)).^2)*.31);

symd=[symd; sqrt((SDP(:,1)-SDP(:,3)).^2+(SDP(:,2)-SDP(:,4)).^2)*.31];
asymd=[asymd; sqrt((ADP(:,1)-ADP(:,3)).^2+(ADP(:,2)-ADP(:,4)).^2)*.31];

symdA{idx}=sqrt((SDP(:,1)-SDP(:,3)).^2+(SDP(:,2)-SDP(:,4)).^2)*.31;
asymdA{idx}=sqrt((ADP(:,1)-ADP(:,3)).^2+(ADP(:,2)-ADP(:,4)).^2)*.31;

SDPHD=mean(SDP(:,13));
ADPHD=mean(ADP(:,13));

symhd=[symhd; SDP(:,13)];
asymhd=[asymhd; ADP(:,13)];

symhdA{idx}=SDP(:,13);
asymhdA{idx}=ADP(:,13);

SDPZD=mean(zres(idxt)*abs(SDP(:,18)-SDP(:,19)));
ADPZD=mean(zres(idxt)*abs(ADP(:,18)-ADP(:,19)));

symzd=[symzd; zres(idxt)*abs(SDP(:,18)-SDP(:,19))];
asymzd=[asymzd; zres(idxt)*abs(ADP(:,18)-ADP(:,19))];

symzdA{idx}=zres(idxt)*abs(SDP(:,18)-SDP(:,19));
asymzdA{idx}=zres(idxt)*abs(ADP(:,18)-ADP(:,19));

MAT(idx,19:20)=[SDPD ADPD];
MAT(idx,22:23)=[SDPHD ADPHD];
MAT(idx,24:25)=[SDPZD ADPZD];

MAT(idx,5)=size(xyval,1)/2;
MAT(idx,6)=SD/2;
MAT(idx,7)=AD/2;
MAT(idx,8)=sum(xyval(:,14)==2 & xyval(:,15)==2)/2;

MD=double(imread([FINR filesep 'DISTANCE MAP' num2str(idxt) '.png']))/64;
ADATALAP=ADATALA(ADATALA(:,1)==1,:);
ttDATA=ADATALAP;

distt=[];
for lin=1:size(ttDATA,1)
    distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;
end

SB=sum(distt<=((STH+25)/1));
SC=size(ttDATA,1)-SB;
S=size(ttDATA,1);

MAT(idx,9:11)=[S SB SC];

ADATALAN=ADATALA(ADATALA(:,1)==2,:);
ttDATA=ADATALAN;

distt=[];
for lin=1:size(ttDATA,1)
    distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;
end

SB=sum(distt<=((STH+25)/1));
SC=size(ttDATA,1)-SB;
S=size(ttDATA,1);

MAT(idx,12:14)=[S SB SC];

load(['FOX' num2str(idxt)],'centerF'); 

distt=[];
for lin=1:size(centerF,1)
    distt(lin)=MD(centerF(lin,1),centerF(lin,2))*.31;
end

FP=sum(distt<=((STH+25)/1));

MAT(idx,15)=[FP];

ttDATA=PDATABB;

distt=[];
for lin=1:size(ttDATA,1)
    distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;
end

BFP=sum(distt<=((STH+25)/1));

MAT(idx,17)=[BFP];

nidx=nidx+1;

FDATACM=DATACM;
Fxyval=xyval;
FDATA=ADATA;

if load_angle==1
    BMAKE_ANGULAR_PLOT
end

AL=[AL;xyvalAR];

close all
end

% save multa.mat multa

if DDM==1
    BMAKE_DIRECTION_PLOTG;
end

if DRAP==1

BRAINBOW_FINAL_PLOT6

end


end

