clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=80;
Bdiff_allowed=80;
Hdiff_allowed=13;
Sdiff_allowed=70;

Hdiff_max=20;
Sdiff_max=140;

% Hdiff_allowed1=15;
% Sdiff_allowed1=75;
% Sdiff_allowed2=100;
load_angle=1;

D_th=2;
T_th=sqrt(2);

nidx=1;
rc=[];


for idx=[1 2 3 5 7 8]
    
% Hdiff_allowed=15;
% Sdiff_allowed=75;
     
loadaddress;
% load('DATA1')

load([Reshome2 filesep 'all.mat'],'DATA'); 
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek;

load([Reshome2 filesep 'all3.mat'],'tDATA','DATACM'); 

load(['FOX' num2str(idx)],'centerF'); 


% LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
%   
%   
%          Img=LCOLORG(:,:,1);
          mean_s=25;
%         h = fspecial('disk', mean_s);
%         Img2 = imfilter(Img,h,'replicate');
% 
%         Img3=Img2;
%         
%         mask=uint16(zeros(size(Img3)));
%         
%                 
%         if idx==1
%         
%         mask(Img3>(max(Img2(:))*.3))=65535;
%         elseif idx==2
%         
%         mask(Img3>(max(Img2(:))*.1))=65535;
%         
%         elseif idx==3
%         
%         mask(Img3>(max(Img2(:))*.15))=65535;
%         
%         elseif idx==5
%         
%         mask(Img3>(max(Img2(:))*.2))=65535;
%         
%         elseif idx==7
%         
%         mask(Img3>(max(Img2(:))*.125))=65535;
%         
%         elseif idx==8
%         
%         mask(Img3>(max(Img2(:))*.2))=65535;
%         end
%         
%         
% %         mask(Img3>(max(Img2(:))*.3))=65535;
%         
%         mask=imdilate(mask,strel('disk',mean_s));
% %         mask = imfill(mask);
% % 
% %         maskf=uint16(zeros(size(Img3)));    
% %            CC = bwconncomp(mask);
% %    numOfPixels = cellfun(@numel,CC.PixelIdxList);
% %    [unused,indexOfMax] = max(numOfPixels);
% %    maskf(CC.PixelIdxList{indexOfMax}) = 65535;
%     
% %         maskb=uint16(zeros(size(Img3)));
% %         Img33=cat(3,Img3,Img3,Img3);
% %         mask3=cat(3,maskf,maskb,maskb);
%         
%         MASK=uint16(65535*mat2gray(mask));
% figure
% imshow(MASK)
% 
% MASK1=imcomplement(MASK);
% 
% MASK1 = bwareaopen(MASK1, 10000);
% 
% 
% MASK1=imcomplement(MASK1);
% 
% MASK1 = bwareaopen(MASK1, 100000);
% 
% MASK1=imcomplement(MASK1);
% 
% figure
% imshow(MASK1)
% 
% MD = bwdist(MASK1);
% 
% 
% 
% 
% figure
% imshow(uint8(MD));
% 
% imwrite(uint16(MD*64),[FINR filesep 'DISTANCE MAP' num2str(idx) '.png']);
% 
% imwrite(uint16(65535*mat2gray(imcomplement(MASK1))),[FINR filesep 'BORDER_AREA' num2str(idx) '.png']);
  
% % %  imwrite(MASK,[FINB filesep 'AREA' num2str(idx) '.png']);



SPACE=min((pdist2(centerF(:,1:2),tDATA(:,4:5))*.31),[],2);

centerF(SPACE>dist_from_brainbow_allowed,:)=[];


     DATA=tDATA;

    tDATA=DATA;
  
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
%      Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     
     
HUEdist=HUEdist(:);
HUEdist(HUEdist==0)=[];


[hc,nc]=hist(HUEdist,linspace(0,180,37));
hc=hc./sum(hc);

% figure
% H=bar(nc,hc,0.5);
% 
% for k=1:1
%   set(H(k),'facecolor',[0.7 0.5 0.5])
% end
% 
% % legend('Singlet','Doublet','Triplet','Location','Best','FontSize',20,'FontWeight','bold','FontName','times');
% ylabel(['Probability'],'FontSize', 20,'FontWeight','bold','FontName','times') % y-axis label
% xlabel(['Hue distance in degrees'],'FontSize', 20,'FontWeight','bold','FontName','times') % y-axis label
% 
%                                                 set(gca, 'Ticklength', [0 0])
%                                                 ax = gca;
%                                                 grid off
%                                                 box off
%                                                 legend('boxoff')
% xlim([-3.5 183.5])
% ylim([0 .1])
% %   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');
% 
% pbaspect([8,6,1])
% 
%  
% %  set(gca,'XTick',1:6,...                         %# Change the axes tick marks
% %         'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
% %         'YTick',1:4,...
% %         'YTickLabel',{'30','50','70','90'},...
%         
%  
% 
% 
%                                                 a = get(gca,'XTickLabel');
%                                                 set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
%                                                 b = get(gca,'YTickLabel');
%                                                 set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
% 
%                                                 ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                                 %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                                                                                             set(gcf,'PaperPositionMode','auto')
% 
% %                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
% set(gcf,'color','w');                                                     
% 
% 
% 
% 
% export_fig([FINR filesep 'HUE_DIST' num2str(idx)],'-a2', '-m6','-p0.02','-png', '-r600');
% 
% 
% 
% 
% SPACEdist=SPACEdist(:);
% SPACEdist(SPACEdist==0)=[];
% 
% 
% [hc1,nc1]=hist(SPACEdist,linspace(0,1500,51))
% 
% hc1=hc1./sum(hc1);
% 
% figure
% H=bar(nc1,hc1,0.5);
% 
% for k=1:1
%   set(H(k),'facecolor',[0.6 0.7 0.6])
% end
% 
% % legend('Singlet','Doublet','Triplet','Location','Best','FontSize',20,'FontWeight','bold','FontName','times');
% ylabel(['Probability'],'FontSize', 20,'FontWeight','bold','FontName','times') % y-axis label
% xlabel(['Spatial distance in microns'],'FontSize', 20,'FontWeight','bold','FontName','times') % y-axis label
% 
%                                                 set(gca, 'Ticklength', [0 0])
%                                                 ax = gca;
%                                                 grid off
%                                                 box off
%                                                 legend('boxoff')
% xlim([-22.5 1522.5])
% ylim([0 .1])
% %   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');
% 
% pbaspect([8,6,1])
% 
%  
% %  set(gca,'XTick',1:6,...                         %# Change the axes tick marks
% %         'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
% %         'YTick',1:4,...
% %         'YTickLabel',{'30','50','70','90'},...
%         
%  
% 
% 
%                                                 a = get(gca,'XTickLabel');
%                                                 set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
%                                                 b = get(gca,'YTickLabel');
%                                                 set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
% 
%                                                 ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                                 %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                                                                                             set(gcf,'PaperPositionMode','auto')
% 
% %                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
% set(gcf,'color','w');                                                     
% 
% 
% 
% 
% export_fig([FINR filesep 'SPATIAL_DIST' num2str(idx)],'-a2', '-m6','-p0.02','-png', '-r600');



% boxp= flipud((repmat(hc1,[length(hc) 1]).*repmat(hc',[1 length(hc1)]))');
% figure
%  imagesc(boxp./sum(boxp(:)))
%  
%  colorbar
%  
%  
%   set(gca,'XTick',5:5:35,...                         %# Change the axes tick marks
%         'XTickLabel',20:25:170,'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%     
%      
%   set(gca,'YTick',10:10:50,...                         %# Change the axes tick marks
%         'YTickLabel',1260:-300:60,'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
% 
%     set(gcf,'PaperPositionMode','auto')
%   set(gcf,'color','w');
% 
%   export_fig([FINR filesep 'DIST' num2str(idx)],'-a2', '-m6','-p0.02','-png', '-r600');


load([Reshome2 filesep 'linkS.mat'],'xyval'); 


[LL,LLD,L]=unique(xyval(:,8))

LC=[];

for lin=1:length(LL)
    
    LC(lin)=sum(xyval(:,8)==LL(lin));


end


DB=sum(LC==1)/2;
TB=sum(LC==2)/3;


% rc(nidx,:)=[SB DB*2 TB*3];



MD=imread([FINR filesep 'DISTANCE MAP' num2str(idx) '.png'])/64;

ttDATA=tDATA;
ttDATA(LL,:)=[];
MD=double(MD);
distt=[];
for lin=1:size(ttDATA,1)
    
    distt(lin)=MD(ttDATA(lin,4),ttDATA(lin,5))*.31;


end

SBC=sum(distt<=((140+mean_s)/2));


SB=size(tDATA,1)-2*DB-3*TB-SBC;

rc(nidx,:)=[SBC SB DB*2 TB*3];

nidx=nidx+1;

% figure
% bar([SB DB*2 TB*3])
close all

end



myC= [0.2 0.2 0.3;
    0.4 0.4 0.6;
  0.5 0.7 0.5;
  1 0.8 0.8];

figure
H=bar(rc,0.5,'stacked');

for k=1:4
  set(H(k),'facecolor',myC(k,:))
end

legend('Singlet (border)','Singlet','Doublet','Triplet','Location','Best','FontSize',20,'FontWeight','bold','FontName','times');
ylabel(['Number of cells'],'FontSize', 20,'FontWeight','bold','FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
                                                legend('boxoff')
xlim([0.5 6.5])
ylim([0 max(sum(rc,2))+10])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([8,6,1])

 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     




export_fig([FINR filesep 'CELL_DISTM'],'-a2', '-m6','-p0.02','-png', '-r600');



figure

H=bar(rc./repmat(sum(rc,2),[1 4]),0.5,'stacked');

for k=1:4
  set(H(k),'facecolor',myC(k,:))
end

% legend('Singlet','Doublet','Triplet','location','northeastoutside','FontSize',20,'FontWeight','bold','FontName','times');
ylabel(['Number of cells'],'FontSize', 20,'FontWeight','bold','FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
%                                                 legend('boxoff')
xlim([0.5 6.5])
ylim([0 1.05])
%   [H,P,KSSTAT] = kstest2(dataW,dataM,0.05,'unequal');

pbaspect([8,6,1])

 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
%         'YTick',1:4,...
%         'YTickLabel',{'30','50','70','90'},...
        
 


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
set(gcf,'color','w');                                                     




export_fig([FINR filesep 'CELL_DISTM2'],'-a2', '-m6','-p0.02','-png', '-r600');

close all;
