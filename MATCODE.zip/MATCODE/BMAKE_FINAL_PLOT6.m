MAT([4 6 7],:)=[];

% MAT(:,21)=MAT(:,1);
MAT(:,21)=[1;2;3;4;5];

MAT([1 2 3 4 5],:)=MAT([5 3 1 4 2],:);
rc([1 2 3 4 5],:)=rc([5 3 1 4 2],:);
rcp([1 2 3 4 5],:)=rcp([5 3 1 4 2],:);

myC= [0.7 0.7 0.7;
    0.9 0.9 1;
    0.9 1 0.9];

figure
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Symmetric division rate = ' num2str(100*mn,'%0.2f') '%, total link = ' num2str(sum(rc(:))/2)],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST3'],'-a2', '-m6','-p0.02','-png', '-r600');


figure
H=bar(rcp./repmat(sum(rcp,2),[1 2]),0.5,'stacked');
mn=sum(rcp(:))/2;

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Power Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Ang. Link weight = ' num2str(100*mn/(sum(rc(:))/2),'%0.2f') ', total link = ' num2str(sum(rc(:))/2)],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST5'],'-a2', '-m6','-p0.02','-png', '-r600');

figure
rc(:,2)=rc(:,2)/2+0.0*MAT(:,11);
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Origin from symmetric division = ' num2str(100*mn,'%0.2f') '%, total cell = ' num2str(sum(rc(:)))],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
ylim([0 1.05])
pbaspect([8,6,1])

 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST4'],'-a2', '-m6','-p0.02','-png', '-r600');


figure
Dist=linspace(0,STH,11);

                                            [n1,x11] = hist(symd,Dist);
                                            [n2,x22] = hist(asymd,Dist);

n11=100*n1/sum(n1);
n22=100*n2/sum(n2);                                                                               valuesmean=[n11' n22'];
                                                                                  
                                                                                   index = Dist; 

                                                                                        hb = bar(index,valuesmean);
                                                                                        hbc = get(hb, 'Children');
                                                                                        set(hbc{1}, 'FaceColor', myC(1,:));
                                                                                        set(hbc{2}, 'FaceColor', myC(2,:));
 hl = legend(hb,['Symmetric division : ' num2str(mean(symd),'%0.1f') ' microns'],['Asymmetric division : ' num2str(mean(asymd),'%0.1f') ' microns']);
                                                                                         set(hl,'FontSize', 12,'FontName','Times');
                                                                                        hbch1 = get(hbc{1}, 'FaceColor');
                                                                                        hbch2 = get(hbc{2}, 'FaceColor');
                                                                                        hc = findobj(hl, '-property', 'FaceColor');
                                                                                        set(hc(1), 'FaceColor', hbch2)
                                                                                        set(hc(2), 'FaceColor', hbch1)                                                                                   

                                       [h,p]= kstest2(symd,asymd);                                       
                                       
                                            xlim([5 STH+5])
                                            ylim([0 30])
%                                             legend([hbc{:}],'old','new');
%                                             legend([h{:}],'PKD1 Ct','PKD1 cKO');
                                            xlabel('Distance in XY','FontSize', 14,'FontName','Times') % x-axis label
                                            ylabel(['Probability'],'FontSize', 14,'FontName','Times') % y-axis label
%                                             title('Probability density function');
                                             title(['Sister cells XY distance distribution (p = ' num2str(p,'%0.3f') ')'] ,'FontSize', 16,'FontName','Times');
                                     
                                                 set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
legend('boxoff')
pbaspect([8,6,1])

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST6'],'-a2', '-m6','-p0.02','-png', '-r600');




figure
rc=MAT(:,19:20);
H=bar(rc,0.5);
% mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end
 hl = legend(H,['Symmetric division : ' num2str(mean(symd),'%0.1f') ' microns'],['Asymmetric division : ' num2str(mean(asymd),'%0.1f') ' microns']);
% hl = legend(H,['Symmetric division'],['Asymmetric division']);
set(hl,'FontSize', 12,'FontName','Times');

legend('boxoff')

ylabel(['Mean distance in XY'],'FontSize', 14,'FontName','times') % y-axis label
title(['Sister cells XY distance distribution'],'FontSize', 18,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
ylim([0 STH])
pbaspect([8,6,1])

 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST7'],'-a2', '-m6','-p0.02','-png', '-r600');





figure

 Dist=linspace(0,HTH,11);


                                            [n1,x11] = hist(symhd,Dist);
                                            [n2,x22] = hist(asymhd,Dist);


n11=100*n1/sum(n1);
n22=100*n2/sum(n2);                                                                               valuesmean=[n11' n22'];
                                                                                  
                                                                                  

                                                                                   index = Dist; 

                                                                                        hb = bar(index,valuesmean);
                                                                                        hbc = get(hb, 'Children');
                                                                                        set(hbc{1}, 'FaceColor', myC(1,:));
                                                                                        set(hbc{2}, 'FaceColor', myC(2,:));
 hl = legend(hb,['Symmetric division : ' num2str(mean(symhd),'%0.1f') ' degrees'],['Asymmetric division : ' num2str(mean(asymhd),'%0.1f') ' degrees']);
                                                                                         set(hl,'FontSize', 12,'FontName','Times');
                                                                                        hbch1 = get(hbc{1}, 'FaceColor');
                                                                                        hbch2 = get(hbc{2}, 'FaceColor');
                                                                                        hc = findobj(hl, '-property', 'FaceColor');
                                                                                        set(hc(1), 'FaceColor', hbch2)
                                                                                        set(hc(2), 'FaceColor', hbch1)
                                                                                    
    [h,p]= kstest2(symhd,asymhd);

                             
                                                                                                                   
                                            xlim([-.5 HTH+.5])
                                            ylim([0 30])
%                                             legend([hbc{:}],'old','new');
%                                             legend([h{:}],'PKD1 Ct','PKD1 cKO');
                                            xlabel('Distance in hue','FontSize', 14,'FontName','Times') % x-axis label
                                            ylabel(['Probability'],'FontSize', 14,'FontName','Times') % y-axis label
%                                             title('Probability density function');
                                             title(['Sister cells Hue variation distribution (p = ' num2str(p,'%0.3f') ')'],'FontSize', 16,'FontName','Times');
                                     

                                                 set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
 legend('boxoff')
pbaspect([8,6,1])


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST9'],'-a2', '-m6','-p0.02','-png', '-r600');




figure
rc=MAT(:,22:23);
H=bar(rc,0.5);
% mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end
 hl = legend(H,['Symmetric division : ' num2str(mean(symhd),'%0.1f') ' degrees'],['Asymmetric division : ' num2str(mean(asymhd),'%0.1f') ' degrees']);
% hl = legend(H,['Symmetric division'],['Asymmetric division']);
set(hl,'FontSize', 12,'FontName','Times');
legend('boxoff')

ylabel(['Mean distance in hue'],'FontSize', 14,'FontName','times') % y-axis label
title(['Sister cells hue variation distribution'],'FontSize', 18,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
ylim([0 HTH])
pbaspect([8,6,1])

 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST10'],'-a2', '-m6','-p0.02','-png', '-r600');





figure

 Dist=linspace(0,25,11);


                                            [n1,x11] = hist(symzd,Dist);
                                            [n2,x22] = hist(asymzd,Dist);


n11=100*n1/sum(n1);
n22=100*n2/sum(n2);                                                                               valuesmean=[n11' n22'];
                                                                                  
                                                                                  

                                                                                   index = Dist; 

                                                                                        hb = bar(index,valuesmean);
                                                                                        hbc = get(hb, 'Children');
                                                                                        set(hbc{1}, 'FaceColor', myC(1,:));
                                                                                        set(hbc{2}, 'FaceColor', myC(2,:));
 hl = legend(hb,['Symmetric division : ' num2str(mean(symzd),'%0.1f') ' microns'],['Asymmetric division : ' num2str(mean(asymzd),'%0.1f') ' microns']);
                                                                                         set(hl,'FontSize', 12,'FontName','Times');
                                                                                        hbch1 = get(hbc{1}, 'FaceColor');
                                                                                        hbch2 = get(hbc{2}, 'FaceColor');
                                                                                        hc = findobj(hl, '-property', 'FaceColor');
                                                                                        set(hc(1), 'FaceColor', hbch2)
                                                                                        set(hc(2), 'FaceColor', hbch1)
                                                                                    
 [h,p]= kstest2(symzd,asymzd);

                                     
                                                                                                                   
                                            xlim([-1.25 25+.5])
                                            ylim([0 60])
%                                             legend([hbc{:}],'old','new');
%                                             legend([h{:}],'PKD1 Ct','PKD1 cKO');
                                            xlabel('Distance in Z','FontSize', 14,'FontName','Times') % x-axis label
                                            ylabel(['Probability'],'FontSize', 14,'FontName','Times') % y-axis label
%                                             title('Probability density function');
                                             title(['Sister cells Z distance distribution (p = ' num2str(p,'%0.3f') ')'],'FontSize', 16,'FontName','Times');
                                     

                                                 set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off
 legend('boxoff')
pbaspect([8,6,1])


                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST11'],'-a2', '-m6','-p0.02','-png', '-r600');




figure
rc=MAT(:,24:25);
H=bar(rc,0.5);
% mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end
 hl = legend(H,['Symmetric division : ' num2str(mean(symzd),'%0.1f') ' microns'],['Asymmetric division : ' num2str(mean(asymzd),'%0.1f') ' microns']);
% hl = legend(H,['Symmetric division'],['Asymmetric division']);
set(hl,'FontSize', 12,'FontName','Times');
legend('boxoff')

ylabel(['Mean distance in Z'],'FontSize', 14,'FontName','times') % y-axis label
title(['Sister cells Z distance distribution'],'FontSize', 18,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
ylim([0 15])
pbaspect([8,6,1])

 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST12'],'-a2', '-m6','-p0.02','-png', '-r600');





figure
rc=MAT(:,6:8);
H=bar(rc,0.5);
% mn=sum(rc(:,1))/sum(rc(:));

for k=1:3
  set(H(k),'facecolor',myC(k,:))
end
 hl = legend(H,'Symmetric division','Asymmetric division','Other division');
% hl = legend(H,['Symmetric division'],['Asymmetric division']);
set(hl,'FontSize', 12,'FontName','Times');
legend('boxoff')

ylabel(['Division count'],'FontSize', 14,'FontName','times') % y-axis label
title(['Division type counts'],'FontSize', 18,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 5.5])
% ylim([0 15])
pbaspect([8,6,1])

 set(gca,'XTick',1:5,...                         %# Change the axes tick marks
        'XTickLabel',{'M5','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIV_TYPE_COUNT'],'-a2', '-m6','-p0.02','-png', '-r600');



  resfile3 = ['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'method1.xlsx'];
  
  MAT(:,16)=MAT(:,11)./MAT(:,15);
  MAT(:,18)=MAT(:,11)./MAT(:,17);
  
if exist(resfile3, 'file')==2
delete(resfile3);
end
clear cell
MATN=MAT(:,1:25);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'F+', 'F-', 'Selected F+', 'Selected F-', 'Total div', 'Sym div', 'Asym div','Other div','B+ F+ Singles',...
    'B+ F+ Singles border','B+ F+ Single center','B+ F- Singles','B+ F- Singles border','B+ F- Single center',...
    'F+ center', 'B+ F+ singles ratio','B+ F+','B+ F+ ratio','Mean symmetric distance','mean asymmetric distance','Mosiac ID','Mean symmetric Hue dist','mean asymmetric Hue dist','Mean symmetric Z dist','mean asymmetric Z dist'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')