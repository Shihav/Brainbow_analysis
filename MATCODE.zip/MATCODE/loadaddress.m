if idx==1
Datahome='F:\ENS_CILTEX\Marie_Brainbow2\Selection Shihav\Marie_brainbow8\Tiff';
Reshome='F:\ENS_CILTEX\Marie_Brainbow2\Selection Shihav\Marie_brainbow8\Imagej2';
Reshome2='F:\ENS_CILTEX\TEST_BRAINBOW\P';
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\P2';
Reshome4='F:\ENS_CILTEX\TEST_BRAINBOW\Mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\P3';

elseif idx==2
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20160704_Daclin_manip12_137_5\E14P10_Nucbow_137_5_40x_tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20160704_Daclin_manip12_137_5\E14P10_Nucbow_137_5_40x_seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20160704_Daclin_manip12_137_5\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20160704_Daclin_manip12_137_5\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20160704_Daclin_manip12_137_5\Mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\20160704_Daclin_manip12_137_5\P3';
elseif idx==3
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\E14P16_Nucbow_140_3_40x_tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\E14P16_Nucbow_140_3_40x_seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\Mosaic'; 
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\P3'; 

elseif idx==4
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\4\E14P16_Nucbow_140_4_40x_tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\4\E14P16_Nucbow_140_4_40x_seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\4\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\4\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\4\Mosaic'; 
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\4\P3'; 

elseif idx==5
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20160626_Daclin_manip12_3\serie_0002_tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20160626_Daclin_manip12_3\serie_0002_seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20160626_Daclin_manip12_3\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20160626_Daclin_manip12_3\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20160626_Daclin_manip12_3\Mosaic'; 
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\20160626_Daclin_manip12_3\P3';
elseif idx==6
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20160928_E14P61_Daclin_Nucbow_manip16_150_1\Tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20160928_E14P61_Daclin_Nucbow_manip16_150_1\Seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20160928_E14P61_Daclin_Nucbow_manip16_150_1\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20160928_E14P61_Daclin_Nucbow_manip16_150_1\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20160928_E14P61_Daclin_Nucbow_manip16_150_1\Mosaic'; 

elseif idx==7
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_1\Tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_1\Seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_1\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_1\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_1\Mosaic'; 
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_1\P3'; 
elseif idx==8
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_4\Tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_4\Seg';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_4\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_4\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_4\Mosaic'; 
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\20161110_E14P15_Daclin_Nucbow_manip17_\163_4\P3'; 

elseif idx==9
    
Datahome='F:\ENS_CILTEX\Brainbow report\Tiff';
Reshome='F:\ENS_CILTEX\Brainbow report\ImageJ';
Reshome2='F:\ENS_CILTEX\Brainbow report\P'; 
Reshome3='F:\ENS_CILTEX\Brainbow report\P2'; 
Reshome4='F:\ENS_CILTEX\Brainbow report\Mosaic';
Reshome5='F:\ENS_CILTEX\Brainbow report\P3';

elseif idx==10
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\REPORT';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\REPORT';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\REPORT'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\REPORT'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\REPORT';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\REPORT';

elseif idx==11
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_tilescanavant\cerveau2_tilescanavant_tiff';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_tilescanavant\cerveau2_tilescanavant_tiff';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_tilescanavant\cerveau2_tilescanavant_P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_tilescanavant\cerveau2_tilescanavant_P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_tilescanavant\cerveau2_tilescanavant_mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_tilescanavant\cerveau2_tilescanavant_P3';

elseif idx==12
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_rostral_position5\cerveau2_rostral_position5_TIFFR';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_rostral_position5\cerveau2_rostral_position5_SEG';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_rostral_position5\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_rostral_position5\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_rostral_position5\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau2_rostral_position5\P3';

elseif idx==13
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau1_EIUfaible_positioncaudale\TIFF';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau1_EIUfaible_positioncaudale\TIFF';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau1_EIUfaible_positioncaudale\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau1_EIUfaible_positioncaudale\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau1_EIUfaible_positioncaudale\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\cerveau1_EIUfaible_positioncaudale\P3';

elseif idx==14
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\muravant_positiondorsale\TIFF';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\muravant_positiondorsale\TIFF';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\muravant_positiondorsale\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\muravant_positiondorsale\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\muravant_positiondorsale\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\muravant_positiondorsale\P3';

elseif idx==15
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUcaudaldorsal\TIFF';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUcaudaldorsal\TIFF';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUcaudaldorsal\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUcaudaldorsal\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUcaudaldorsal\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUcaudaldorsal\P3';

elseif idx==16
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUdorsal\TIFF';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUdorsal\TIFF';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUdorsal\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUdorsal\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUdorsal\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\murdorsal_cerveau3EIUdorsal\P3';

elseif idx==17
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170619 eiu e13 analyse P16 tile\TIFFR';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170619 eiu e13 analyse P16 tile\SEG2';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170619 eiu e13 analyse P16 tile\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170619 eiu e13 analyse P16 tile\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170619 eiu e13 analyse P16 tile\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170619 eiu e13 analyse P16 tile\P3';

elseif idx==18
    
Datahome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170704 eiu e13 manip juin 2017\TIFFR';
Reshome='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170704 eiu e13 manip juin 2017\SEG';
Reshome2='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170704 eiu e13 manip juin 2017\P'; 
Reshome3='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170704 eiu e13 manip juin 2017\P2'; 
Reshome4='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170704 eiu e13 manip juin 2017\mosaic';
Reshome5='F:\ENS_CILTEX\Marie_2016_NEW\brainbowE13\170704 eiu e13 manip juin 2017\P3';

end

% end

FINR='F:\ENS_CILTEX\Marie_2016_NEW\Combined3';
FINB='F:\ENS_CILTEX\Marie_2016_NEW\Combined2';