Ternary plotting for Matlab
===========================

This is the GitHub repository for the [Ternplot package](http://www.mathworks.com/matlabcentral/fileexchange/2299-ternplot)
on File Exchange.

This code helps you to plot ternary phase data on a ternary phase diagram.

It acts like plot (responds to hold, etc), also includes `ternlabel.m`
to label all three axes. There are also functions to plot three
dimensional plots and contours.