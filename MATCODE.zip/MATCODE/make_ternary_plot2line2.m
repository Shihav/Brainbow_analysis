function make_ternary_plot2line2(DATA,xyvals,LW,NL) 

xyvals=xyvals(ismember(xyvals(:,24),DATA(:,2)) & ismember(xyvals(:,25),DATA(:,2)),:);

DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;

% NL=prctile(DATAT,5,1);
DATAT=[DATAT;xyvals(:,5:7);xyvals(:,10:12)];
DATAT(:,1) =255*imadjust(DATAT(:,1)/255,[NL(1) 255]/255,[0 255]/255);
DATAT(:,2) =255*imadjust(DATAT(:,2)/255,[NL(2) 255]/255,[0 255]/255);
DATAT(:,3) =255*imadjust(DATAT(:,3)/255,[NL(3) 255]/255,[0 255]/255);

DATA(:,6:8)=DATAT(1:size(DATA,1),:);
      xyvals(:,5:7) =DATAT(size(DATA,1)+1:size(DATA,1)+size(xyvals,1),:);
         xyvals(:,10:12) =DATAT(size(DATA,1)+size(xyvals,1)+1:size(DATA,1)+2*size(xyvals,1),:);

figure()

    valn=DATA(:,6);
     valr=DATA(:,7);
     vals=DATA(:,8);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',3,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
       
%          [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
%         text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel2('Blue - Red', 'Green - Red', 'Blue - Green')  


     for zin=1:size(xyvals,1) 
         
%          if xyvals(zin,14)==1 && xyvals(zin,15)==1
%              CC=0.5*[1 1 1];
%          elseif xyvals(zin,14)==1 && xyvals(zin,15)==2
%              CC=0.5*[1 1 0];
%          elseif xyvals(zin,14)==2 && xyvals(zin,15)==1
%              CC=0.5*[1 1 0]; 
%          elseif xyvals(zin,14)==2 && xyvals(zin,15)==2
%              CC=0.5*[0.5 1 .5];
%          end
         
        CC=[0 0 0];
         
            valn=xyvals(zin,5);
     valr=xyvals(zin,6);
     vals=xyvals(zin,7);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
         
         
         
                  [x1 y1]=terncoords(NMI,RMSE,SNR);
%         text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');
         
             valn=xyvals(zin,10);
     valr=xyvals(zin,11);
     vals=xyvals(zin,12);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
         
         
         
                  [x2 y2]=terncoords(NMI,RMSE,SNR);

%          
%          DATACM1=rgb2hsv(xyvals(zin,5:7));
%          DATACM2=rgb2hsv(xyvals(zin,10:12));
% 
% HUE1=DATACM1(:,1)*360;
% HUE2=DATACM2(:,1)*360;
% 
% x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
% x2=DATACM2(:,3)*cos(2*pi*DATACM2(:,1));
% 
% y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
% y2=DATACM2(:,3)*sin(2*pi*DATACM2(:,1));
         
   U=x2-x1;
   V=y2-y1;
   Z=sqrt(U.^2+V.^2);   
%   quiver(x1,y1,U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',1*LW) ; hold on
%          end
   
     end
     
         valn=DATA(:,6);
     valr=DATA(:,7);
     vals=DATA(:,8);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,6:8)./255,'LineWidth',1.5,'MarkerSize',3,'MarkerFaceColor',DATA(n,6:8)./255);hold on; 
       
%          [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
%         text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
 
set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure     