function [ADATAS_T_MA,xyvals_T_MA,ADATAS_T_MAR]=crop_cell_link_dyn(ADATAS_T,xyvals_T,mn,AG,LINKA,mod,SNA)
 
% ADATAS_T=ADATAS_M;
% xyvals_T=xyvals_M;
% mod=1;
% SNA=[5:8];

ADATAS_T_MA=[];
xyvals_T_MA=[];

if mod ==1
ADATAS_T(:,2)=10000*(ADATAS_T(:,1)-1)+ADATAS_T(:,2);
end

for sn=SNA
valA=[];
for kin=1:size(LINKA,1)    
    val=LINKA{kin,1};    
    if size(val,1)==sn       
        valA=[valA;val];        
    end    
end
valAT=valA;

DG=diag(diag(ones(sn))+0);
TAG=zeros(size(ADATAS_T,1),1);

for kin=1:sn:size(valAT,1)
 ar=valAT(kin:kin+sn-1); 
 TAG(ismember(ADATAS_T(:,2),ar))=kin;
end

ADATAS_T_M=[];
pcells=unique(TAG);
pcells(pcells==0)=[];
for kin=1:length(pcells)
    
    TEM=ADATAS_T(TAG==pcells(kin),:);
    select=TEM(:,4)>mn(1) & TEM(:,4)<(size(AG,1)-mn(2)) & TEM(:,5)>mn(3) & TEM(:,5)<(size(AG,2)-mn(4));
    if sum(select)==size(TEM,1)
    ADATAS_T_M=[ADATAS_T_M;TEM];
    end
end

if size(ADATAS_T_M,1)>0
xyvals_T_M=xyvals_T(ismember(xyvals_T(:,24),ADATAS_T_M(:,2)),:);

ADATAS_T_MA=[ADATAS_T_MA;ADATAS_T_M];
xyvals_T_MA=[xyvals_T_MA;xyvals_T_M];
end
end

ADATAS_T_MAR=ADATAS_T;
% select=ADATAS_T_MAR(:,4)>mn(1) & ADATAS_T_MAR(:,4)<(size(AG,1)-mn(2)) & ADATAS_T_MAR(:,5)>mn(3) & ADATAS_T_MAR(:,5)<(size(AG,2)-mn(4));
% ADATAS_T_MAR=ADATAS_T_MAR(select,:);
% ADATAS_T_MAR(ismember(ADATAS_T_MAR(:,2),ADATAS_T_MA(:,2)),:)=[];
