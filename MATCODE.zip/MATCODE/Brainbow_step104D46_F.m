clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

pool=[1 2 3 0 4 0 5 6 0 0 7 8 9 10 11 12 13 14];

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36 .36 .36 .36 .36 .36 .36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);
mkfig=1;
countAS=[];
xyvals=[];
ADATAS=[];
load multa.mat multa
sisters=100;
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14)]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\HUE' ]);
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF' ]);
% m=1;
m{3}=[3139 785 2245 854];
m{10}=[1 0 1 0];
multa(10,:)=multa(3,:);
count=[];
for idx=[12]
    
    mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(14) '\REPORTF\' 'M' num2str(pool(idx))]);
      mn=[1 0 1 0];  
     if idx==7
     LW=0.2;
     elseif idx==11
     LW=0.2;
     elseif idx==10
     LW=2;
     elseif idx==12
     LW=0.8;
     else
     LW=0.4;
     end
     
        if idx==10
     LW2=.5*LW;
        else
     LW2=2*LW;
        end
     
     
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB','valAT','valAQ','LINKA'); 


if idx==10
    nk=m{3};
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(3) 'ang' num2str(14)  'CG' '.png']); 
AG=LCOLORG;
LCOLORG=LCOLORG(nk(1):size(AG,1)-nk(2),nk(3):size(AG,2)-nk(4),:);
elseif idx>10
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
else
LCOLORG=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
end
AG=LCOLORG;
LCOLORG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

% count(1,1)=size(PDATABB,1);
% count(1,2)=size(NDATABB,1);
select=PDATABB(:,4)>mn(1) & PDATABB(:,4)<(size(AG,1)-mn(2)) & PDATABB(:,5)>mn(3) & PDATABB(:,5)<(size(AG,2)-mn(4));
PDATABB=PDATABB(select,:);

select=NDATABB(:,4)>mn(1) & NDATABB(:,4)<(size(AG,1)-mn(2)) & NDATABB(:,5)>mn(3) & NDATABB(:,5)<(size(AG,2)-mn(4));
NDATABB=NDATABB(select,:);

count(1,1)=size(PDATABB,1);
count(1,2)=size(NDATABB,1);


AG=imread([Reshome3 filesep 'mosaicG.png']);
LCOLORC=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW\' 'M' num2str(pool(idx)) '_A0_ALL_AC.png']);

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);
 
 LCOLORCA=multp(1)*LCOLORCA;
 LCOLORCB=multp(2)*LCOLORCB;
 LCOLORCC=multp(3)*LCOLORCC;
 
 CL=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);

LCOLORG=CL+0.5*AG;    


imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW2\' 'M' num2str(pool(idx)) '_A1_ALL_AN.png']);

LCOLORG=CL+0.0*AG;    


imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\RAW3\' 'M' num2str(pool(idx)) '_A1_ALL_ACN.png']);
imwrite(LCOLORG,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'M' num2str(pool(idx)) '\' 'M' num2str(pool(idx)) '_A0_ALL_ACN.png']);


idx
close all
end

