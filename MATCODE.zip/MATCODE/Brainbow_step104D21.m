clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

ftype=7;

DRF=0;
DRS=0;
DR=1;
DH=0;
GL=0.2;

cr=0;

MAT=[];

for sisters=2
LM=1;

nidx=1;
rc=[];
rcp=[];
nc=[];

HTH=10;
STH=100;
BTH=100;
SATH=0.33;
CPL=1;

ts=0;
tm=0;

OLDIST=7;

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);

final_remove_list;

for idx=[1 2 3 5 7 8]
    
    xyvalAR=[];
    ADATAAR=[];
    xyvalsAR=[];
    ADATASAR=[];
    
for darkest_cells_cutid=1:length(darkest_cells_cutupA) 
    
    darkest_cells_cutup=darkest_cells_cutupA(darkest_cells_cutid);
    darkest_cells_cutdown=darkest_cells_cutdownA(darkest_cells_cutid);
    
          
loadaddress;
  
load([Reshome2 filesep 'Pall.mat'],'PDATA'); 
PDATA(Prlist{idx},:)=[];
PDATAB=PDATA;

% rid=randperm(size(PDATA,1));
% PDATA=[PDATA(rid,1:5) PDATA(:,6:11)];

load([Reshome2 filesep 'Nall.mat'],'NDATA');
NDATA(Nrlist{idx},:)=[];


% rid=randperm(size(NDATA,1));
% NDATA=[NDATA(rid,1:5) NDATA(:,6:11)];

nc(nidx)=size(PDATA,1);

dmap=pdist2(PDATA(:,4:5),NDATA(:,4:5));
dmapmin=min(dmap);

NDATA((dmapmin<OLDIST)',:)=[];
NDATAB=NDATA;

MAT(idx,1)=size(PDATAB,1);
MAT(idx,2)=size(NDATAB,1);


DATA=PDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multp=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

tests=[DATA(:,6:8)./DATA(:,9:11)];
testm=DATA(:,6:8);
select=max(tests,[],2)>ts & max(testm,[],2)>tm;
DATA=DATA(select==1,:);

PDATABB=DATA;

if ftype==5
filter_data5;
elseif ftype==6
filter_data6;
end
PSDATA=DATA;

DATA=NDATA;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
mult=255./rangek; 
multn=mult;
  
DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATA(:,6:8)=DATAT;

select=sum(DATA(:,6:8)>254,2)<3;    
DATA=DATA(select==1,:);

tests=[DATA(:,6:8)./DATA(:,9:11)];
testm=DATA(:,6:8);
select=max(tests,[],2)>ts & max(testm,[],2)>tm;
DATA=DATA(select==1,:);

NDATABB=DATA;

if ftype==5
filter_data5;
elseif ftype==6
filter_data6;
end
NSDATA=DATA;

NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
ADATAB=[PDATABB;NDATABB];

if ftype==7
filter_data7;
end

if DRF==1    
BMAKE_FILTERED_PLOT2;
end   

    tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=CPL;
     
     ADATA=ADATA(select,:);  
     
     NSDATA=ADATA(ADATA(:,1)==2,:);
     PSDATA=ADATA(ADATA(:,1)==1,:);
if cr==1     
     rid=randperm(size(PDATAB,1));
PSDATA=[PDATAB(rid(1:size(PSDATA,1)),1:5) PSDATA(:,6:end)];

    rid=randperm(size(NDATAB,1));
NSDATA=[NDATAB(rid(1:size(NSDATA,1)),1:5) NSDATA(:,6:end)];
NSDATA(:,1)=2;
ADATA=[PSDATA;NSDATA];
end
     
 
 
%    xyval(xyval(:,14)==2 & xyval(:,15)==2,:)=[];



% xyvalAR=[xyvalAR;xyval];
ADATAAR=[ADATAAR;ADATA];
% ADATASAR=[ADATASAR;ADATAS];
% xyvalsAR=[xyvalsAR;xyvals];


end

MAT(idx,3)=size(PSDATA,1);
MAT(idx,4)=size(NSDATA,1);

if DH==1
make_hue_plot2(ADATAB)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) ''],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2(ADATAAR)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) '_R'],'-a2', '-m6','-p0','-q101','-png', '-r600');
end


ADATA=ADATAAR;


   tDATA=ADATA;
    DATACM=rgb2hsv(ADATA(:,6:8));
    
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     HUEdistB=HUEdist<=(HTH*LM);
     BdistB=Bdist<=(BTH*LM);
     SPACEdistB=SPACEdist<=(STH*LM);
     SATdistB=SATdist<=(SATH*LM);

     PC=HUEdistB & BdistB & SPACEdistB & SATdistB;
     select=sum(PC,2)<=sisters & sum(PC,2)>=CPL;
     
     ADATA=ADATA(select,:);  



    tDATA=ADATA;
     tDATACM=rgb2hsv(ADATA(:,6:8));
     DATACM=rgb2hsv(ADATA(:,6:8));
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;
     SATdist=pdist2(DATACM(:,2),DATACM(:,2));

     
%% check conditions    
%    Costmat=SPACEdist/10+HUEdist;
div=HTH/STH;

% %   Costmat=SPACEdist;%HUEdist + SPACEdist*div;
   if sisters <4
   Costmat=1*HUEdist + SPACEdist*0;
   
   else
%     HUEdist(SPACEdist<(STH/2))=SPACEdist(SPACEdist<(STH/2));
    Costmat=0*HUEdist + SPACEdist*1;
   end
   Costmat1 = diag(diag(Costmat)+1);
   
   Costmat(Costmat1>0)=20000;
%    Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
%    Costmat(SPACEdist<=(STH/4) & Costmat<20000)=SPACEdist(SPACEdist<=(STH/4) & Costmat<20000)/STH;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;
                           xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];
                            xyval(cp,16:17)=[tDATA(Aida(cp,1),12) tDATA(Aida(cp,2),12)];
                 end  
   xyval(xyval(:,13)>=20000,:)=[];


imp=(xyval(:,14)==1 & xyval(:,15)==1) | (xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1);
xyvals=xyval(imp,:);
ADATAS=ADATA(unique(xyvals(:,8:9)),:);



% xyval=xyvalAR;


if DRS==1
    BMAKE_SELECTED_PLOT;
end

% xyval=xyvalAR;
% ADATA=ADATAAR;
% 
% xyvals=xyvalsAR;
% ADATAS=ADATASAR;

if DR==1
    BMAKE_FINAL_PLOT2;
end

SD=sum(xyval(:,14)==1 & xyval(:,15)==1);
AD=sum(xyval(:,14)==1 & xyval(:,15)==2) + sum(xyval(:,14)==2 & xyval(:,15)==1);
rc(nidx,:)=[SD AD];

SDP=xyval((xyval(:,14)==1 & xyval(:,15)==1),16:17);
ADP=xyval((xyval(:,14)==1 & xyval(:,15)==2) | (xyval(:,14)==2 & xyval(:,15)==1),16:17);
rcp(nidx,:)=[sum(SDP(:)) sum(ADP(:))];



MAT(idx,5)=size(xyval,1)/2;
MAT(idx,6)=SD/2;
MAT(idx,7)=AD/2;
MAT(idx,8)=sum(xyval(:,14)==2 & xyval(:,15)==2)/2;




nidx=nidx+1;

FDATACM=DATACM;
Fxyval=xyval;
FDATA=ADATA;

if load_angle==1
    BMAKE_ANGULAR_PLOT
end

close all
end

myC= [0.5 0.8 0.5;
    0.8 0.8 0.8];

figure
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Symmetric division rate = ' num2str(mn,'%0.2f') '%, total link = ' num2str(sum(rc(:))/2)],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST3'],'-a2', '-m6','-p0.02','-png', '-r600');


figure
H=bar(rcp./repmat(sum(rcp,2),[1 2]),0.5,'stacked');
mn=sum(rcp(:))/2;

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Power Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Ang. Link weight = ' num2str(mn/(sum(rc(:))/2),'%0.2f') ', total link = ' num2str(sum(rc(:))/2)],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST5'],'-a2', '-m6','-p0.02','-png', '-r600');

figure
rc(:,2)=rc(:,2)/2;
H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Origin from symmetric division = ' num2str(mn,'%0.2f') '%, total cell = ' num2str(sum(rc(:)))],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 6.5])
ylim([0 1.05])
pbaspect([8,6,1])

 set(gca,'XTick',1:6,...                         %# Change the axes tick marks
        'XTickLabel',{'M1','M2','M3','M4','M5','M6'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'CELL_DIST4'],'-a2', '-m6','-p0.02','-png', '-r600');


  resfile3 = ['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'method1.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=round(MAT(:,1:8));
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
A = {'F+', 'F-', 'Selected F+', 'Selected F-', 'Total div', 'Sym div', 'Asym div','Other div'};
C=[A;B];
xlswrite(resfile3,C,1,'A1')



end

