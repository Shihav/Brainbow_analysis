clear all
close all

clc

zres=[.52 .36 .36 0 .36 0 .47 .47];

slice=ceil(25./zres)+1

% slice(slice>0)=51

for idx=[1 2 3 5 7 8]

loadaddress;

% mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
%          mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
     
% load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB'); 


% if idx>7
% 
% load([Reshome2 filesep filename2 filesep filename2 'Imgsegk4.mat'],'Imgsegk4');  
% 
% Imgseg=Imgsegk4;
% 
% else
% 
% % save([Reshome2 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg','-v7.3');  
% load([Reshome2 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg'); 

% end


% zmap=imread([Reshome2 filesep filename2 filesep filename2 'ZMAP.png'])/256;
% 
%      ImgR(Imgseg>0)=0;
%      ImgG(Imgseg>0)=0;
%      ImgB(Imgseg>0)=0;   
     
%       [Img11r,zval11r,stackR]=FV1_make_projection_from_layer2(ImgR,zmap,25,slice(idx));
%       [Img11g,zval11g,stackG]=FV1_make_projection_from_layer2(ImgG,zmap,25,slice(idx));
%       [Img11b,zval11b,stackB]=FV1_make_projection_from_layer2(ImgB,zmap,25,slice(idx));
%       
%       save([Reshome2 filesep filename2 filesep filename2 'stackR.mat'],'stackR','-v7.3'); 
%       save([Reshome2 filesep filename2 filesep filename2 'stackG.mat'],'stackG','-v7.3');  
%       save([Reshome2 filesep filename2 filesep filename2 'stackB.mat'],'stackB','-v7.3');  
     
     
     
     
     
      load([Reshome2 filesep filename2 filesep filename2 'stackR.mat'],'stackR'); 
      load([Reshome2 filesep filename2 filesep filename2 'stackG.mat'],'stackG');  
      load([Reshome2 filesep filename2 filesep filename2 'stackB.mat'],'stackB');  
            
      [Img11r,zval11r]=max(stackR(:,:,26:76),[],3);
      [Img11g,zval11g]=max(stackG(:,:,26:76),[],3);
      [Img11b,zval11b]=max(stackB(:,:,26:76),[],3); 
%      
%       Img11r=FV1_make_projection_from_layer(ImgR,zmap,25,50);
%       Img11g=FV1_make_projection_from_layer(ImgG,zmap,25,50);
%       Img11b=FV1_make_projection_from_layer(ImgB,zmap,25,50);
%       
      CO=uint16(cat(3,Img11r,Img11g,Img11b));
      C=CO;
      imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NegC3.png']); 

imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NOverlayM1.png']); 

idx
imgid


close all
% clc
end

end