clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=75;
Bdiff_allowed=80;
Hdiff_allowed=13;
Sdiff_allowed=70;

Hdiff_max=20;
Sdiff_max=140;

% Hdiff_allowed1=15;
% Sdiff_allowed1=75;
% Sdiff_allowed2=100;
load_angle=1;

D_th=2;
T_th=sqrt(2);

wd=15;

SVTH=100;

SU=0;


for idx=[1]
         
  loadaddress;
  
  
% load([Reshome2 filesep 'Pall.mat'],'PDATA'); 
% save([Reshome2 filesep 'PallF.mat'],'PDATA'); 
% 
% load([Reshome2 filesep 'Nall.mat'],'NDATA'); 
% save([Reshome2 filesep 'NallF.mat'],'NDATA'); 
  

load([Reshome2 filesep 'Pall.mat'],'PDATA'); 

DATA=PDATA;
% 
% tDATA=DATA;
% DATA=tDATA;
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

% HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<3;
    
DATA=DATA(select==1,:);
% DATACM=DATACM(select==1,:);

  
%  DATA=tDATA;
 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;
 
 make_hue_plot(DATA,DATACM)
 
 find_SV

raw1=HUE>=(360-wd) | HUE<=(0+wd);
raw2=HUE>=(120-wd) & HUE<=(120+wd);
raw3=HUE>=(240-wd) & HUE<=(240+wd);
raw4=DATACM(:,3)<SV;

select=raw1 | raw2 | raw3 | raw4;

DATA(select==1,:)=[];
DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;

make_hue_plot(DATAk,DATACMk)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'FangHUE'],'-a2', '-m6','-p0','-q101','-png', '-r600');


 LCOLORC=imread([Reshome3 filesep 'PmosaicO.png']);
 LCOLORL=imread([Reshome3 filesep 'PFinalmapM.png']);
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
  
  imwrite(uint16(CLC),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(13) '.png']);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);
                           LCOLORL=labeledImage;
 for cell=1:size(tDATA,1)
     
     val=LCOLORL(tDATA(cell,4),tDATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000   
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
% CO=LCOLORG;
COF=CL;
m=1;
    
%      figure
%   imshow(COF);hold on
  
  imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(8) '.png']);
  
  
  
  loadaddress;

load([Reshome2 filesep 'Nall.mat'],'NDATA'); 

DATA=NDATA;




% rangek=[min(DATA(:,6),[],1) min(DATA(:,7),[],1) min(DATA(:,8),[],1)];

% DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

% HUE=DATACM(:,1)*360;

     select=sum(DATA(:,6:8)>254,2)<3;
    
DATA=DATA(select==1,:);
% DATACM=DATACM(select==1,:);

  
%  DATA=tDATA;
 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;
 
 make_hue_plot(DATA,DATACM)
 
 find_SV


% 
% tDATA=NDATA;
% DATA=tDATA;
% cut=0.99;
% rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
%  mult=255./rangek; 
%   
%  DATA=tDATA;
%  DATACM=rgb2hsv(tDATA(:,6:8));
%  HUE=DATACM(:,1)*360;

raw1=HUE>=(360-wd) | HUE<=(0+wd);
raw2=HUE>=(120-wd) & HUE<=(120+wd);
raw3=HUE>=(240-wd) & HUE<=(240+wd);
raw4=DATACM(:,3)<SV;

select=raw1 | raw2 | raw3 | raw4;

DATA(select==1,:)=[];
DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;

make_hue_plot(DATAk,DATACMk)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'NangHUE'],'-a2', '-m6','-p0','-q101','-png', '-r600');


 LCOLORC=imread([Reshome3 filesep 'NmosaicO.png']);
 LCOLORL=imread([Reshome3 filesep 'NFinalmapM.png']);
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
  
    imwrite(uint16(CLC),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(14) '.png']);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 8);
                           LCOLORL=labeledImage;

 for cell=1:size(tDATA,1)
     
     val=LCOLORL(tDATA(cell,4),tDATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000   
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
% CO=LCOLORG;
COF=CL;
m=1;
    
%      figure
%   imshow(COF);hold on
  
  imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(7) '.png']);
  
  
  
  
  COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(8) '.png']);
    COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(7) '.png']);
    
      imwrite(COF1+COF2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(9) '.png']);
      
      
    loadaddress;

load([Reshome2 filesep 'Pall.mat'],'PDATA'); 

DATA=PDATA;
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

% HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<3;
    
DATA=DATA(select==1,:);
% DATACM=DATACM(select==1,:);

  
%  DATA=tDATA;
 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;
 
%  make_hue_plot(DATA,DATACM)
 
 find_SV

raw1=HUE>=(360-wd) | HUE<=(0+wd);
raw2=HUE>=(120-wd) & HUE<=(120+wd);
raw3=HUE>=(240-wd) & HUE<=(240+wd);
raw4=DATACM(:,3)<SV;

select=raw1 | raw2 | raw3 | raw4;

DATA(select==1,:)=[];
DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;

  figure
  imshow(COF1+COF2);hold on
   
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
         
     
load([Reshome2 filesep 'Nall.mat'],'NDATA'); 

DATA=NDATA;
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

    select=sum(DATA(:,6:8)>254,2)<3;
    
DATA=DATA(select==1,:);

 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;

 find_SV

raw1=HUE>=(360-wd) | HUE<=(0+wd);
raw2=HUE>=(120-wd) & HUE<=(120+wd);
raw3=HUE>=(240-wd) & HUE<=(240+wd);
raw4=DATACM(:,3)<SV;

select=raw1 | raw2 | raw3 | raw4;

DATA(select==1,:)=[];
DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;

%   figure
%   imshow(COF1+COF2);hold on
   
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end     
     
     
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(11)],'-a2', '-m6','-p0','-q101','-png', '-r600');
%close all

LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  figure
  imshow(COF1+COF2+0.2*LCOLORG);hold on
  
  
  load([Reshome2 filesep 'Pall.mat'],'PDATA'); 

DATA=PDATA;
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

% HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<3;
    
DATA=DATA(select==1,:);
% DATACM=DATACM(select==1,:);

  
%  DATA=tDATA;
 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;
 
%  make_hue_plot(DATA,DATACM)
 
 find_SV

raw1=HUE>=(360-wd) | HUE<=(0+wd);
raw2=HUE>=(120-wd) & HUE<=(120+wd);
raw3=HUE>=(240-wd) & HUE<=(240+wd);
raw4=DATACM(:,3)<SV;

select=raw1 | raw2 | raw3 | raw4;

DATA(select==1,:)=[];
DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;

      
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
         
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(10)],'-a2', '-m6','-p0','-q101','-png', '-r600');



PLCOLORC=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(13) '.png']);
NLCOLORC=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(14) '.png']);

  imwrite(uint16(PLCOLORC+NLCOLORC),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(15) '.png']);
  
  
ALCOLORC=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(15) '.png']);


load([Reshome2 filesep 'Pall.mat'],'PDATA'); 

DATA=PDATA;
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

% HUE=DATACM(:,1)*360;

%     select=sum(DATA(:,6:8)>254,2)<3;
%     
% DATA=DATA(select==1,:);
% DATACM=DATACM(select==1,:);

  
%  DATA=tDATA;
 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;
 
%  make_hue_plot(DATA,DATACM)
 
 find_SV

raw1=HUE>=(360-wd) | HUE<=(0+wd);
raw2=HUE>=(120-wd) & HUE<=(120+wd);
raw3=HUE>=(240-wd) & HUE<=(240+wd);
raw4=DATACM(:,3)<SV;

select=raw1 | raw2 | raw3 | raw4;

DATA(select==1,:)=[];
DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;

  figure
  imshow(ALCOLORC);hold on
   
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
         
     
load([Reshome2 filesep 'Nall.mat'],'NDATA'); 

DATA=NDATA;
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek; 
 
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

    select=sum(DATA(:,6:8)>254,2)<3;
    
DATA=DATA(select==1,:);

 DATACM=rgb2hsv(DATA(:,6:8));
 HUE=DATACM(:,1)*360;

%  find_SV
% 
% raw1=HUE>=(360-wd) | HUE<=(0+wd);
% raw2=HUE>=(120-wd) & HUE<=(120+wd);
% raw3=HUE>=(240-wd) & HUE<=(240+wd);
% raw4=DATACM(:,3)<SV;
% 
% select=raw1 | raw2 | raw3 | raw4;
% 
% DATA(select==1,:)=[];
% DATACM(select==1,:)=[];

DATAk=DATA;
DATACMk=DATACM;
tDATA=DATA;
  
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));  
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end     
     
     
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(12)],'-a2', '-m6','-p0','-q101','-png', '-r600');
%close all  
  
%    imwrite(PLCOLORC,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(13) '.png']);
%     imwrite(NLCOLORC,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(14) '.png']);

close all
end


