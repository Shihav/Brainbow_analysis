clear all
close all
% 
clc

for cutp=[50]

for idx=[1:5]

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;



    select=DATACM(:,3)>quantile(DATACM(:,3),cutp/100);
%     select=DATACM(:,3)>75;
    
    DATAori=DATA;
    DATACMori=DATACM;
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

DATAk=DATA;
DATACMk=DATACM;

ncoupA=[];
ncA=[];
HTHid=0;

for HTH=[5]
    HTHid=HTHid+1;
    STHid=0;
for STH=[75]    
    STHid=STHid+1;
    ncoup=[];
    nc=[];
for loopin=1:101

    
DATA=DATAk;
DATACM=DATACMk;
    
    
if loopin>1

rdid=randperm(size(DATA,1));

DATA=[DATA(:,1:5) DATA(rdid,6:11)];
DATACM=DATACM(rdid,:);

% rdid=randperm(size(DATAori,1));
% rdid2=randperm(size(DATA,1));
% 
% DATA=[DATAori(rdid(1:size(DATA,1)),1:5) DATA(rdid2,6:11)];
% DATACM=DATACM(rdid2,:);


end

    tDATA=DATA;
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     
     SPACEdist=pdist2(DATA(:,4:5),DATA(:,4:5))*.31;

     
%% check conditions    
   Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  
   
   
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end  
                 

%                   [rowsol,cost,v,u,costMat] = lapjv(Costmat); 
%                  xyval=[];
%                  Aida=[];
%                  cp=1;
%                  for cp1=1:size(rowsol,2)
%                      
%                      if cp1==rowsol(rowsol(cp1))
%                  Aida(cp,1)=cp1;
%                  Aida(cp,2)=rowsol(cp1);
% 
%                      xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
%                         xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
%                          xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
%                          xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
%                            xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
%                            xyval(cp,13)=Costmat(cp1,rowsol(cp1));
%                            cp=cp+1;
%                      end
% 
%                  end 

    
%       SD=pdist2(tDATA(:,4:5),tDATA(:,4:5));   
%     DF=D<10000;
% 
% Connection=sum(DF,2);
% NB=[];    
% DFF=sum(DF,2);
%         for cp2=1:size(tDATA,1)
%             if DFF(cp2)>0;
%             PO=find(DF(cp2,:)==1);
%                  [list,POS]= min(SD(cp2,PO));
%                  NB(cp2,1:2)=[PO(POS) list];
%             end
%         end
% cp=1;
%     xyval=[];
%     
%     for cp1=1:size(tDATA,1)
%          if DFF(cp1)>0;
%            cp2=NB(cp1,1);    
%                   if cp1 == NB(cp2,1)
% %                       cp2=
%                      xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
%                         xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
%                          xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
%                          xyval(cp,8:9)=[cp1 cp2];
%                            xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
%                            xyval(cp,13)=Costmat(cp1,cp2);
%                            cp=cp+1;
%                   end
% %             end
%         end
%     end 



                 

   xyval(xyval(:,13)>=10000,:)=[];
   
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 nc(loopin)=size(xyval,1);
 
if loopin==1
 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
% LCOLORG(LCOLORL==0)=0; 
 
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);


 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
%                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');

                           labeledImage = bwlabel(I2cpsegb>0, 4);
% LCOLORL

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
     
     colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell;
     
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.25*CO;

     figure
  imshow(COF);hold on
 m=1
 
%  
%  
%  
%  
%  
%  
%  
%           m=2;       
%      Imk2=imresize(LCOLORC,m);
%  
%    CK=xyval(:,5:7)/32;
%    CK(CK>1)=1;
% 
%      figure
  
%   imshow(Imk2);hold on


    for zin=1:size(tDATA,1)       
         text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,num2str(zin),'FontSize',3,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(Connection(zin))],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
          num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
       text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
          num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
  

  
     for zin=1:size(xyval,1)   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.5) ; hold on
%          end

     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\Marie_2016_NEW\Combined' filesep 'Sister_assignment_idx' num2str(idx)],'-a2', '-m2','-p0','-q101','-png', '-r300');

      close all    
end 
end

 ncoupA=ncoup;
 ncA=ncoup;
 [h,p]=ttest2(ncoup(1),ncoup(2:101));
 p
 ratio=ncoup(1)
 
 random_ratio=mean(ncoup(2:101))
 
 
 
end
end

 save(['G:\Marie_2016_NEW\Combined\' 'ncoupA2_' num2str(idx) '.mat'],'ncoupA','ncA');  

end


end