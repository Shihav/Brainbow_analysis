  clear all 
  close all
  clc

  res=128;
  
for idx=[5]

loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

mkdir([FINR filesep 'RESULT_M' num2str(idx)]);

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);

DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

  select=sum(DATAT>254,2)<1;

DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

HUE=DATACM(:,1)*360;

 figure

HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATA(mt,6:8)/255)
end

set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'Allcell' num2str(idx)],'-a2', '-m4','-p0.02','-q101','-png', '-r600');





data=[HUE DATACM(:,3)];
data2=[DATACM(:,3).*cosd(HUE) DATACM(:,3).*sind(HUE)];

  [bandwidth,density,X,Y]=kde2d(data2,res,[-255,-255],[255,255]);  
  
       hG = fspecial('gaussian',[15 15],5);
               
                      density = imfilter(density,hG,'symmetric'); 
                       density=flipud(density);
                       Y=flipud(Y);
                       
  
  density2=density./sum(density(:)); 
  density=density2;
  
[B,I] = sort(density2(:),'descend');
C=cumsum(B);
CC=C;
CC(I)=C;

COL=flipud(jet(res*res));
COL(I,:)=COL;

CC2=reshape(CC,[res res]);

mD=res/64;

figure
imagesc(density)
 caxis manual
             caxis([0.000002 0.002]);
set(gcf,'color','w');
set(gca,'XTick',mD*10:mD*10:mD*60,...                         %# Change the axes tick marks
        'XTickLabel',{'-255','-153','-51','51','153','255'},...  %#   and tick labels
        'YTick',mD*10:mD*10:mD*60,...
        'YTickLabel',{'255','153','51','-51','-153','-255'},...
        'TickLength',[0 0],'FontSize', 15,'FontName','Times');

export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'Color_densityP2' num2str(idx)],'-a2', '-m4','-p0','-q101','-png', '-r600');

% figure
% imagesc(round(10000*density)/10000)
%  caxis manual
%             caxis([0.000002 0.002]);
% set(gcf,'color','w');
% set(gca,'XTick',mD*10:mD*10:mD*60,...                         %# Change the axes tick marks
%         'XTickLabel',{'-255','-153','-51','51','153','255'},...  %#   and tick labels
%         'YTick',mD*10:mD*10:mD*60,...
%         'YTickLabel',{'255','153','51','-51','-153','-255'},...
%         'TickLength',[0 0],'FontSize', 15,'FontName','Times');
% 
% export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'Color_densityP3' num2str(idx)],'-a2', '-m4','-p0','-q101','-png', '-r600');

% flag=CC2>0.5;
nk=512/res;
data3=round((data2+256)/nk);

select2=[];
density=flipud(density);
% density=fliplr(density);
for n=1:size(data3,1)
    
    select2(n,1)=density(data3(n,2),data3(n,1));
    
end
select2=select2<quantile(select2,(1-(60/100)));

DATA=DATA(select2==1,:);
DATACM=DATACM(select2==1,:);

HUE=DATACM(:,1)*360;

 figure

HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',6)
set(h,'color',DATA(mt,6:8)/255)
end

set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

% export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'Removedcell' num2str(idx)],'-a2', '-m4','-p0.02','-q101','-png', '-r600');

      close all    


% CC2=round(5*CC2)/5;
CC4=1-CC2;
[rr cc] = meshgrid(1:res);
CK = sqrt((rr-(res/2+.5)).^2+(cc-(res/2+.5)).^2)<=res/2;

   figure

            imagesc(CC4);
              colormap(jet) 
            axis tight
            caxis manual
                        caxis([0 1]);
  
                C = colormap; 
                L = size(C,1);
                Gs = round(interp1(linspace(0,1,L),1:L,double(CC4)));
                     Gs(isnan(Gs))=1;
       
%                 H = reshape(C(Gs,:),[size(Gs) 3]); 
%                 imwrite(uint16(65535*H),[nametex num2str(md) 'mdprojC.png']);
%              close all   
%  
%                 C = colormap; 
%                 L = size(C,1);
%                  Gs = round(interp1(linspace(0,1,L),1:L,double(CC4)));
       
                H = reshape(C(Gs,:),[size(Gs) 3]); 
                
                for ch=1:3
                    
                Ht=H(:,:,ch);
                Ht(CK==0)=1;
                H(:,:,ch)=Ht;
                end
                imwrite(uint16(65535*imresize(H,10)),[FINR filesep 'RESULT_M' num2str(idx) filesep 'Color_density' num2str(idx) '.png']);
             close all   
 
% export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'SisterF3_assignment_idx' num2str(idx)],'-a2', '-m4','-p0','-q101','-png', '-r600');


figure
imagesc(1-CC2)


COL=colormap;
colorbar
 print([FINR filesep 'RESULT_M' num2str(idx) filesep 'Color_bar' num2str(idx)], '-dpdf', '-r300');

X=X(:);
Y=Y(:);
CC3=1-CC2(:);

figure
[TH,R]=cart2pol(X,Y);

TH(R>255)=[];
CC3(R>255)=[];
R(R>255)=[];

HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)


if res==128
ms=7;
else
 ms=14;
end

for mt=1:size(TH,1)
    
%     if R(mt)<255
    
h=polar(TH(mt),R(mt),'.');hold on
set(h,'markersize',ms,'color',COL(round((64-1)*CC3(mt))+1,:));
% set(h,'linewidth',1)
% if res==128
% set(h,'markersize',7)
% else
%     set(h,'markersize',14)
% end
% set(h,'color',COL(round((64-1)*CC3(mt))+1,:))
%     end
    mt;
end

% colorbar

set(gcf,'color','w');
grid off
box off
axis off
 axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

 export_fig([FINR filesep 'RESULT_M' num2str(idx) filesep 'Color_densityP' num2str(idx)],'-a2', '-m4','-p0','-q101','-png', '-r600');

close all;
  
end
