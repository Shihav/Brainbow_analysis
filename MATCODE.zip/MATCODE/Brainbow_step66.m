clear all
% close all
% 
clc

for idx=[1 3 4]

for cutp=[10 20 30 40 50 60 70 80 90]



loadaddress;

load([Reshome2 filesep 'all.mat'],'DATA'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;



    select=DATACM(:,3)>quantile(DATACM(:,3),cutp/100) & sum(DATAT>254,2)<2;
    
    DATAori=DATA;
    DATACMori=DATACM;
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

DATAk=DATA;
DATACMk=DATACM;

ncoupA=[];
HTHid=0;

for HTH=[2.5 5 7.5 10 12.5 15 17.5 20]
    HTHid=HTHid+1;
    STHid=0;
for STH=[25 50 75 100 125 150 175 200]   
    STHid=STHid+1;
    ncoup=[];
for loopin=1:101

    
DATA=DATAk;
DATACM=DATACMk;
    
    
if loopin>1

% rdid=randperm(size(DATA,1));
% 
% DATA=[DATA(:,1:5) DATA(rdid,6:11)];
% DATACM=DATACM(rdid,:);

rdid=randperm(size(DATAori,1));
rdid2=randperm(size(DATA,1));

DATA=[DATAori(rdid(1:size(DATA,1)),1:5) DATA(rdid2,6:11)];
DATACM=DATACM(rdid2,:);


end

    tDATA=DATA;
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     
     SPACEdist=pdist2(DATA(:,4:5),DATA(:,4:5))*.31;

     
%% check conditions    
   Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end  
                 
%                   [rowsol,cost,v,u,costMat] = lapjv(Costmat); 
%                  xyval=[];
%                  Aida=[];
%                  cp=1;
%                  for cp1=1:size(rowsol,2)
%                      
%                      if cp1==rowsol(rowsol(cp1))
%                  Aida(cp,1)=cp1;
%                  Aida(cp,2)=rowsol(cp1);
% 
%                      xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
%                         xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
%                          xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
%                          xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
%                            xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
%                            xyval(cp,13)=Costmat(cp1,rowsol(cp1));
%                            cp=cp+1;
%                      end
% 
%                  end  
                 

   xyval(xyval(:,13)>=10000,:)=[];
   
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 
if loopin==0
 LCOLORC=imread([Reshome3 filesep 'mosaicCMO.png']);
          m=2;       
     Imk2=imresize(LCOLORC,m);
 
   CK=xyval(:,5:7)/32;
   CK(CK>1)=1;

     figure
  
  imshow(Imk2);hold on
  
     for zin=1:size(xyval,1)   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.5) ; hold on
%          end

     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig([Reshome3 filesep 'Sister_assignment_STH' num2str(STH) '_HTH' num2str(HTH)],'-a2', '-m2','-p0','-q101','-png', '-r300');

      close all    
end 
end

 ncoupA{HTHid,STHid}=ncoup;
 [h,p]=ttest2(ncoup(1),ncoup(2:101));
 p
 
end
end

 save([Reshome3 filesep 'ncoupA_' num2str(cutp) '.mat'],'ncoupA');  

end


end