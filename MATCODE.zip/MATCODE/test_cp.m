clear all
close all
clc

for idx=[9]

loadaddress;

% mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

for imgid=1:3%:numel(Types)
  close all     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
 mkdir([[Reshome5 filesep filename2]]);
        inp=imread([Reshome2 filesep filename2 filesep filename2 'ALL_RC.png']); 
        
       mult=[1 1 3.2; 1 1 1.3; 1 1 1.5];
for ind=1:3
col_img2a=mult(imgid,ind)*inp(:,:,ind);
%                           col_img2a(LABELM==0)=0;
% col_img2a(LABELM==0)=0;
inp(:,:,ind)=col_img2a;
end 
        
        
        imwrite(inp,[Reshome5 filesep filename2 filesep filename2 'RB.png']);
        
        
           inp2=imread([Reshome2 filesep filename2 filesep filename2 'ALL_FC.png']); 
           
           mult=[1.4 1.8 4; 1 1 1.5; 1 1 3.1];
for ind=1:3
col_img2a=mult(imgid,ind)*inp2(:,:,ind);
%                           col_img2a(LABELM==0)=0;
% col_img2a(LABELM==0)=0;
inp2(:,:,ind)=col_img2a;
end
        
  imwrite(inp2,[Reshome5 filesep filename2 filesep filename2 'FC.png']);   
  
  
 imwrite(inp+inp2,[Reshome5 filesep filename2 filesep filename2 'ALLC.png']);   


LABELM=imread([Reshome3 filesep filename2 filesep filename2 'LABELMN.png']);

load([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR'); 
[Img11gr,zval11gr]=max(ImgGR,[],3);

GB=uint16(cat(3,Img11gr,Img11gr,Img11gr));

 imwrite(GB,[Reshome5 filesep filename2 filesep filename2 'FOXJ1.png']);   

imwrite(inp+inp2+0.5*GB,[Reshome5 filesep filename2 filesep filename2 'ALL.png']);   

load([Reshome2 filesep filename2 filesep filename2 'Imgsegb.mat'],'Imgseg');      
           
maxL=uint16(max(Imgseg,[],3));

LABELMP=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapM.png'])+100;

maxL(maxL==1)=0;
maxL=maxL+imdilate(LABELMP,ones(1));
classmap5=maxL;

% classmap4=classmap5;
% pcells=unique(classmap5);
% se = ones(5); 
% sek = ones(3); 
% for nid=2:length(pcells)
%        
%         label = pcells(nid); 
% object = classmap4 == label;
% ownA=sum(sum(object));
% 
% neighbours = imdilate(object, se) & ~object;
% neighbourLabels = unique(classmap4(neighbours));
% neighbourLabels(1)=[];
% Ath=885;
% 
% if ~isempty(neighbourLabels)
%     if ownA<Ath
%     areak=[];
%     for kin=1:length(neighbourLabels)    
%     areak(kin)=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));
%     end
%     [areak,kin]=min(areak);
%     
%     block=classmap4==neighbourLabels(kin) | classmap4==label;
%     [X,Y]=find(block==1);    
%     [CH,Ak]= convhull(X,Y);
% 
%             if ((Ak-areak)/Ak) <.025
% 
%                 ND=max([label neighbourLabels(kin)]);
%                 object2 = classmap4 == neighbourLabels(kin);
% 
%                 classmap5(object2)=ND;
%                 classmap5(object)=ND;
% 
%                 middle = imdilate(object2, sek) & imdilate(object, sek);
%                 classmap5(middle)=ND;
%                 
%             end
%     end
% end
% end

Img13=classmap5;
objectbor_map=(Img13-imerode(Img13,ones(3)))>0;
imwrite(objectbor_map,[Reshome5 filesep filename2 filesep filename2 'BORDER_F.png']);

objectbor_map=imread([Reshome5 filesep filename2 filesep filename2 'BORDER_FM.png']);

classmap5=bwlabel(1-objectbor_map);
classmap5=imdilate(classmap5,ones(3));
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));

LABELM=classmap5;
classmap=LABELM;
pcells=unique(classmap);

         for nk=2:length(pcells)            
            val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));
            if sizek<110    
                classmap(object2)=0;               
            end
         end

classmap5=classmap;
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));

classmapR=inp2(:,:,1);
classmapG=inp2(:,:,2);
classmapB=inp2(:,:,3);
sek = ones(5); 
  tol=0.05;
   CTH=13;
                           
classmap4=classmap5; 
pcells=unique(classmap4);
se = ones(5); 

for nid=2:length(pcells)
       
        label = pcells(nid); 
object = classmap4 == label;
ownA=sum(sum(object));

neighbours = imdilate(object, se) & ~object;
neighbourLabels = unique(classmap4(neighbours));
neighbourLabels(1)=[];

Ath=885;

if ~isempty(neighbourLabels)
    if ownA<Ath
    Hk=[];
    for kin=1:length(neighbourLabels)
        
        H1=rgb2hsv([mean(classmapR(classmap4==neighbourLabels(kin)))/256 mean(classmapG(classmap4==neighbourLabels(kin)))/256 mean(classmapB(classmap4==neighbourLabels(kin)))/256]);
        H1=360*H1(:,1);

        H2=rgb2hsv([mean(classmapR(classmap4==label))/256 mean(classmapG(classmap4==label))/256 mean(classmapB(classmap4==label))/256]);
        H2=360*H2(:,1);

        H=abs(H1-H2);
        H(H>180)=360-H(H>180);

    Hk(kin)=H;
    end
    [Hk2,kin]=min(Hk);
    
    areak=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));

    block=classmap4==neighbourLabels(kin) | classmap4==label;
    [X,Y]=find(block==1);
    
    [CH,Ak]= convhull(X,Y);

    H=Hk(kin);

            if ((Ak-areak)/Ak) <tol && H<CTH

                ND=max([label neighbourLabels(kin)]);
                
                object2 = classmap4 == neighbourLabels(kin);

                classmap5(object2)=ND;
                 classmap5(object)=ND;

                middle = imdilate(object2, sek) & imdilate(object, sek);
                classmap5(middle)=ND; 
                
            end
    end
end
nid;
end

figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));

classmap4=classmap5; 
pcells=unique(classmap4);
se = ones(5); 

for nid=2:length(pcells)
       
        label = pcells(nid); 
object = classmap4 == label;
ownA=sum(sum(object));

neighbours = imdilate(object, se) & ~object;
neighbourLabels = unique(classmap4(neighbours));
neighbourLabels(1)=[];

Ath=885;

if ~isempty(neighbourLabels)
    if ownA<Ath
    Hk=[];
    for kin=1:length(neighbourLabels)
        
        H1=rgb2hsv([mean(classmapR(classmap4==neighbourLabels(kin)))/256 mean(classmapG(classmap4==neighbourLabels(kin)))/256 mean(classmapB(classmap4==neighbourLabels(kin)))/256]);
        H1=360*H1(:,1);

        H2=rgb2hsv([mean(classmapR(classmap4==label))/256 mean(classmapG(classmap4==label))/256 mean(classmapB(classmap4==label))/256]);
        H2=360*H2(:,1);

        H=abs(H1-H2);
        H(H>180)=360-H(H>180);

    Hk(kin)=H;
    end
    [Hk2,kin]=min(Hk);
    
    areak=sum(sum(classmap4==neighbourLabels(kin) | classmap4==label));

    block=classmap4==neighbourLabels(kin) | classmap4==label;
    [X,Y]=find(block==1);
    
    [CH,Ak]= convhull(X,Y);

    H=Hk(kin);

            if ((Ak-areak)/Ak) <tol && H<CTH

                ND=max([label neighbourLabels(kin)]);
                
                object2 = classmap4 == neighbourLabels(kin);

                classmap5(object2)=ND;
                 classmap5(object)=ND;

                middle = imdilate(object2, sek) & imdilate(object, sek);
                classmap5(middle)=ND; 
                
            end
    end
end
nid;
end

figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));

LABELM=classmap5;
classmap=LABELM;
pcells=unique(classmap);

         for nk=2:length(pcells)            
            val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));
  
            if sizek<110
                classmap(object2)=0;              
            end
         end
                 
figure,imshow(label2rgb(classmap,'jet','k','shuffle'));
            
pcells=unique(classmap);

         for nk=2:length(pcells)  
              val=pcells(nk);  
            object2 = classmap==val;
            sizek=sum(sum(object2));      
                                         
                                             [X,Y]=find(object2==1);
    
                                          [CH,Ak]= convhull(X,Y);  
                                                                                    
                                          if (abs(double(Ak)-double(sizek))/double(sizek)) >0.25 
                                                classmap(object2)=0;

                                          end
                                          
            nk ;
         end
         
         figure,imshow(label2rgb(classmap,'jet','k','shuffle'));
         
 pcells=unique(classmap);

         for nk=2:length(pcells)  
              val=pcells(nk);  
            object2 = classmap==val;
            SR=double(classmapR(object2));
            SG=double(classmapR(object2));
            SB=double(classmapR(object2));
            IGG=max([mean(SR(:))/std(SR(:)) mean(SG(:))/std(SG(:)) mean(SB(:))/std(SB(:))]);
             IGG2=max([mean(SR(:)) mean(SG(:)) mean(SB(:))]);
            if isnan(IGG)
                IGG=0;
            end
%             sizek=sum(sum(object2));  
                                          
                                          if IGG<.5% || IGG2<(65535*0.05)
                                                classmap(object2)=0;

                                          end
                                          
%                                           if sizek

            nk ;
         end
 figure,imshow(label2rgb(classmap,'jet','k','shuffle'));
 figure,imshow(inp2);

cdata=GB; 
mult=[1 1 1];
for ind=1:2
col_img2a=mult(ind)*cdata(:,:,ind);
%                           col_img2a(LABELM==0)=0;
col_img2a(objectbor_map>0)=65535;
cdata(:,:,ind)=col_img2a;
end
imwrite(cdata,[Reshome5 filesep filename2 filesep filename2 'FSEG.png']);

Img13=classmap;
objectbor_map=(Img13-imerode(Img13,ones(3)))>0;
imwrite(objectbor_map,[Reshome5 filesep filename2 filesep filename2 'BORDER_F_S.png']);

cdata=inp2; 
mult=[1 1 1];
for ind=1:3
col_img2a=mult(ind)*cdata(:,:,ind);
%                           col_img2a(LABELM==0)=0;
col_img2a(objectbor_map>0)=65535;
cdata(:,:,ind)=col_img2a;
end
imwrite(cdata,[Reshome5 filesep filename2 filesep filename2 'FSEG_F.png']);

cdata=imread([Reshome2 filesep filename2 filesep filename2 'ALL_RC.png']); 
mult=[1 1 1];
for ind=1:3
col_img2a=mult(ind)*cdata(:,:,ind);
%                           col_img2a(LABELM==0)=0;
col_img2a(LABELM==0)=0;
cdata(:,:,ind)=col_img2a;
end
imwrite(cdata,[Reshome3 filesep filename2 filesep filename2 'BSEGR.png'])

cdata2=imread([Reshome2 filesep filename2 filesep filename2 'ALL_FC.png']); 
imwrite(cdata+cdata2,[Reshome3 filesep filename2 filesep filename2 'SUM.png'])

mult=[1 1 3.23];
for ind=1:3
col_img2a=mult(ind)*cdata(:,:,ind);
%                           col_img2a(LABELM==0)=0;
% col_img2a(LABELM==0)=0;
cdata(:,:,ind)=col_img2a;
end

mult=[1.4 1.4 4];
for ind=1:3
col_img2a=mult(ind)*cdata2(:,:,ind);
%                           col_img2a(LABELM==0)=0;
% col_img2a(LABELM==0)=0;
cdata2(:,:,ind)=col_img2a;
end

imwrite(cdata+cdata2,[Reshome3 filesep filename2 filesep filename2 'SUM2.png'])
% close all
end

end