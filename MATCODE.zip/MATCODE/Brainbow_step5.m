clear all
close all

clc

for idx=[2 3 5 7]

loadaddress;

mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);
 
RANDN=10;


MTYPE={'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h'};
     C2count=[];
     CLIST=1;
     DLIST=[];
     YA=[];
     
     DVlist=[];
     YVlist=[];
     
cut(1,1:4)=round([1 1+pdist2(114.9,-170.7)/0.31 1 1024]);  
cut(2,1:4)=round([1 1+pdist2(-170.7,-456.3)/0.31 1 1+pdist2(5113.2,5398.8)/0.31]); 
cut(3,1:4)=round([1 1+pdist2(-170.7,-456.3)/0.31 1 1024]); 
cut(4,1:4)=round([1 1024 1 1+pdist2(4827.6,5113.2)/0.31]); 
cut(5,1:4)=round([1 1024 1 1024]); 
worklist =1:numel(Types);

load_pic
create_HM
HM=round(HM);
shift2=HM;


shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];





%  LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%  LCOLORL=imread([Reshome3 filesep 'mosaicL.png']);
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
     
DATA=cells2.data.Sheet1;
ID=DATA(:,1);
    for IDk=1:5
    tDATA=DATA(ID==IDk,:);
    
    tDATA(:,4:5)=tDATA(:,4:5)+repmat(shift(IDk,1:2),size(tDATA,1),1);
    DATA(ID==IDk,:)=tDATA;
    end

            SD=pdist2(DATA(:,4:5),DATA(:,4:5));
    
    thresh = 0;
    SD(SD==0)=3*1024;
    [mask,mpos] = min(SD,[],1);
    mergeid=mask<thresh;
    class=1:1:length(mergeid);
    ttDATA=[];
    cnk=1;
    for loopk=1:length(mergeid)
        
        if mergeid(loopk)>0
           ttDATA(cnk,:)=round(mean([DATA(loopk,:);DATA(mpos(loopk),:)]));
            cnk=cnk+1;
        end
    end
    [A,B]=unique(ttDATA,'rows');
    kDATA=DATA(mergeid==0,:);
    DATA=[kDATA;A];
    
    
    
figure()
varv=0;
  DATA=DATA(~(DATA(:,6)<varv & DATA(:,7)<varv & DATA(:,8)<varv),:);
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:11);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:11)=DATAT;
     
 %% positing final positives  
 
    tDATA=DATA;
         m=4;
         
d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};


for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
        
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk4.mat'],'Imgsegk4');
LABELM=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);

LCOLOR5=imread([Reshome2 filesep filename2 filesep filename2 'FINALC2.png']);
Compb=LCOLOR5;
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'FINALC3.png']);  

pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
objectcore_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imerode(object, se);
                              objectbor=(object-objectcore)>0;
                       objectbor_map(objectbor)=1;
                       objectcore_map(objectcore)=val;
                             
         end
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   
imwrite(uint16(objectcore_map),[Reshome2 filesep filename2 filesep filename2 'Core.png']);  
imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'OverlayM3.png']);  
         
 load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');            
  load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center'); 
  
  if size(CA,1)>0
  
   CA(:,10:18)=CA(:,10:18).*repmat(mult,size(CA,1),3);
  
  figure
  imagesc(imresize(Compb,4));hold on
m=4;
     for zin=1:size(CA,1)       

         text(m*center(zin,2)+30,m*center(zin,1)-30,num2str(zin),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
                          text(m*center(zin,2)+10,m*center(zin,1)-10,[char(10) '(' num2str(round((CA(zin,10)))) ',' num2str(round((CA(zin,11)))) ','...
          num2str(round((CA(zin,12)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     
              text(m*center(zin,2)+0,m*center(zin,1)-10,[char(10) char(10) '(' num2str(round((CA(zin,16)))) ',' num2str(round((CA(zin,17)))) ','...
          num2str(round((CA(zin,18)))) ')'],'FontSize',3,'FontName','Times','Color',[.95 .65 0.65],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
     end

     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
  
  export_fig([Reshome2 filesep filename2 filesep filename2 '_method3'],'-a2', '-m4','-png', '-r300');

  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_method3' '.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LABELM,1) 2*size(LABELM,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_method3' '.png']);
  end

close all
end

pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'OverlayM3.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,[Reshome3 filesep 'mosaicO.png']);

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicL.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
 
 
   LCOLORC(:,:,1)=mult(1)*LCOLORC(:,:,1);
  LCOLORC(:,:,2)=mult(2)*LCOLORC(:,:,2);
  LCOLORC(:,:,3)=mult(3)*LCOLORC(:,:,3);
  
  imwrite(LCOLORC,[Reshome3 filesep 'mosaicCM.png']);
  
   imwrite(LCOLORC+0.25*LCOLORG,[Reshome3 filesep 'mosaicCMO.png']);
   
    imwrite(pic+0.25*LCOLORG,[Reshome3 filesep 'mosaicBMO.png']);
   
pic1=[];
load_pic1;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'Core.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024); 
imwrite(pic,[Reshome3 filesep 'mosaicLC.png']);
    
    
pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVp.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,[Reshome3 filesep 'mosaicRAW.png']);  

G=imread([Reshome3 filesep 'mosaicG.png']);
C=imread([Reshome3 filesep 'mosaicC.png']);
F=C+0.3*G;
imwrite(F,[Reshome3 filesep 'mosaicMod.png']);

CM=imread([Reshome3 filesep 'mosaicCM.png']);
F=CM+0.3*G;
imwrite(F,[Reshome3 filesep 'mosaicEnhanced.png']);


load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);

typ=1;
ang=0;

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLC.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

imwrite(uint16(LABELM),[Reshome3 filesep 'mosaicLM.png'])


LABEL=LABELM;

pcells=unique(LABEL);
CA=[];
CA2=[];
center=[];
DATA=[];

 INFO=cells2.data.Sheet1;
ID=INFO(:,1);
    for IDk=1:numel(Types)
    tINFO=INFO(ID==IDk,:);
    
    tINFO(:,4:5)=tINFO(:,4:5)+repmat(shift(IDk,1:2),size(tINFO,1),1);
    INFO(ID==IDk,:)=tINFO;
    end
 

         for nk=2:length(pcells)            
            val=pcells(nk); 
           
            
object=LABEL==val;      
                              s = regionprops(object,'centroid');
                             cent=s.Centroid;
                              cent=fliplr(double(round(cent)));
                              CA2(nk-1,10:11)=cent;
              center(nk-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              
              obc=double([round(s.Centroid(2)) round(s.Centroid(1))]);
              [vlist,plist]=min(pdist2(obc,INFO(:,4:5)));
              
                            center(nk-1,3:5)=INFO(plist,6:8); 
            CA(nk-1,:)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)];
            CA2(nk-1,1:9)=[INFO(plist,6:8) INFO(plist,6:8) INFO(plist,9:11)]; 
 DATA(nk-1,1:11)=[1 1 length(pcells) center(nk-1,1:2) INFO(plist,6:8) INFO(plist,9:11)];


          nk
         end 
         
save([Reshome2 filesep 'all.mat'],'DATA','CA','CA2','center','RAK','GAK','BAK'); 

% typ=1;
% ang=0;
% 
% % AK=[320 20 80 140 200 260]
% % BK=[40 100 160 220 280 340]
% 
% AK=[330 10 50 90 130 170 210 250 290]
% BK=[30 70 110 150 190 230 270 310 350]
% 
% for anga=1:9
% load([Reshome2 filesep 'all.mat'],'DATA'); 
% % DATA=cells2.data.Sheet1;
% % ID=DATA(:,1);
% %     for IDk=1:5
% %     tDATA=DATA(ID==IDk,:);
% %     
% %     tDATA(:,4:5)=tDATA(:,4:5)+repmat(shift(IDk,1:2),size(tDATA,1),1);
% %     DATA(ID==IDk,:)=tDATA;
% %     end
% % 
% %             SD=pdist2(DATA(:,4:5),DATA(:,4:5));
% %     
% %     thresh = 15;
% %     SD(SD==0)=3*1024;
% %     [mask,mpos] = min(SD,[],1);
% %     mergeid=mask<thresh;
% %     class=1:1:length(mergeid);
% %     ttDATA=[];
% %     cnk=1;
% %     for loopk=1:length(mergeid)
% %         
% %         if mergeid(loopk)>0
% %            ttDATA(cnk,:)=round(mean([DATA(loopk,:);DATA(mpos(loopk),:)]));
% %             cnk=cnk+1;
% %         end
% %     end
% %     [A,B]=unique(ttDATA,'rows');
% %     kDATA=DATA(mergeid==0,:);
% %     DATA=[kDATA;A];
%     
%     
%     
% figure()
% % varv=6;
% %   DATA=DATA(~(DATA(:,6)<varv & DATA(:,7)<varv & DATA(:,8)<varv),:);
% cut=0.99;
% rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
%  mult=255./ rangek;
%   DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% % DATA(:,7)=1.5*DATA(:,7);
% DATAT=DATA(:,6:8);
% DATAT(DATAT>255)=255;
% DATACM=rgb2hsv(DATAT(:,1:3));
% DATA(:,6:8)=DATAT;
% 
% 
% HUE=DATACM(:,1)*360;
% if typ==1
% 
% 
% raw=HUE>=AK(anga) | HUE<BK(anga);
% select=DATACM(:,3)>25 & raw==1;
% else
%     select=DATACM(:,3)>25 & HUE>=AK(anga) & HUE<BK(anga);
% end
% 
% DATA=DATA(select==1,:);
% DATACM=DATACM(select==1,:);
% 
% h=polar(0,255,'.');hold on
% set(h,'linewidth',0.01)
% set(h,'markersize',0.01)
% for mt=1:size(DATACM,1)
% h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
% set(h,'linewidth',1)
% set(h,'markersize',6)
% set(h,'color',DATA(mt,6:8)/255)
% end
% 
% 
% % xlim([-255 255]);
% % ylim([-255 255]);
% %  xlabel('Hue','FontSize', 20,'FontName','Times');
% %                                             ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['HSV distribution adjusted'], 'FontSize',24,'FontName','Times') % y-axis label   
%                                              a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'FontName','Times','fontsize',12,'FontName','Times');
% b = get(gca,'YTickLabel');
% set(gca,'YTickLabel',b,'FontName','Times','fontsize',12,'FontName','Times');
% 
% ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
% %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                                             set(gcf,'PaperPositionMode','auto')
% print([Reshome3 filesep  'HSV distributionT' num2str(anga+ang)], '-dpng', '-r300'); 
% 
%  LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%  LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
%  LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
% % LCOLORG(LCOLORL==0)=0; 
%  
% colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
% colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
% colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
% 
% LCOLORCA=LCOLORC(:,:,1);
% LCOLORCB=LCOLORC(:,:,2);
% LCOLORCC=LCOLORC(:,:,3);
% 
% 
%  T1=LCOLORL>0;
%  I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
%  
%  LCOLORCA(I2cpsegb==0)=0;
%  LCOLORCB(I2cpsegb==0)=0;
%  LCOLORCC(I2cpsegb==0)=0;
%  
%  LCOLORCA=mult(1)*LCOLORCA;
%  LCOLORCB=mult(2)*LCOLORCB;
%  LCOLORCC=mult(3)*LCOLORCC;
%  
%   CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
%                         
% %                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');
% 
%                            labeledImage = bwlabel(I2cpsegb>0, 4);
% % LCOLORL
% 
%  for cell=1:size(DATA,1)
%      
%      
%      
%      val=LCOLORL(DATA(cell,4),DATA(cell,5));
%      pos=LCOLORL==val;
%      
%      colorA(pos)=LCOLORCA(pos);
%       colorB(pos)=LCOLORCB(pos);
%        colorC(pos)=LCOLORCC(pos);
%      cell
%      
%  end
%  
%  CL=cat(3,colorA,colorB,colorC);
%  
% CO=LCOLORG;
% % CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
% COF=CL+0.25*CO;
% 
% % imwrite(uint16(65535*mat2gray(COF)),[Reshome3 filesep 'FmaxVp.png']);  
% % 
% 
%  m=2;
%     
%      COFM=imresize(COF,m);
%  figure
%   imshow(uint16(65535*mat2gray(COFM)));hold on
%   
%   
%     for zin=1:size(DATA,1)       
%          text(m*DATA(zin,5)+30,m*DATA(zin,4)-30,num2str(round(360*DATACM(zin,1)),'%0.0f'),'FontSize',2.5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*DATA(zin,5)+10,m*DATA(zin,4)-10,[char(10) '(' num2str(round((DATA(zin,6)))) ',' num2str(round((DATA(zin,7)))) ','...
%           num2str(round((DATA(zin,8)))) ')'],'FontSize',1.5,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%   
% %      for zin=1:size(xyval,1)   
% %          
% %             
% % %          if  diffval(zin)<0.25
% % 
% % %  text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(zin),'FontSize',2.5,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % %                           text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)))) ',' num2str(round((xyval(zin,6)))) ','...
% % %           num2str(round((xyval(zin,7)))) ')'],'FontSize',1.5,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
% % 
% %    U=m*xyval(zin,4)-m*xyval(zin,2);
% %    V=m*xyval(zin,3)-m*xyval(zin,1);
% %    Z=sqrt(U.^2+V.^2);   
% %   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',CK(zin,:),'maxheadsize',0.025,'linewidth',.5) ; hold on
% % %          end
% 
% %      end
%      axis equal
%    
%  set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
%    
%     ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             set(gcf,'PaperPositionMode','auto')
%                                      
% %         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
% export_fig([Reshome3 filesep 'Mvector_direction_varkk' num2str(anga+ang)],'-a2', '-m4','-png', '-r300');
% 
%   LCOLORk=imread([Reshome3 filesep 'Mvector_direction_varkk' num2str(anga+ang) '.png']);
%   LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
% %   Imk2=imresize(LCOLORk,[2*size(LCOLOR4,1) 2*size(LCOLOR4,2)]);
%   imwrite(uint8(LCOLORk),[Reshome3 filesep 'Mvector_direction_varkk' num2str(anga+ang) '.png']);
%       close all  
% typ=typ+1;
% end
% % 
% % DATACMx=DATACM(:,2).*cosd(360*DATACM(:,1));
% % DATACMy=DATACM(:,2).*sind(360*DATACM(:,1));
% 
% % h=scatter(DATACMx,DATACMy,15,[DATA(:,6:8)/255],'filled');
% 
% % h=polar(0,255,'.');hold on
% % for mt=1:size(DATACM,1)
% % h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
% % set(h,'linewidth',1)
% % set(h,'markersize',6)
% % set(h,'color',DATADC(mt,1:3))
% % end
% % 
% % 
% % % xlim([-255 255]);
% % % ylim([-255 255]);
% % %  xlabel('Hue','FontSize', 20,'FontName','Times');
% % %                                             ylabel('standard deviation', 'FontSize', 20,'FontName','Times') % y-axis label
% %                                             title(['HSV distribution adjusted'], 'FontSize',24,'FontName','Times') % y-axis label   
% %                                              a = get(gca,'XTickLabel');
% % set(gca,'XTickLabel',a,'FontName','Times','fontsize',12,'FontName','Times');
% % b = get(gca,'YTickLabel');
% % set(gca,'YTickLabel',b,'FontName','Times','fontsize',12,'FontName','Times');
% % 
% % ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
% % %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %                                             set(gcf,'PaperPositionMode','auto')
% % print([Reshome3 filesep  'HSV distributionT'], '-dpng', '-r300'); 
% % 
% % 


end


