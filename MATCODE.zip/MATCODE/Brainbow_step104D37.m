clear all
close all

load_angle=0;
cut=0.99;
darkest_cells_cut=75;

darkest_cells_cutupA=[100 67 33];
darkest_cells_cutdownA=[67 33 0];

zres=[0.52 0.36 0.36 1 0.36 1 0.47 0.47 1 0.36];
% zres(13)=zres(3);
% zres(23)=zres(3);
nslice=ceil(20./zres);


xyvals=[];
ADATAS=[];
load multa.mat multa

multa(10,:)=multa(3,:);
sisters=100;
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters)]);
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE' ]);
m=1;

for idx=[10]
    
        if idx==7
     LW=0.2;
        elseif idx==10
     LW=2;
     else
     LW=0.4;
        end
     idxt=idx;  
    multp=multa(idx,:);
multn=multa(idx,:);
    
    loadaddress2
    
%     idxt=idx;

load([Reshome2 filesep '36DATA' num2str(idx) '.mat'],'ADATAS_otherAR','xyvals_otherAR','SINGLEP','SINGLEN','DOUBLETN','RAWF',...
    'ADATAS_DSYM','xyvals_DSYM','ADATAS_DASYM','xyvals_DASYM','ADATAS_D','xyvals_D','ADATAS_T','xyvals_T','ADATAS_Q','xyvals_Q',...
    'ADATAS_M','xyvals_M','ADATAS_R','xyvals_R','ADATAS_R2','xyvals_R2','ADATAS_Z','xyvals_R','PDATABB','PDATAB','NDATABB','NDATAB'); 


RM=[DOUBLETN;ADATAS_Z;ADATAS_R2];

check=min(pdist2(RAWF(:,4:5),RM(:,4:5)),[],2);
RAWF(check==0,:)=[];  

% check=min(pdist2(ADATAS_TASYM(:,4:5),xyvals_TASYM(:,1:2)),[],2);
% ADATAS_TASYM(check>0,:)=[];



make_hue_plot2([SINGLEP;SINGLEN])
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) 'SINGLE'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S([SINGLEP;SINGLEP])
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) 'SINGLE'],'-a2', '-m6','-p0','-q101','-png', '-r600');

tDATA=SINGLEP;
LCOLORC=imread([Reshome3 filesep 'PmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM2.png']);

mult=multp;
make_CL_B;
COF1=CL;

imwrite(COF1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) 'SINGLEP' '.png']);

tDATA=SINGLEN;
LCOLORC=imread([Reshome3 filesep 'NmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM2.png']);

mult=multn;
make_CL;
COF2=CL;  
imwrite(COF2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) 'SINGLEN' '.png']);

close all
% makes_linked_images(ADATAS_D,xyvals_D,LW,sisters,idx,'_D',multp,multn,Reshome3,0);
makes_linked_images(ADATAS_D,xyvals_D,LW,sisters,idx,'_DB',multp,multn,Reshome3,1);
% makes_linked_images(ADATAS_otherAR,xyvals_otherAR,LW,sisters,idx,'_DN',multp,multn,Reshome3,0);
% makes_linked_images(ADATAS_otherAR,xyvals_otherAR,LW,sisters,idx,'_DNB',multp,multn,Reshome3,1);
makes_linked_images(ADATAS_DSYM,xyvals_DSYM,LW,sisters,idx,'_DS',multp,multn,Reshome3,0);
% makes_linked_images(ADATAS_DASYM,xyvals_DASYM,LW,sisters,idx,'_DAS',multp,multn,Reshome3,0);
makes_linked_images(ADATAS_DASYM,xyvals_DASYM,LW,sisters,idx,'_DASB',multp,multn,Reshome3,1);

% tDATA=DOUBLETN;
% make_CL;
% COF2=CL;  
% imwrite(COF2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) 'DOUBLETN' '.png']);

makes_cell_images([DOUBLETN;ADATAS_Z],sisters,idx,'DOUBLETN',multp,multn,Reshome3,0);

make_hue_plot2([DOUBLETN;ADATAS_Z])
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) 'DOUBLETN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S([DOUBLETN;ADATAS_Z])
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) 'DOUBLETN'],'-a2', '-m6','-p0','-q101','-png', '-r600');

makes_cell_images(RAWF,sisters,idx,'_RAWF',multp,multn,Reshome3,0);
close all
% makes_linked_images(ADATAS_T,xyvals_T,LW,sisters,idx,'_T',multp,multn,Reshome3,0);
makes_linked_images(ADATAS_T,xyvals_T,LW,sisters,idx,'_TB',multp,multn,Reshome3,1);

% makes_linked_images(ADATAS_Q,xyvals_Q,LW,sisters,idx,'_Q',multp,multn,Reshome3,0);
makes_linked_images(ADATAS_Q,xyvals_Q,LW,sisters,idx,'_QB',multp,multn,Reshome3,1);

% makes_linked_images([ADATAS_T;ADATAS_Q],[xyvals_T;xyvals_Q],LW,sisters,idx,'_Q2',multp,multn,Reshome3,0);
% makes_linked_images([ADATAS_T;ADATAS_Q],[xyvals_T;xyvals_Q],LW,sisters,idx,'_QB2',multp,multn,Reshome3,1);

% makes_linked_images(ADATAS_M,xyvals_M,LW,sisters,idx,'_M',multp,multn,Reshome3,0);
makes_linked_images(ADATAS_M,xyvals_M,LW,sisters,idx,'_MB',multp,multn,Reshome3,1);

% makes_linked_images(ADATAS_R,xyvals_R,LW,sisters,idx,'_R',multp,multn,Reshome3,0);
% makes_linked_images(ADATAS_R2,xyvals_R2,LW,sisters,idx,'_R2',multp,multn,Reshome3,0);



close all

makes_linked_images(ADATAS_R,xyvals_R,LW,sisters,idx,'_RB',multp,multn,Reshome3,1);
makes_linked_images(ADATAS_R2,xyvals_R2,LW,sisters,idx,'_RB2',multp,multn,Reshome3,1);

close all
end
