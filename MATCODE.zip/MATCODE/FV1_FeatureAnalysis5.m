clear all
close all

clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\IMAGEJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB';
% Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\FINAL';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);
   Pantone = importdata([Reshome2 filesep 'Pantone_list.xlsx']);

PDATA=Pantone.data.Sheet1(:,2:4);

figure()

    valn=PDATA(:,1);
     valr=PDATA(:,2);
     vals=PDATA(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val;      
     
    for n=1:size(PDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',PDATA(n,1:3)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',PDATA(n,1:3)./255);hold on; 
       
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution Pantone');
print([Reshome2 filesep 'Color distribution Pantone'], '-dpng', '-r300');  


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter(PDATA(:,1),PDATA(:,2),25*(mat2gray(PDATA(:,3))+0.5),PDATA(:,1:3)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution Pantone 2'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution Pantone 2'], '-dpng', '-r300'); 


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter3(PDATA(:,1),PDATA(:,2),PDATA(:,3),15,PDATA(:,1:3)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
view(38,18)

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution Pantone 3'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution Pantone 3'], '-dpng', '-r300'); 


DATA=cells2.data.Sheet1;

% DATA(end-1:end,:)=[];
ID=DATA(:,1);

DATA(:,1)=[];

FP=unique(ID);

% pos=[];
val=[];
FJ=[]
for pid=1:length(FP)
val(pid)=sum(ID==pid);
FJ(pid)=mean(DATA(ID==pid,1));
% val(pid)=DATA(pos(pid),2);
end
sdiffvalk=[];
cdiffvalk=[];
diffvalk=[];

COA=[];
for imgid=1:numel(Types)
  
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
  LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
       load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');
        load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');  
 
       wgt=1;
        norm=[size(LABEL,1) size(LABEL,2) wgt*65535 wgt*65535 wgt*65535];
           center2=center./repmat(norm,size(center,1),1);

            norm2=[1 1 1 1 1 1 1 1 1 4096 4096 4096 4096 4096 4096 4096 4096 4096];
           CA2=CA./repmat(norm2,size(CA,1),1);
           
           [COPx,COPy]=terncoords(CA2(:,4),CA2(:,5),CA2(:,6));
           COP=[COPx COPy];
           
           CO=[CA2(:,[4:6 13:18]) center2(:,[1:2])]; 
           COA=[COA;CA];
     
                  DS = single(pdist2(CO(:,10:11),CO(:,10:11),'euclidean')); 
                  DC = single(pdist2(CO(:,1:9),CO(:,1:9),'euclidean')); 
                  
                  D = single(pdist2(CO,CO,'euclidean'));
                  D(D==0)=11;
                  DS(DS==0)=11;
                    DC(DC==0)=11;      
       cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];
         diffval=[];
   
                xyval=[];
            cdiffval=[];
              sdiffval=[];
                diffval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     diffval(cp,1)=D(Aida(cp,1),Aida(cp,2));
                     sdiffval(cp,1)=DS(Aida(cp,1),Aida(cp,2));
                     cdiffval(cp,1)=DC(Aida(cp,1),Aida(cp,2));

                     xyval(cp,1:2)=[center(Aida(cp,1),1) center(Aida(cp,1),2)];
                        xyval(cp,3:4)=[center(Aida(cp,2),1) center(Aida(cp,2),2)];
                         xyval(cp,5:7)=[center(Aida(cp,1),3) center(Aida(cp,1),4) center(Aida(cp,1),5)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[center(Aida(cp,2),3) center(Aida(cp,2),4) center(Aida(cp,2),5)];

                 end   
                 

sdiffvalk=[sdiffvalk;sdiffval];
cdiffvalk=[cdiffvalk;cdiffval];
diffvalk=[diffvalk;diffval];

end


[w pc ev] = princomp(COA(:,[10:12])/16);

 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter(pc(:,1),pc(:,2),15,DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
xlim([-200 200]);
ylim([-200 200]);

  xlabel('PCA component 1','FontSize', 20,'FontName','Times');
                                            ylabel('PCA component 2', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['PCA of color descriptor'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'PCA of color descriptor'], '-dpng', '-r300'); 


[w pc ev] = princomp(PDATA);

 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter(pc(:,1),pc(:,2),15,PDATA/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
xlim([-200 200]);
ylim([-200 200]);
  xlabel('PCA component 1','FontSize', 20,'FontName','Times');
                                            ylabel('PCA component 2', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['PCA of Pantone'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'PCA of Pantone'], '-dpng', '-r300'); 



[w pc ev] = princomp([COA(:,[13:15])/16;PDATA]);

 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');

h=scatter(pc(size(COA,1)+1:end,1),pc(size(COA,1)+1:end,2),10,PDATA/255,'filled');hold on;
h=scatter(pc(1:size(COA,1),1),pc(1:size(COA,1),2),15,[0 0 0],'filled');hold on;
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
xlim([-200 200]);
ylim([-200 200]);
  xlabel('PCA component 1','FontSize', 20,'FontName','Times');
                                            ylabel('PCA component 2', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['PCA'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'PCA'], '-dpng', '-r300'); 


D=5;
sdiffvalk(diffvalk>D)=[];
cdiffvalk(diffvalk>D)=[];
diffvalk(diffvalk>D)=[];

sdiffvalk=sdiffvalk(1:2:end);
cdiffvalk=cdiffvalk(1:2:end);
diffvalk=diffvalk(1:2:end);


figure

scatter(sdiffvalk,cdiffvalk)

h=scatter(cdiffvalk,sdiffvalk,15,[0.1 0.5 0.7],'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
 colormap((pink)); 
 
 xlim([0 1])
  ylim([0 1])
 
 xlabel('Color distance','FontSize', 20,'FontName','Times');
                                            ylabel('Spatial distance', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color Space correlation = ' num2str(corr(cdiffvalk,sdiffvalk))], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color Space correlation'], '-dpng', '-r300'); 


figure()
 [nc,hc]=hist(RAK/16,linspace(0,255,25));
 nc=nc/sum(nc); 
 plot(hc,nc,'r','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(GAK/16,linspace(0,255,25));
 nc=nc/sum(nc); 
 plot(hc,nc,'g','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(BAK/16,linspace(0,255,25));
 nc=nc/sum(nc); 
 plot(hc,nc,'b','LineStyle','-','LineWidth',2);
 
  hold on
  [hleg1, hobj1]=legend(['STD = ' num2str(std(RAK/16))],['STD = ' num2str(std(GAK/16))],['STD = ' num2str(std(BAK/16))],'Location','northeast');
legend('boxoff')

set(hleg1,'FontSize',16,'FontName','Times');  

xlim([0 255])

  xlabel('Spectrum','FontSize', 20,'FontName','Times');
                                            ylabel('Probability', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['RGB color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 10'], '-dpng', '-r300'); 



figure
h=bar([FJ-val;val]','stacked')
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
colk=bone(length(FP))/1.25;
ylim([0 1000]);
y=FJ;
x=1:length(FP);
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(val(i1),'%0.0f'),'Color',[0.4 0.1 0.1],...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end

% h=scatter(FP,val,90*(mat2gray(val)+0.5),colk,'filled');
% child=get(h,'Children');
% set(child,'FaceAlpha',0.5); 
 colormap([0.8 0.8 0.8; 0.8 0.2 0.2]);  %# Change the colormap to gray (so higher values are
    %   colorbar                       %#   black and lower values are white)
    caxis manual
    caxis([1 2])
%     colorbar
legend('FOXJ1','Brainbow+FoXJ1');
xlabel('Image ID','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Brainbow efficiency'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 8'], '-dpng', '-r300');                        
                        


figure
hBar=bar(FP,100*(val./FJ)',0.8) 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
colk=bone(length(FP))/1.25;


                        hBarChildren = get(hBar, 'Children');
                        index = 1:length(FP);
                        set(hBarChildren, 'CData', index);
                        colormap(colk);

y=100*(val./FJ)';
x=1:length(FP);
for i1=1:numel(y)
    text(x(i1)+0.4,y(i1)+0.65,num2str(y(i1),'%0.2f'),'rotation', 90,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end

xlabel('Image ID','FontSize', 20,'FontName','Times');
                                            ylabel('Brainbow (%)', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Brainbow efficiency'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 9'], '-dpng', '-r300');        



TH=255*.05;
DATAR=DATA(:,5:7);

R=sum(DATA(:,5)>TH & DATA(:,6)<TH & DATA(:,7)<TH)
G=sum(DATA(:,5)<TH & DATA(:,6)>TH & DATA(:,7)<TH)
B=sum(DATA(:,5)<TH & DATA(:,6)<TH & DATA(:,7)>TH)
RG=sum(DATA(:,5)>TH & DATA(:,6)>TH & DATA(:,7)<TH)
GB=sum(DATA(:,5)<TH & DATA(:,6)>TH & DATA(:,7)>TH)
BR=sum(DATA(:,5)>TH & DATA(:,6)<TH & DATA(:,7)>TH)
RGB=sum(DATA(:,5)>TH & DATA(:,6)>TH & DATA(:,7)>TH)
A=sum([R G B RG GB BR RGB]);

   figure() 
                   
                    hBar= bar([1:7],[R G B RG GB BR RGB],0.6);
colk=[1 0 0; 0 1 0; 0 0 1; 1 1 0; 0 1 1; 1 0 1; 1 1 1]/1.3;
                        hBarChildren = get(hBar, 'Children');
                        index = 1:7;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);
                        ylim([0 140])
                        
                        y=[R G B RG GB BR RGB];
x=[1:7];
for i1=1:numel(y)
    text(x(i1),y(i1),num2str(y(i1),'%0.0f'),'Color',colk(i1,:)/1.2,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
                        
 set(gca,'XTick',1:7)
 ax = gca;
 set(ax,'XTickLabel',{'R', 'G', 'B','RG', 'GB', 'BR','RGB'});
                       
                        
 xlabel('Color combinations','FontSize', 20,'FontName','Times');
                                            ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 6'], '-dpng', '-r300');                        
                        

              figure          
                        
                        
%                         X = categorical({'North','South','North','East','South','West'});
% explode = {'North','South'};
hBar=pie([R G B RG GB BR RGB],[0 0 1 0 0 0 1],{['R = ' num2str(R) ' (' num2str(100*R./A,'%.2f') '%)'],['G = ' num2str(G) ' (' num2str(100*G./A,'%.2f') '%)'],...
    ['B = ' num2str(B) ' (' num2str(100*B./A,'%.2f') '%)'],['RG = ' num2str(RG) ' (' num2str(100*RG./A,'%.2f') '%)'],['GB = ' num2str(GB) ' (' num2str(100*GB./A,'%.2f') '%)'],...
    ['BR = ' num2str(BR) ' (' num2str(100*BR./A,'%.2f') '%)'],['RGB = ' num2str(RGB) ' (' num2str(100*RGB./A,'%.2f') '%)']})
colormap(colk)             

h = hBar;

hText = findobj(h,'Type','text');
textPositions_cell = get(hText,{'Position'}); % cell array
textPositions = cell2mat(textPositions_cell); % numeric array
textPositions = textPositions * 1.1; % scale position
set(hText,{'Position'},num2cell(textPositions,[3,2])) % set new position

%  xlabel('Color combinations','FontSize', 20,'FontName','Times');
%                                             ylabel('Counts', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 7'], '-dpng', '-r300'); 


d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];


   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);

DATA=cells2.data.Sheet1;
% DATA(end-1:end,:)=[];
ID=DATA(:,1);

DATA(:,1)=[];

% DATA=DATA(1:28,:)

figure()

    valn=DATA(:,5);
     valr=DATA(:,6);
     vals=DATA(:,7);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(DATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',DATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',DATA(n,5:7)./255);hold on; 
       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution 4');
print([Reshome2 filesep  'Color distribution 4'], '-dpng', '-r300'); 
% print(['aPerf_terplot_synTissue'], '-dpdf', '-r300');
% print(['aPerf_terplot_synTissue'], '-dpng', '-r300');


FP=DATA(DATA(:,2)==1,1);

% pos=[];
val=[];
for pid=1:length(FP)
val(pid)=sum(ID==pid);
% val(pid)=DATA(pos(pid),2);
end

figure
scatter(FP,val) 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
colk=pink(length(FP))/1.25;

h=scatter(FP,val,90*(mat2gray(val)+0.5),colk,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
 colormap((pink));  %# Change the colormap to gray (so higher values are
    %   colorbar                       %#   black and lower values are white)
    caxis manual
    caxis([1 length(FP)])
    colorbar


for pid=1:length(FP)
   text(FP(pid)+7,val(pid)+1,num2str(val(pid)/FP(pid),'%.2f'),'FontSize',9,'FontName','Times','Color',colk(pid,:),'HorizontalAlignment','left','VerticalAlignment', 'top');
end
 xlabel('FoxJ1 positives','FontSize', 20,'FontName','Times');
                                            ylabel('Brainbow positives', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Rate of Brainbow positive cells'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 5'], '-dpng', '-r300'); 


 figure()
 [nc,hc]=hist(DATA(:,5),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'r','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(DATA(:,6),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'g','LineStyle','-','LineWidth',2);

 hold on
 [nc,hc]=hist(DATA(:,7),linspace(0,255,15));
 nc=nc/sum(nc); 
 plot(hc,nc,'b','LineStyle','-','LineWidth',2);
 
  hold on
  [hleg1, hobj1]=legend(['STD = ' num2str(std(DATA(:,5)))],['STD = ' num2str(std(DATA(:,6)))],['STD = ' num2str(std(DATA(:,7)))],'Location','northeast');
legend('boxoff')

set(hleg1,'FontSize',16,'FontName','Times');  

xlim([0 255])

  xlabel('Spectrum','FontSize', 20,'FontName','Times');
                                            ylabel('Probability', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution'], '-dpng', '-r300'); 


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter(DATA(:,5),DATA(:,6),50*(mat2gray(DATA(:,7))+0.5),DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution 2'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 2'], '-dpng', '-r300'); 


 figure()
 
%   scatter(dg,sg,10,colk(3,:)/1.1,'filled');
h=scatter3(DATA(:,5),DATA(:,6),DATA(:,7),sum(DATA(:,5:7),2)/5,DATA(:,5:7)/255,'filled');
child=get(h,'Children');
set(child,'FaceAlpha',0.5); 
view(38,18)

  xlabel('Red','FontSize', 20,'FontName','Times');
                                            ylabel('Green', 'FontSize', 20,'FontName','Times') % y-axis label
                                            zlabel('Blue', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Color distribution 3'], 'FontSize',24,'FontName','Times') % y-axis label                                           
print([Reshome2 filesep  'Color distribution 3'], '-dpng', '-r300'); 

for imgid=1:numel(Types)
  
     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
        
     LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
        
       load([Reshome2 filesep filename2 filesep filename2 'CA.mat'],'CA');
        load([Reshome2 filesep filename2 filesep filename2 'center.mat'],'center');                         
        
       tDATA=DATA(ID==imgid,:);

figure()

    valn=tDATA(:,5);
     valr=tDATA(:,6);
     vals=tDATA(:,7);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution ternary');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution 4'], '-dpng', '-r300');  


figure()

    valn=CA(:,1);
     valr=CA(:,2);
     vals=CA(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution mean ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution mean ratio'], '-dpng', '-r300');  

figure()

    valn=CA(:,1);
     valr=CA(:,2);
     vals=CA(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution mean ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution mean ratio'], '-dpng', '-r300');  
        
figure()

    valn=CA(:,4);
     valr=CA(:,5);
     vals=CA(:,6);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution median ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution median ratio'], '-dpng', '-r300');  

figure()

    valn=CA(:,7);
     valr=CA(:,8);
     vals=CA(:,9);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution STD ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution STD ratio'], '-dpng', '-r300');  


figure()

    valn=CA(:,10);
     valr=CA(:,11);
     vals=CA(:,12);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution mean');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution mean'], '-dpng', '-r300');  
        
figure()

    valn=CA(:,13);
     valr=CA(:,14);
     vals=CA(:,15);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution median');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution median'], '-dpng', '-r300');  

figure()

    valn=CA(:,16);
     valr=CA(:,17);
     vals=CA(:,18);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
     
     
    for n=1:size(tDATA,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',tDATA(n,5:7)./255,'LineWidth',1.5,'MarkerSize',4,'MarkerFaceColor',tDATA(n,5:7)./255);hold on; 
       
       [x y]=terncoords(NMI(n),RMSE(n),SNR(n));
        text(x,y,num2str(tDATA(n,2)),'FontSize',6,'FontName','Times','Color',[0.5 0.1 0.1],'HorizontalAlignment','left','VerticalAlignment', 'top');

       %terncontour(NMI,RMSE,SNR,Z);hold on;
    end
     ternlabel('RED', 'GREEN', 'BLUE')      

title('Color distribution STD ratio');
print([Reshome2 filesep  filename2 filesep filename2 'Color distribution STD'], '-dpng', '-r300'); 
close all

end








