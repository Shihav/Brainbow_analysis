clear all
close all

clc

for idx=1:5

loadaddress;

mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

MTYPE={'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h'};
     C2count=[];
     CLIST=1;
     DLIST=[];
     YA=[];
     
     DVlist=[];
     YVlist=[];
     
worklist =1:numel(Types);

load_pic
create_HM
HM=round(HM);
shift2=HM;

shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];

         m=4;

load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);

typ=1;
ang=0;

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLC.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

 ImgR=LCOLORC(:,:,1);
 ImgG=LCOLORC(:,:,2);
 ImgB=LCOLORC(:,:,3);
 
[LABELM,NUM] = bwlabel(LCOLORL>0,8);

imwrite(uint16(LABELM),[Reshome3 filesep 'mosaicLM.png'])

LABEL=LABELM;

typ=1;
ang=0;

% AK=[320 20 80 140 200 260]
% BK=[40 100 160 220 280 340]

AK=[330 10 50 90 130 170 210 250 290]
BK=[30 70 110 150 190 230 270 310 350]

for anga=1:9
load([Reshome2 filesep 'all.mat'],'DATA'); 

% varv=6;
%   DATA=DATA(~(DATA(:,6)<varv & DATA(:,7)<varv & DATA(:,8)<varv),:);
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;


HUE=DATACM(:,1)*360;
if typ==1


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>25 & raw==1;
else
    select=DATACM(:,3)>25 & HUE>=AK(anga) & HUE<BK(anga);
end

DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);


 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
% LCOLORG(LCOLORL==0)=0; 
 
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);


 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
%                            [B1,L1,N1,A1] = bwboundaries(T3,8,'noholes');

                           labeledImage = bwlabel(I2cpsegb>0, 4);
% LCOLORL

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
     
     colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell
     
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.25*CO;

 m=2;

  imwrite(uint16(65535*mat2gray(COF)),[Reshome3 filesep 'Angular_cell' num2str(anga+ang) '.png']);

typ=typ+1;
end

end


