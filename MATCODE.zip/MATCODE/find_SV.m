if SU==1
    
SV=SVTH;
    
else

SV=quantile(DATACM(:,3),((darkest_cells_cut/100)));

end
