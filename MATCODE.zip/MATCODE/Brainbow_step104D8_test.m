clear all
close all

clc

zres=[.52 .36 .36 0 .36 0 .47 .47 .52 .36 .46 .36];

slice=ceil(25./zres)+1

for idx=[12]

loadaddress;

% mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
         mkdir([[Reshome5 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
     
load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB'); 

if idx>0
load([Reshome2 filesep filename2 filesep filename2 'Imgsegk4.mat'],'Imgsegk4');  

Imgseg=imdilate(Imgsegk4,ones(7,7,7));
save([Reshome5 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg','-v7.3');  
end
load([Reshome5 filesep filename2 filesep filename2 'Imgseg5.mat'],'Imgseg'); 

load([Reshome2 filesep filename2 filesep filename2 'ImgGR.mat'],'ImgGR'); 
mask=uint16([]);
for k=1:size(ImgGR,3)

                   timg=ImgGR(:,:,k);
                   
                   h = fspecial('disk',55);
                   timg2 = imfilter(timg,h,'replicate');

                    timg2(timg2>(25*255))=(255*255);
%                     imshow(uint8(timg3));

                    mask(:,:,k)=timg2;
                                      
k ;       
end
[maskm,zmap]=max(mask,[],3);
hG = fspecial('gaussian',[45 45],9); 
    zmap=round(imfilter(zmap,hG,'replicate'));


                   timg2 = imfilter(timg,h,'replicate');


imwrite(uint16(256*zmap),[Reshome5 filesep filename2 filesep filename2 'ZMAP.png']);

% [Img11r,zval11r]=max(ImgR,[],3);
% [Img11g,zval11g]=max(ImgG,[],3);
% [Img11b,zval11b]=max(ImgB,[],3);
% 
% CO=uint16(cat(3,Img11r,Img11g,Img11b));
% 
% imwrite(uint16(CO),[Reshome2 filesep filename2 filesep filename2 'NegC33.png']);
  
%      ImgR(Imgseg>0)=0;
%      ImgG(Imgseg>0)=0;
%      ImgB(Imgseg>0)=0;   
     
     [Img11r,zval11r]=max(ImgR,[],3);
     [Img11g,zval11g]=max(ImgG,[],3);
     [Img11b,zval11b]=max(ImgB,[],3);
     [Img11gr,zval11gr]=max(ImgGR,[],3);
     CO=uint16(cat(3,Img11r,Img11g,Img11b));
     C=CO;
     imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALLC.png']); 
     
     CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
     COF=CO+1*CGO;

     imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL.png']);  
 
      [~,~,stackR]=FV1_make_projection_from_layer2(ImgR,zmap,25,slice(idx));
      [~,~,stackG]=FV1_make_projection_from_layer2(ImgG,zmap,25,slice(idx));
      [~,~,stackB]=FV1_make_projection_from_layer2(ImgB,zmap,25,slice(idx));
      [~,~,stackGR]=FV1_make_projection_from_layer2(ImgGR,zmap,25,slice(idx));
      [~,~,ImgsegM]=FV1_make_projection_from_layer2(Imgseg,zmap,25,slice(idx));
      
      save([Reshome5 filesep filename2 filesep filename2 'stackR.mat'],'stackR','-v7.3'); 
      save([Reshome5 filesep filename2 filesep filename2 'stackG.mat'],'stackG','-v7.3');  
      save([Reshome5 filesep filename2 filesep filename2 'stackB.mat'],'stackB','-v7.3');
      save([Reshome5 filesep filename2 filesep filename2 'stackGR.mat'],'stackGR','-v7.3');
      save([Reshome5 filesep filename2 filesep filename2 'ImgsegM.mat'],'ImgsegM','-v7.3');  
      
      load([Reshome5 filesep filename2 filesep filename2 'stackR.mat'],'stackR'); 
      load([Reshome5 filesep filename2 filesep filename2 'stackG.mat'],'stackG');  
      load([Reshome5 filesep filename2 filesep filename2 'stackB.mat'],'stackB'); 
      load([Reshome5 filesep filename2 filesep filename2 'stackGR.mat'],'stackGR'); 
      load([Reshome5 filesep filename2 filesep filename2 'ImgsegM.mat'],'ImgsegM');  
            
      [Img11r,zval11r]=max(stackR,[],3);
      [Img11g,zval11g]=max(stackG,[],3);
      [Img11b,zval11b]=max(stackB,[],3); 
      [Img11gr,zval11gr]=max(stackGR,[],3);
      
     CO=uint16(cat(3,Img11r,Img11g,Img11b));
     C=CO;
     imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALL_AC.png']); 
     
     CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
     COF=CO+1*CGO;

     imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL_A.png']);  
     
     
     stackR(ImgsegM==0)=0;
     stackG(ImgsegM==0)=0;
     stackB(ImgsegM==0)=0; 
     stackGR(ImgsegM==0)=0; 
     
      [Img11r,zval11r]=max(stackR,[],3);
      [Img11g,zval11g]=max(stackG,[],3);
      [Img11b,zval11b]=max(stackB,[],3); 
      [Img11gr,zval11gr]=max(stackGR,[],3);
      
         CO=uint16(cat(3,Img11r,Img11g,Img11b));
     C=CO;
     imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALL_FC.png']); 
     
     CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
     COF=CO+1*CGO;

     imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL_F.png']);  
     

     
           load([Reshome5 filesep filename2 filesep filename2 'stackR.mat'],'stackR'); 
      load([Reshome5 filesep filename2 filesep filename2 'stackG.mat'],'stackG');  
      load([Reshome5 filesep filename2 filesep filename2 'stackB.mat'],'stackB'); 
      load([Reshome5 filesep filename2 filesep filename2 'stackGR.mat'],'stackGR');  
     
     
%       Img11r=FV1_make_projection_from_layer(ImgR,zmap,25,50);
%       Img11g=FV1_make_projection_from_layer(ImgG,zmap,25,50);
%       Img11b=FV1_make_projection_from_layer(ImgB,zmap,25,50);

     stackR(ImgsegM>0)=0;
     stackG(ImgsegM>0)=0;
     stackB(ImgsegM>0)=0; 
     stackGR(ImgsegM>0)=0; 
     
      [Img11r,zval11r]=max(stackR,[],3);
      [Img11g,zval11g]=max(stackG,[],3);
      [Img11b,zval11b]=max(stackB,[],3); 
      [Img11gr,zval11gr]=max(stackGR,[],3);
      
         CO=uint16(cat(3,Img11r,Img11g,Img11b));
     C=CO;
     imwrite(uint16(C),[Reshome5 filesep filename2 filesep filename2 'ALL_RC.png']); 
     
     CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
     COF=CO+1*CGO;

     imwrite(uint16(65535*mat2gray(COF)),[Reshome5 filesep filename2 filesep filename2 'ALL_R.png']);  
      
%       C=CO;
%       imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NegC3.png']); 
% 
% imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NOverlayM1.png']); 
% C=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM1.png']);
% 
% LABELM2=color_seg(C);
% 
% classmap5=LABELM2;
% figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));
% LABELM=classmap5;
% LABELM=imerode(LABELM,ones(3,3));
% 
% pcells=unique(LABELM);
% objectbor_map=zeros(size(LABELM));
% se=ones(3);
%          for nk=2:length(pcells)            
%             val=pcells(nk); 
% 
%                               object = LABELM == val;
%                               objectcore=imdilate(object, se);
%                               objectbor=(objectcore-object)>0;
%                        objectbor_map(objectbor)=1;
%                              
%          end
%    LCOLOR5=C;                                    
% mult=[1 1 1];
%                           for ind=1:3
%                           col_img2a=mult(ind)*LCOLOR5(:,:,ind);
%                           col_img2a(LABELM==0)=0;  
%                           col_img2a(objectbor_map==1)=65535;    
%                           Compb(:,:,ind)=col_img2a;
%                           end   
% 
% imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'NOverlayM2.png']);  
% imwrite(uint16(LABELM),[Reshome2 filesep filename2 filesep filename2 'NFinalmapM.png']);
% 
%    LCOLOR5=C;                                    
% mult=[1 1 1];
%                           for ind=1:3
%                           col_img2a=mult(ind)*LCOLOR5(:,:,ind);
%                           col_img2a(LABELM==0)=0;  
% %                           col_img2a(objectbor_map==1)=65535;    
%                           Compb(:,:,ind)=col_img2a;
%                           end  
% imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'NOverlayM3.png']); 

idx
imgid


close all
% clc
end

end