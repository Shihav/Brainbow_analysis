 clear all;close all;clc;
 load S22M.mat;
%  load S22cost.mat;
 x=1:1:59;
 iter=1;
 nametex='S22_';
 
 colk=flipud(pink(59))/1.1;
 for iter=1:758
   if(iter<50)
     if(mod(iter,2)==0)                                              
                 iter

                    figure(1) 
                    temp=M(:,:,iter);
                    [nc,hc]=hist(temp(:),x);
                     colormap(jet);
%                     hc(end)=[];
%                     nc(end)=[];
                    nc=nc./sum(nc);
                    hBar= bar(hc,nc,0.9);

                        hBarChildren = get(hBar, 'Children');
                        index = 1:59;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);
                  
                     ylim([0 0.06]);
%                       xlim([-0.25 5]);
                    xlabel('Z index','FontName','Times','fontsize',20);
                    ylabel('Frequency','FontName','Times','fontsize',20);
                    title(strcat('Z histogram, iteration ',num2str(iter,'%2d')),'FontName','Times','fontsize',25);
                    z=strcat(nametex,'Z_hist',num2str(iter,'%2d'));
                    print(z,'-dtiff','-r300'); 

     end
    else
             if(mod(iter,20)==0)
                             iter
                    
                    figure(2) 
                    temp=(M(:,:,iter));
                    [nc,hc]=hist(temp(:),x);
%                     colormap(gray);
%                     hc(end)=[];
%                     nc(end)=[];
                    nc=nc./sum(nc);
                    
                    hBar= bar(hc,nc,0.9);

                        hBarChildren = get(hBar, 'Children');
                        index = 1:59;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);
%                     bar(hc,nc,0.9);
                    ylim([0 0.06]);
%                       xlim([-0.25 5]);
                    xlabel('Z index','FontName','Times','fontsize',20);
                    ylabel('Frequency','FontName','Times','fontsize',20);
                    title(strcat('Z histogram, iteration ',num2str(iter,'%2d')),'FontName','Times','fontsize',25);
                    z=strcat(nametex,'Z_hist',num2str(iter,'%2d'));
                    print(z,'-dtiff','-r300'); 

           end 
     end
  end
 