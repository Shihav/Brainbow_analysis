Prlist{1}=[];
Prlist{2}=[];
Prlist{3}=[];
Prlist{5}=[];
Prlist{7}=[];
Prlist{8}=[];
Prlist{10}=[];

Nrlist{1}=[];
Nrlist{2}=[];
Nrlist{3}=[];
Nrlist{5}=[];
Nrlist{7}=[];
Nrlist{8}=[];
Nrlist{10}=[];