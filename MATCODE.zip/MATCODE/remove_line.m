function A=remove_line(A,A1)

AIG=rgb2gray(A1);

LBB=AIG>0;
LBB=imerode(LBB,ones(1));
for nk=1:3
    tm=A(:,:,nk);
    tm(LBB)=0;
    A(:,:,nk)=tm;
end