 if excl==1 
   Costmat1 = diag(diag(Costmat)+1);
   Costmat(Costmat1>0)=20000;
%    Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
%    Costmat(SPACEdist<=(STH/4) & Costmat<20000)=SPACEdist(SPACEdist<=(STH/4) & Costmat<20000)/STH;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;
                           xyval(cp,14:15)=[tDATA(Aida(cp,1),1) tDATA(Aida(cp,2),1)];
                            xyval(cp,16:17)=[tDATA(Aida(cp,1),end) tDATA(Aida(cp,2),end)];
                            xyval(cp,18:19)=[tDATA(Aida(cp,1),12) tDATA(Aida(cp,2),12)];
                            xyval(cp,20:21)=[tDATA(Aida(cp,1),13) tDATA(Aida(cp,2),13)];
                            xyval(cp,22:23)=[tDATA(Aida(cp,1),2) tDATA(Aida(cp,2),2)];
                            xyval(cp,24:25)=[10000*(tDATA(Aida(cp,1),1)-1)+tDATA(Aida(cp,1),2) 10000*(tDATA(Aida(cp,2),1)-1)+tDATA(Aida(cp,2),2)];
                 end  
   xyval(xyval(:,13)>=20000,:)=[];
   
 else 
   
   
      Costmat1 = diag(diag(Costmat)+1);
   
   Costmat(Costmat1>0)=20000;
%    Costmat(Costmat==0)=20000;
   Costmat(Bdist>BTH)=20000;
   Costmat(HUEdist>HTH)=20000;
   Costmat(SPACEdist>STH)=20000;
   Costmat(SATdist>SATH)=20000;
%    Costmat(SPACEdist<=(STH/4) & Costmat<20000)=SPACEdist(SPACEdist<=(STH/4) & Costmat<20000)/STH;


    DF=Costmat<HTH;

NB=[];    
DFF=sum(DF);

%         for cp2=1:size(tDATA,1)
%             if DFF(cp2)>0;
%             PO=find(DF(cp2,:)==1);
%                  [list,POS]= min(SD(cp2,PO));
%                  NB(cp2,1:2)=[PO(POS) list];
%             end
%         end


cp=1;
    xyval=[];
    
    for cp1=1:size(tDATA,1)
         if DFF(cp1)>0;
           cp2A=find(DF(cp1,:)==1);    
                  for cin=1:length(cp2A)
                      cp2=cp2A(cin);
%                       cp2=
                     xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
                        xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
                         xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
                         xyval(cp,8:9)=[cp1 cp2];
                           xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
                           xyval(cp,13)=Costmat(cp1,cp2);
                           xyval(cp,14:15)=[tDATA(cp1,1) tDATA(cp2,1)];
                            xyval(cp,16:17)=[tDATA(cp1,end) tDATA(cp2,end)];
                            xyval(cp,18:19)=[tDATA(cp1,12) tDATA(cp2,12)];
                            xyval(cp,20:21)=[tDATA(cp1,13) tDATA(cp2,13)];
                            xyval(cp,22:23)=[tDATA(cp1,2) tDATA(cp2,2)];
                            xyval(cp,24:25)=[10000*(tDATA(cp1,1)-1)+tDATA(cp1,2) 10000*(tDATA(cp2,1)-1)+tDATA(cp2,2)];
                           cp=cp+1;
                  end
%             end
        end
    end 
xyval(xyval(:,13)>=HTH,:)=[];
% xyval(xyval(:,13)==0,:)=[];

 end