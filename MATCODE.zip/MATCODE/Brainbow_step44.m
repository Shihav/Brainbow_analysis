clear all
close all

clc


sizeth2=275;
% for idx=[8]
% 
% loadaddress;
% ad=1;
% 
% d=dir(fullfile(Datahome,'*.tif*'));
% Types={d.name};
% 
% for imgid=1:numel(Types)
%      
%         tol=0.065;
% 
%      filename=Types{imgid};
%      filename2=strrep(filename,'.tif',''); 
%      mkdir([[Reshome2 filesep filename2]]);
%      segname=[Reshome filesep filename2 '4-Watershed.tif'];
% 
%      info = imfinfo(segname);
%         num_images = numel(info);
%   
% load([Reshome2 filesep filename2 filesep filename2 'Imgseg.mat'],'Imgseg'); 
% MV=max(Imgseg(:))+1;
% Imgseg=MV-Imgseg;
% Imgseg(Imgseg==MV)=0;
% Imgseg(Imgseg==MV-1)=0;
% 
% LB=uint16(max(Imgseg,[],3));
% LB = imclearborder(LB);
% imgid
%           
% pcells=unique(LB);
% 
%   stats = regionprops(LB>0,LB,'Area','Centroid','MajorAxisLength','MinorAxisLength','ConvexArea','Eccentricity','MeanIntensity');
%   
%       for nk=1:length(stats)    
%                                  xc=round(stats(nk).Centroid(2));
%                                  yc=round(stats(nk).Centroid(1));
% 
%                                 val=stats(nk).MeanIntensity; 
%                                        object = LB == val; 
%                                        sizen=stats(nk).Area;
%                                        R=sizen./(stats(nk).ConvexArea);
%                                        
%                                         if sizen<500 || R<0.85 
%                                             LB(LB==val)=0;
%                                         end
% 
% 
%                             nk
%       end 
%                                                 
% pcells=unique(LB);
%          for nk=1:length(pcells)            
%             val=pcells(nk); 
%             object=LB==val;
%             sizek=sum(sum(object)); 
%             object=LB==val;
%             stats = regionprops(object,'MajorAxisLength','MinorAxisLength','ConvexArea','Eccentricity');
%   Radi=sizek./(stats(1).ConvexArea);
%             if sizek<sizeth2 || (Radi<0.75) || length(stats)>1
%                 LB(object)=0;
%             end
%             nk;    
%          end
%      
%          pcells=unique(LB);
%          
%          se=ones(3);
%          for nk=2:length(pcells)            
%             val=pcells(nk); 
% 
%                               object = LB == val;
%                               objectcore=imdilate(object, se);
%                               objectbor=(objectcore-object)>0;
%                        LB(objectbor)=0;
%          
%          end
% 
% imwrite(uint16(LB),[Reshome2 filesep filename2 filesep filename2 'FOXL.png']);  
% 
% imgid
% 
% end
% end




for idx=[8]

loadaddress;
mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

load([Reshome2 filesep 'color.mat'],'RAK','GAK','BAK');  
   cells2 = importdata([Reshome2 filesep 'Result.xlsx']);
 
RANDN=10;

DATA=cells2.data.Sheet1;
ID=DATA(:,1);
MTYPE={'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h',...
         'o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h','o','s','d','^','v','>','<','p','h'};
     C2count=[];
     CLIST=1;
     DLIST=[];
     YA=[];
     
     DVlist=[];
     YVlist=[];
     create_HM;
     
worklist =1:numel(Types);

load_pic;

HM=round(HM);
create_HM
HM=round(HM);
shift2=HM;


shift=fliplr(shift2);

dimm1=max(shift2(:,1))+DY;
dimm2=max(shift2(:,2))+DX;

shift=[shift(:,1)+DX shift(:,2)+DY];

pic1=[];
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'GRAY2.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};
%                  pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,[Reshome3 filesep 'mosaicG.png']);

pic1=[];
load_pic1;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024); 
imwrite(pic,[Reshome3 filesep 'mosaicL.png']);

pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FINALC2.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,[Reshome3 filesep 'mosaicC.png']);



pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif',''); 
%      if idx==1
     LCOLOR4=imread([Reshome filesep filename2 '4-MAX_3D.tif']);
%      else
%      LCOLOR4=imread([Reshome filesep filename2 '-MAX_3D.tif']);
%      end
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024); 
imwrite(pic,[Reshome3 filesep 'CENTER.png']);



pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif',''); 
%      if idx==1
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FOXL.png'])+worklistn*1000;
     LCOLOR4(LCOLOR4==worklistn*1000)=0;
%      else
%      LCOLOR4=imread([Reshome filesep filename2 '-MAX_3D.tif']);
%      end
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024); 
imwrite(pic,[Reshome3 filesep 'FOXLM.png']);


LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
 
  CENTER=imread([Reshome3 filesep 'CENTER.png']);
  
%   fpc=sum(sum(CENTER>0))
  
  
         Img=LCOLORG(:,:,1);
          mean_s=45;
        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=Img2;
        
        mask=uint16(zeros(size(Img3)));
        
%         if idx==7
%         
%         mask(Img3>(max(Img2(:))*.15))=65535;
%         elseif idx==8
%         
%         mask(Img3>(max(Img2(:))*.15))=65535;
%         else
        mask(Img3>(max(Img2(:))*.15))=65535;
%         end
        
        mask=imdilate(mask,strel('disk',45));
        mask = imfill(mask);

        maskf=uint16(zeros(size(Img3)));    
           CC = bwconncomp(mask);
   numOfPixels = cellfun(@numel,CC.PixelIdxList);
   [unused,indexOfMax] = max(numOfPixels);
   maskf(CC.PixelIdxList{indexOfMax}) = 65535;
    
        maskb=uint16(zeros(size(Img3)));
        Img33=cat(3,Img3,Img3,Img3);
        mask3=cat(3,maskf,maskb,maskb);
        
        MASK=uint16(65535*mat2gray(maskf));

%                 imwrite2tif(Img1,[],[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2mask.tif'],'uint16');
             %    imwrite2tif(Imgover,[],[dir_images 'Images' filesep P 'series' num2str(sn,'%.2d') 'channel2maskover.tif'],'uint16');
% 
CENTER(MASK==0)=0;
  fpc=sum(sum(CENTER>0))
  
  areaV=(sum(sum(MASK>0))*0.31*0.31)/1000000
  
 imwrite(MASK,[FINB filesep 'AREA' num2str(idx) '.png']);


MASK=imread([FINB filesep 'AREA' num2str(idx) '.png']);
pic(MASK==0)=0;
imwrite(pic,[Reshome3 filesep 'FOXLM2.png']);


 s = regionprops(pic>0,'centroid');
 
 centerF=[];
for nk=1:length(s)
              centerF(nk,1:2)=double([round(s(nk).Centroid(2)) round(s(nk).Centroid(1))]);
end              

size(centerF,1)

save(['FOX' num2str(idx)],'centerF'); 


% tile06_01FmaxVp

pic1=[];
load_pic;
for worklistn=1:numel(Types)
     filename2=strrep(Types{worklistn},'.tif','');    
     LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);
     pic1{worklistn}=LCOLOR4;
end
for j=numel(Types):-1:1
                pic(DX+HM(j,2):DX+HM(j,2)+1023,DY+HM(j,1):DY+HM(j,1)+1023,:)=pic1{j};                
end
pic=pic(1:dimm2+1024,1:dimm1+1024,:); 
imwrite(pic,[Reshome3 filesep 'mosaicCF.png']);


end   


