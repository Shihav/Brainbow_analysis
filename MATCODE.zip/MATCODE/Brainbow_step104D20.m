clear all
close all


% m{1}=[2312 1600 1241 2641];
% m{2}=[1404 2351 2221 2481];
% m{3}=[1570 2737 2024 1600];
% m{5}=[1891 2115 2859 7202];
% m{7}=[1875 2006 562 1279];
% m{8}=[232 4369 4596 2206];

% m{1}=[2267 2096 1585 2748];
% m{2}=[1404 2351 2221 2481];
% m{3}=[1570 2737 2024 1600];
% m{5}=[1891 2115 2859 7202];
% m{7}=[959 2993 973 934];
% m{8}=[341 4357 4711 2206];

% m{1}=[2158 15 679 1474];
% m{2}=[776 2356 1652 2437];
% m{3}=[913 2617 1841 995];
% m{5}=[2009 1588 2831 6789];
% m{7}=[885 2201 252 775];
% m{8}=[618 3428 4312 1947];


m{1}=[2109 0 855 1234];
m{2}=[230 2832 2231 1672];
m{3}=[1778 3048 2050 1949];
m{5}=[1205 930 1611 4176];
m{7}=[6728 0 2066 1039];
m{8}=[293 3656 4006 1934];


m{3}=[1561 3263 2456 1543];

for sisters=2

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\cropped']);

for idx=[1 2 3 5 7 8]
    
loadaddress;

LCOLORG=imread([Reshome3 filesep 'mosaicRAW.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'mosaicRAW.png']);

LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);

% LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
% imwrite(LCOLORG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);
% 


mn=m{idx};

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLF' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RF' '.png']);

imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO' '.png']);
imwrite(256*uint16(B)+B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO' '.png']);

AG=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);
BG=AG(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:);

imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG' '.png']);
imwrite(256*uint16(B)+B1+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '.png']);

B3=B;
A3=A;

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fplus' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fplus' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fplus' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14) '_Fminus' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_R' '.png']);

A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RL' '.png']);
A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RL' '.png']);
B1=A1(mn(1):size(A1,1)-mn(2),mn(3):size(A1,2)-mn(4),:);
imwrite(B1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RL' '.png']);

imwrite(256*uint16(A1)+uint16(A),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLO' '.png']);
imwrite(256*uint16(B1)+uint16(B),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLO' '.png']);

imwrite(256*uint16(A1)+uint16(A)+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLOG' '.png']);
imwrite(256*uint16(B1)+uint16(B)+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLOG' '.png']);

A2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLW' '.png']);
A2=imresize(A2,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLW' '.png']);
B2=A2(mn(1):size(A2,1)-mn(2),mn(3):size(A2,2)-mn(4),:);
imwrite(B2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLW' '.png']);

imwrite(256*uint16(A2)+uint16(A),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWO' '.png']);
imwrite(256*uint16(B2)+uint16(B),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWO' '.png']);

imwrite(256*uint16(A2)+uint16(A)+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWOG' '.png']);
imwrite(256*uint16(B2)+uint16(B)+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RLWOG' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RP' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_1' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_1' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_1' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_2' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_2' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_3' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_3' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_F_3' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_1' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_1' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_1' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_2' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_2' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_2' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_3' '.png']);
A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_3' '.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_FR_3' '.png']);


% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'G.png']);
% B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  'G' '.png']);

imwrite(B3+0.5*BG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);
imwrite(A3+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14)  'CG' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' 'MZLINK_idx' num2str(idx) 'ang' num2str(14) 'mosaicRAW.png']);
B=A(mn(1):size(A,1)-mn(2),mn(3):size(A,2)-mn(4),:);
imwrite(B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'cropped\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  'mosaicRAW' '.png']);



idx

end
end

