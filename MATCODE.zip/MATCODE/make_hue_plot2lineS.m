function make_hue_plot2lineS(DATA,xyvals,LW,NL) 

% DATA=[PDATABB;NDATABB];
% xyvals=xyval;
% LW=2*LW;

xyvals=xyvals(ismember(xyvals(:,24),DATA(:,2)) & ismember(xyvals(:,25),DATA(:,2)),:);

DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;

% NL=prctile(DATAT,5,1);
DATAT=[DATAT;xyvals(:,5:7);xyvals(:,10:12)];
DATAT(:,1) =255*imadjust(DATAT(:,1)/255,[NL(1) 255]/255,[0 255]/255);
DATAT(:,2) =255*imadjust(DATAT(:,2)/255,[NL(2) 255]/255,[0 255]/255);
DATAT(:,3) =255*imadjust(DATAT(:,3)/255,[NL(3) 255]/255,[0 255]/255);

DATA(:,6:8)=DATAT(1:size(DATA,1),:);
         xyvals(:,5:7) =DATAT(size(DATA,1)+1:size(DATA,1)+size(xyvals,1),:);
         xyvals(:,10:12) =DATAT(size(DATA,1)+size(xyvals,1)+1:size(DATA,1)+2*size(xyvals,1),:);

DATACM=rgb2hsv(DATA(:,6:8));

figure

HUE=DATACM(:,1)*360;
h=polar(0,1,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,2),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',15)
set(h,'color',DATA(mt,6:8)/255)
end



     for zin=1:size(xyvals,1) 
         
%          if xyvals(zin,14)==1 && xyvals(zin,15)==1
%              CC=0.5*[1 1 1];
%          elseif xyvals(zin,14)==1 && xyvals(zin,15)==2
%              CC=0.5*[1 1 0];
%          elseif xyvals(zin,14)==2 && xyvals(zin,15)==1
%              CC=0.5*[1 1 0]; 
%          elseif xyvals(zin,14)==2 && xyvals(zin,15)==2
%              CC=0.5*[0.5 1 .5];
%          end
         
        CC=[0 0 0];

         
         DATACM1=rgb2hsv(xyvals(zin,5:7));
         DATACM2=rgb2hsv(xyvals(zin,10:12));

HUE1=DATACM1(:,1)*360;
HUE2=DATACM2(:,1)*360;

x1=DATACM1(:,2)*cos(2*pi*DATACM1(:,1));
x2=DATACM2(:,2)*cos(2*pi*DATACM2(:,1));

y1=DATACM1(:,2)*sin(2*pi*DATACM1(:,1));
y2=DATACM2(:,2)*sin(2*pi*DATACM2(:,1));
         
   U=x2-x1;
   V=y2-y1;
   Z=sqrt(U.^2+V.^2);   
  quiver(x1,y1,U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',1*LW) ; hold on
%          end
   
     end
     
     HUE=DATACM(:,1)*360;
h=polar(0,1,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,2),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',15)
set(h,'color',DATA(mt,6:8)/255)
end
 
set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure     