clear all
close all

clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\IMAGEJ';
Reshome2='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\MATLAB';
% Reshome3='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\FINAL';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};

BKA=[];

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
     
          info = imfinfo(oriname);
        num_images = numel(info);
     
             ImgGR=[];
        kn=1;
        for k = 4:4:num_images
            I = imread(oriname, k);
              ImgGR(:,:,kn)=I;   
              kn=kn+1
        end
%         
          segname=[Reshome filesep filename2 '4-Watershed.tif'];

     info = imfinfo(segname);
        num_images = numel(info);
        Imgseg=[];
        for k = 1:num_images
            I = imread(segname, k);
              Imgseg(:,:,k)=I;   
              k
        end        
        
         ImgGR(Imgseg==0)=0;
         ImgGRk=uint16(65535.*(ImgGR./4096));
         [Img11gr,zval11gr]=max(ImgGRk,[],3);
 
LABEL=imread([Reshome2 filesep filename2 filesep filename2 'Finalmap.png']);
LCOLOR=imread([Reshome2 filesep filename2 filesep filename2 'FLmapC.png']);
LCOLOR2=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC2.png']);
LCOLOR3=imread([Reshome2 filesep filename2 filesep filename2 'FmaxV.png']);
LCOLOR5=imread([Reshome2 filesep filename2 filesep filename2 'FmaxVC.png']);

Comp=zeros(size(LCOLOR5));

                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          col_img2a(LABEL==0)=0;    
                          Comp(:,:,ind)=col_img2a;
                          end 
                          
CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
Compk=uint16(Comp)+0.6*CGO;                          
                          
imwrite(uint16(Compk),[Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);
imwrite(uint16(Comp),[Reshome2 filesep filename2 filesep filename2 'Finalmap3.png']);
LCOLOR4=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapC3.png']);

RL=LCOLOR(:,:,1);
GL=LCOLOR(:,:,2);
BL=LCOLOR(:,:,3);

       labeledImage1=LABEL;
       center=[];
       cellsL=unique(labeledImage1);

           for id=2:size(cellsL,1)
               tag=cellsL(id);

                                     object = labeledImage1 == tag;
                            CL=[];         
                          for ind=1:3
                          col_img2a=LCOLOR5(:,:,ind);
                          CL(ind)=mean(col_img2a(object));    
                          end 
                                     
                              s = regionprops(object,'centroid');
                              center(id-1,1:2)=double([round(s.Centroid(2)) round(s.Centroid(1))]);
                            center(id-1,3:5)=CL; 
                           
           end
           wgt=1;
           norm=[size(LABEL,1) size(LABEL,2) wgt*65535 wgt*65535 wgt*65535];
           center2=center./repmat(norm,size(center,1),1);
     
                  D = single(pdist2(center2(:,1:5),center2(:,1:5),'euclidean')); 
                  D2 = single(pdist2(center(:,1:2),center(:,1:2),'euclidean')); 
                  D3 = single(pdist2(center(:,3:5),center(:,3:5),'euclidean')); 
                   DR = single(pdist2(center(:,3),center(:,3),'euclidean')); 
                    DG = single(pdist2(center(:,4),center(:,4),'euclidean')); 
                     DB = single(pdist2(center(:,5),center(:,5),'euclidean')); 
                  D(D==0)=8;
                  D2(D2==0)=size(LABEL,1)+size(LABEL,2);
                    D3(D3==0)=size(LABEL,1)+size(LABEL,2);      
       cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];
         diffval=[];
   
                xyval=[];
            cdiffval=[];
              sdiffval=[];
                diffval=[];
                Rdiffval=[];
                Gdiffval=[];
                Bdiffval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     diffval(cp,1)=D(Aida(cp,1),Aida(cp,2));
                     sdiffval(cp,1)=D2(Aida(cp,1),Aida(cp,2));
                     cdiffval(cp,1)=D3(Aida(cp,1),Aida(cp,2));
                      Rdiffval(cp,1)=DR(Aida(cp,1),Aida(cp,2));
                     Gdiffval(cp,1)=DG(Aida(cp,1),Aida(cp,2));
                      Bdiffval(cp,1)=DB(Aida(cp,1),Aida(cp,2));
                     xyval(cp,1:2)=[center(Aida(cp,1),1) center(Aida(cp,1),2)];
                        xyval(cp,3:4)=[center(Aida(cp,2),1) center(Aida(cp,2),2)];
                         xyval(cp,5:7)=[center(Aida(cp,1),3) center(Aida(cp,1),4) center(Aida(cp,1),5)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[center(Aida(cp,2),3) center(Aida(cp,2),4) center(Aida(cp,2),5)];

                 end
                 
                       figure
      m=4;
     Imk2=imresize(LCOLOR4,m);
    
   imagesc(Imk2);hold on

   RM=mean(xyval(:,[5 10]),2);
   GM=mean(xyval(:,[6 11]),2);
   BM=mean(xyval(:,[7 12]),2);
   CM=[RM+GM+BM];
   RT=0.08;
   
     for zin=1:size(cosmat,1)        
                  
         if sdiffval(zin)<1024*0.2 && Rdiffval(zin)<((RT+(2*RM(zin)/65535)*RT)*65535) && Gdiffval(zin)<((RT+(2*GM(zin)/65535)*RT)*65535) && Bdiffval(zin)<((RT+(2*BM(zin)/65535)*RT)*65535) && cdiffval(zin)<((RT+(4*CM(zin)/65535)*RT)*65535)
                         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
    
     if xyval(zin,2)<900
     
     text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');

     else         
           text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');     
     end
             
         else  
           
     if xyval(zin,2)<900
     
     text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     else
         
           text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');    
     end                      
         end   
         
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction'],'-a2', '-m4','-png', '-r300');

                       figure
  
   imagesc(Imk2);hold on
   
     for zin=1:size(cosmat,1)      
                  
         if sdiffval(zin)<1024*0.2 && Rdiffval(zin)<((RT+(2*RM(zin)/65535)*RT)*65535) && Gdiffval(zin)<((RT+(2*GM(zin)/65535)*RT)*65535) && Bdiffval(zin)<((RT+(2*BM(zin)/65535)*RT)*65535) && cdiffval(zin)<((RT+(4*CM(zin)/65535)*RT)*65535)
             
            
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
   
     if xyval(zin,2)<900
     
     text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
          num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     else
         
           text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
           
          text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[num2str(xyval(zin,8)), char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
          num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','right','VerticalAlignment', 'top');
     
     end
         else  
           
     if xyval(zin,2)<900
     
     text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
      
        text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
          num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');     
     else         
           text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
         
          text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[num2str(xyval(zin,8)), char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
          num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','right','VerticalAlignment', 'top');     
     end
                      
         end            
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction2'],'-a2', '-m4','-png', '-r300');

figure

  imagesc(Imk2);hold on

     for zin=1:size(cosmat,1)       
                  
         if sdiffval(zin)<1024*0.2 && Rdiffval(zin)<((RT+(2*RM(zin)/65535)*RT)*65535) && Gdiffval(zin)<((RT+(2*GM(zin)/65535)*RT)*65535) && Bdiffval(zin)<((RT+(2*BM(zin)/65535)*RT)*65535) && cdiffval(zin)<((RT+(4*CM(zin)/65535)*RT)*65535)             
            
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[.75 .75 0],'maxheadsize',100/Z,'linewidth',0.5) ; hold on
     
%      if xyval(zin,2)<900
%      
%      text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
%           num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      else
%          
%            text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%            
%           text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[num2str(xyval(zin,8)), char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
%           num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','right','VerticalAlignment', 'top');     
%      end             
%          else  
           
%      if xyval(zin,2)<900
%      
%      text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%       
%         text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
%           num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      
%      else         
%            text(m*xyval(zin,2)+30,m*xyval(zin,1)-30,num2str(xyval(zin,8)),'FontSize',4,'FontName','Times','Color',[.8 .8 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%          
%           text(m*xyval(zin,2)+10,m*xyval(zin,1)-10,[num2str(xyval(zin,8)), char(10) '(' num2str(round((xyval(zin,5)/255))) ',' num2str(round((xyval(zin,6)/255))) ','...
%           num2str(round((xyval(zin,7)/255))) ')'],'FontSize',4,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','right','VerticalAlignment', 'top');     
%      end                     
         end   
         
     end
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
   
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                            set(gcf,'PaperPositionMode','auto')
                                     
%         print([Reshome filesep filename2 'Vector'], '-dpng', '-r300');
export_fig([Reshome2 filesep filename2 filesep filename2 '_vector_direction3'],'-a2', '-m4','-png', '-r300');

                      
  LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR,1) 2*size(LCOLOR,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction.png']);  
  
    LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction2.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR,1) 2*size(LCOLOR,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction2.png']);
  
    LCOLORk=imread([Reshome2 filesep filename2 filesep filename2 '_vector_direction3.png']);
  LCOLORk=LCOLORk(:,228:size(LCOLORk,2)-227,:);
  Imk2=imresize(LCOLORk,[2*size(LCOLOR,1) 2*size(LCOLOR,2)]);
  imwrite(uint8(Imk2),[Reshome2 filesep filename2 filesep filename2 '_vector_direction3.png']);
   close all
      
    resfile = [Reshome2 filesep filename2 filesep filename2 '_Result.xlsx'];
    
    if exist(resfile, 'file')==2
  delete(resfile);
    end
    
    [V,D]=sort(xyval(:,8));
    xyval2=xyval(D,:);
      
    MATT=[xyval2(:,8) center(:,1:2) round(center(:,3:5)/255)];
    nps=length(unique(Imgseg))-2;
    
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end

    BK = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  BK(ii,jj+3) = {MATT(ii,jj)};
    end
      BK(ii,1) = {filename2};
       BK(ii,2) = {imgid};
       BK(ii,3) = {nps};
end
    
BKA=[BKA;BK];
A = {'Cell id','Center X', 'Center Y','Red','Green','Blue'};
C=[A;B];
xlswrite(resfile,C,1,'A1') 
      
    MATT=[xyval(:,8:9) xyval(:,1:2) round(xyval(:,5:7)/255) xyval(:,3:4) round(xyval(:,10:12)/255)];
    
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end
    
A = {'Cell id','Neighbour ID', 'Center X', 'Center Y','Red','Green','Blue','Neighbour X','Neighbour Y','Red N','Green N','Blue N'};
C=[A;B];
xlswrite(resfile,C,3,'A1')

zind=find(sdiffval<1024*0.2 & Rdiffval<((RT+(2*RM/65535)*RT)*65535) & Gdiffval<((RT+(2*GM/65535)*RT)*65535) & Bdiffval<((RT+(BM/65535)*RT)*65535) & cdiffval<((2*RT)*65535));
xyval=xyval(zind,:);

CP=1:2:size(xyval,1)-1;
xyval=xyval(CP,:);

    MATT=[xyval(:,8:9) xyval(:,1:2) round(xyval(:,5:7)/255) xyval(:,3:4) round(xyval(:,10:12)/255)];
    
    B = cell(size(MATT,1),size(MATT,2));
for ii=1:size(MATT,1)
    for jj=1:size(MATT,2)
  B(ii,jj) = {MATT(ii,jj)};
    end
end
    
A = {'Cell id','Neighbour ID', 'Center X', 'Center Y','Red','Green','Blue','Neighbour X','Neighbour Y','Red N','Green N','Blue N'};
C=[A;B];
xlswrite(resfile,C,2,'A1')

end

AK = {'Image name','Image id','FOXJ1 positive','Cell id','Center X', 'Center Y','Red','Green','Blue'};
C=[AK;BKA];

   resfile = [Reshome2 filesep 'Result.xlsx'];

    if exist(resfile, 'file')==2
  delete(resfile);
    end

xlswrite([Reshome2 filesep 'Result.xlsx'],C,1,'A1')






