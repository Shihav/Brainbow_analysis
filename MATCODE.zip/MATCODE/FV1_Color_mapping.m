clear all
close all
clc

Datahome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFF';
Reshome='G:\Marie_Brainbow2\S�lection Shihav\Manip 6\TIFFR';

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name};
% 
for imgid=4:numel(Types)
     
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
     
     info = imfinfo(segname);
        num_images = numel(info);
        Imgseg=[];
        for k = 1:num_images
            I = imread(segname, k);
              Imgseg(:,:,k)=I;   
              k
        end        
        pcells=unique(Imgseg);
        
                oriname=[Datahome filesep filename2 '.tif'];
     
          info = imfinfo(oriname);
        num_images = numel(info);

        ImgR=[];
        kn=1;
        for k = 1:4:num_images
            I = imread(oriname, k);
              ImgR(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgG=[];
        kn=1;
        for k = 2:4:num_images
            I = imread(oriname, k);
              ImgG(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgB=[];
        kn=1;
        for k = 3:4:num_images
            I = imread(oriname, k);
              ImgB(:,:,kn)=I;   
              kn=kn+1
        end
        
        ImgGR=[];
        kn=1;
        for k = 4:4:num_images
            I = imread(oriname, k);
              ImgGR(:,:,kn)=I;   
              kn=kn+1
        end
        
ImgRp=uint16(65535.*(ImgR./4096));
ImgGp=uint16(65535.*(ImgG./4096));
ImgBp=uint16(65535.*(ImgB./4096));
ImgGRp=uint16(65535.*(ImgGR./4096));

[Img11r,zval11r]=max(ImgRp,[],3);
[Img11g,zval11g]=max(ImgGp,[],3);
[Img11b,zval11b]=max(ImgBp,[],3);

[Img11gr,zval11gr]=max(ImgGRp,[],3);

CO=uint16(65535*mat2gray(cat(3,Img11r,Img11g,Img11b)));
CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
COF=CO+0.6*CGO;

imwrite(uint16(65535*mat2gray(COF)),[Reshome filesep filename2 'FmaxVp.png']);  

imwrite(uint16(65535*mat2gray(CO)),[Reshome filesep filename2 'FmaxVpC.png']);  
          
     ImgR(Imgseg==0)=0;
     ImgG(Imgseg==0)=0;
     ImgB(Imgseg==0)=0;
     ImgGR(Imgseg==0)=0;     
     
     ImgRk=uint16(65535.*(ImgR./4096));
ImgGk=uint16(65535.*(ImgG./4096));
ImgBk=uint16(65535.*(ImgB./4096));
ImgGRk=uint16(65535.*(ImgGR./4096));

[Img11r,zval11r]=max(ImgRk,[],3);
[Img11g,zval11g]=max(ImgGk,[],3);
[Img11b,zval11b]=max(ImgBk,[],3);

[Img11gr,zval11gr]=max(ImgGRk,[],3);

CO=uint16(65535*mat2gray(cat(3,Img11r,Img11g,Img11b)));
CGO=uint16(65535*mat2gray(cat(3,Img11gr,Img11gr,Img11gr)));
COF=CO+0.6*CGO;

imwrite(uint16(65535*mat2gray(COF)),[Reshome filesep filename2 'FmaxV.png']);

imwrite(uint16(65535*mat2gray(CO)),[Reshome filesep filename2 'FmaxVC.png']);


Imgsegk=Imgseg;
% Imgsegk(Imgseg==0)=max(pcells)+1;
% Imgsegk=max(pcells)+1-Imgsegk;
classmap=max(Imgsegk,[],3);
classmap(classmap==max(pcells))=0;
      
       T1=im2bw(uint16(65535*(classmap>0)));
                           T2=T1;
                           T3 = imclearborder(T2);

classmap(T3==0)=0; 
pcells=unique(classmap);

         for nk=2:length(pcells)            
            val=pcells(nk);            
            sizek=sum(sum(classmap==val));            
            if sizek<225
                classmap(classmap==val)=0;
            end
            nk    
         end
         
pcells=unique(classmap);
classmap2=classmap;
classmap2(:)=0;
 h = fspecial('gaussian',[3 3],2);
         for nk=2:length(pcells)
            
            val=pcells(nk);
            I2cpsegb=classmap==val;
                           Im47=imfilter(I2cpsegb>0,h,'replicate');
             classmap2(Im47>0)=val;                
nk
         end
       

classmapR=uint16(0*ones(size(classmap,1),size(classmap,2)));
classmapG=uint16(0*ones(size(classmap,1),size(classmap,2)));
classmapB=uint16(0*ones(size(classmap,1),size(classmap,2)));
pcells=unique(classmap2);
 se=ones(3);

         for nk=2:length(pcells)
            
            val=pcells(nk);
             object = classmap2==val;
                              objectcore = imerode(object, se);
                              objectbor=object-objectcore;
                            
                              
                              RV=quantile(Img11r(objectcore==1),.95);
                              GV=quantile(Img11g(objectcore==1),.95);
                              BV=quantile(Img11b(objectcore==1),.95);
                               GRV=quantile(Img11gr(objectcore==1),.95);
                              
                              CV=max([RV GV BV]);
                              
                              if CV>65535*0.15
                                  
                                    classmapR(objectbor==1)=2*(RV+0.1*GRV);
                              classmapG(objectbor==1)=2*(GV+0.1*GRV);
                              classmapB(objectbor==1)=2*(BV+0.1*GRV);
                              
                              classmapR(objectcore==1)=RV+0.1*GRV;
                              classmapG(objectcore==1)=GV+0.1*GRV;
                              classmapB(objectcore==1)=BV+0.1*GRV;
                              
                              else
                                  
%                                    classmapR(objectcore==1)=65535;
%                               classmapG(objectcore==1)=65535;
%                               classmapB(objectcore==1)=65535; 
%                               
                                classmapR(object==1)=15000;
                              classmapG(object==1)=15000;
                              classmapB(object==1)=15000;
                              end
            
% %             R=mean(Img11r(classmap2==val));  
% %             G=mean(Img11g(classmap2==val));  
% %             B=mean(Img11b(classmap2==val));  
% %        
%              classmapR(classmap2==val)=R;  
%              classmapG(classmap2==val)=G;  
%              classmapB(classmap2==val)=B;  
nk
         end
        
         classmap3=uint16((cat(3,classmapR,classmapG,classmapB)));
imwrite(uint16(classmap3),[Reshome filesep filename2 'Classmap3.png']);
%   
end