function makes_cell_images(ADATAS,sisters,idx,name,multp,multn,Reshome3,border)


make_hue_plot2(ADATAS)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'Hue' num2str(14) name],'-a2', '-m6','-p0','-q101','-png', '-r600');

make_hue_plot2S(ADATAS)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'HueS' num2str(14) name],'-a2', '-m6','-p0','-q101','-png', '-r600');


PSDATA=ADATAS(ADATAS(:,1)==1,:);
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM2.png']);

mult=multp;
if border == 0
make_CL;

elseif border==1
 make_CL_B;   
end
COF1=CL;
COFB=uint16(zeros(size(COF1)));

NSDATA=ADATAS(ADATAS(:,1)==2,:);
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM2.png']);
% LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
imwrite(COF1+COF2,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) name '.png']);

%   figure
%   imshow(COFB);hold on
% 
%      for zin=1:size(xyvals,1) 
%          
%          if xyvals(zin,14)==1 && xyvals(zin,15)==1
%              CC=[1 1 1];
%          elseif xyvals(zin,14)==1 && xyvals(zin,15)==2
%              CC=[1 1 0];
%          elseif xyvals(zin,14)==2 && xyvals(zin,15)==1
%              CC=[1 1 0]; 
%          elseif xyvals(zin,14)==2 && xyvals(zin,15)==2
%              CC=[0.5 1 .5];
%          end
%          
%    U=m*xyvals(zin,4)-m*xyvals(zin,2);
%    V=m*xyvals(zin,3)-m*xyvals(zin,1);
% %    Z=sqrt(U.^2+V.^2);   
%   quiver(m*xyvals(zin,2),m*xyvals(zin,1),U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',LW) ; hold on
%      end
%    
% set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
% 
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) name 'L'],'-a2', '-m6','-p0','-q101','-png', '-r600');
% 
% mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK']);
% 
% AG=imread([Reshome3 filesep 'mosaicG.png']);
% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14) name 'L' '.png']);
% if size(A,3)==1
%     A=cat(3,A,A,A);
% end
% A=imresize(A,[size(LCOLORG,1) size(LCOLORG,2)]);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14)  name 'L' '.png']);
% 
% A1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' '36ZLINK_idx' num2str(idx) 'ang' num2str(14)  name '.png']);
% A1=imresize(A1,[size(LCOLORG,1) size(LCOLORG,2)]);
% imwrite(A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14)  name '.png']);
% 
% A=remove_line(A,A1);
% imwrite(256*uint16(A)+A1,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14)  name 'LO' '.png']);
% imwrite(256*uint16(A)+A1+0.5*AG,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MLINK\' '36MZLINK_idx' num2str(idx) 'ang' num2str(14)  name 'LOG' '.png']);
% 
% 
