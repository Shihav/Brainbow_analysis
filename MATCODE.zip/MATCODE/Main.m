% FV2_FeatureAnalysis2

worklist =1:numel(Types);
RANDN=100;
FV2_FeatureAnalysis5
% FV2_FeatureAnalysis4
% FV2_FeatureAnalysis3
% FV2_FeatureAnalysis6