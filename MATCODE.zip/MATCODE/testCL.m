clear all
close all
clc
addpath('C:\Users\shiha\Downloads\GMM\GMM')

load CL



A=sum(CL,1);
B=[A(1:12) sum(A(13:22)) sum(A(23:32))];
C=B./sum(B)


[INDEX, Mu, Variances] = GMM(C, 2,100)
[PC,INDEX] = Cluster_Probability(C,Mu)
mu = Compute_Mean_for_Cluster(C,Mu,Variances,PC,INDEX)

% C=[fliplr(C) C]
figure
bar(C')

hold on
bar(find(INDEX==2),C(INDEX==2))

set(gcf,'color','w');
grid off
box off
% axis off
%      axis equal
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure 

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF2\' 'CLONES_DISTRIBUTION_MIXTURE_MODEL'],'-a1', '-m3','-p0','-q101','-png', '-r600');
  % screenposition = get(gcf,'Position');

% [Priors2, Mu2, Sigma2] = EM_init_kmeans(C, 2);
% [Priors2, Mu2, Sigma2] = EM(C, Priors2, Mu2, Sigma2);
% clear expData;
% expData(1,:) = linspace(1, 26, 26);
% [expData(2:2,:), expSigma] = GMR(Priors2, Mu2, Sigma2,  expData(1,:), [1], [2:2]);

% options = statset('Display','final');
% obj = fitgmdist(C,2,'Options',options);

binCtrs=1:32;
prob = B;
Life=B';
figure
plot(binCtrs,prob,'ko');hold on
%% finding the number of components 
numComponents=1;
paramEsts= gmdistribution.fit(Life,numComponents)  
%mu of mixture of gaussians of 4 components
MU=[paramEsts.mu(1);paramEsts.mu(2)];
SIGMA=cat(3,[paramEsts.Sigma(1)],[paramEsts.Sigma(2)]);
PPp=[paramEsts.PComponents(1),paramEsts.PComponents(2)];
objA = gmdistribution(MU,SIGMA,PPp);
plot(binCtrs',pdf(objA,binCtrs'),'r-','linewidth',2)
% toc

