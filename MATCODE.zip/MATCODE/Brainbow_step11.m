close all
clc

figure

mat=sum(DF);
pcells=unique(mat);
val=[]
for k=1:length(pcells)
    
    TD=sum(mat==pcells(k));
    
    val(k,1)=[TD];
    
end

hBar=bar(val,1); 
colk=bone(length(val))/1.25;

%                         hBarChildren = get(hBar, 'Children');
%                         index = 1:length(val);
%                         set(hBarChildren, 'CData', index);
%                         colormap(colk);

% y=[val];
% x=1:length(val);
% for i1=1:numel(y)
%     text(x(i1),y(i1)+2,num2str(y(i1),'%0.0f'),'rotation', 0,...
%                'HorizontalAlignment','center',...
%                'VerticalAlignment','bottom','FontSize', 6,'FontName','Times')
% end

xlim([-1 length(val)+1])
ylim([0 25])

% xlabel('Conditions','FontSize', 20,'FontName','Times');
                                            ylabel('Cell count', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Brainbow connection type'], 'FontSize',24,'FontName','Times') % y-axis label  
                                            
                                             set(gca,'XTick',1:10:length(val))
 ax = gca;
 set(ax,'XTickLabel',pcells(1:10:length(val)));

  box off

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',8);
b = get(gca,'YTickLabel');
set(gca,'YTickLabel',b,'FontName','Times','fontsize',8);

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
                                          
print([Reshome3 filesep  'Brainbow connection typeM'], '-dpng', '-r300'); 








figure
hBar=bar([size(tDATA,1) size(xyval,1)],0.5); 
colk=bone(2)/1.25;

                        hBarChildren = get(hBar, 'Children');
                        index = 1:2;
                        set(hBarChildren, 'CData', index);
                        colormap(colk);

y=[size(tDATA,1) size(xyval,1)];
x=1:2;
for i1=1:numel(y)
    text(x(i1),y(i1)+20,num2str(y(i1),'%0.0f'),'rotation', 0,...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end

xlim([0 3])
ylim([0 900])

% xlabel('Conditions','FontSize', 20,'FontName','Times');
                                            ylabel('Cell count', 'FontSize', 20,'FontName','Times') % y-axis label
                                            title(['Brainbow coupling'], 'FontSize',24,'FontName','Times') % y-axis label  
                                            
                                             set(gca,'XTick',1:2)
 ax = gca;
 set(ax,'XTickLabel',{'Total cells', 'Coupled cells'});

  box off

a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'FontName','Times','fontsize',18);
b = get(gca,'YTickLabel');
set(gca,'YTickLabel',b,'FontName','Times','fontsize',18);

ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
%                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                            set(gcf,'PaperPositionMode','auto')
                                          
print([Reshome3 filesep  'Brainbow couplingM'], '-dpng', '-r300'); 

% RDT=1;
% RDS=[];
% for rtimes=1:RDT
%    RtDATA=DATA(round((size(DATA,1)-1)*rand(size(tDATA,1),1))+1,6:11);
% tDATA=[DATA(:,1:5) RtDATA];
% 
%          m=4;
%              
% %% check conditions    
%     RT=[];
%     GT=[];
%     BT=[];
%     RSTD=[];
%     GSTD=[];
%     BSTD=[];
%     Rdiff=[];
%     Gdiff=[];
%     Bdiff=[];
%     for pn1=1:size(tDATA,1)
%         for pn2=1:size(tDATA,1)
% %                 RMEAN(pn1,pn2)=mean([tDATA(pn1,6) tDATA(pn2,6)]);
% %                  GMEAN(pn1,pn2)=mean([tDATA(pn1,7) tDATA(pn2,7)]);
% %                   BMEAN(pn1,pn2)=mean([tDATA(pn1,8) tDATA(pn2,8)]);
%             
%                 RSTD(pn1,pn2)=max([tDATA(pn1,9) tDATA(pn2,9)]);
%                  GSTD(pn1,pn2)=max([tDATA(pn1,10) tDATA(pn2,10)]);
%                   BSTD(pn1,pn2)=max([tDATA(pn1,11) tDATA(pn2,11)]);
%                                   
%                 Rdiff(pn1,pn2)=tDATA(pn1,6)-tDATA(pn2,6);
%                  Gdiff(pn1,pn2)=tDATA(pn1,7)-tDATA(pn2,7);
%                   Bdiff(pn1,pn2)=tDATA(pn1,8)-tDATA(pn2,8);
%                   
%                 RT(pn1,pn2)=abs(tDATA(pn1,6)-tDATA(pn2,6))./tDATA(pn1,6);
%                  GT(pn1,pn2)=abs(tDATA(pn1,7)-tDATA(pn2,7))./tDATA(pn1,7);
%                   BT(pn1,pn2)=abs(tDATA(pn1,8)-tDATA(pn2,8))./tDATA(pn1,8);
%         end
%     end
%     
%       SD=pdist2(tDATA(:,4:5),tDATA(:,4:5));
%     direction=(abs(Rdiff)+abs(Gdiff)+abs(Bdiff))-abs(Rdiff+Gdiff+Bdiff)>10;
%     
% 
%     RD=pdist2(tDATA(:,6),tDATA(:,6));
%     Rvarv=RSTD.*varv;
%     RD(RD>=Rvarv)=255;
%     RD(SD==0)=254;
%     
%     GD=pdist2(tDATA(:,7),tDATA(:,7));
%     Gvarv=GSTD.*varv;
%     GD(GD>=Gvarv)=255;
%     GD(SD==0)=254;
%     
%     BD=pdist2(tDATA(:,8),tDATA(:,8));
%     Bvarv=BSTD.*varv;
%     BD(BD>=Bvarv)=255;
%     BD(SD==0)=254;
% 
%    
%     DF=RD<254 & GD<254 & BD<254 & direction==0 & RT<5 & GT<5 & BT<5;
% 
% NB=[];    
% DFF=sum(DF);
%         for cp2=1:size(tDATA,1)
%             if DFF(cp2)>0;
%             PO=find(DF(cp2,:)==1);
%                  [list,POS]= min(SD(cp2,PO));
%                  NB(cp2,1:2)=[PO(POS) list];
%             end
%         end
% 
% cp=1;
%     xyval=[];
%     
%     for cp1=1:size(tDATA,1)
%          if DFF(cp1)>0;
%            cp2=NB(cp1,1);    
%                   if cp1 == NB(cp2,1)
% %                       cp2=
%                      xyval(cp,1:2)=[tDATA(cp1,4) tDATA(cp1,5)];
%                         xyval(cp,3:4)=[tDATA(cp2,4) tDATA(cp2,5)];
%                          xyval(cp,5:7)=[tDATA(cp1,6) tDATA(cp1,7) tDATA(cp1,8)];
%                          xyval(cp,8:9)=[cp1 cp2];
%                            xyval(cp,10:12)=[tDATA(cp2,6) tDATA(cp2,7) tDATA(cp2,8)];
%                            cp=cp+1;
%                   end
% %             end
%         end
%     end 
%    RDS(rtimes)=size(xyval,1);
%    rtimes
% end  
%      
% 
% figure
% hBar=bar([size(tDATA,1) 340 mean(RDS)],0.5); 
% colk=bone(3)/1.25;
% 
%                         hBarChildren = get(hBar, 'Children');
%                         index = 1:3;
%                         set(hBarChildren, 'CData', index);
%                         colormap(colk);
% 
% y=[size(tDATA,1) 340 mean(RDS)];
% x=1:3;
% for i1=1:numel(y)
%     text(x(i1),y(i1)+20,num2str(y(i1),'%0.0f'),'rotation', 0,...
%                'HorizontalAlignment','center',...
%                'VerticalAlignment','bottom')
% end
% 
% xlim([0 4])
% ylim([0 900])
% 
% % xlabel('Conditions','FontSize', 20,'FontName','Times');
%                                             ylabel('Cell count', 'FontSize', 20,'FontName','Times') % y-axis label
%                                             title(['Brainbow coupling vs random'], 'FontSize',24,'FontName','Times') % y-axis label  
%                                             
%                                              set(gca,'XTick',1:3)
%  ax = gca;
%  set(ax,'XTickLabel',{'Total cells', 'Coupled cells', 'Random'});
% 
%   box off
% 
% a = get(gca,'XTickLabel');
% set(gca,'XTickLabel',a,'FontName','Times','fontsize',18);
% b = get(gca,'YTickLabel');
% set(gca,'YTickLabel',b,'FontName','Times','fontsize',18);
% 
% ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
% %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                                             set(gcf,'PaperPositionMode','auto')
%                                           
% print([Reshome3 filesep  'Brainbow coupling Random'], '-dpng', '-r300'); 
