if idx==4
pic=uint16(zeros(4*1024,5*1024,3));
DX=5;
DY=5;
elseif idx==3
pic=uint16(zeros(6*1024,5*1024,3));
DX=5;
DY=1910;
elseif idx==2
pic=uint16(zeros(4*1024,5*1024,3));
DX=5;
DY=5;
elseif idx==5
pic=uint16(zeros(3*1024,7*1024,3));
DX=5;
DY=935;
elseif idx==1
pic=uint16(zeros(3*1024,3*1024,3));
DX=5;
DY=890;


elseif idx==7
pic=uint16(zeros(8*1024,4*1024,3));
DX=5;
DY=1910;

elseif idx==8
pic=uint16(zeros(6*1024,7*1024,3));
DX=5;
DY=3820;

elseif idx==11
pic=uint16(zeros(7.5*1024,4*1024,3));
DX=1085;
DY=520;

elseif idx==12
pic=uint16(zeros(2.25*1024,2.5*1024,3));
DX=5;
DY=610;

elseif idx==13
pic=uint16(zeros(3*1024,4*1024,3));
DX=6;
DY=6;

elseif idx==14
pic=uint16(zeros(2*1024,3*1024,3));
DX=6;
DY=6;

elseif idx==15
pic=uint16(zeros(2*1024,2*1024,3));
DX=6;
DY=6;

elseif idx==16
pic=uint16(zeros(4*1024,4*1024,3));
DX=6;
DY=26;

elseif idx==17
pic=uint16(zeros(2*1024,5*1024,3));
DX=6;
DY=6;

elseif idx==18
pic=uint16(zeros(4*1024,6*1024,3));
DX=6;
DY=6;



end