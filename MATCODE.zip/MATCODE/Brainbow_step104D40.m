clear all
close all

COLORA=[];

m{3}=[3139 785 2245 854];
sisters=100;
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL']);


for idx=[3]
     mn=m{idx};
    idxt=idx;
    
    loadaddress2;
    
   BORDER=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'MANUALN1.tif']);
   LABELM= bwlabel(1-BORDER>0,8);
   LABELM(LABELM<2)=0;
   
   LABELM=imerode(LABELM,ones(3));
   
%    LCOLORLM=imread([Reshome3 filesep 'NFinalmapM2.png']);
   
   LCOLORL=imread([Reshome3 filesep 'NFinalmapM4.png']);
   LCOLORCP=imread([Reshome3 filesep 'NmosaicOP.png']);
   AG=LCOLORL;
   LCOLORL(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:)=LABELM;

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
                       
                           labeledImage = bwlabel(I2cpsegb>0,8);
                           LCOLORL=labeledImage;

LCOLORLM=imdilate(LCOLORL,ones(5,5));

                          for ind=1:3
                          col_img2a=LCOLORCP(:,:,ind); 
                          col_img2a(LCOLORLM==0)=0;
                          LCOLORCP(:,:,ind)=col_img2a;
                          end   
figure
imshow(LCOLORCP);

 imwrite(LCOLORCP(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'MANCLN1.png']);

imwrite(LCOLORCP,[Reshome3 filesep 'NmosaicO2.png']);
imwrite(uint16(LCOLORLM),[Reshome3 filesep 'NFinalmapM2.png']);

imwrite(LCOLORL,[Reshome3 filesep 'NFinalmapM.png']);
    
    BORDER=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'MANUALP1.tif']);
   LABELM= bwlabel(1-BORDER>0,8);
   LABELM(LABELM<2)=0;
   
   LABELM=imerode(LABELM,ones(3));
   
%    LCOLORLM=imread([Reshome3 filesep 'NFinalmapM2.png']);
   
   LCOLORL=imread([Reshome3 filesep 'PFinalmapM4.png']);
   LCOLORCP=imread([Reshome3 filesep 'PmosaicOP.png']);
   AG=LCOLORL;
   LCOLORL(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:)=LABELM;

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
                       
                           labeledImage = bwlabel(I2cpsegb>0,8);
                           LCOLORL=labeledImage;

LCOLORLM=imdilate(LCOLORL,ones(5,5));

                          for ind=1:3
                          col_img2a=LCOLORCP(:,:,ind); 
                          col_img2a(LCOLORLM==0)=0;
                          LCOLORCP(:,:,ind)=col_img2a;
                          end   
figure
imshow(LCOLORCP);
imwrite(LCOLORCP(mn(1):size(AG,1)-mn(2),mn(3):size(AG,2)-mn(4),:),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\MANUAL\' 'MANCLP1.png']);
imwrite(LCOLORCP,[Reshome3 filesep 'PmosaicO2.png']);
imwrite(uint16(LCOLORLM),[Reshome3 filesep 'PFinalmapM2.png']);

imwrite(LCOLORL,[Reshome3 filesep 'PFinalmapM.png']);   
 
close all
    
end