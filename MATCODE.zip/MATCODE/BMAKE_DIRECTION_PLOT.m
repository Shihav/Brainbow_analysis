% tADATA=ADATA(unique(xyval(:,8)),:);

%   figure
  
close all
LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
m=1; 
  figure
  imshow(LCOLORG*0.2);hold on
     
%      if idx==7
%      LW=0.25;
%      else
%      LW=0.5;
%      end
     
  xyvalt=xyval;
  xyvalt(xyvalt(:,14)==2 & xyvalt(:,15)==2,:)=[];
%    dif=[];
%   for zin=1:1:size(xyval,1) 
%       
%       dif(zin)=xyval(zin,2)<xyval(zin,4);
%       
%   end
%      
%   xyvalt(dif==0,:)=[]; 
     
     for zin=1:size(xyvalt,1) 
         
         if xyvalt(zin,14)==1 && xyvalt(zin,15)==1
             CC=[1 1 1];
         elseif xyvalt(zin,14)==1 && xyvalt(zin,15)==2
             CC=[1 1 0];
         elseif xyvalt(zin,14)==2 && xyvalt(zin,15)==1
             CC=[1 1 0]; 
         elseif xyvalt(zin,14)==2 && xyvalt(zin,15)==2
             CC=[0.5 1 .5];
         end
         
   U=m*xyvalt(zin,4)-m*xyvalt(zin,2);
   V=m*xyvalt(zin,3)-m*xyvalt(zin,1);
   Z=sqrt(U.^2+V.^2);   
    U=100*m*U./Z;
    V=100*m*V./Z;
   
         [arrowx,arrowy]=vekplot2(m*((xyvalt(zin,2)+xyvalt(zin,4))/2),m*((xyvalt(zin,1)+xyvalt(zin,3))/2),U,V,1);
     plot(arrowx,arrowy,'Color',CC,'linewidth',5*LW);
 
%   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,1,'color',CC,'maxheadsize',0.025,'linewidth',LW) ; hold on
%   dg=pdist2(xyval(zin,1:2),xyval(zin,3:4))*.31;
%     text(m*mean([xyval(zin,2) xyval(zin,4)])+1,m*mean([xyval(zin,1) xyval(zin,3)])-1,[char(10) num2str(round(dg))],'FontSize',3,'FontName','Times','Color',[1 1 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');

     end
   
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\Division\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_DD'],'-a2', '-m6','-p0','-q101','-png', '-r600');




make_circ_hist

set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure  

set(gcf,'color','w');   
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\Division\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_HIST'],'-a2', '-m6','-p0','-q101','-png', '-r600');



%    dif=[];
%   for zin=1:1:size(xyvalt,1) 
%       
%       dif(zin)=xyvalt(zin,2)<xyvalt(zin,4);
%       
%   end
%      
%   xyvalt(dif==0,:)=[]; 






wsize=900;
shift=50;
circ=1;

xyvalk=xyvalt;
  figure
  imshow(LCOLORG*0.2);hold on
NMAX=4;
CCN=[0 1 1];

make_local_vectors;
    
%      quiver(m*XP(2:end),m*YP(2:end),UPm(2:end),VPm(2:end),0,'color',[1 0 0],'maxheadsize',1,'linewidth',1)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\Division\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_DDG'],'-a2', '-m6','-p0','-q101','-png', '-r600');


xyvalk=xyvalt(xyvalt(:,14)==1 & xyvalt(:,15)==1,:);
  figure
  imshow(LCOLORG*0.2);hold on
NMAX=2;
CCN=[1 1 1];

make_local_vectors;

xyvalk=xyvalt((xyvalt(:,14)==1 & xyvalt(:,15)==2) | (xyvalt(:,14)==2 & xyvalt(:,15)==1),:);
NMAX=2;
CCN=[1 1 0];

make_local_vectors;

xyvalk=xyvalt(xyvalt(:,14)==2 & xyvalt(:,15)==2,:);
NMAX=2;
CCN=[0.5 1 .5];

make_local_vectors;

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\Division\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_DDL'],'-a2', '-m6','-p0','-q101','-png', '-r600');