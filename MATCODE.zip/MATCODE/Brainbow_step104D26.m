clear all
close all
clc

load PMATSEARCH.mat PMAT
% load PMATRAND.mat PMAT
 ncoup=PMAT(3,3,:,10,5);
 ncoup=ncoup(:);
 
 Rmat=ncoup(1)
 
 RRmat=mean(ncoup(2:end))
 
[h,p]=ttest2(ncoup(1),ncoup(2:end)) 

Pmat=p;

minp=0.0
maxp=0.85

minpR=0.0
maxpR=85

    figure
      
        [nc,hc]=hist(ncoup(2:end)',linspace(minp,maxp,101));
 nc=nc/sum(nc);
 hck=hc;
 nck=nc;
       
    nc = smooth(nc,15,'loess');
    nc(nc<0)=0;
    nc=nc./sum(nc);
 
    Colors=[0.5 0.5 0.5];
  hc=hc*100;     
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on


  text(5, .17,['P = ' num2str(p,'%10.2e')],'color',Colors/1.5,'FontSize', 14,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
  
  text(5, .14,[num2str(length(ncoup)-1) ' random runs'],'color',[0.4 0.4 0.4]/1.5,'FontSize', 14,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
  
%   text(100*DATA(nk,1)+3, .10,['\leftarrow' num2str(100*DATA(nk,1),'%.2f')],'color',[0.2 0.4 0.2],'FontSize', 14,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
       

xlim ([minpR maxpR])

       hold on
       
 Colors=[0.1 0.65 0.1];
hold on

hc=100*[ncoup(1,1)'-.0 ncoup(1,1)'+.02];

     
nc=[0.18 0.18];

       
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on

ylim([0 0.18])

pbaspect([12,5,1])
set(gcf,'color','w');  


 ylabel('Probability','FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label
xlabel('Origin from symmetric division (%)','FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label
% set(gca,'xtick',[])
set(gca,'ytick',[])
  grid off
  set(gca, 'Ticklength', [0 0])
%                                                 box off
box off

    a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
                                                    
  

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\PLOT\' 'COMP_DIST_M'],'-a2', '-m2','-p0.02','-png', '-r200');
% close all

for idx=[1 2 3 5 7 8]

 ncoup=PMAT(3,3,:,idx,5);
 ncoup=ncoup(:);
 
 Rmat=ncoup(1)
 
 RRmat=mean(ncoup(2:end))
 
[h,p]=ttest2(ncoup(1),ncoup(2:end)) 

Pmat=p;

minp=0.0
maxp=0.85

minpR=0.0
maxpR=85

    figure
      
        [nc,hc]=hist(ncoup(2:end)',linspace(minp,maxp,101));
 nc=nc/sum(nc);
 hck=hc;
 nck=nc;
       
    nc = smooth(nc,15,'loess');
    nc(nc<0)=0;
    nc=nc./sum(nc);
 
    Colors=[0.5 0.5 0.5];
  hc=hc*100;     
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on


  text(5, .17,['P = ' num2str(p,'%10.2e')],'color',Colors/1.5,'FontSize', 14,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
  
  text(5, .14,[num2str(length(ncoup)-1) ' random runs'],'color',[0.4 0.4 0.4]/1.5,'FontSize', 14,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
  
%   text(100*DATA(nk,1)+3, .10,['\leftarrow' num2str(100*DATA(nk,1),'%.2f')],'color',[0.2 0.4 0.2],'FontSize', 14,'HorizontalAlignment','left','VerticalAlignment', 'top','FontName','Times');
       

xlim ([minpR maxpR])

       hold on
       
 Colors=[0.1 0.65 0.1];
hold on

hc=100*[ncoup(1,1)'-.0 ncoup(1,1)'+.02];

     
nc=[0.18 0.18];

       
h=area(hc,nc,'FaceColor',Colors/1,'LineStyle','-','LineWidth',2,'EdgeColor','None');hold on
child=get(h,'Children');
set(child,'FaceAlpha',0.75); 

plot(hc,nc,'color',Colors/1.5,'LineStyle','-','LineWidth',2);hold on

ylim([0 0.18])

pbaspect([12,5,1])
set(gcf,'color','w');  


 ylabel('Probability','FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label
xlabel('Origin from symmetric division (%)','FontSize', 12,'FontWeight','bold','FontName','times') % y-axis label
% set(gca,'xtick',[])
set(gca,'ytick',[])
  grid off
  set(gca, 'Ticklength', [0 0])
%                                                 box off
box off

    a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times','FontWeight','bold');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')

%                                                         print([cd '\Area\' 'Replicates_P1_BETACAT_SAS6' '.png'], '-dpng', '-r300');
                                                    
  

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\PLOT\' 'COMP_DIST_M_' num2str(idx)],'-a2', '-m2','-p0.02','-png', '-r200');
% close all
end