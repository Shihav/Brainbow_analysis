make_hue_plot2(ADATA)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\HUE\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_F_' num2str(darkest_cells_cutid) '_HR'],'-a2', '-m6','-p0','-q101','-png', '-r600');

% make_hue_plot2(ADATAB)
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_F_' num2str(darkest_cells_cutid) '_HR'],'-a2', '-m6','-p0','-q101','-png', '-r600');


PSDATA=ADATA(ADATA(:,1)==1,:);
% make_hue_plot2(PSDATA)
tDATA=PSDATA;
LCOLORC=imread([Reshome3 filesep 'PmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'PFinalmapM2.png']);

% LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
% LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);

mult=multp;
make_CL;
COF1=CL;
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);

%NSDATA=tADATA(tADATA(:,1)==2,:);
NSDATA=ADATA(ADATA(:,1)==2,:);
% make_hue_plot2(NSDATA)
tDATA=NSDATA;
LCOLORC=imread([Reshome3 filesep 'NmosaicO2.png']);
LCOLORL=imread([Reshome3 filesep 'NFinalmapM2.png']);

mult=multn;
make_CL;
COF2=CL;
m=1;  
% imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
  
% COF1=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(16) '.png']);
% COF2=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINALANG\' 'DLINK_idx' num2str(idx) 'loop' num2str(17) '.png']);
%     
imwrite(uint16(COF1+COF2),['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_FR_' num2str(darkest_cells_cutid) '.png']);


%   figure
%   imshow(COF1+COF2);hold on
%   tDATA=PSDATA;
%      for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));  
% %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%      
%    tDATA=NSDATA;
%      for zin=1:size(tDATA,1)  
%            DATACM1=rgb2hsv(tDATA(zin,6:8));  
% %            text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(tDATA(zin,2))],'FontSize',3,'FontName','Times','Color',[1 0.7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
% %               text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) char(10) num2str(round(360*DATACM1(:,1)))],'FontSize',3,'FontName','Times','Color',[0.7 0.7 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%      end
%      
%      set(gca,'XTick',[]) % Remove the ticks in the x axis!
% set(gca,'YTick',[]) % Remove the ticks in the y axis
% set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    
% 
% export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(sisters) '\FILTER\' 'ZLINK_idx' num2str(idx) 'ang' num2str(14) '_FR_' num2str(darkest_cells_cutid)],'-a2', '-m6','-p0','-q101','-png', '-r600');