clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=80;
Bdiff_allowed=80;
Hdiff_allowed=6.5;
Sdiff_allowed=90;
% Sdiff_allowed2=100;
load_angle=0;

% rlist{1}=[81,5,62,64,2,3,40,54,79];
% rlist{2}=[1,4,12,14,7,28,53,21,32];
% rlist{3}=[1,2,3,17,22,37,46,55,42,53,57,62,107];
% rlist{5}=[1,2,4];
% rlist{7}=[1,20,24,22,16,19,25,29,37,40,43,44,50,48,52];
% rlist{8}=[10,11,17,22,18,27,43];

rlist{1}=[];
rlist{2}=[11,12];
rlist{3}=[];
rlist{5}=[];
rlist{7}=[];
rlist{8}=[];


for idx=[5]
     
loadaddress;
% load('DATA1')

load([Reshome2 filesep 'all.mat'],'DATA'); 
cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./rangek;

load([Reshome2 filesep 'all2.mat'],'tDATA','DATACM'); 

load(['FOX' num2str(idx)],'centerF'); 

SPACE=min((pdist2(centerF(:,1:2),tDATA(:,4:5))*.31),[],2);

centerF(SPACE>dist_from_brainbow_allowed,:)=[];

tDATA(rlist{idx},:)=[];
DATACM(rlist{idx},:)=[];

save([Reshome2 filesep 'all3.mat'],'tDATA','DATACM'); 

make_hue_plot(tDATA,DATACM)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'HUE00'],'-a2', '-m6','-p0','-q101','-png', '-r600');

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
 
%  if idx==7
%      LCOLORL=imdilate(LCOLORL,ones(9,9));
%  end
  
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);

 for cell=1:size(tDATA,1)
     
     val=LCOLORL(tDATA(cell,4),tDATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000   
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell;
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.0*CO;
m=1;
    
     figure
  imshow(COF);hold on
  
%   imwrite(COF,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(3) '.png']);
  
%      for zin=1:size(xyval,1)   
%          
%    U=m*xyval(zin,4)-m*xyval(zin,2);
%    V=m*xyval(zin,3)-m*xyval(zin,1);
%    Z=sqrt(U.^2+V.^2);   
%   quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.75) ; hold on
% %          end
% 
%      end
     
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));
%            HUE1=DATACM1(:,1)*360;
%            x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
%            y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
%          text(x1+3,y1-5,num2str(zin),'FontSize',3,'FontName','Times','Color',[0 0 0],'HorizontalAlignment','center','VerticalAlignment', 'top');  
%         
%          text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',2.5,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
%           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     
     
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(3)],'-a2', '-m6','-p0','-q101','-png', '-r600');
%close all


tDATACM=DATACM;

if load_angle==1
    
%     AK=[330 10 50 90 130 170 210 250 290 -10]
% BK=[30 70 110 150 190 230 270 310 350 370]

    AK=[340 10 40 70 100 130 160 190 220 250 280 310]
BK=[20 50 80 110 140 170 200 230 260 290 320 350]


for anga=1:length(AK)
    
    DATA=tDATA;
    DATACM=tDATACM;
    HUE=DATACM(:,1)*360;
 if anga==1


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;
else
    select=DATACM(:,3)>5 & HUE>=AK(anga) & HUE<BK(anga);
 end

 DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

DATAk=DATA;
DATACMk=DATACM;

make_hue_plot(DATAk,DATACMk)
export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'angHUE' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');

colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000    
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell;
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.33*CO;
m=1;
    
     figure
  imshow(COF);hold on
 
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'ang' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');
close all

end


end

close all
end