clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=300;
darkest_cells_cut=80;
Bdiff_allowed=80;
Hdiff_allowed=13;
Sdiff_allowed=70;

Hdiff_max=20;
Sdiff_max=140;

% Hdiff_allowed1=15;
% Sdiff_allowed1=75;
% Sdiff_allowed2=100;
load_angle=1;

D_th=2;
T_th=sqrt(2);

nidx=1;
rc=[];


for idx=[18]
    
% Hdiff_allowed=15;
% Sdiff_allowed=75;
     
loadaddress;


load([Reshome2 filesep 'Pall2.mat'],'PDATA'); 
% PDATA(Prlist{idx},:)=[];
PDATAB=PDATA;

% rid=randperm(size(PDATA,1));
% PDATA=[PDATA(rid,1:5) PDATA(:,6:11)];

if idx>0
load([Reshome2 filesep 'Nall3.mat'],'NDATA');
else
load([Reshome2 filesep 'Nall2.mat'],'NDATA');
end

centerF=[PDATA;NDATA];

save(['FOX' num2str(idx)],'centerF'); 

% load('DATA1')

% load([Reshome2 filesep 'all.mat'],'DATA'); 
% cut=0.99;
% rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
%  mult=255./rangek;
% 
% load([Reshome2 filesep 'all3.mat'],'tDATA','DATACM'); 
% 
% load(['FOX' num2str(idx)],'centerF'); 


LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  
  
         Img=LCOLORG(:,:,1);
          mean_s=25;
        h = fspecial('disk', mean_s);
        Img2 = imfilter(Img,h,'replicate');

        Img3=Img2;
        
        mask=uint16(zeros(size(Img3)));
        
                
        if idx==1
        
        mask(Img3>(max(Img2(:))*.3))=65535;
        elseif idx==2
        
        mask(Img3>(max(Img2(:))*.1))=65535;
        
        elseif idx==3
        
        mask(Img3>(max(Img2(:))*.15))=65535;
        
        elseif idx==5
        
        mask(Img3>(max(Img2(:))*.2))=65535;
        
        elseif idx==7
        
        mask(Img3>(max(Img2(:))*.125))=65535;
        
        elseif idx==8
        
        mask(Img3>(max(Img2(:))*.2))=65535;
        
        else
        
        mask(Img3>(max(Img2(:))*.2))=65535;
        end
        
        
%         mask(Img3>(max(Img2(:))*.3))=65535;
        
        mask=imdilate(mask,strel('disk',mean_s));
%         mask = imfill(mask);
% 
%         maskf=uint16(zeros(size(Img3)));    
%            CC = bwconncomp(mask);
%    numOfPixels = cellfun(@numel,CC.PixelIdxList);
%    [unused,indexOfMax] = max(numOfPixels);
%    maskf(CC.PixelIdxList{indexOfMax}) = 65535;
    
%         maskb=uint16(zeros(size(Img3)));
%         Img33=cat(3,Img3,Img3,Img3);
%         mask3=cat(3,maskf,maskb,maskb);
        
        MASK=uint16(65535*mat2gray(mask));
figure
imshow(MASK)

MASK1=imcomplement(MASK);

MASK1 = bwareaopen(MASK1, 10000);


MASK1=imcomplement(MASK1);

MASK1 = bwareaopen(MASK1, 100000);

MASK1=imcomplement(MASK1);

figure
imshow(MASK1)

MD = bwdist(MASK1);




figure
imshow(uint8(MD));

imwrite(uint16(MD*64),[FINR filesep 'DISTANCE MAP' num2str(idx) '.png']);

imwrite(uint16(65535*mat2gray(imcomplement(MASK1))),[FINR filesep 'BORDER_AREA' num2str(idx) '.png']);
  
% %  imwrite(MASK,[FINB filesep 'AREA' num2str(idx) '.png']);

end
