Xin=-10:0.1:10;
Yin=-5:0.1:5;

Xmat = ones(length(Yin),1)*Xin;
Ymat = Yin'*ones(1,length(Xin));

D1=1;
D2=3;
Dist=exp(-Ymat.^2/(2*D1^2)-Xmat.^2/(2*D2^2));

N=10000;

vals=zeros(2,N);
for i=1:N
   [vals(1,i),vals(2,i)]=pinky(Xin,Yin,Dist);
end

figure;
hold on
imagesc(Xin,Yin,Dist)
colormap(gray)
plot(vals(1,:),vals(2,:),'r.')
xlabel('Xin')
ylabel('Yin')
axis equal tight
box on

clear all
close all
% 
clc
% BTH=75;
for idx=[1]
     
loadaddress;
% load('DATA1')

load([Reshome2 filesep 'all.mat'],'DATA'); 

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

    select=sum(DATA(:,6:8)>254,2)<1;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

 DATAori=DATA;
    DATACMori=DATACM;
    
    DT{1}=DATA;
    DTCM{1}=DATACM;

 for loopin=2:101   
    
    rdid=randperm(size(DATA,1));
DATAn=[DATAori(:,1:5) DATAori(rdid(1:size(DATA,1)),6:11)];

DATACMn=rgb2hsv(DATAn(:,6:8));


HUEn=DATACMn(:,1)*360;
data2n=[DATACMn(:,3).*cosd(HUEn) DATACMn(:,3).*sind(HUEn)];


DATAk=DATA;
DATACMk=DATACM;

HUE=DATACM(:,1)*360;

res=64;
data=[HUE DATACM(:,3)];
data2=[DATACM(:,3).*cosd(HUE) DATACM(:,3).*sind(HUE)];

  [bandwidth,density,X,Y]=kde2d(data2,res,[-255,-255],[255,255]);  
  
       hG = fspecial('gaussian',[9 9],1.5);
               
                      density = imfilter(density,hG,'symmetric'); 
                                 density=flipud(density);
                                 
                                 
        Xin=linspace(-255,255,res);
Yin=linspace(255,-255,res);

Dist=density;

N=100;

vals=zeros(2,N);
for i=1:N
   [vals(1,i),vals(2,i)]=pinky(Xin,Yin,Dist,10);
end

figure;
hold on
imagesc(Xin,Yin,Dist)
colormap(gray)
plot(vals(1,:),vals(2,:),'r.')
xlabel('Xin')
ylabel('Yin')
axis equal tight
box on
                         
                                 
                                 
                                 
                       Y=flipud(Y);
nk=512/res;
data3=round((data2+255)/nk);
data3(data3<1)=1;
data3(data3>res)=res;




bin=128;
PD=hist(data2n(:,1),linspace(-255,255,bin));
  hG = fspecial('gaussian',[5 5],0.75);
               
                      PD2 = imfilter(PD,hG,'symmetric'); 
                      PD2=PD2./sum(PD2);
                      
  px=linspace(-255,255,bin);
  p= PD2;
  RH=randpdf(p,px,[size(DATA,1),1]);
  
%   figure
% hist(RH,linspace(0,1,bin))
% figure
% %  hold on
% hist(DATACMn(:,1),linspace(0,1,bin))
                      
bin=128;
PD=hist(data2n(:,2),linspace(-255,255,bin));
  hG = fspecial('gaussian',[5 5],0.75);
               
                      PD2 = imfilter(PD,hG,'symmetric'); 
                      PD2=PD2./sum(PD2);

  px=linspace(-255,255,bin);
  p= PD2;
  RS=randpdf(p,px,[size(DATA,1),1]);
  
%   figure
% hist(RS,linspace(0,255,bin))
% 
%   figure
% hist(DATACMn(:,3),linspace(0,255,bin))

theta=(180./pi.*atan2(RS,RH));

    theta(theta<0)=theta(theta<0)+360;
    
    RB=sqrt(RS.^2+RH.^2);
    RB(RB>255)=255;

DATACMn(:,1)=theta/360;
DATACMn(:,3)=RB;


 end
end