clear all
close all
% 
clc
% BTH=75;


dist_from_brainbow_allowed=150;
min_saturation_allowed=0;
dist_from_border_allowed=0;
darkest_cells_cut=75;
Bdiff_allowed=80;
Hdiff_allowed=6.5;
Sdiff_allowed=90;
% Sdiff_allowed2=100;
load_angle=0;



for idx=[5 1 2 3 7 8]
     
loadaddress;
% load('DATA1')

load([Reshome2 filesep 'all.mat'],'DATA'); 

load(['FOX' num2str(idx)],'centerF'); 

SPACE=min((pdist2(centerF(:,1:2),DATA(:,4:5))*.31),[],2);

centerF(SPACE>dist_from_brainbow_allowed,:)=[];

cut=0.99;
rangek=[quantile(DATA(:,6),cut) quantile(DATA(:,7),cut) quantile(DATA(:,8),cut)];
 mult=255./ rangek;
  DATA(:,6:11)=DATA(:,6:11).*repmat(mult,size(DATA,1),2);
% DATA(:,7)=1.5*DATA(:,7);
DATAT=DATA(:,6:8);
DATAT(DATAT>255)=255;
DATACM=rgb2hsv(DATAT(:,1:3));
DATA(:,6:8)=DATAT;

HUE=DATACM(:,1)*360;

select=DATACM(:,2)>=min_saturation_allowed;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);


LB=imread([FINR filesep 'RESULT_M' num2str(idx) filesep 'BAREA'  num2str(idx) '.png']);

D = bwdist(LB==0);

% vald=[];
% for kin=1:size(centerF,1)
%     
%     vald(kin,1)=D(centerF(kin,1),centerF(kin,2));
% 
% end
% select=vald>dist_from_border_allowed;
% centerF=centerF(select==1,:);


 DATAori=DATA;
    DATACMori=DATACM;
    
    DT{1}=DATA;
    DTCM{1}=DATACM;
    
    
make_hue_plot(DATA,DATACM)  
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'HUE' 'all'],'-a2', '-m6','-p0','-q101','-png', '-r600');

 for loopin=2:101   
     
     loopin;
    
    rdid=randperm(size(DATA,1));
    
    rdidF=randperm(size(centerF,1));
    
DATAn=[DATAori(:,1:3) centerF(rdidF(1:size(DATA,1)),1:2) DATAori(rdid(1:size(DATA,1)),6:11)];

DATACMn=rgb2hsv(DATAn(:,6:8));

    DT{loopin}=DATAn;
    DTCM{loopin}=DATACMn;
 end
 
for loopin=1:101 
     
      DATA=DT{loopin};
    DATACM=DTCM{loopin};
    
    
    vald=[];
for kin=1:size(DATA,1)
    
    vald(kin,1)=D(DATA(kin,4),DATA(kin,5));

end
select=vald>dist_from_border_allowed;
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

select=sum(DATA(:,6:8)>=255,2)<2;
    
DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);
    
     
 cutpid=0;
 for cutp=darkest_cells_cut
 
     cutpid=cutpid+1;
     select2=DATACM(:,3);
%  select2k=DATACM(:,3)>=204;
 
select2k=select2>quantile(select2,((cutp/100)));

DATAx=DATA(select2k==1,:);
DATACMx=DATACM(select2k==1,:);

  DTA{loopin,cutpid}=DATAx;
    DTCMA{loopin,cutpid}=DATACMx;
    
     
%    if loopin<3 
%        
%   
%     DATAx(:,6:8)=hsv2rgb(DATACMx(:,1:3));
%     
%           
%    end
       
 
 end
 end

  
 
save(['DATAFD' num2str(idx)],'DTA','DTCMA'); 

load(['DATAFD' num2str(idx)],'DTA','DTCMA'); 
 
 ttt=1;
     cutpid=0;
for cutp=darkest_cells_cut
         cutpid=cutpid+1;
    
for BTH=[Bdiff_allowed]
    
ncoupA=[];
HTHid=0;

for HTH=[Hdiff_allowed]
    HTHid=HTHid+1;
    STHid=0;
for STH=[Sdiff_allowed]   
    STHid=STHid+1;
    ncoup=[];
for loopin=1:101
   

     DATA=DTA{loopin,cutpid};
    DATACM=DTCMA{loopin,cutpid};
    
    if loopin==1
    
     make_hue_plot(DATA,DATACM)
   export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'HUE' num2str(1)],'-a2', '-m6','-p0','-q101','-png', '-r600');
    end
    tDATA=DATA;
    
    DATAori=DT{loopin};
    DATACMori=DTCM{loopin};
     
     HUEdist=pdist2(DATACM(:,1)*360,DATACMori(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACMori(:,3));
     SPACEdist=pdist2(DATA(:,4:5),DATAori(:,4:5))*.31;

     
%% check conditions  
   Costmat=SPACEdist;
%    Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(Bdist>BTH)=12000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
%    Costmat(Bdist<5)=12000;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                cp=0;
                 while size(cosmatw,1)>0 %cp=1:min([NBP1 NBP2])
                     cp=cp+1;
%                   for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                        
%                         
                         BBdist=min(pdist2(tDATA(:,4:5),DATAori(Aida(cp,2),4:5)),[],2);
                        
                          idbox1(ismember(idbox1,find(BBdist<5)))=[];
                          
                            BBdist=min(pdist2(tDATA(Aida(cp,1),4:5),DATAori(:,4:5)),[],1);
                        
                          idbox2(ismember(idbox2,find(BBdist<5)))=[];
                        
                        
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[DATAori(Aida(cp,2),4) DATAori(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[DATAori(Aida(cp,2),6) DATAori(Aida(cp,2),7) DATAori(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end  

   xyval(xyval(:,13)>=10000,:)=[];
   xyval=[xyval;xyval];
   
%   tDATAt=DATAori(xyval(:,9),:);
%   
%   BBdist=min(pdist2(tDATAt(:,4:5),tDATA(:,4:5)),[],2);
%    
%    tDATAt(BBdist<5,:)=[];
%   tDATA=[tDATA;tDATAt]; 
%   
%   
%   [B,I,J]=unique(tDATA(:,4:5),'rows');
%   
%   tDATA=tDATA(I,:);
  

  DATACM=rgb2hsv(tDATA(:,6:8));
  
     HUEdist=pdist2(DATACM(:,1)*360,DATACM(:,1)*360);
     HUEdist(HUEdist>180)=360-HUEdist(HUEdist>180);
     Bdist=pdist2(DATACM(:,3),DATACM(:,3));
     SPACEdist=pdist2(tDATA(:,4:5),tDATA(:,4:5))*.31;

     
%% check conditions    
   Costmat=SPACEdist;
%    Costmat=HUEdist;
   Costmat(HUEdist>HTH)=10000;
   Costmat(Bdist>BTH)=12000;
   Costmat(SPACEdist>STH)=15000;
   Costmat(Costmat==0)=20000;
   
   D=Costmat;  
          cosmatw=D;
        cosmat=D;
        NBP1=size(D,1);
         NBP2=size(D,2);
       idbox1=[1:NBP1];
        idbox2=[1:NBP2];
         Aida=[];  
                xyval=[];
                 for cp=1:min([NBP1 NBP2])
                     point=min(cosmatw(:));
                     [Aid,Bid]=find(cosmatw==point);
                      Aida=[Aida;[idbox1(Aid(1)) idbox2(Bid(1))]];

                     idbox1(ismember(idbox1,Aida(:,1)))=[];
                        idbox2(ismember(idbox2,Aida(:,2)))=[];
                     cosmatw=cosmat(idbox1,idbox2);   

                     xyval(cp,1:2)=[tDATA(Aida(cp,1),4) tDATA(Aida(cp,1),5)];
                        xyval(cp,3:4)=[tDATA(Aida(cp,2),4) tDATA(Aida(cp,2),5)];
                         xyval(cp,5:7)=[tDATA(Aida(cp,1),6) tDATA(Aida(cp,1),7) tDATA(Aida(cp,1),8)];
                         xyval(cp,8:9)=[Aida(cp,1) Aida(cp,2)];
                           xyval(cp,10:12)=[tDATA(Aida(cp,2),6) tDATA(Aida(cp,2),7) tDATA(Aida(cp,2),8)];
                           xyval(cp,13)=point;

                 end  

   xyval(xyval(:,13)>=10000,:)=[];
   
  
%   DATA=tDATA;
 ncoup(loopin)=size(xyval,1)/size(tDATA,1);
 
if ttt<2
    ttt=ttt+1;

 LCOLORC=imread([Reshome3 filesep 'mosaicC.png']);
%
 if ttt==2
 LCOLORL=imread([Reshome3 filesep 'mosaicLM.png']);
 else
 LCOLORL=imread([Reshome3 filesep 'FOXLM2.png']);
 end

 LCOLORG=imread([Reshome3 filesep 'mosaicG.png']);
  
colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);

 for cell=1:size(tDATA,1)
     
     val=LCOLORL(tDATA(cell,4),tDATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000
%   if mean(pos(:))<10000
     
%      colorA(pos)=LCOLORCA(pos)+(256*tDATA(cell,6)-mean(LCOLORCA(pos)));
%       colorB(pos)=LCOLORCB(pos)+(256*tDATA(cell,7)-mean(LCOLORCB(pos)));
%        colorC(pos)=LCOLORCC(pos)+(256*tDATA(cell,8)-mean(LCOLORCC(pos)));
       
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell;
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.33*CO;
m=1;
    
     figure
  imshow(COF);hold on
  
  imwrite(COF,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(ttt-1) '.png']);
  
     for zin=1:size(xyval,1)   
         
   U=m*xyval(zin,4)-m*xyval(zin,2);
   V=m*xyval(zin,3)-m*xyval(zin,1);
   Z=sqrt(U.^2+V.^2);   
  quiver(m*xyval(zin,2),m*xyval(zin,1),U,V,0,'color',[1 1 1],'maxheadsize',0.025,'linewidth',.75) ; hold on
%          end

     end
     
     
     for zin=1:size(tDATA,1)  
           DATACM1=rgb2hsv(tDATA(zin,6:8));
%            HUE1=DATACM1(:,1)*360;
%            x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
%            y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
%          text(x1+3,y1-5,num2str(zin),'FontSize',3,'FontName','Times','Color',[0 0 0],'HorizontalAlignment','center','VerticalAlignment', 'top');  
%         
         text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-5,num2str(round(DATACM1(:,1)*360)),'FontSize',3,'FontName','Times','Color',[1 1 1],'HorizontalAlignment','center','VerticalAlignment', 'top');
           text(m*tDATA(zin,5)+3,m*tDATA(zin,4)-3,[char(10) num2str(zin)],'FontSize',2.5,'FontName','Times','Color',[1 .7 0.7],'HorizontalAlignment','center','VerticalAlignment', 'top');
%                           text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) '(' num2str(round((tDATA(zin,6)))) ',' num2str(round((tDATA(zin,7)))) ','...
%           num2str(round((tDATA(zin,8)))) ')'],'FontSize',2,'FontName','Times','Color',[.95 .95 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
%        text(m*tDATA(zin,5)+10,m*tDATA(zin,4)-10,[char(10) char(10) char(10) '(' num2str(round((tDATA(zin,9)))) ',' num2str(round((tDATA(zin,10)))) ','...
%           num2str(round((tDATA(zin,11)))) ')'],'FontSize',2,'FontName','Times','Color',[.75 .75 0.95],'HorizontalAlignment','center','VerticalAlignment', 'top');
     end
     
     
     
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'loop' num2str(ttt)],'-a2', '-m6','-p0','-q101','-png', '-r600');
%close all


make_hue_plot(tDATA,DATACM)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'HUE' num2str(0)],'-a2', '-m6','-p0','-q101','-png', '-r600');

save([Reshome2 filesep 'all2.mat'],'tDATA','DATACM'); 


tDATACM=DATACM;

if load_angle==1
    
%     AK=[330 10 50 90 130 170 210 250 290 -10]
% BK=[30 70 110 150 190 230 270 310 350 370]

    AK=[340 10 40 70 100 130 160 190 220 250 280 310]
BK=[20 50 80 110 140 170 200 230 260 290 320 350]


for anga=1:length(AK)
    
    DATA=tDATA;
    DATACM=tDATACM;
    HUE=DATACM(:,1)*360;
 if anga==1


raw=HUE>=AK(anga) | HUE<BK(anga);
select=DATACM(:,3)>5 & raw==1;
else
    select=DATACM(:,3)>5 & HUE>=AK(anga) & HUE<BK(anga);
 end

 DATA=DATA(select==1,:);
DATACM=DATACM(select==1,:);

DATAk=DATA;
DATACMk=DATACM;

make_hue_plot(DATAk,DATACMk)
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'angHUE' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');

colorA=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorB=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));
colorC=uint16(zeros(size(LCOLORC,1),size(LCOLORC,2)));

LCOLORCA=LCOLORC(:,:,1);
LCOLORCB=LCOLORC(:,:,2);
LCOLORCC=LCOLORC(:,:,3);

 T1=LCOLORL>0;
 I2cpsegb=imerode(uint8(255*im2bw(T1,0.5)),strel('ball',1,1));
 
 LCOLORCA(I2cpsegb==0)=0;
 LCOLORCB(I2cpsegb==0)=0;
 LCOLORCC(I2cpsegb==0)=0;
 
 LCOLORCA=mult(1)*LCOLORCA;
 LCOLORCB=mult(2)*LCOLORCB;
 LCOLORCC=mult(3)*LCOLORCC;
 
  CLC=cat(3,LCOLORCA,LCOLORCB,LCOLORCC);
                        
                           labeledImage = bwlabel(I2cpsegb>0, 4);

 for cell=1:size(DATA,1)
     
     val=LCOLORL(DATA(cell,4),DATA(cell,5));
     pos=LCOLORL==val;
  if sum(pos(:))<30000    
          colorA(pos)=LCOLORCA(pos);
      colorB(pos)=LCOLORCB(pos);
       colorC(pos)=LCOLORCC(pos);
     cell;
  end
 end
 
 CL=cat(3,colorA,colorB,colorC);
 
CO=LCOLORG;
COF=CL+0.33*CO;
m=1;
    
     figure
  imshow(COF);hold on
 
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\Filtered_cells\' 'DLINK_idx' num2str(idx) 'ang' num2str(anga)],'-a2', '-m6','-p0','-q101','-png', '-r600');
close all

end


end
 
end 
end
idx
 ncoupA{HTHid,STHid}=ncoup;
 [h,p]=ttest2(ncoup(1),ncoup(2:101));
 ncoup(1)
 mean(ncoup(2:101))
 p
 cutp
 BTH
 HTH
 STH
 
end
end

 save([Reshome3 filesep 'DncoupA_' num2str(cutp) '_' num2str(BTH) '.mat'],'ncoupA');  

end

end

close all
end