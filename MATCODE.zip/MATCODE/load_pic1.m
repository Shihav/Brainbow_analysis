if idx==4
pic=uint16(zeros(4*1024,5*1024));
DX=5;
DY=5;
elseif idx==3
pic=uint16(zeros(6*1024,5*1024));
DX=5;
DY=1910;
elseif idx==2
pic=uint16(zeros(4*1024,5*1024));
DX=5;
DY=5;
elseif idx==5
pic=uint16(zeros(3*1024,7*1024));
DX=5;
DY=935;
elseif idx==1
pic=uint16(zeros(3*1024,3*1024));
DX=5;
DY=890;
end