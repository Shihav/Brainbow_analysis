clear all
close all

clc
mn=[130 1429 69 1490];
mn=[525 944 590 879];
mn=[82 1296 845 533];
mn=[1094 301 185 1210];
mn=[1172 255 211 1236];
mn=[81 1300 843 538];
% mn=[773 596 1268 101];
% mn=[1066 411 115 1362];
% mn=[1069 412 109 1372];



% mn=[380 642 543 479];
% mn=[545 649 546 648];
idx=3;
borders=10;
borderb=15;


%
%% fig 2%%
%%

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_AC' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_A' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_A' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_E' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_B' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_B' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_F' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3FSEG' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_C' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_C' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_G' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_Fplus' '.png']);
% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'RAW_plus.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_D' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_D' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_H' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_RC' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_E' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_I' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_M' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3GRAD' '.png']);
A=1*uint16(cat(3,A,A,A));
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_F' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_J' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_N' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3NFSEG' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_G' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_K' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_O' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_Fminus' '.png']);
% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_3' 'RAW_minus.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_H' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_L' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG2\' 'FIG2_P' '.png']);






%%
%% Fig 3
%%

mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\']);

% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx) 'RAW_pm.png']);
% % imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_J' '.png']);
% process_crop
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_A' '.png']);
% imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_B' '.png']);
% 
% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\PMAT\' 'ZLINK_idx10RHue14' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_C' '.png']);
% 
% A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\PMAT\' 'ZLINK_idx10RSHue14' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_D' '.png']);



A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_J' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_A' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_B' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_C' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_D' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_J' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_E' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_F' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_G' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_H' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_P' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_J' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_I' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_J' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_RP' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_K' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_RP' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_L' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_N' '.png']);
% imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\' 'FIG_J' '.png']);
process_crop
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_M' '.png']);
imwrite(ck,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_N' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_RN' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_O' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_RN' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG3\' 'FIG3_P' '.png']);

%%
%% fig 4
%%
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG4\']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_P' '.png']);
B=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
imwrite(A+0.5*B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG4\' 'FIG4_A' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_N' '.png']);
B=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
imwrite(A+0.0*B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG4\' 'FIG4_B' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_sym' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG4\' 'FIG4_C' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_asym' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG4\' 'FIG4_D' '.png']);



%%
%% fig 5
%%
mkdir(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\P2\' 'ALL_AC.png']);
B=imread(['G:\ENS_CILTEX\Marie_2016_NEW\20160711_Daclin_manip14\3\P2\' 'mosaicG.png']);

imwrite(A+0.5*B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_A' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'AIN_' num2str(idx)  'ALL_AC' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_B' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_C' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_D' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_E' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_P' '.png']);
B=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
imwrite(A+0.5*B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_F' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14_R_N' '.png']);
B=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx3ang14G' '.png']);
imwrite(A+0.0*B,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG5_G' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10Hue14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG3_H' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL2\HUE\' 'ZLINK_idx10HueS14_R' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG3_I' '.png']);


A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFOG_sym' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG4_J' '.png']);

A=imread(['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORT\' 'CroppedZLINK_idx' num2str(idx) 'ang' num2str(14)  '_RFO_asym' '.png']);
imwrite(A,['G:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(2) '\' 'REPORTF\FIG5\' 'FIG4_K' '.png']);






