clear all
close all

clc
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT']);

load TQRES.mat infoTA infoQA infoDA


myC= [0.7 0.7 0.7;
    0.9 0.9 1;
    0.9 1 0.9];
k=1;
rc3=[];
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=infoTA(infoTA(:,10)==kin,:);
    
    for kin2=1:size(tem,1)
        if tem(kin2,1)==1
        tem(kin2,11)=0;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==2
                   if tem(kin2,6)<tem(kin2,8)
            
        tem(kin2,11)=2;
        tem(kin2,12)=0;
        
           else
                 tem(kin2,11)=1;
        tem(kin2,12)=1;
           end
        elseif tem(kin2,1)==3
        tem(kin2,11)=2;
        tem(kin2,12)=1;
        end
        
    end
    
  rc3(k,1)=sum(tem(:,11));  
  rc3(k,2)=sum(tem(:,12)); 
   
  k=k+1;
    
end

myC= [0.7 0.7 0.7;
    0.9 0.9 1;
    0.9 1 0.9];
k=1;
rc4=[];
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=infoQA(infoQA(:,10)==kin,:);
    
    for kin2=1:size(tem,1)
        if tem(kin2,1)==1
        tem(kin2,11)=0;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==2
                   if tem(kin2,6)<tem(kin2,8)
            
        tem(kin2,11)=2;
        tem(kin2,12)=0;
        
           else
                 tem(kin2,11)=1;
        tem(kin2,12)=1;
           end
        elseif tem(kin2,1)==3
        tem(kin2,11)=2;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==4
        tem(kin2,11)=4;
        tem(kin2,12)=0;
        end
        
    end
    
  rc4(k,1)=sum(tem(:,11));  
  rc4(k,2)=sum(tem(:,12)); 
   
  k=k+1;
    
end

myC= [0.7 0.7 0.7;
    0.9 0.9 1;
    0.9 1 0.9];
k=1;
rc=[];
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=infoDA(infoDA(:,10)==kin,:);
    
    for kin2=1:size(tem,1)
        if tem(kin2,1)==1
        tem(kin2,11)=0;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==2
        tem(kin2,11)=2;
        tem(kin2,12)=0;
        end
        
    end
    
  rc2(k,1)=sum(tem(:,11));  
  rc2(k,2)=sum(tem(:,12)); 
   
  k=k+1;
    
end

rc=rc2+rc3+rc4;

figure

H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Origin from symmetric division = ' num2str(100*mn,'%0.2f') '%, total cell = ' num2str(sum(rc(:)))],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
ylim([0 1.05])
pbaspect([8,6,1])

set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'ASYM_SYM'],'-a2', '-m6','-p0.02','-png', '-r600');



