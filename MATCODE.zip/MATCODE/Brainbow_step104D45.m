clear all
close all

clc
mkdir(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT']);

load TQRES.mat infoDA

myC= [0.7 0.7 0.7;
    0.9 0.9 1;
    0.9 1 0.9];
k=1;
rc=[];
for kin=[7 8 3 1 13 15 5 17 18 14 16 12 2 11]
    
    tem=infoDA(infoDA(:,10)==kin,:);
    
    for kin2=1:size(tem,1)
        if tem(kin2,1)==1
        tem(kin2,11)=0;
        tem(kin2,12)=1;
        elseif tem(kin2,1)==2
        tem(kin2,11)=2;
        tem(kin2,12)=0;
        end
        
    end
    
  rc(k,1)=sum(tem(:,11));  
  rc(k,2)=sum(tem(:,12)); 
   
  k=k+1;
    
end


figure

H=bar(rc./repmat(sum(rc,2),[1 2]),0.5,'stacked');
mn=sum(rc(:,1))/sum(rc(:));

for k=1:2
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Ratio count of division type'],'FontSize', 14,'FontName','times') % y-axis label
title(['Origin from symmetric division = ' num2str(100*mn,'%0.2f') '%, total cell = ' num2str(sum(rc(:)))],'FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
ylim([0 1.05])
pbaspect([8,6,1])

set_xlabel_12

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     
                                                   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'DOUB_SYM'],'-a2', '-m6','-p0.02','-png', '-r600');




mat=[];
mat(1,1)=sum(infoDA(:,1)==1);
mat(1,2)=sum(infoDA(:,1)==2);
% mat(1,3)=sum(infoDA(:,1)==3);
% mat(1,4)=sum(infoDA(:,1)==4);

myC=[1 0.6 0.6];

figure

hold on
    h=bar(1,mat(1,1),0.5);
        set(h,'FaceColor',[0.2 0.2 1]);
       set(get(h,'Children'),'FaceAlpha',0.6);
            h=bar(2,mat(1,2),0.5);
        set(h,'FaceColor',[0.2 1 0.2]);
        set(get(h,'Children'),'FaceAlpha',0.6);
%             h=bar(3,mat(1,3),0.5);
%         set(h,'FaceColor',[1 0 0]);
%         set(get(h,'Children'),'FaceAlpha',0.7);
%     h=bar(4,mat(1,4),0.5);
%         set(h,'FaceColor',[1 0 1]);
%         set(get(h,'Children'),'FaceAlpha',0.7);
hold off


% H=bar(mat,0.5);

% 
% for k=1:1
%   set(H(k),'facecolor',myC(k,:))
% end

ylabel(['Number of samples'],'FontSize', 14,'FontName','times') % y-axis label
xlabel(['Number of ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
title('Types of doublets','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 2.5])
% ylim([0 1.05])
pbaspect([8,6,1])
 
 set(gca,'XTick',1:2,...                         %# Change the axes tick marks
        'XTickLabel',{'1','2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'DOUB_TYPE'],'-a2', '-m6','-p0.02','-png', '-r600');


mat=[];
mat(1,1)=sum(infoDA(:,10)==7);
mat(1,2)=sum(infoDA(:,10)==8);
mat(1,3)=sum(infoDA(:,10)==3);
mat(1,4)=sum(infoDA(:,10)==1);
mat(1,5)=sum(infoDA(:,10)==13);
mat(1,6)=sum(infoDA(:,10)==15);
mat(1,7)=sum(infoDA(:,10)==5);
mat(1,8)=sum(infoDA(:,10)==17);
mat(1,9)=sum(infoDA(:,10)==18);
mat(1,10)=sum(infoDA(:,10)==14);
mat(1,11)=sum(infoDA(:,10)==16);
mat(1,12)=sum(infoDA(:,10)==12);
mat(1,13)=sum(infoDA(:,10)==2);
mat(1,14)=sum(infoDA(:,10)==11);

myC=[0.9 0.7 0.7];

figure
H=bar(mat,0.5);

for k=1:1
  set(H(k),'facecolor',myC(k,:))
end

ylabel(['Number of doublets'],'FontSize', 14,'FontName','times') % y-axis label
title('doublets among mosaics','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.5 14.5])
% ylim([0 1.05])
pbaspect([8,6,1])
 
set_xlabel_12
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'DOUB_COUNT'],'-a2', '-m6','-p0.02','-png', '-r600');



figure; hold on

for kin=1:size(infoDA,1)

    if infoDA(kin,1)==1
scatter(infoDA(kin,2),infoDA(kin,4),50,[0.2 0.2 1],'filled'); hold on;
alpha(0.6);
    elseif infoDA(kin,1)==2
scatter(infoDA(kin,2),infoDA(kin,4),50,[0.2 1 0.2],'filled'); hold on;
alpha(0.6);
%     elseif infoDA(kin,1)==3
% scatter(infoDA(kin,2),infoDA(kin,4),50,[1 0 0],'filled'); hold on;
% alpha(0.7);
%     elseif infoDA(kin,1)==4
% scatter(infoDA(kin,2),infoDA(kin,4),50,[1 0 1],'filled'); hold on;
% alpha(0.7);
    end
alpha(0.6)
end

%  hl = legend('1 FoxJ1+','2 FoxJ1+','3 FoxJ1+');
% % hl = legend(H,['Symmetric division'],['Asymmetric division']);
% set(hl,'FontSize', 12,'FontName','Times');
% legend('boxoff')
% 
%                                                                                         hc = findobj(hl, '-property', 'FaceColor');
%                                                                                         set(hc(1), 'FaceColor',[1 0 0])
%                                                                                         set(hc(2), 'FaceColor', [0 1 0])
%                                                                                         set(hc(3), 'FaceColor', [0 0 1])
%                                                                                         
%                                                                                         

xlabel(['Mean distance among ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
ylabel(['Mean distance to ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label

title('doublets spatial distance relation','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0 150])
ylim([0 150])
pbaspect([8,8,1])
 
%  set(gca,'XTick',1:6,...                         %# Change the axes tick marks
%         'XTickLabel',{'M5','M6','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'DOUB_spatial_distance'],'-a2', '-m6','-p0.02','-png', '-r600');


figure; hold on

for kin=1:size(infoDA,1)

    if infoDA(kin,1)==1
scatter(infoDA(kin,6),infoDA(kin,8),50,[0.2 0.2 1],'filled'); hold on;
alpha(0.6);
    elseif infoDA(kin,1)==2
scatter(infoDA(kin,6),infoDA(kin,8),50,[0.2 1 0.2],'filled'); hold on;
alpha(0.6);
%     elseif infoDA(kin,1)==3
% scatter(infoDA(kin,6),infoDA(kin,8),50,[1 0 0],'filled'); hold on;
% alpha(0.7);
%     elseif infoDA(kin,1)==4
% scatter(infoDA(kin,6),infoDA(kin,8),50,[1 0 1],'filled'); hold on;
% alpha(0.7);
    end
alpha(0.6);
end

%  hl = legend('1 FoxJ1+','2 FoxJ1+','3 FoxJ1+');
% % hl = legend(H,['Symmetric division'],['Asymmetric division']);
% set(hl,'FontSize', 12,'FontName','Times');
% legend('boxoff')
% 
%                                                                                         hc = findobj(hl, '-property', 'FaceColor');
%                                                                                         set(hc(1), 'FaceColor',[1 0 0])
%                                                                                         set(hc(2), 'FaceColor', [0 1 0])
%                                                                                         set(hc(3), 'FaceColor', [0 0 1])
%                                                                                         
%                                                                                         

xlabel(['Mean distance among ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label
ylabel(['Mean distance to ependymal cells'],'FontSize', 14,'FontName','times') % y-axis label

title('doublets color distance relation','FontSize', 15,'FontName','times')

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0 15])
ylim([0 15])
pbaspect([8,8,1])
 
%  set(gca,'XTick',1:6,...                         %# Change the axes tick marks
%         'XTickLabel',{'M5','M6','M3','M1','M4','M2'},'TickLength',[0 0],'FontSize', 15,'FontName','times');  %#   and tick labels
                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

                                                ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                %                                             text(0.5,1,['Comparison of nMI' ],'HorizontalAlignment','center','VerticalAlignment', 'top');
                                                                                            set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');                                                     

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL' num2str(100) '\PLOT\' 'DOUB_hue_distance'],'-a2', '-m6','-p0.02','-png', '-r600');

