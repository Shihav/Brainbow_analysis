   
addpath('C:\Users\shiha\Downloads\circstat2010b')

data1=HUE_6A;
data2=HUE_32A;
% [p,h,stats] = ranksum(data1,data2)
% 
% [h1,p1] = kstest(data1);
% [h2,p2] = kstest(data2);
[pval, k, K] = circ_kuipertest(degtorad(data1'),degtorad(data2'))

col=[.8 .1 .1; 0.1 0.1 0.8; 0.5 0.5 0.5];

                                            minS=0;
                                            maxS=360;

                                            Distk=[0 20 40 60 80 100 120 140 160 180 200 220 240 260 280 300 320 340 360];
                                            Center=[10 30 50 70 90 110 130 150 170 190 210 230 250 270 290 310 330 350];
%                                             figure()
                                            [n1,x11] = histc(data1',Distk);
                                            n1(19)=[];
                                             [n2,x22] = histc(data2',Distk);
                                            n2(19)=[];
%                                              [n3,x33] = histc(data3',Distk);
%                                             n3(19)=[];
                                                                                     
        n11=100*n1/sum(n1);
            n22=100*n2/sum(n2);
%                 n33=100*n3/sum(n3);
%                                                                           valuesmean=[n11' n22' n33'];                        
                                                                                   index = Distk; 
                                                                                   center2=[5 95 185 275];
%                                                                                    n44=n33;
                                                                                   n44(1:4)=25%max([n33 n22 n11]);
               figure
%                h4=compass(n44.*cosd(center2),n44.*sind(center2));    
%                        set(h4,'Color',[1 1 1],'linewidth',0.001)
% %                   hold on
%                        h3=compass(n33.*cosd(Center),n33.*sind(Center));    
%                        set(h3,'Color',[0.5 0.5 0.5],'linewidth',1)
%                           hold on, 
                          h2=compass(n22.*cosd(Center+1),n22.*sind(Center+1));
                    set(h2,'Color',[0.1 0.1 0.8],'linewidth',1) 
                    hold on
              h1=compass(n11.*cosd(Center+2),n11.*sind(Center+2)); 
               set(h1,'Color',[0.8 0.1 0.1],'linewidth',1) 
             
              
                       hold on  
                       
                       
                          figure
           
           MVAL=max([n11 n22]);
   [t,r] = rose(degtorad(data2'),18); 
ADJ=n22(1)./r(2);
r=r*ADJ;

 h2=compass(n22.*cosd(Center),n22.*sind(Center));
                    set(h2,'Color',[0.1 0.1 0.8],'linewidth',0.1) 
                    hold on

% rMax = MVAL;
% h2 = compass(MVAL, 2);
% set(h2,'Color',[1 1 1],'linewidth',0.001) 

%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t,r);
Cut=1.4;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;
h = patch(Xin2, Yin2, 'w');
alpha(h, 1)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.1 0.1 0.8],'LineStyle',':','Linewidth',1.5);  
                       hold on                                                         

  [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n22.*cosd(Center),n22.*sind(Center),0.99);
     plot(arrowx,arrowy,'Color',[0.1 0.1 0.8],'linewidth',0.75);

deg=0.1;
ang=deg/(2*pi);

[t,r] = rose(degtorad(data1'),18);               %# this does not generate a plot
ADJ=n11(1)./r(2);
r=r*ADJ;
%# draw patches instead of lines: polar(t,r)
[x,y] = pol2cart(t+ang/7,r);
Cut=1.4;
Xin=reshape(x,4,[]);
Xin2=[Xin(1:2,:);mean(Xin(2:3,:));Xin(3:4,:)];
Xin2([2 4],:)=Xin2([2 4],:)./Cut;
Yin=reshape(y,4,[]);
Yin2=[Yin(1:2,:);mean(Yin(2:3,:));Yin(3:4,:)];
Yin2([2 4],:)=Yin2([2 4],:)./Cut;
h = patch(Xin2, Yin2, 'w');
alpha(h, 1)       %# note: this switches to OpenGL renderer
set(h,'EdgeColor',[0.8 0.1 0.1],'LineStyle',':','Linewidth',1.5);  
                       hold on                                                         

  [arrowx,arrowy]=vekplot3(zeros(size(Center)),zeros(size(Center)),n11.*cosd(Center+deg),n11.*sind(Center+deg),0.99);
     plot(arrowx,arrowy,'Color',[0.8 0.1 0.1],'linewidth',0.75);                      