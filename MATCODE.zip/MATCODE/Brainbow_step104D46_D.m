clear all
close all
clc

newData1 = importdata('F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M1\Manual1\Manual_Data.xlsx');

                            vars = fieldnames(newData1);
                            for i = 1:length(vars)
                                assignin('base', ['MTcells' vars{i}], newData1.(vars{i}));
                            end
                            
                            VAL1=MTcellsdata.Sheet1;
                            
newData1 = importdata('F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M2\Manual2\Manual_Data.xlsx');

                            vars = fieldnames(newData1);
                            for i = 1:length(vars)
                                assignin('base', ['MTcells' vars{i}], newData1.(vars{i}));
                            end
                            
                            VAL2=MTcellsdata.Sheet1;
                            
newData1 = importdata('F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M3\Manual3\Manual_Data.xlsx');

                            vars = fieldnames(newData1);
                            for i = 1:length(vars)
                                assignin('base', ['MTcells' vars{i}], newData1.(vars{i}));
                            end
                            
                            VAL3=MTcellsdata.Sheet1;
                            
newData1 = importdata('F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M5\Manual5\Manual_Data.xlsx');

                            vars = fieldnames(newData1);
                            for i = 1:length(vars)
                                assignin('base', ['MTcells' vars{i}], newData1.(vars{i}));
                            end
                            
                            VAL5=MTcellsdata.Sheet1;
                            
                            VAL=[VAL1;VAL2;VAL3;VAL5];


figure()
LW=1;
    valn=VAL(:,1);
     valr=VAL(:,2);
     vals=VAL(:,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 
    for n=1:size(VAL,1)
       ternplot(NMI(n),RMSE(n),SNR(n),'-o','Color',VAL(n,1:3)./255,...
           'LineWidth',1.5,'MarkerSize',3,'MarkerFaceColor',VAL(n,1:3)./255);hold on; 
    end
     ternlabel2('Blue - Red', 'Green - Red', 'Blue - Green')  


     for zin=1:2:size(VAL,1) 
         
             CC=0.5*[1 1 1];
         
            valn=VAL(zin,1);
     valr=VAL(zin,2);
     vals=VAL(zin,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 

                  [x1 y1]=terncoords(NMI,RMSE,SNR);
     
             valn=VAL(zin+1,1);
     valr=VAL(zin+1,2);
     vals=VAL(zin+1,3);
     val=(valn+valr+vals);
     NMI=valn./val; 
     RMSE=valr./val; 
     SNR=vals./val; 

                  [x2 y2]=terncoords(NMI,RMSE,SNR);

   U=x2-x1;
   V=y2-y1;
   Z=sqrt(U.^2+V.^2);   
  quiver(x1,y1,U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',1*LW) ; hold on
%          end
   
     end
 
set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
   

export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_TRIANGULAR'],'-a2', '-m6','-p0','-q101','-png', '-r600');



DATAT=VAL(:,1:3);
DATAT(DATAT>255)=255;
VAL(:,6:8)=DATAT;

DATACM=rgb2hsv(VAL(:,1:3));

figure

HUE=DATACM(:,1)*360;
h=polar(0,255,'.');hold on
set(h,'linewidth',0.01)
set(h,'markersize',0.01)
for mt=1:size(DATACM,1)
h=polar(2*pi*DATACM(mt,1),DATACM(mt,3),'.');hold on
set(h,'linewidth',1)
set(h,'markersize',15)
set(h,'color',DATA(mt,6:8)/255)
end


     for zin=1:2:size(VAL,1) 
         
      CC=0.5*[1 1 1];
               
         DATACM1=rgb2hsv(VAL(zin,1:3));
         DATACM2=rgb2hsv(VAL(zin+1,1:3));

HUE1=DATACM1(:,1)*360;
HUE2=DATACM2(:,1)*360;

x1=DATACM1(:,3)*cos(2*pi*DATACM1(:,1));
x2=DATACM2(:,3)*cos(2*pi*DATACM2(:,1));

y1=DATACM1(:,3)*sin(2*pi*DATACM1(:,1));
y2=DATACM2(:,3)*sin(2*pi*DATACM2(:,1));
         
   U=x2-x1;
   V=y2-y1;
   Z=sqrt(U.^2+V.^2);   
  quiver(x1,y1,U,V,0,'color',CC,'maxheadsize',0.025,'linewidth',1*LW) ; hold on
%          end
   
     end
 
set(gcf,'color','w');
grid off
box off
axis off
     axis equal
   
 set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure    


export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_HUE_VS_VALUE'],...
    '-a2', '-m6','-p0','-q101','-png', '-r600');








D=100;
MAT=[];
k=1;
for kin=1:size(VAL1,1)
    
    A=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M1\Manual1\cellid' num2str(kin) '.png']);
    B=imresize(A,[D D]);    
    MAT(:,:,:,k)=B;    
    k=k+1;
end

for kin=1:size(VAL2,1)
    
    A=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M2\Manual2\cellid' num2str(kin) '.png']);
    B=imresize(A,[D D]);    
    MAT(:,:,:,k)=B;    
    k=k+1;
end

for kin=1:size(VAL3,1)
    
    A=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M3\Manual3\cellid' num2str(kin) '.png']);
    B=imresize(A,[D D]);    
    MAT(:,:,:,k)=B;    
    k=k+1;
end

for kin=1:size(VAL5,1)
    
    A=imread(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\RESULT_M5\Manual5\cellid' num2str(kin) '.png']);
    B=imresize(A,[D D]);    
    MAT(:,:,:,k)=B;    
    k=k+1;
end

W1=1;
W2=2;

MATA=uint16([]);
ND=1;
for kin=1:14:size(VAL,1)
    for ID=1:2:14
        
        A=MAT(:,:,:,kin-1+ID);
        
%         A(1:W1,:,:)=65535;
%         A(D-W1+1,:,:)=65535;
%         A(:,1:W1,:)=65535;
%         A(:,D-W1+1,:)=65535;       
        
        B=MAT(:,:,:,kin-1+ID+1);
        
%         B(1:W1,:,:)=65535;
%         B(D-W1+1,:,:)=65535;
%         B(:,1:W1,:)=65535;
%         B(:,D-W1+1,:)=65535;
        
        C=[A B];
        
        C(1:W2,:,:)=65535;
        C(D-W2+1:D,:,:)=65535;
        C(:,1:W2,:)=65535;
        C(:,2*D-W2+1:2*D,:)=65535;
        
    MATA((ND-1)*D+1:(ND-1)*D+D,(ID-1)*D+1:(ID-1)*D+2*D,1:3)=C;
    
    end
    
    ND=ND+1;
end

imwrite(MATA,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_example.png']);



% MATA=uint16([]);
% ND=1;
% for kin=1:14:size(VAL,1)
%     for ID=1:14
%     MATA((ND-1)*D+1:(ND-1)*D+D,(ID-1)*D+1:(ID-1)*D+D,1:3)=MAT(:,:,:,kin-1+ID);
%     
%     end
%     
%     ND=ND+1;
% end
% 
% imwrite(MATA,['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_example.png']);

close all
clc
diff=[];                            
k=1;
for kin=1:2:size(VAL,1)
    
    HS1=rgb2hsv(VAL(kin,1:3));
    HS1(1)=360*HS1(1);
    
    HS2=rgb2hsv(VAL(kin+1,1:3));
    HS2(1)=360*HS2(1);
    
    HS=HS1-HS2;
    
    if HS(1)>180
        HS(1)=360-HS(1);
    end
    diff(k,1:3)=HS;
    diff(k,4)=VAL(kin,11);
    k=k+1;
end  

diff=abs(diff);

DataArray=zeros(49,1);
DataArray(1:49,1)=diff(:,1);

    Colors=[0 0 0];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Hue difference'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.25 1.75])
ylim([0 10])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:1,...                         %# Change the axes tick marks
        'XTickLabel',{'Manual'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_HUE_diff_distribution'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_HUE_diff_distribution.pdf'], '-dpdf', '-r600');  

   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_HUE_diff_distribution' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:49,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,1)



DataArray=zeros(49,1);
DataArray(1:49,1)=diff(:,2);

    Colors=[0 0 0];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Saturation difference'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.25 1.75])
ylim([0 .5])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:1,...                         %# Change the axes tick marks
        'XTickLabel',{'Manual'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_SAT_diff_distribution'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_SAT_diff_distribution.pdf'], '-dpdf', '-r600');  


   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_SAT_diff_distribution' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:49,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,1)



DataArray=zeros(49,1);
DataArray(1:49,1)=diff(:,3);

    Colors=[0 0 0];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Value difference'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.25 1.75])
ylim([0 100])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:1,...                         %# Change the axes tick marks
        'XTickLabel',{'Manual'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_VALUE_diff_distribution'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_VALUE_diff_distribution.pdf'], '-dpdf', '-r600'); 

   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_VALUE_diff_distribution' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:49,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,1)


DataArray=zeros(49,1);
DataArray(1:49,1)=diff(:,4);

    Colors=[0 0 0];

figure
UnivarScatter(DataArray,'PointSize',20,'Width',.75,'MarkerFaceColor',Colors/1.25,'MarkerEdgeColor',Colors/1.5);
legend('boxoff')
ylabel(['Spatial distance'],'FontSize', 14,'FontName','times') % y-axis label

                                                set(gca, 'Ticklength', [0 0])
                                                ax = gca;
                                                grid off
                                                box off

xlim([0.25 1.75])
ylim([0 100])
pbaspect([4,6,1])
set(gcf,'color','w'); 
set(gca,'XTick',1:1,...                         %# Change the axes tick marks
        'XTickLabel',{'Manual'},'TickLength',[0 0],'FontSize', 20,'FontName','times');  %#   and tick labels

                                                a = get(gca,'XTickLabel');
                                                set(gca,'XTickLabel',a,'FontName','times','fontsize',10,'FontName','times');
                                                b = get(gca,'YTickLabel');
                                                set(gca,'YTickLabel',b,'FontName','times','fontsize',10,'FontName','times');

               ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping' , 'off');
                                                                                            set(gcf,'PaperPositionMode','auto')
                                                                    
export_fig(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_Spatial_distance_distribution'],'-a2', '-m6','-p0.02','-png', '-r600');

print(['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_Spatial_distance_distribution.pdf'], '-dpdf', '-r600');  

   resfile3 = ['F:\ENS_CILTEX\Marie_2016_NEW\Combined3\FINAL14\REPORTF\' 'MANUAL_Spatial_distance_distribution' '_data.xlsx'];
if exist(resfile3, 'file')==2
delete(resfile3);
end
MATN=DataArray(1:49,1);
B = cell(size(MATN,1),size(MATN,2));
for ii=1:size(MATN,1)
for jj=1:size(MATN,2)
B(ii,jj) = {MATN(ii,jj)};
end
end
xlswrite(resfile3,B,1)
