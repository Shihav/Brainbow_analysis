clear all
close all

clc

%% this is to use when foxj1 segmentation is not good

zres=[.52 .36 .36 0 .36 0 .47 .47];

slice=ceil(25./zres)+1

for idx=[8]

loadaddress;

% mkdir(Reshome3);

d=dir(fullfile(Datahome,'*.tif*'));
Types={d.name}; 

for imgid=1:numel(Types)
       
     filename=Types{imgid};
     filename2=strrep(filename,'.tif','');     
        oriname=[Datahome filesep filename2 '.tif'];
%          mkdir([[Reshome2 filesep filename2]]);
     segname=[Reshome filesep filename2 '4-Watershed.tif'];
     
% load([Reshome2 filesep filename2 filesep filename2 'ImgG.mat'],'ImgG'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgR.mat'],'ImgR'); 
% load([Reshome2 filesep filename2 filesep filename2 'ImgB.mat'],'ImgB');  
% 
% zmap=imread([Reshome2 filesep filename2 filesep filename2 'ZMAP.png'])/256;
%      
%       [~,~,stackR]=FV1_make_projection_from_layer2(ImgR,zmap,25,slice(idx));
%       [~,~,stackG]=FV1_make_projection_from_layer2(ImgG,zmap,25,slice(idx));
%       [~,~,stackB]=FV1_make_projection_from_layer2(ImgB,zmap,25,slice(idx));
%       
%       save([Reshome2 filesep filename2 filesep filename2 'stackR2.mat'],'stackR','-v7.3'); 
%       save([Reshome2 filesep filename2 filesep filename2 'stackG2.mat'],'stackG','-v7.3');  
%       save([Reshome2 filesep filename2 filesep filename2 'stackB2.mat'],'stackB','-v7.3');  
%       
%       load([Reshome2 filesep filename2 filesep filename2 'stackR2.mat'],'stackR'); 
%       load([Reshome2 filesep filename2 filesep filename2 'stackG2.mat'],'stackG');  
%       load([Reshome2 filesep filename2 filesep filename2 'stackB2.mat'],'stackB');  
%             
%       [Img11r,zval11r]=max(stackR,[],3);
%       [Img11g,zval11g]=max(stackG,[],3);
%       [Img11b,zval11b]=max(stackB,[],3); 
%       
%       CO=uint16(cat(3,Img11r,Img11g,Img11b));
%       C=CO;
%       
%       imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NOverlayM11.png']);
      C=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM11.png']);
      
if idx>7
CP=imread([Reshome2 filesep filename2 filesep filename2 'POverlayM1.png']);
LABELM2=color_seg2(CP);
else
LABELM2=imread([Reshome2 filesep filename2 filesep filename2 'FinalmapM.png']);
end

LABELM=imdilate(LABELM2,ones(8,8));

                          for ind=1:3
                          col_img2a=C(:,:,ind);
                          col_img2a(LABELM>0)=0;     
                          C(:,:,ind)=col_img2a;
                          end 
% imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NegC3.png']); 

imwrite(uint16(C),[Reshome2 filesep filename2 filesep filename2 'NOverlayM12.png']); 
C=imread([Reshome2 filesep filename2 filesep filename2 'NOverlayM12.png']);

LABELM2=color_seg8(C);

                          for ind=1:3
                          col_img2a=C(:,:,ind);
                          col_img2a(LABELM2==0)=0;     
                          C(:,:,ind)=col_img2a;
                          end 
                          
LABELM2=color_seg9(C);

classmap5=LABELM2;
figure,imshow(label2rgb(classmap5,'jet','k','shuffle'));
LABELM=classmap5;
LABELM=imerode(LABELM,ones(3,3));

pcells=unique(LABELM);
objectbor_map=zeros(size(LABELM));
se=ones(3);
         for nk=2:length(pcells)            
            val=pcells(nk); 

                              object = LABELM == val;
                              objectcore=imdilate(object, se);
                              objectbor=(objectcore-object)>0;
                       objectbor_map(objectbor)=1;
                             
         end
   LCOLOR5=C;                                    
mult=[1 1 1];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
                          col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end   

imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'NOverlayM2.png']);  
imwrite(uint16(LABELM),[Reshome2 filesep filename2 filesep filename2 'NFinalmapM.png']);

   LCOLOR5=C;                                    
mult=[1 1 1];
                          for ind=1:3
                          col_img2a=mult(ind)*LCOLOR5(:,:,ind);
                          col_img2a(LABELM==0)=0;  
%                           col_img2a(objectbor_map==1)=65535;    
                          Compb(:,:,ind)=col_img2a;
                          end  
imwrite(uint16(Compb),[Reshome2 filesep filename2 filesep filename2 'NOverlayM3.png']); 

idx
imgid


close all
% clc
end

end