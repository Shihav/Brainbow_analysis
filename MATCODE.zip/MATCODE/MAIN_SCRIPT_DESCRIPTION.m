%% script descriptions


% D49. D50 - prcoess with Dapi
% D51, D52 - process with FOXJ1
% D29 - adjust postive and negative map

% make distance map

% 19 - previous way of analyzing with plots

% 36_C - Analyzing with new method
% 39, 40 - used for manual corrections
% 41_A - make figure for paper (cropped)
% 46 - make figure for all dataset
% 42_A - calculate doublets, triplets and quaraplets
% 43, 44, 45 - make individual doublets, triplets and quadruplets plot
% 47, 48 - make final plots